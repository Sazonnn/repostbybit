import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import type { Context } from "grammy";

test("connection mode changes only when a usable session exists and work is idle", async () => {
  const dir = mkdtempSync(join(tmpdir(), "bybit-connection-mode-"));
  process.env.SQLITE_PATH = join(dir, "bot.db");
  process.env.API_CREDENTIALS_KEY_PATH = join(dir, "api-key");
  process.env.TELEGRAM_BOT_TOKEN = "test:token";
  const { runMigrations } = await import("../db/migrate.js");
  const { db } = await import("../db/pool.js");
  const { ensureSettings, updateSettings } = await import("../db/repositories/userSettings.js");
  const { saveWorkingAd } = await import("../db/repositories/workingAds.js");
  const { saveApiAccount } = await import("../db/repositories/apiAccounts.js");
  const { authService } = await import("../auth/authService.js");
  const { handleConnectionShow, handleConnectionCallback } = await import("./connectionHandlers.js");
  const chatId = 123456789;
  const replies: string[] = [];
  const ctx = (data?: string) => ({
    chat: { id: chatId },
    callbackQuery: data ? { data } : undefined,
    answerCallbackQuery: async () => {},
    reply: async (message: string) => { replies.push(message); },
  }) as unknown as Context;

  try {
    await runMigrations();
    await handleConnectionShow(ctx());
    assert.equal((await ensureSettings(chatId)).connection_mode, "api");

    await handleConnectionCallback(ctx("c:mode:session"));
    assert.equal((await ensureSettings(chatId)).connection_mode, "api");

    await authService.save({
      bybitUid: "42", cookie: "test-cookie", riskToken: "test-risk",
      guid: "test-guid", userAgent: "test-agent",
      expiresAt: new Date(Date.now() + 60_000),
    });
    await handleConnectionCallback(ctx("c:mode:session"));
    assert.equal((await ensureSettings(chatId)).connection_mode, "session");
    await handleConnectionShow(ctx());
    assert.equal((await ensureSettings(chatId)).connection_mode, "session");

    await handleConnectionCallback(ctx("c:mode:api"));
    assert.equal((await ensureSettings(chatId)).connection_mode, "session");

    await saveApiAccount({ chatId, name: "Test", apiKey: "test-api-key", apiSecret: "test-api-secret" });
    await handleConnectionCallback(ctx("c:mode:api"));
    assert.equal((await ensureSettings(chatId)).connection_mode, "api");
    await handleConnectionCallback(ctx("c:mode:session"));
    assert.equal((await ensureSettings(chatId)).connection_mode, "session");

    await updateSettings(chatId, { workingAdsEnabled: true });
    await saveWorkingAd({
      chatId, itemId: "1111111111111111111", tokenId: "USDT", currencyId: "RUB",
      side: "0", priceType: "0", lastPrice: "90.00",
    });
    await handleConnectionCallback(ctx("c:mode:api"));
    assert.match(replies.at(-1) ?? "", /Сначала останови/);
    assert.equal((await ensureSettings(chatId)).connection_mode, "session");
  } finally {
    db.close();
    rmSync(dir, { recursive: true, force: true });
  }
});
