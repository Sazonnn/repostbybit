import { Bot } from "grammy";
import { config } from "../config.js";
import { CycleRunner } from "../services/cycleRunner.js";
import { SessionWatcher } from "../services/sessionWatcher.js";
import { WorkingAdsManager } from "../services/workingAdsManager.js";
import { buildHandlers } from "./handlers.js";
import {
  consumePendingInput,
  handleCancelInput,
  handleSettingsCallback,
  handleSettingsShow,
} from "./settingsHandlers.js";
import {
  cancelApiAccountInput,
  consumeApiAccountInput,
  handleConnectionCallback,
  handleConnectionShow,
} from "./connectionHandlers.js";
import { buildWorkingAdsHandlers } from "./workingAdsHandlers.js";
import type { WorkingAdEvent } from "../web/telemetry.js";

export function buildBot(observe?: (event: WorkingAdEvent) => void): {
  bot: Bot;
  runner: CycleRunner;
  sessionWatcher: SessionWatcher;
  workingAdsManager: WorkingAdsManager;
} {
  const bot = new Bot(config.telegram.botToken);

  const notify = async (chatId: number, text: string) => {
    try {
      await bot.api.sendMessage(chatId, text, { parse_mode: "HTML" });
    } catch (err) {
      console.error(`Failed to notify ${chatId}:`, err);
    }
  };

  const runner = new CycleRunner(notify);
  const workingAdsManager = new WorkingAdsManager(notify, observe);
  const workingAdsHandlers = buildWorkingAdsHandlers(workingAdsManager);

  const sessionWatcher = new SessionWatcher(async (text) => {
    // Шлём первому из allowlist кто реально открыл чат с ботом.
    for (const id of config.telegram.allowedUserIds) {
      try {
        await bot.api.sendMessage(id, text, { parse_mode: "HTML" });
        return;
      } catch {
        // chat not found / user blocked / etc — пробуем следующего
      }
    }
    console.warn(`Никому из allowlist не удалось доставить: ${text}`);
  });

  const handlers = buildHandlers({ runner });

  const allowed = config.telegram.allowedUserIds;
  bot.use(async (ctx, next) => {
    if (allowed.length === 0) return next();
    const id = ctx.from?.id;
    if (id && allowed.includes(id)) return next();
    await ctx.reply("⛔️ Доступ запрещён.");
  });

  bot.command("start", handlers.handleStart);
  bot.command("stop", handlers.handleStopCycle);
  bot.command("status", handlers.handleStatus);
  bot.command("connection", handleConnectionShow);
  bot.command("auth_status", handlers.handleAuthStatus);
  bot.command("auth_refresh", handlers.handleAuthRefresh);
  bot.command("settings", handleSettingsShow);
  bot.command("work_ads", async (ctx) => {
    await workingAdsHandlers.show(ctx);
  });
  bot.command("stack", handlers.handleStack);
  bot.command("cancel", async (ctx) => {
    const id = ctx.chat?.id;
    if (id && cancelApiAccountInput(id)) {
      await ctx.reply("Добавление API-аккаунта отменено.");
      return;
    }
    if (id && workingAdsHandlers.cancelInput(id)) {
      await ctx.reply("Добавление объявления отменено.");
      return;
    }
    await handleCancelInput(ctx);
  });

  // Если у юзера есть pending input — съедаем текстовое сообщение как значение
  bot.on("message:text", async (ctx, next) => {
    const apiConsumed = await consumeApiAccountInput(ctx);
    if (apiConsumed) return;
    const workingAdConsumed = await workingAdsHandlers.consumeInput(ctx);
    if (workingAdConsumed) return;
    const consumed = await consumePendingInput(ctx);
    if (!consumed) return next();
  });

  bot.callbackQuery(/^(s|sm|p|dp):/, handleSettingsCallback);
  bot.callbackQuery(/^c:/, handleConnectionCallback);
  bot.callbackQuery(/^wa:/, workingAdsHandlers.callback);

  bot.callbackQuery("stop_cycle", async (ctx) => {
    await ctx.answerCallbackQuery();
    await handlers.handleStopCycle(ctx);
  });
  bot.callbackQuery("status", async (ctx) => {
    await ctx.answerCallbackQuery();
    await handlers.handleStatus(ctx);
  });
  bot.callbackQuery("stack_open", async (ctx) => {
    await ctx.answerCallbackQuery();
    await handlers.handleStack(ctx);
  });
  bot.callbackQuery("menu_open", async (ctx) => {
    await ctx.answerCallbackQuery();
    await handlers.handleStart(ctx);
  });
  bot.callbackQuery("settings_open", async (ctx) => {
    await ctx.answerCallbackQuery();
    await handleSettingsShow(ctx);
  });
  bot.callbackQuery("connection_open", async (ctx) => {
    await ctx.answerCallbackQuery();
    await handleConnectionShow(ctx);
  });
  bot.callbackQuery("working_ads_open", async (ctx) => {
    await ctx.answerCallbackQuery();
    await workingAdsHandlers.show(ctx);
  });

  bot.catch((err) => console.error("Bot error:", err));

  return { bot, runner, sessionWatcher, workingAdsManager };
}
