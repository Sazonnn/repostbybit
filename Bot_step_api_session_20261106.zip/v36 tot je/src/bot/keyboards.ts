import { InlineKeyboard } from "grammy";

// Одно главное меню: объявления, настройки и подключение Bybit.
export const mainKeyboard = new InlineKeyboard()
  .text("💼 Мои объявления", "working_ads_open")
  .row()
  .text("⚙️ Параметры", "settings_open")
  .text("🔗 Подключение", "connection_open");

// Старые имена оставлены, чтобы не ломать импорты: все показывают одно меню.
export const idleKeyboard = mainKeyboard;
export const manualKeyboard = mainKeyboard;
export const runningKeyboard = mainKeyboard;
export const monitoringKeyboard = mainKeyboard;
