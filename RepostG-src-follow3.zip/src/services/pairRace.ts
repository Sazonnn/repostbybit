/**
 * Чехарда двух объявлений для поиска потолка.
 *
 * Объявления по очереди перепрыгивают друг друга на копейку: одно стоит на
 * последней ПРОВЕРЕННОЙ допустимой цене ("держатель"), второе ставит на
 * копейку выше ("проба"). Проба прошла — роли меняются: проба становится
 * держателем, а бывший держатель прыгает ещё на копейку выше. Проба не прошла —
 * потолок найден, оба встают на него.
 *
 * Для floating-объявления бот опирается не на цену, которую он поставил, а на
 * ту, которую Bybit реально применил (и показывает в стакане): из-за пересчёта
 * по эталону она может отличаться на копейку. Следующий прыжок идёт от
 * реальной цены, поэтому выше потолка пара не встаёт.
 *
 * Цена допустима, если объявление с этой ценой видно в стакане, или если у
 * кого-то из конкурентов на видимых страницах цена такая же или лучше.
 * Недопустима, если объявления нет в стакане, а его цена лучше всех видимых.
 *
 * Защита по месту (идея из бота друга): если якорь и проба оба видны в
 * первых 50, а проба стоит в выдаче НИЖЕ якоря — шаг вверх ухудшил место.
 * Это тоже потолок: лучшая цена — у якоря. Цели "топ-N" нет: пара идёт до
 * потолка, чтобы занять его первой.
 *
 * Конкурент перебил (топ-1 выше проверенной цены): прыгает отстающее
 * объявление — сразу на топ-1 + копейка. Второе стоит на месте. Одно изменение
 * на каждый ход конкурента, без промежуточной постановки "вровень с топ-1".
 *
 * Лимит Bybit — 4 изменения за 5 с на аккаунт. Держатель (объявление, которое
 * должно стоять на потолке / топ-1) может потратить любой слот. Проба и
 * возврат второго объявления после остановки — только если после них
 * останется хотя бы 1 слот: он всегда в запасе для держателя.
 *
 * Модуль — чистая логика без запросов: его кормят снимками стакана (onScan)
 * и фактами применения цены (onApplied), а он говорит, какую цену поставить
 * каждому объявлению (target).
 */

export type Side = "0" | "1";

export interface PairScan {
  at: number;
  top1: number | null;
  best: number | null;
  // itemId -> цена, с которой объявление видно в стакане, или null (не видно).
  hits: Map<string, number | null>;
  // itemId -> место в первых 50 (1 — самый верх), или null (не видно).
  ranks?: Map<string, number | null>;
  // С какого IP прочитан этот стакан (для защиты от устаревших снимков).
  source?: string;
}

export interface PairOptions {
  side: Side;
  step: number;
  min: number;
  max: number;
  floating: Set<string>;
  log?: (message: string) => void;
  // Этот IP прислал устаревший снимок (возврат топ-1 не подтвердился).
  onStaleSource?: (source: string, reason: string) => void;
  // Сколько изменений цены ещё можно сделать без отказа 10006 (по аккаунту).
  updatesLeft?: () => number;
}

function envMs(name: string, fallback: number, min: number, max: number): number {
  const value = Number(process.env[name]);
  return process.env[name] !== undefined && process.env[name] !== "" && Number.isFinite(value) &&
    value >= min && value <= max ? Math.round(value) : fallback;
}

// Первые столько мс гонки: если рынок поднялся на копейку выше нас, отстающее
// объявление встаёт ровно на топ-1, а не прыгает сразу выше него. Можно
// поменять в .env: MATCH_TOP_EARLY_MS=10000 (0 — выключить, до 60000).
const MATCH_TOP_EARLY_MS = envMs("MATCH_TOP_EARLY_MS", 10_000, 0, 60_000);

// Первое изменение при смене курса: 0 — ровно на топ-1 (как раньше), 1 — сразу
// на копейку выше топ-1. Значения выше 1 не поддерживаются (считаются как 1).
// В .env: FIRST_JUMP_STEPS=1
const FIRST_JUMP_STEPS = Number(process.env.FIRST_JUMP_STEPS) >= 1 ? 1 : 0;
// Страховка для FIRST_JUMP_STEPS=1: пока первое объявление проверяет топ-1 +
// шаг, второе не ждёт, а сразу после ответа Bybit встаёт ровно на топ-1. Если
// копейка выше окажется выше потолка — второе уже стоит на потолке (а не
// приходит на него через ~1,3 с после проверки). Если допустима — второе
// прыгает с топ-1 ещё выше, обычная чехарда.
// В .env: FIRST_JUMP_HEDGE=1 (по умолчанию 0 — выключено, второе ждёт проверки).
const FIRST_JUMP_HEDGE = process.env.FIRST_JUMP_HEDGE === "1";
// То же правило "топ-1 + копейка", но когда рынок поднялся выше нас УЖЕ ВО
// ВРЕМЯ гонки: одно объявление сразу прыгает на новый топ-1 + шаг, второе
// встаёт ровно на новый топ-1 (после ответа Bybit, если FIRST_JUMP_HEDGE=1,
// иначе ждёт проверки). Выгодно, когда потолок на копейку выше нового топ-1
// (лог 02.10 14:30: рынок 89.35, потолок 89.36 — конкуренты прыгнули сразу и
// встали на 0,3–0,8 с раньше). Невыгодно, когда новый топ-1 и есть потолок:
// прыжок скрыт и возвращается через ~1,5 с.
// В .env: RISE_JUMP_STEPS=1 (по умолчанию 0 — сначала вровень с топ-1).
const RISE_JUMP_STEPS = Number(process.env.RISE_JUMP_STEPS) >= 1 ? 1 : 0;
// Режим "за рынком" (как у конкурентов): чехарды нет, роли закреплены.
//  - "прыгун" (PAIR_FIRST, по умолчанию fixed) встаёт на топ-1 + шаг каждый раз,
//    когда чужой топ-1 оказался выше его цены;
//  - второе объявление встаёт ровно на топ-1 (страховка) и выше не ходит;
//  - выше СВОЕЙ цены никто не пробует: если чужие пришли на цену прыгуна —
//    стоим и ждём, пока рынок поднимет топ;
//  - прыжок не появился в стакане (выше потолка) — прыгун возвращается на
//    топ-1, где уже стоит страховка.
// Так у floating нет проб, и слот Bybit свободен для прыжка fixed (лог 02.10
// 17:27: проба floating на 88.08 за 0,6 с до прыжка fixed на 88.11 — отказ).
// В .env: FOLLOW_MARKET=1 (по умолчанию 0 — чехарда как раньше).
const FOLLOW_MARKET = process.env.FOLLOW_MARKET === "1";
// Через сколько мс тишины подтянуть страховку на цену прыгуна (0 — не подтягивать).
const FOLLOW_PULL_MS = envMs("FOLLOW_PULL_MS", 2_000, 0, 60_000);
// Режим "за рынком": страховка (второе объявление на топ-1) уходит
// ОДНОВРЕМЕННО с прыжком, а не после ответа Bybit на него. Так делают
// конкуренты: их fixed и floating появляются на новых ценах в одном снимке
// (лог 02.10 19:26), и при промахе их floating встаёт на потолок раньше
// (лог 02.10 21:27: code1n3 18-е место, наше floating 27-е — ушло на 0,5 с
// позже). Риск: два запроса сразу — Bybit может отклонить прыжок.
// В .env: FOLLOW_HEDGE_PARALLEL=1 (по умолчанию 0 — страховка после ответа).
const FOLLOW_HEDGE_PARALLEL = process.env.FOLLOW_HEDGE_PARALLEL === "1";
console.log(`[pair] первый ход: ${FIRST_JUMP_STEPS >= 1 ? "сразу на топ-1 + шаг" : "ровно на топ-1"} ` +
  `(FIRST_JUMP_STEPS=${FIRST_JUMP_STEPS})` +
  (FIRST_JUMP_STEPS >= 1 ? `, второе ${FIRST_JUMP_HEDGE ? "сразу встаёт на топ-1" : "ждёт проверки"} (FIRST_JUMP_HEDGE=${FIRST_JUMP_HEDGE ? 1 : 0})` : "") +
  `, при подъёме рынка в гонке: ${RISE_JUMP_STEPS >= 1 ? "сразу топ-1 + шаг" : "сначала вровень с топ-1"} (RISE_JUMP_STEPS=${RISE_JUMP_STEPS})` +
  (FOLLOW_MARKET ? `, РЕЖИМ "ЗА РЫНКОМ" (FOLLOW_MARKET=1): прыгун = топ-1 + шаг, второе = топ-1, выше своей цены не пробуем, ` +
    `подтягивание второго через ${FOLLOW_PULL_MS} мс (FOLLOW_PULL_MS), ` +
    `страховка ${FOLLOW_HEDGE_PARALLEL ? "одновременно с прыжком" : "после ответа на прыжок"} (FOLLOW_HEDGE_PARALLEL=${FOLLOW_HEDGE_PARALLEL ? 1 : 0})` : "") +
  `, первым идёт ${process.env.PAIR_FIRST === "floating" ? "floating" : "fixed"} (PAIR_FIRST), ` +
  `пробует ${process.env.FIXED_NO_PROBE === "1" ? "только floating" : "любое"} (FIXED_NO_PROBE)`);

// .env: FIXED_NO_PROBE=1 — пробует копейку выше только floating; fixed встаёт
// на топ-1 и в конце гонки на найденный потолок (по умолчанию 0 — пробуют оба
// по очереди).
const FIXED_NO_PROBE = process.env.FIXED_NO_PROBE === "1";

// Проба после отказа держателю ждёт, пока новый держатель встанет, но не дольше.
const PROBE_AFTER_REJECT_MAX_MS = 3_000;

const MAX_PROBES = 12;
// Проверке стакана верим, только если она начата не раньше чем через
// CONFIRM_MS после того, как цена применилась.
// .env: PROBE_CONFIRM_MS (0..2000).
const CONFIRM_MS = envMs("PROBE_CONFIRM_MS", 100, 0, 2_000);
// Стакан Bybit показывает новую цену с опозданием ~1–1,5 с. Если объявления в
// стакане нет совсем, считать пробу "выше потолка" можно только после этого.
// Было 1,5 с. Можно поменять в .env: PROBE_INVISIBLE_MS=1000 (от 300 до 5000).
const INVISIBLE_CONFIRM_MS = envMs("PROBE_INVISIBLE_MS", 1_000, 300, 5_000);
// Сколько проверок подряд объявление должно отсутствовать в стакане (одна
// проверка может "не показать" его из-за перестановки в рейтинге).
const INVISIBLE_SCANS = 2;
// Сколько проверок подряд проба должна стоять ниже якоря, чтобы считать, что
// шаг вверх ухудшил место (одна проверка может ошибиться из-за перестановок).
const WORSE_RANK_SCANS = 2;
// Если стакан всё ещё показывает объявление по старой цене дольше этого —
// считаем пробу не прошедшей (держатель остаётся на проверенной цене).
// Было 3 с. Можно поменять в .env: PROBE_STALE_MAX_MS=2000 (от 500 до 10000).
const STALE_MAX_MS = envMs("PROBE_STALE_MAX_MS", 2_000, 500, 10_000);
console.log(`[pair] проба: "выше потолка" через ${INVISIBLE_CONFIRM_MS} мс (PROBE_INVISIBLE_MS), ` +
  `старая цена в стакане — не дольше ${STALE_MAX_MS} мс (PROBE_STALE_MAX_MS)`);
// Похоже, Bybit обрабатывает изменения одного аккаунта по очереди: если проба
// уходит одновременно с топ-1, изменение топ-1 ждёт её в очереди (~1,2 с вместо
// ~0,5). Поэтому при старте проба уходит только после ответа Bybit на топ-1 —
// но не позже чем через столько мс, если ответа всё нет.
// .env: PROBE_RELEASE_MAX_MS (0..10000). 0 — проба уходит сразу, не дожидаясь
// ответа Bybit на топ-1 (оба изменения почти одновременно).
const PROBE_RELEASE_MAX_MS = envMs("PROBE_RELEASE_MAX_MS", 3_000, 0, 10_000);
const RACE_TIMEOUT_MS = 30_000;
// Если топ-1 "вернулся" к прошлому значению в течение этого времени после
// смены — это, скорее всего, устаревший снимок стакана: нужно подтверждение.
// .env: REVERT_WINDOW_MS (0..60000; 0 — не считать возврат топ-1 подозрительным).
const REVERT_WINDOW_MS = envMs("REVERT_WINDOW_MS", 10_000, 0, 60_000);
// Если IP один: сколько чтений подряд должны показать возврат топ-1.
const REVERT_SAME_SOURCE_SCANS = 3;
// Сколько ДРУГИХ IP должны подтвердить возврат топ-1 к прошлому значению.
// .env: REVERT_CONFIRMATIONS (1..4, по умолчанию 2). Каждое подтверждение —
// срочное чтение стакана (~50–80 мс), и только когда пришёл такой снимок.
export const REVERT_CONFIRMATIONS = (() => {
  const value = Number(process.env.REVERT_CONFIRMATIONS);
  return process.env.REVERT_CONFIRMATIONS && Number.isInteger(value) && value >= 1 && value <= 4 ? value : 2;
})();
// Сторож "держатель выше потолка": столько проверок подряд, и не раньше чем
// через столько мс после последнего изменения цены (стакан Bybit запаздывает).
const ABOVE_CEILING_SCANS = 3;
// .env: ABOVE_CEILING_GRACE_MS (0..30000).
const ABOVE_CEILING_GRACE_MS = envMs("ABOVE_CEILING_GRACE_MS", 3_000, 0, 30_000);
// Не меняем роли на объявление, которое само получило отказ недавно.
// .env: REJECT_SWAP_BLOCK_MS (0..60000).
const REJECT_SWAP_BLOCK_MS = envMs("REJECT_SWAP_BLOCK_MS", 5_000, 0, 60_000);
console.log(`[pair] задержки (.env): PROBE_CONFIRM_MS=${CONFIRM_MS}, PROBE_RELEASE_MAX_MS=${PROBE_RELEASE_MAX_MS}, ` +
  `REVERT_WINDOW_MS=${REVERT_WINDOW_MS}, ABOVE_CEILING_GRACE_MS=${ABOVE_CEILING_GRACE_MS}, ` +
  `REJECT_SWAP_BLOCK_MS=${REJECT_SWAP_BLOCK_MS}`);
const EPS = 0.005;
// Floating-цена в стакане может отличаться на копейку от применённой.
const FLOATING_TOLERANCE = 0.011;
// Сколько мс после ответа Bybit считаем, что объявление стоит на подтверждённой
// цене, даже если стакан его ещё не показал (потом верим только стакану).
const CONFIRMED_STANDING_MS = 5_000;
// Сколько слотов лимита держим в запасе для держателя: проба и возврат
// второго объявления уходят, только если после них останется столько.
const RESERVE_UPDATES = 1;

const round2 = (value: number) => Math.round(value * 100) / 100;

interface Applied {
  price: number;
  at: number;
  // Для какой цели было это изменение (чтобы не переставлять floating
  // заново, если Bybit применил цену с отличием в копейку).
  forTarget: number | undefined;
}

export class PairRace {
  readonly a: string;
  readonly b: string;
  private options: PairOptions;
  private mode: "idle" | "race" | "settled" = "idle";
  private low: number | null = null;
  // Цена, про которую уже известно, что она выше потолка, — туда не прыгаем.
  private high: number | null = null;
  private holder: string;
  private prober: string;
  private probeTarget: number | null = null;
  // Проба, которая уйдёт сразу после ответа Bybit на изменение топ-1.
  private pendingProbe: number | null = null;
  private readonly targets = new Map<string, number>();
  // Когда пара решила поставить объявлению текущую цель (для лога задержек).
  private readonly targetSetAt = new Map<string, number>();
  private readonly applied = new Map<string, Applied>();
  private readonly current = new Map<string, number>();
  private raceStartedAt = 0;
  private probes = 0;
  private lastActivityAt = 0;
  private probeSetAt = 0;
  private invisibleScans = 0;
  private worseRankScans = 0;
  // Топ-1, при котором пара встала на потолок. Пока он не изменился, пара
  // стоит на месте и ничего не пересчитывает.
  private settleTop: number | null = null;
  private lastTop1: number | null = null;
  // Топ-1 до последней смены и когда она была (защита от устаревших снимков).
  private prevTop: number | null = null;
  private topChangedAt = 0;
  private revertScans = 0;
  private readonly revertSources = new Set<string | null>();
  private lastScanAccepted = false;
  private readonly scanWaiters: Array<() => void> = [];
  // Когда проба стала ждать ответа Bybit по держателю.
  private pendingProbeSince = 0;
  private aboveScans = 0;
  // Когда объявление последний раз получило отказ Bybit по лимиту.
  private readonly rejectedAt = new Map<string, number>();
  // Для лога "ждёт лимит": по какой цели уже написали.
  private readonly budgetLogged = new Map<string, number>();

  constructor(a: string, b: string, options: PairOptions) {
    this.a = a;
    this.b = b;
    this.options = options;
    this.holder = a;
    this.prober = b;
  }

  configure(options: PairOptions): void {
    this.options = options;
  }

  get state(): "idle" | "race" | "settled" {
    return this.mode;
  }

  /** Идёт гонка или объявления недавно меняли цену. */
  isActive(now: number): boolean {
    return this.mode === "race" || now - this.lastActivityAt < 15_000;
  }

  /** Объявление сейчас пробует цену — боту нужна его реальная цена после изменения. */
  isProber(itemId: string): boolean {
    return this.mode === "race" && this.prober === itemId;
  }

  /** Актуальная цена объявления (из чтения объявления). */
  onCurrentPrice(itemId: string, price: number, at: number): void {
    this.current.set(itemId, price);
    const target = this.targets.get(itemId);
    const applied = this.applied.get(itemId);
    if (target !== undefined && Math.abs(price - target) < EPS && applied?.forTarget !== target) {
      // Уже стоит на нужной цене — считаем применённой.
      this.applied.set(itemId, { price, at, forTarget: target });
      if (itemId === this.holder) this.releaseProbe(at, "топ-1 уже стоит");
    }
  }

  /**
   * Bybit отказал объявлению по лимиту (10006). Если это держатель, который
   * ещё не встал на свою цель, — роли меняются: на цель сразу идёт второе
   * объявление, а отказанное ждёт и потом пробует выше. Возвращает true, если
   * роли поменялись (второму объявлению нужно сразу отправить изменение).
   */
  onRejected(itemId: string, at: number): boolean {
    this.rejectedAt.set(itemId, at);
    if (this.mode === "race" && this.hedgeActive) {
      // Первый ход со страховкой: роли не меняем, каждое объявление повторяет
      // свою цель. Страховку при отказе прыжка НЕ отпускаем: Bybit принимает
      // примерно одно изменение в секунду на аккаунт, и страховка заняла бы
      // этот слот раньше прыжка (лог 02.10 13:26: floating ушёл на 89.57 после
      // отказа прыжка, из-за этого fixed получил ещё два отказа и встал на
      // потолок 89.58 на ~1 с позже). Страховка уйдёт после ответа на прыжок
      // или по таймауту PROBE_RELEASE_MAX_MS.
      return false;
    }
    if (this.mode !== "race" || itemId !== this.holder) return false;
    const target = this.targets.get(this.holder);
    if (target === undefined || this.applied.get(this.holder)?.forTarget === target) return false;
    const other = this.prober;
    // Второе тоже недавно получило отказ — менять бессмысленно.
    const otherRejectedAt = this.rejectedAt.get(other);
    if (otherRejectedAt !== undefined && at - otherRejectedAt < REJECT_SWAP_BLOCK_MS) return false;
    // Проба уже встала выше — не тянем её вниз, держатель просто повторит.
    const probeApplied = this.probeTarget !== null && this.applied.get(other)?.forTarget === this.probeTarget;
    if (probeApplied) return false;
    this.holder = other;
    this.prober = itemId;
    this.setTarget(this.holder, target);
    this.targets.delete(this.prober);
    this.probeTarget = null;
    if (FIXED_NO_PROBE && !this.isFloating(itemId) && this.isFloating(other)) {
      // Fixed выше не пробует: на топ-1 сразу идёт floating, а fixed повторяет
      // ту же цену. Когда fixed встанет — роли вернутся, и пробовать выше
      // пойдёт floating (см. onApplied).
      this.setTarget(itemId, target);
      this.pendingProbe = null;
      this.log(`${this.short(itemId)} получил отказ Bybit — на ${target.toFixed(2)} сразу идёт ${this.short(other)}, ` +
        `${this.short(itemId)} повторит ${target.toFixed(2)} (FIXED_NO_PROBE)`);
      return true;
    }
    const probe = this.clamp(this.up(target));
    this.pendingProbe = this.better(probe, target) && (this.high === null || this.better(this.high, probe))
      ? probe : null;
    this.pendingProbeSince = at;
    this.probeAfterHolder = true;
    this.log(`${this.short(itemId)} получил отказ Bybit — на ${target.toFixed(2)} сразу идёт ${this.short(other)}, ` +
      `${this.short(itemId)} попробует выше после паузы`);
    // Второе уже стоит на цели — проба может уйти.
    if (this.applied.get(this.holder)?.forTarget === target) this.releaseProbe(at, "топ-1 уже стоит");
    return true;
  }

  /** Bybit подтвердил изменение цены (price — реально применённая цена). */
  onApplied(itemId: string, price: number, at: number): void {
    // Ответ мог прийти на СТАРЫЙ запрос (цель за это время сменилась). Тогда
    // это не применение текущей цели: иначе бот считает, что объявление уже
    // "встало" на новую цель, и роли гоняются по кругу без единого запроса
    // (лог 01.10 12:26: 12 "прыжков" за мгновение, стоп "предел прыжков").
    const currentTarget = this.targets.get(itemId);
    const tolerance = this.isFloating(itemId) ? FLOATING_TOLERANCE : EPS;
    const forTarget = currentTarget !== undefined && Math.abs(price - currentTarget) < tolerance
      ? currentTarget : undefined;
    this.applied.set(itemId, { price, at, forTarget });
    this.current.set(itemId, price);
    this.lastActivityAt = at;
    // FIXED_NO_PROBE: fixed после отказа встал на ту же цену, что держит
    // floating, — возвращаем роли: fixed держит, floating пробует выше.
    if (FIXED_NO_PROBE && this.mode === "race" && itemId === this.prober && !this.isFloating(itemId) &&
        this.isFloating(this.holder) && this.probeTarget === null && this.pendingProbe === null &&
        this.low !== null && Math.abs(price - this.low) < EPS) {
      this.prober = this.holder;
      this.holder = itemId;
      const next = this.clamp(this.up(this.low));
      if (this.better(next, this.low) && (this.high === null || this.better(this.high, next)) &&
          this.probes < MAX_PROBES) {
        this.setProbe(next, at);
        this.log(`${this.short(itemId)} встал на ${this.low.toFixed(2)} — ${this.short(this.prober)} пробует ${next.toFixed(2)}`);
      }
      return;
    }
    // Страховку отпускаем только по ответу на ТЕКУЩИЙ прыжок. Ответ на прошлую
    // цену (рынок успел подняться, прыгуну назначена новая) не считается: прыгун
    // сейчас отправит новую цену, и страховка заняла бы его слот (лог 02.10
    // 19:26: ответ на 89.75 отпустил страховку, пока fixed шёл на 89.80 —
    // отказ fixed и три отказа floating).
    if (itemId === this.prober && forTarget !== undefined && forTarget === this.probeTarget) {
      this.releaseHold(at, "Bybit ответил на прыжок");
    }
    if (itemId === this.holder) this.releaseProbe(at, "Bybit ответил на топ-1");
  }

  /**
   * Какую цену поставить объявлению. null — менять не нужно: изменение под
   * эту цель уже применено (даже если floating встал на копейку в сторону).
   */
  target(itemId: string): string | null {
    const target = this.targets.get(itemId);
    if (target === undefined) return null;
    if (this.applied.get(itemId)?.forTarget === target) return null;
    if (itemId !== this.holder && !this.hasSpareUpdate()) {
      // Проба / возврат второго объявления ждут, пока освободится слот лимита:
      // последний слот — только для держателя.
      if (this.budgetLogged.get(itemId) !== target) {
        this.budgetLogged.set(itemId, target);
        this.log(`${this.short(itemId)} ждёт лимит Bybit для ${target.toFixed(2)} (последний слот — для держателя)`);
      }
      return null;
    }
    return target.toFixed(2);
  }

  /** После изменения цены останется хотя бы RESERVE_UPDATES слотов лимита. */
  private hasSpareUpdate(): boolean {
    const left = this.options.updatesLeft?.();
    if (left === undefined || left > RESERVE_UPDATES) return true;
    // Держателю сейчас менять нечего (его цель уже поставлена) — последний
    // слот не держим впустую: пусть второе быстрее ищет/занимает потолок.
    return left > 0 && !this.holderPending();
  }

  /** У держателя есть цель, которую Bybit ещё не подтвердил. */
  private holderPending(): boolean {
    const target = this.targets.get(this.holder);
    return target !== undefined && this.applied.get(this.holder)?.forTarget !== target;
  }

  /** Когда пара поставила объявлению текущую цель (мс), или undefined. */
  targetSince(itemId: string): number | undefined {
    return this.targets.has(itemId) ? this.targetSetAt.get(itemId) : undefined;
  }

  /** Второе объявление пары. */
  other(itemId: string): string {
    return itemId === this.a ? this.b : this.a;
  }

  private setTarget(itemId: string, price: number): void {
    if (this.targets.get(itemId) !== price) this.targetSetAt.set(itemId, Date.now());
    this.targets.set(itemId, price);
  }

  /** Проба ещё применяется — читать стакан бесполезно. */
  shouldHoldScan(now: number): boolean {
    // Стакан читаем всегда, в том числе пока проба применяется: так бот сразу
    // видит, если конкурент перебил. Выводы о потолке и так делаются только
    // после подтверждения пробы (CONFIRM_MS / INVISIBLE_CONFIRM_MS).
    void now;
    return false;
  }

  onScan(scan: PairScan): void {
    this.lastScanAccepted = false;
    try {
      this.onScanInner(scan);
    } finally {
      const waiters = this.scanWaiters.splice(0);
      for (const resolve of waiters) resolve();
    }
  }

  private lastAcceptedAt = 0;
  // После отказа Bybit держателю: проба не уходит, пока новый держатель не
  // встанет на топ-1 (даже при PROBE_RELEASE_MAX_MS=0). Иначе она забирает
  // слот лимита и сама вызывает отказы держателю (лог 01.10 10:28).
  private probeAfterHolder = false;
  // От какого топ-1 последний раз "вернулись" к старому значению (и когда).
  private revertedFrom: number | null = null;
  private revertedAt = 0;
  private firstSent = true;
  // FIRST_JUMP_HEDGE: цена-страховка (топ-1) для второго объявления. Уходит
  // сразу после ответа Bybit на первый прыжок (или по таймауту).
  private pendingHold: number | null = null;
  private pendingHoldSince = 0;
  // Идёт первый ход со страховкой: у объявлений РАЗНЫЕ цели (топ-1 + шаг и
  // топ-1), при отказе Bybit роли не меняем — каждое повторяет свою цель.
  private hedgeActive = false;

  /**
   * FIRST_UPDATE_DELAY_MS: сколько ещё ждать перед ПЕРВЫМ изменением цены после
   * смены курса (0 — можно отправлять). Отсчёт — от снимка, в котором бот
   * увидел смену.
   */
  firstSendWait(now: number, delayMs: number): number {
    if (this.firstSent || delayMs <= 0 || this.mode !== "race") return 0;
    return Math.max(0, this.raceStartedAt + delayMs - now);
  }

  /** Первое изменение этой смены отправлено. */
  markSent(): void {
    this.firstSent = true;
  }
  private swapScanAt = 0;
  private swapsThisScan = 0;
  // Последний принятый снимок стакана (для проверки при остановке гонки).
  private lastScan: PairScan | null = null;
  // Гонка начата сразу после запуска бота, а наших объявлений в стакане не
  // нашлось (например, в окне смены курса бот читает только первые 20).
  // Если окажется, что держатель уже стоит на топ-1 — пробу не делаем.
  private startupRace = false;

  /** Когда (мс) пара последний раз приняла снимок стакана. */
  get lastAcceptedScanAt(): number {
    return this.lastAcceptedAt;
  }

  /** Последний снимок стакана принят (не отброшен как устаревший). */
  get scanAccepted(): boolean {
    return this.lastScanAccepted;
  }

  /** Топ-1, который пара считает текущим (после фильтра устаревших снимков). */
  get acceptedTop(): number | null {
    return this.lastTop1;
  }

  /** Цена хуже текущей — объявление возвращается вниз (под потолок/к топ-1). */
  isRetreat(itemId: string, price: number): boolean {
    const current = this.current.get(itemId);
    return current !== undefined && this.better(round2(current), round2(price));
  }

  /** Потолок, на котором пара остановилась (null — пара не в покое). */
  get settledPrice(): number | null {
    return this.mode === "settled" ? this.low : null;
  }

  /** Когда (мс) последний раз Bybit подтвердил изменение цены в паре. */
  get lastActivity(): number {
    return this.lastActivityAt;
  }

  /**
   * Объявление "уплыло" с цели (floating: Bybit пересчитал цену по новому
   * эталону) — забываем, что цель применена, чтобы бот поставил её заново.
   */
  forgetApplied(itemId: string): void {
    this.applied.delete(itemId);
  }

  isHolder(itemId: string): boolean {
    return this.holder === itemId;
  }

  /** Дождаться следующего чтения стакана (не дольше timeoutMs). */
  waitNextScan(timeoutMs: number): Promise<void> {
    return new Promise((resolve) => {
      const timer = setTimeout(done, timeoutMs);
      function done() {
        clearTimeout(timer);
        resolve();
      }
      this.scanWaiters.push(done);
    });
  }

  /** Пара сейчас проверяет подозрительный снимок (возврат топ-1). */
  get checkingSnapshot(): boolean {
    return this.revertSources.size > 0;
  }

  private onScanInner(scan: PairScan): void {
    if (scan.top1 === null) return;
    // Защита от устаревшего снимка стакана: топ-1 "вернулся" к значению,
    // которое было до последней смены (в пределах REVERT_WINDOW_MS). Так
    // выглядит старый снимок — ему не верим, пока возврат не подтвердит
    // чтение с ДРУГОГО IP (старый снимок одного узла не может подтвердить сам
    // себя). Если IP всего один — нужно REVERT_SAME_SOURCE_SCANS чтений подряд.
    const source = scan.source ?? null;
    if (this.lastTop1 !== null && Math.abs(scan.top1 - this.lastTop1) >= EPS) {
      // Мы только что поверили "возврату" к старому значению, а теперь снова
      // видим то, от чего вернулись. Значит, тот возврат был старыми снимками
      // с нескольких IP, а настоящий топ-1 — этот: принимаем сразу, без
      // повторных проверок (лог 01.10 19:31: 89.75 → "возврат" к 89.32 с трёх
      // IP → 89.75 ещё раз проверяли двумя срочными чтениями).
      const flipBack = this.revertedFrom !== null && Math.abs(scan.top1 - this.revertedFrom) < EPS &&
        scan.at - this.revertedAt < REVERT_WINDOW_MS;
      if (flipBack) {
        this.log(`топ-1 снова ${scan.top1.toFixed(2)}${source ? ` (${source})` : ""} — прошлый "возврат" ` +
          `был старыми снимками, принимаю сразу`);
        this.revertedFrom = null;
      } else if (this.prevTop !== null && Math.abs(scan.top1 - this.prevTop) < EPS &&
          scan.at - this.topChangedAt < REVERT_WINDOW_MS) {
        this.revertSources.add(source);
        this.revertScans += 1;
        // Нужно столько РАЗНЫХ IP, показавших возврат: первый + REVERT_CONFIRMATIONS
        // подтверждений. Лог 01.10 07:29: старый снимок 88.53 пришёл с двух IP
        // подряд — одного подтверждения не хватило, пара ушла на 88.53/88.54
        // выше потолка на ~5 с.
        const needed = 1 + REVERT_CONFIRMATIONS;
        const accepted = this.revertSources.size >= needed ||
          this.revertScans >= Math.max(REVERT_SAME_SOURCE_SCANS, needed + 1);
        if (!accepted) {
          this.log(`топ-1 ${scan.top1.toFixed(2)} — это прошлый топ-1 (до смены на ${this.lastTop1.toFixed(2)}), ` +
            `похоже на устаревший снимок${source ? ` (${source})` : ""} — жду подтверждения с другого IP ` +
            `(${this.revertSources.size} из ${needed})`);
          return;
        }
        this.log(`возврат топ-1 к ${scan.top1.toFixed(2)} подтверждён${source ? ` (${source})` : ""}`);
        this.revertedFrom = this.lastTop1;
        this.revertedAt = scan.at;
      }
      this.prevTop = this.lastTop1;
      this.topChangedAt = scan.at;
    } else if (this.revertSources.size > 0) {
      // Возврат не подтвердился — те IP прислали старый снимок.
      for (const stale of this.revertSources) {
        if (stale) this.options.onStaleSource?.(stale, "старый снимок: топ-1 откатился к прошлому значению");
      }
      this.log(`топ-1 ${scan.top1.toFixed(2)} подтверждён${source ? ` (${source})` : ""} — снимок с прошлым топ-1 был устаревшим`);
    }
    this.revertSources.clear();
    this.revertScans = 0;
    this.lastTop1 = scan.top1;
    this.lastScanAccepted = true;
    this.lastAcceptedAt = Date.now();
    this.lastScan = scan;
    // Сторож: держатель стоит ВЫШЕ топ-1 (лучше всех чужих цен) и его не видно
    // в стакане — значит, он выше потолка (курс упал или пара ошиблась из-за
    // устаревшего снимка). Если так несколько проверок подряд и после
    // последнего изменения цены прошло достаточно времени — ищем потолок заново.
    if (this.mode !== "idle" && this.low !== null && this.better(this.low, scan.top1) &&
        (scan.hits.get(FOLLOW_MARKET ? this.jumperId() : this.holder) ?? null) === null &&
        scan.at - this.lastChangeAt() > ABOVE_CEILING_GRACE_MS) {
      this.aboveScans += 1;
      if (this.aboveScans >= ABOVE_CEILING_SCANS) {
        this.aboveScans = 0;
        this.log(`${this.short(FOLLOW_MARKET ? this.jumperId() : this.holder)} стоит на ${this.low.toFixed(2)} — выше топ-1 ${scan.top1.toFixed(2)} ` +
          `и не виден в стакане: ищу потолок заново`);
        this.mode = "settled";
        this.settleTop = null;
        this.start(scan);
        return;
      }
    } else {
      this.aboveScans = 0;
    }
    if (this.mode === "race") {
      this.stepRace(scan);
      return;
    }
    if (this.shouldStart(scan)) {
      this.start(scan);
      return;
    }
    if (FOLLOW_MARKET) this.followPull(scan);
  }

  /**
   * Последнее движение в паре: подтверждённое Bybit изменение, начало гонки или
   * постановка новой цели. Пока изменение в пути, lastActivityAt ещё старый, и
   * стакан (который показывает новую цену с опозданием) мог принять за "выше
   * потолка" то, что просто ещё не применилось.
   */
  private lastChangeAt(): number {
    let latest = Math.max(this.lastActivityAt, this.raceStartedAt);
    for (const at of this.targetSetAt.values()) latest = Math.max(latest, at);
    return latest;
  }

  // ---------------------------------------------------------------------

  /**
   * Какое из наших объявлений УЖЕ видно в стакане ровно на этой цене (без
   * изменения цены — например, floating сам пересчитался на неё). Его не
   * трогаем: оно держит цену и своё место в очереди, пробует другое.
   */
  private alreadyOn(scan: PairScan, price: number): string | null {
    for (const id of [this.a, this.b]) {
      const hit = scan.hits.get(id);
      if (hit !== undefined && hit !== null && Math.abs(hit - price) < EPS) return id;
    }
    return null;
  }

  /**
   * Какое из наших объявлений Bybit уже ПОДТВЕРДИЛ на этой цене (ответ на
   * изменение пришёл), хотя в стакане его ещё может быть не видно — стакан
   * показывает новую цену через 1–1,5 с. Такое объявление тоже "уже стоит":
   * снимать его на пробу нельзя, оно потеряет место в очереди (лог 02.10
   * 07:28: floating встал на 88.74 в 27.63, рынок пришёл на 88.74, бот
   * поставил туда fixed, а floating отправил на 88.75 и вернул — floating
   * оказался за первыми 50).
   */
  private confirmedOn(scan: PairScan, price: number): string | null {
    if (FIXED_NO_PROBE) return null;
    for (const id of [this.a, this.b]) {
      const applied = this.applied.get(id);
      if (!applied || applied.forTarget === undefined) continue;
      if (Math.abs(applied.price - price) >= EPS) continue;
      if (scan.at - applied.at > CONFIRMED_STANDING_MS) continue;
      // Объявлению уже назначена другая цена — оно с этой уходит.
      const target = this.targets.get(id);
      if (target !== undefined && target !== applied.forTarget) continue;
      return id;
    }
    return null;
  }

  private isFloating(itemId: string): boolean {
    return this.options.floating.has(itemId);
  }

  private better(x: number, y: number): boolean {
    return this.options.side === "1" ? x < y - EPS : x > y + EPS;
  }

  private up(price: number): number {
    const { side, step } = this.options;
    return round2(side === "1" ? price - step : price + step);
  }

  private clamp(price: number): number {
    return round2(Math.min(this.options.max, Math.max(this.options.min, price)));
  }

  /** Цена не лучше лучшей видимой чужой цены — значит, её показывают у других. */
  private withinBest(price: number, best: number | null): boolean {
    return best !== null && !this.better(price, best);
  }

  private shouldStart(scan: PairScan): boolean {
    if (this.mode === "idle" || this.low === null || this.settleTop === null) return true;
    // Потолок найден — стоим на месте, пока не сменится топ-1.
    return Math.abs(scan.top1! - this.settleTop) >= EPS;
  }

  private start(scan: PairScan): void {
    const top = this.clamp(scan.top1!);
    // После запуска бота: если наше объявление уже стоит на топ-1 и его видно
    // в стакане — потолок найден ещё до перезапуска. Пробу выше не отправляем
    // (иначе объявление "улетает" выше потолка и его не видно), просто стоим.
    const fromIdle = this.mode === "idle";
    this.startupRace = false;
    this.pendingHold = null;
    this.hedgeActive = false;
    if (fromIdle) {
      const onTop = [this.a, this.b].filter((id) => {
        const hit = scan.hits.get(id);
        const tolerance = this.isFloating(id) ? FLOATING_TOLERANCE : EPS;
        return hit !== undefined && hit !== null && Math.abs(hit - top) < tolerance;
      });
      if (onTop.length > 0) {
        this.low = top;
        this.high = null;
        this.probes = 0;
        this.holder = onTop.includes(this.a) || onTop.length === 0 ? this.a : this.b;
        this.prober = this.holder === this.a ? this.b : this.a;
        this.pendingProbe = null;
        for (const id of onTop) {
          this.applied.set(id, { price: scan.hits.get(id)!, at: scan.at, forTarget: top });
          this.current.set(id, scan.hits.get(id)!);
        }
        this.setTarget(this.a, top);
        this.setTarget(this.b, top);
        this.settle(`после запуска ${onTop.map((id) => this.short(id)).join(" и ")} уже на топ-1 ${top.toFixed(2)} — пробу не делаю`);
        return;
      }
    }
    if (FOLLOW_MARKET) {
      this.probes = 0;
      this.pendingProbe = null;
      if (fromIdle) {
        // После запуска бота своих объявлений в стакане не нашли: оба встают
        // ровно на топ-1, прыжок вверх не делаем (не знаем, где потолок).
        this.low = top;
        this.high = null;
        this.probeTarget = null;
        this.setTarget(this.a, top);
        this.setTarget(this.b, top);
        this.settle(`после запуска (режим "за рынком") — встаём на топ-1 ${top.toFixed(2)}, выше не пробуем`);
        return;
      }
      this.raceStartedAt = scan.at;
      this.firstSent = false;
      this.followOnTop(scan, top);
      return;
    }
    this.low = top;
    this.high = null;
    this.raceStartedAt = scan.at;
    // Первое изменение этой смены ещё не уходило (для FIRST_UPDATE_DELAY_MS).
    // После запуска бота задержку не делаем.
    this.firstSent = fromIdle;
    this.probes = 0;
    // Главное — чтобы одно объявление как можно быстрее встало ровно на топ-1.
    // Это делает fixed: его цена точная (floating после изменения может
    // оказаться на копейку выше из-за пересчёта по эталону). Floating пробует
    // выше — его реальная цена сверяется. Разведчик обрабатывается в цикле
    // сразу после чтения стакана, поэтому изменение держателя уходит первым.
    // PAIR_FIRST=floating в .env — первым на топ-1 идёт floating (по умолчанию fixed).
    const floatingFirst = process.env.PAIR_FIRST === "floating";
    const mixed = this.isFloating(this.a) !== this.isFloating(this.b);
    this.holder = mixed
      ? ((this.isFloating(this.a) === floatingFirst) ? this.a : this.b)
      : this.a;
    this.prober = this.holder === this.a ? this.b : this.a;
    {
      const standing = this.alreadyOn(scan, top);
      if (standing !== null && standing !== this.holder) {
        this.prober = this.holder;
        this.holder = standing;
      }
    }
    // Оптимистичный старт (FIRST_JUMP_STEPS=1): первое объявление сразу идёт на
    // топ-1 + шаг, без предварительной постановки на топ-1. Второе стоит на
    // месте: если копейка выше допустима — оно прыгнет ещё выше (одним
    // изменением), если нет — оба вернутся на топ-1 (ветка "выше потолка").
    // Только не сразу после запуска бота: там свои объявления могут быть не
    // видны в сокращённом стакане.
    if (FIRST_JUMP_STEPS >= 1 && !fromIdle) {
      const jump = this.clamp(this.up(top));
      if (this.better(jump, top)) {
        // Одно из наших уже стоит на топ-1 (видно в стакане) — его не трогаем,
        // оно и есть страховка; прыгает другое.
        const onTop = this.alreadyOn(scan, top);
        if (onTop === null) {
          const first = this.holder;
          this.holder = this.prober;
          this.prober = first;
        }
        this.targets.delete(this.holder);
        this.targets.delete(this.prober);
        this.pendingProbe = null;
        this.probeAfterHolder = false;
        this.mode = "race";
        if (onTop !== null) {
          this.setTarget(this.holder, top);
          this.applied.set(this.holder, { price: top, at: scan.at, forTarget: top });
          this.hedgeActive = true;
        } else if (FIRST_JUMP_HEDGE) {
          this.pendingHold = top;
          this.pendingHoldSince = scan.at;
          this.hedgeActive = true;
        }
        this.setProbe(jump, scan.at);
        this.log(`старт: топ-1 ${top.toFixed(2)} → ${this.short(this.prober)} сразу на ${jump.toFixed(2)}, ` +
          `${this.short(this.holder)} ${onTop !== null ? `уже стоит на ${top.toFixed(2)}`
            : this.pendingHold !== null ? `встанет на ${top.toFixed(2)} сразу после ответа Bybit (страховка)`
            : "ждёт проверки"}`);
        return;
      }
    }
    this.setTarget(this.holder, top);
    if (this.alreadyOn(scan, top) === this.holder) {
      // Уже стоит на топ-1 — менять не нужно, проба уйдёт сразу.
      this.applied.set(this.holder, { price: top, at: scan.at, forTarget: top });
    }
    this.targets.delete(this.prober);
    this.probeTarget = null;
    this.pendingProbe = null;
    const probe = this.clamp(this.up(top));
    if (!this.better(probe, top)) {
      this.setTarget(this.prober, top);
      this.settle(`граница цены из настроек`);
      return;
    }
    this.mode = "race";
    this.probeAfterHolder = false;
    this.startupRace = fromIdle;
    this.pendingProbe = probe;
    this.pendingProbeSince = scan.at;
    this.log(`старт: топ-1 ${top.toFixed(2)} → ${this.short(this.holder)} на ${top.toFixed(2)} (одно изменение), ` +
      `${this.short(this.prober)} прыгнет на ${probe.toFixed(2)} сразу после ответа Bybit`);
    // Если держатель уже стоит на топ-1 — проба уходит сразу.
    const applied = this.applied.get(this.holder);
    if (applied?.forTarget === top) this.releaseProbe(scan.at, "топ-1 уже стоит");
  }

  /** Режим "за рынком": какое объявление прыгает на топ-1 + шаг (PAIR_FIRST, по умолчанию fixed). */
  private jumperId(): string {
    const floatingFirst = process.env.PAIR_FIRST === "floating";
    const mixed = this.isFloating(this.a) !== this.isFloating(this.b);
    return mixed ? ((this.isFloating(this.a) === floatingFirst) ? this.a : this.b) : this.a;
  }

  /** Режим "за рынком": стоим и ждём, пока рынок поднимет топ-1. */
  private followSettle(reason: string): void {
    this.mode = "settled";
    this.probeTarget = null;
    this.pendingProbe = null;
    this.pendingHold = null;
    this.hedgeActive = false;
    this.settleTop = this.lastTop1;
    this.log(`стоп (за рынком): ${reason} — выше не пробуем, ждём, пока рынок поднимет топ-1`);
  }

  /**
   * Режим "за рынком": чужой топ-1 изменился (или поднялся во время гонки).
   * Решаем, что делать прыгуну и страховке.
   */
  private followOnTop(scan: PairScan, top: number): void {
    const jumper = this.jumperId();
    const hedger = jumper === this.a ? this.b : this.a;
    this.prober = jumper;
    this.holder = hedger;
    this.pendingProbe = null;
    this.probeAfterHolder = false;
    // Цена, про которую известно, что она выше потолка, действует, пока топ-1
    // не поднялся выше прошлой проверенной цены (иначе это уже новый потолок).
    if (this.low === null || this.better(top, this.low)) this.high = null;
    if (this.high !== null && !this.better(this.high, top)) this.high = null;

    const jumperHit = scan.hits.get(jumper) ?? null;
    const jumperApplied = this.applied.get(jumper);
    // Прыгун уже идёт ровно на этот топ-1 (изменение в пути) — ждём ответа.
    if (this.mode === "race" && this.probeTarget !== null && Math.abs(this.probeTarget - top) < EPS &&
        jumperApplied?.forTarget !== this.probeTarget) {
      this.low = top;
      this.pendingHold = null;
      this.log(`рынок поднялся до ${top.toFixed(2)}: ${this.short(jumper)} и так встаёт на ${top.toFixed(2)}`);
      return;
    }
    // Прыгун уже стоит на этом топ-1: видно в стакане или Bybit подтвердил.
    const known = jumperHit ?? (jumperApplied && jumperApplied.forTarget !== undefined &&
      this.targets.get(jumper) === jumperApplied.forTarget ? jumperApplied.price : this.current.get(jumper) ?? null);
    if (known !== null && Math.abs(known - top) < EPS) {
      this.low = top;
      this.setTarget(jumper, top);
      this.applied.set(jumper, { price: top, at: jumperApplied?.at ?? scan.at, forTarget: top });
      this.followSettle(`чужие пришли на ${top.toFixed(2)}, ${this.short(jumper)} уже стоит на этой цене`);
      return;
    }
    // Прыгун виден ВЫШЕ чужого топ-1 — он лидер, его цена допустима: стоим.
    if (jumperHit !== null && this.better(jumperHit, top)) {
      this.low = round2(jumperHit);
      this.followSettle(`${this.short(jumper)} виден на ${jumperHit.toFixed(2)} — выше чужого топ-1 ${top.toFixed(2)}`);
      return;
    }
    this.low = top;
    this.mode = "race";
    this.targets.delete(jumper);
    this.targets.delete(hedger);
    this.probeTarget = null;
    const next = this.clamp(this.up(top));
    const canJump = this.better(next, top) && (this.high === null || this.better(this.high, next)) &&
      this.probes < MAX_PROBES;
    if (!canJump) {
      // Копейка выше уже проверена (выше потолка) или упёрлись в границу цены:
      // оба встают ровно на топ-1.
      this.finish(`потолок ${top.toFixed(2)} (выше не прыгаю: ${this.high !== null
        ? `${this.high.toFixed(2)} уже проверена — выше потолка` : "граница цены или предел прыжков"})`);
      return;
    }
    // Страховка: второе объявление на топ-1. Уже стоит там — не трогаем.
    const hedgerOn = this.alreadyOn(scan, top) === hedger || this.confirmedOn(scan, top) === hedger;
    this.hedgeActive = true;
    if (hedgerOn) {
      this.setTarget(hedger, top);
      this.applied.set(hedger, { price: top, at: this.applied.get(hedger)?.at ?? scan.at, forTarget: top });
      this.pendingHold = null;
    } else if (FOLLOW_HEDGE_PARALLEL) {
      // Страховка уходит сразу, вместе с прыжком.
      this.pendingHold = null;
      this.setTarget(hedger, top);
    } else {
      this.pendingHold = top;
      this.pendingHoldSince = scan.at;
    }
    this.setProbe(next, scan.at);
    this.log(`за рынком: топ-1 ${top.toFixed(2)} → ${this.short(jumper)} сразу на ${next.toFixed(2)} (топ-1 + шаг), ` +
      `${this.short(hedger)} ${hedgerOn ? `уже стоит на ${top.toFixed(2)}`
        : FOLLOW_HEDGE_PARALLEL ? `одновременно встаёт на ${top.toFixed(2)} (страховка)`
        : `встанет на ${top.toFixed(2)} сразу после ответа Bybit (страховка)`}`);
  }

  /** Режим "за рынком": после тишины подтягиваем страховку на цену прыгуна. */
  private followPull(scan: PairScan): void {
    if (this.mode !== "settled" || this.low === null || FOLLOW_PULL_MS <= 0) return;
    const jumper = this.jumperId();
    const hedger = jumper === this.a ? this.b : this.a;
    if (this.targets.get(hedger) === this.low) return;
    // Прыгун должен стоять на этой цене (Bybit подтвердил).
    if (this.applied.get(jumper)?.forTarget !== this.low && this.targets.get(jumper) !== this.low) return;
    if (scan.at - this.lastChangeAt() < FOLLOW_PULL_MS) return;
    this.setTarget(hedger, this.low);
    this.log(`за рынком: ${FOLLOW_PULL_MS} мс тишины — ${this.short(hedger)} подтягивается на ${this.low.toFixed(2)}`);
  }

  /** FIRST_JUMP_HEDGE: второе объявление встаёт ровно на топ-1, пока первое проверяет копейку выше. */
  private releaseHold(at: number, reason: string): boolean {
    if (this.mode !== "race" || this.pendingHold === null) return false;
    const price = this.pendingHold;
    this.pendingHold = null;
    // Рынок уже двинулся или держателю назначена другая цена — страховка не нужна.
    if (this.targets.has(this.holder) || this.low === null || Math.abs(this.low - price) >= EPS) return false;
    this.setTarget(this.holder, price);
    void at;
    this.log(`${this.short(this.holder)} встаёт на ${price.toFixed(2)} — страховка на топ-1 (${reason})`);
    return true;
  }

  private releaseProbe(at: number, reason: string): void {
    if (this.mode !== "race" || this.pendingProbe === null) return;
    if (this.probeAfterHolder && reason === "нет ответа" &&
        this.applied.get(this.holder)?.forTarget !== this.targets.get(this.holder)) {
      // После отказа ждём, пока держатель реально встанет (но не дольше
      // PROBE_AFTER_REJECT_MAX_MS — чтобы гонка не зависла).
      if (at - this.pendingProbeSince < PROBE_AFTER_REJECT_MAX_MS) return;
    }
    this.probeAfterHolder = false;
    if (this.startupRace && reason === "топ-1 уже стоит") {
      // После запуска держатель, оказывается, уже стоял на топ-1 — потолок
      // был найден до перезапуска, пробу выше не отправляем.
      this.startupRace = false;
      this.pendingProbe = null;
      this.finish(`после запуска ${this.short(this.holder)} уже стоял на топ-1 ${this.low!.toFixed(2)} — пробу не делаю`);
      return;
    }
    // После запуска бота цена держателя ещё могла не прочитаться (объявление не
    // видно в сокращённом стакане). Пока её не знаем — пробу вверх не шлём:
    // возможно, он уже стоит вровень с топ-1 и менять ничего не нужно.
    if (this.startupRace && reason === "нет ответа" && !this.current.has(this.holder)) return;
    this.startupRace = false;
    const holderTarget = this.targets.get(this.holder);
    const applied = this.applied.get(this.holder);
    if (reason !== "нет ответа" && applied?.forTarget !== holderTarget) return;
    const probe = this.pendingProbe;
    this.pendingProbe = null;
    this.setProbe(probe, at);
    this.log(`${this.short(this.prober)} прыгает на ${probe.toFixed(2)} (${reason})`);
  }

  private setProbe(price: number, at: number): void {
    this.probeTarget = price;
    this.probeSetAt = at;
    this.invisibleScans = 0;
    this.worseRankScans = 0;
    this.setTarget(this.prober, price);
    this.probes += 1;
  }

  private swapAndJump(scan: PairScan): void {
    this.pendingHold = null;
    this.hedgeActive = false;
    if (FOLLOW_MARKET) {
      // Чехарды нет: прыгун стоит на проверенной цене, выше своей цены не пробуем.
      this.followSettle(`${this.short(this.jumperId())} стоит на ${this.low!.toFixed(2)} (цена допустима)`);
      return;
    }
    // Защита от зацикливания: не больше 2 смен ролей на один снимок стакана.
    if (this.swapScanAt === scan.at) {
      if (++this.swapsThisScan > 2) return;
    } else {
      this.swapScanAt = scan.at;
      this.swapsThisScan = 1;
    }
    // FIXED_NO_PROBE=1: fixed не пробует копейку выше — он стоит там, куда
    // встал (топ-1), и в конце один раз переходит на найденный потолок.
    // Потолок ищет только floating. Так у fixed 1–2 изменения за смену, и он
    // никогда не оказывается выше потолка (место в очереди на цене не теряет).
    const keepFixed = FIXED_NO_PROBE && !this.isFloating(this.holder) && this.isFloating(this.prober);
    if (!keepFixed) {
      const previous = this.holder;
      this.holder = this.prober;
      this.prober = previous;
    } else if (this.low !== null && this.targets.get(this.holder) !== this.low) {
      // Floating подтвердил цену выше той, где стоит fixed (рынок поднялся),
      // — fixed сразу встаёт на неё, а не ждёт конца гонки (лог 01.10 09:25:
      // fixed стоял на 88.78 до 01.56, хотя 88.79 была подтверждена в 58.5).
      this.setTarget(this.holder, this.low);
      this.log(`${this.short(this.holder)} сразу встаёт на подтверждённую ${this.low.toFixed(2)}`);
    }
    const next = this.clamp(this.up(this.low!));
    if (!this.better(next, this.low!)) {
      this.finish("граница цены из настроек");
      return;
    }
    if (this.high !== null && !this.better(this.high, next)) {
      this.finish(`потолок ${this.low!.toFixed(2)} (${this.high.toFixed(2)} уже проверена — выше потолка)`);
      return;
    }
    if (this.probes >= MAX_PROBES) {
      this.finish("достигнут предел прыжков");
      return;
    }
    this.setProbe(next, scan.at);
    this.log(`${this.short(this.prober)} прыгает на ${next.toFixed(2)}`);
  }

  private stepRace(scan: PairScan): void {
    const top1 = scan.top1!;
    if (FOLLOW_MARKET && this.low !== null && Math.abs(this.clamp(top1) - this.low) >= EPS &&
        // Топ-1 ниже нашей проверенной цены во время гонки — это наш же прыжок
        // впереди рынка, ничего не делаем; реагируем только на подъём.
        this.better(top1, this.low)) {
      this.startupRace = false;
      this.followOnTop(scan, this.clamp(top1));
      if (this.mode !== "race") return;
    }
    // Рынок сам ушёл выше проверенной цены — это тоже допустимая цена.
    // Держателя вровень с топ-1 не ставим (это лишнее изменение): конкурента
    // перепрыгивает отстающее объявление, сразу на топ-1 + копейка.
    if (this.low !== null && this.better(top1, this.low)) {
      this.startupRace = false; // рынок двинулся — это уже настоящая гонка
      // Страховка первого хода больше не нужна: топ-1 уже другой.
      this.pendingHold = null;
      this.hedgeActive = false;
      // Наша лучшая цена, которую уже видит рынок: применённая проба или
      // проверенная цена (неприменённую пробу конкуренты ещё не видят).
      const proberApplied = this.probeTarget !== null && this.applied.get(this.prober)?.forTarget === this.probeTarget
        ? round2(this.applied.get(this.prober)!.price) : null;
      const ours = proberApplied !== null && this.better(proberApplied, this.low) ? proberApplied : this.low;
      this.low = this.clamp(top1);
      if (this.high !== null && !this.better(this.high, this.low)) this.high = null;
      const next = this.clamp(this.up(this.low));
      // Топ-1 прыгнул выше нашей лучшей цены больше чем на копейку — это не
      // бот, перебивающий нас по копейке, а другие уже встали на потолок (или
      // рядом). Тогда держатель СРАЗУ встаёт ровно на новый топ-1, а второе
      // объявление после него проверяет копейку выше.
      const bigJump = this.better(this.low, this.clamp(this.up(ours)));
      // Первые секунды после смены курса: подъём даже на копейку — это чаще
      // сам новый потолок (выше пусто). Встаём ровно на топ-1 (его точно
      // видно), а копейку выше проверяем следующим шагом.
      const early = !bigJump && scan.at - this.raceStartedAt < MATCH_TOP_EARLY_MS;
      // Проба и так идёт ровно на новый топ-1 (ещё не применена) — оставляем её:
      // она встанет на топ-1, и дальше прыгнет другое.
      const probeOnTop = this.probeTarget !== null && Math.abs(this.probeTarget - this.low) < EPS &&
        this.applied.get(this.prober)?.forTarget !== this.probeTarget;
      if (early && probeOnTop) {
        this.log(`рынок поднялся до ${this.low.toFixed(2)} сразу после смены курса: ` +
          `${this.short(this.prober)} и так встаёт на ${this.low.toFixed(2)}`);
      } else if (bigJump || early) {
        // Одно из наших уже стоит на новом топ-1 (видно в стакане) — оно и
        // держит, его место в очереди не сбиваем; пробует другое (лог 01.10
        // 13:27: floating сам стоял на 89.05 на 1-й стр., его отправили
        // пробовать 89.06 и вернули — оказался на 4-й).
        const visibleOn = this.alreadyOn(scan, this.low);
        // В стакане ещё не видно, но Bybit уже подтвердил эту цену — тоже стоит.
        const confirmed = visibleOn === null ? this.confirmedOn(scan, this.low) : null;
        const standing = visibleOn ?? confirmed;
        // RISE_JUMP_STEPS=1: никто из наших на новом топ-1 не стоит — одно
        // объявление сразу прыгает на копейку выше, второе страхует на топ-1.
        if (RISE_JUMP_STEPS >= 1 && standing === null && !FIXED_NO_PROBE &&
            this.better(next, this.low) && (this.high === null || this.better(this.high, next)) &&
            this.probes < MAX_PROBES) {
          // Прыгает то же объявление, что и на первом ходе (PAIR_FIRST, по умолчанию fixed).
          const floatingFirst = process.env.PAIR_FIRST === "floating";
          const mixed = this.isFloating(this.a) !== this.isFloating(this.b);
          const jumper = mixed
            ? ((this.isFloating(this.a) === floatingFirst) ? this.a : this.b)
            : this.prober;
          this.prober = jumper;
          this.holder = jumper === this.a ? this.b : this.a;
          this.targets.delete(this.holder);
          this.targets.delete(this.prober);
          this.pendingProbe = null;
          this.probeAfterHolder = false;
          this.hedgeActive = true;
          if (FIRST_JUMP_HEDGE) {
            this.pendingHold = this.low;
            this.pendingHoldSince = scan.at;
          }
          this.setProbe(next, scan.at);
          this.log(`рынок поднялся до ${this.low.toFixed(2)} — выше нашей ${ours.toFixed(2)}: ` +
            `${this.short(this.prober)} сразу на ${next.toFixed(2)} (топ-1 + шаг), ` +
            `${this.short(this.holder)} ${FIRST_JUMP_HEDGE
              ? `встанет на ${this.low.toFixed(2)} сразу после ответа Bybit (страховка)` : "ждёт проверки"}`);
        } else {
        if (standing !== null && standing !== this.holder) {
          this.prober = this.holder;
          this.holder = standing;
        }
        this.setTarget(this.holder, this.low);
        if (standing === this.holder) {
          this.applied.set(this.holder, {
            price: this.low, forTarget: this.low,
            at: confirmed !== null ? (this.applied.get(this.holder)?.at ?? scan.at) : scan.at,
          });
        }
        this.targets.delete(this.prober);
        this.probeTarget = null;
        this.pendingProbe = this.better(next, this.low) && (this.high === null || this.better(this.high, next))
          ? next : null;
        this.pendingProbeSince = scan.at;
        if (standing !== null) {
          this.log(`рынок поднялся до ${this.low.toFixed(2)}: ${this.short(this.holder)} уже стоит на ${this.low.toFixed(2)} ` +
            `(${confirmed !== null ? "Bybit подтвердил, в стакане ещё не видно" : "видно в стакане"}) — остаётся на месте` +
            (this.pendingProbe !== null ? `, ${next.toFixed(2)} проверит ${this.short(this.prober)}` : ""));
        } else {
          this.log(`рынок поднялся до ${this.low.toFixed(2)} — ${early ? "сразу после смены курса" : "больше чем на копейку"} выше нашей ${ours.toFixed(2)}: ` +
            `${this.short(this.holder)} сразу встаёт на ${this.low.toFixed(2)}` +
            (this.pendingProbe !== null ? `, ${this.short(this.prober)} потом проверит ${next.toFixed(2)}` : ""));
        }
        if (this.applied.get(this.holder)?.forTarget === this.low) this.releaseProbe(scan.at, "топ-1 уже стоит");
        }
      } else if (this.pendingProbe !== null) {
        // Старт: держатель ещё встаёт на топ-1 — проба уйдёт после него, но
        // уже выше нового топ-1.
        this.pendingProbe = next;
        this.log(`рынок поднялся до ${this.low.toFixed(2)}: ${this.short(this.prober)} прыгнет на ${next.toFixed(2)}`);
      } else if (this.probeTarget !== null && !this.better(this.probeTarget, this.low) &&
          this.applied.get(this.prober)?.forTarget !== this.probeTarget &&
          this.better(next, this.low) && (this.high === null || this.better(this.high, next))) {
        // Проба ещё не встала, а конкурент уже на её цене или выше — сразу
        // перенацеливаем её выше конкурента. Если изменение уже ушло к Bybit,
        // применится старая цена, и тогда прыгнет второе объявление.
        this.setProbe(next, scan.at);
        this.log(`рынок поднялся до ${this.low.toFixed(2)}: ${this.short(this.prober)} прыгает сразу на ${next.toFixed(2)}`);
      } else {
        this.log(`рынок поднялся до ${this.low.toFixed(2)}`);
      }
    }
    if (scan.at - this.raceStartedAt > RACE_TIMEOUT_MS) {
      this.finish("время гонки вышло");
      return;
    }
    // Страховка ждёт ответа Bybit на первый прыжок; слишком долго нет — отпускаем.
    // Отсчёт — от старта или от последнего отказа прыжку: пока Bybit отказывает,
    // прыжок повторяется, и страховка не должна занять его слот.
    if (this.pendingHold !== null &&
        scan.at - Math.max(this.pendingHoldSince, this.rejectedAt.get(this.prober) ?? 0) > PROBE_RELEASE_MAX_MS) {
      this.releaseHold(scan.at, "нет ответа");
    }
    if (this.pendingProbe !== null) {
      // Проба ждёт ответа Bybit на топ-1; если ответа слишком долго нет —
      // отпускаем её, чтобы гонка не зависла.
      if (scan.at - this.pendingProbeSince > PROBE_RELEASE_MAX_MS) this.releaseProbe(scan.at, "нет ответа");
      return;
    }

    const applied = this.applied.get(this.prober);
    if (!applied || applied.forTarget !== this.probeTarget) return; // прыжок ещё не применён
    if (scan.at < applied.at + CONFIRM_MS) return;

    // Реально применённая цена прыжка (у floating может отличаться на копейку).
    const jumped = round2(applied.price);
    if (!this.better(jumped, this.low!)) {
      // Floating встал не выше проверенной цены — проверять нечего, прыгает другое.
      if (!FOLLOW_MARKET) this.log(`${this.short(this.prober)} встал на ${jumped.toFixed(2)} (не выше ${this.low!.toFixed(2)}) — прыгает другое`);
      this.swapAndJump(scan);
      return;
    }

    const hit = scan.hits.get(this.prober) ?? null;
    const tolerance = this.isFloating(this.prober) ? FLOATING_TOLERANCE : EPS;
    // Floating может встать на копейку в сторону — такую цену тоже считаем
    // "видна", но только если она ВЫШЕ проверенной. Если стакан показывает
    // floating по проверенной цене (ниже пробы) — это его СТАРАЯ цена: стакан
    // ещё не обновился (лог 01.10 06:27: 88.53 вместо 88.54 приняли за "видна",
    // второе объявление тоже прыгнуло на 88.54, и оба оказались выше потолка).
    const visible = hit !== null && Math.abs(hit - jumped) < tolerance &&
      (Math.abs(hit - jumped) < EPS ||
        (scan.at >= applied.at + INVISIBLE_CONFIRM_MS && this.better(round2(hit), this.low!)));
    // Цена, которую реально проверил стакан.
    const tested = visible ? round2(hit!) : jumped;
    const withinBest = this.withinBest(tested, scan.best);
    // Объявление в стакане есть, но по старой цене — стакан ещё не обновился.
    const stale = !visible && hit !== null;

    // Защита по месту: якорь стоит на проверенной цене, оба видны — сравниваем.
    const probeRank = scan.ranks?.get(this.prober) ?? null;
    const anchorRank = scan.ranks?.get(this.holder) ?? null;
    const anchorHit = scan.hits.get(this.holder) ?? null;
    const anchorTolerance = this.isFloating(this.holder) ? FLOATING_TOLERANCE : EPS;
    const anchorCurrent = anchorHit !== null && Math.abs(anchorHit - this.low!) < anchorTolerance;
    if (visible && anchorCurrent && probeRank !== null && anchorRank !== null) {
      if (probeRank > anchorRank) {
        if (++this.worseRankScans < WORSE_RANK_SCANS) return; // подтвердим ещё одной проверкой
        this.log(`${tested.toFixed(2)} ухудшила место (якорь ${anchorRank}-й, проба ${probeRank}-я) — ` +
          `лучшая цена ${this.low!.toFixed(2)}`);
        if (this.high === null || this.better(this.high, tested)) this.high = tested;
        this.finish(`потолок по месту ${this.low!.toFixed(2)}`);
        return;
      }
      this.worseRankScans = 0;
    }

    if ((visible || withinBest) && this.better(tested, this.low!)) {
      this.low = tested;
      this.log(`${tested.toFixed(2)} допустима (${visible
        ? `видна${probeRank !== null ? ` на ${probeRank}-м месте` : ""}, стакан обновился через ${scan.at - applied.at} мс`
        : "не лучше видимых"})`);
      this.swapAndJump(scan);
      return;
    }
    if (visible || withinBest) {
      // Проверенная цена не выше уже известной — просто прыгает другое.
      this.swapAndJump(scan);
      return;
    }
    const invalid = stale
      ? scan.at >= applied.at + STALE_MAX_MS
      : scan.at >= applied.at + INVISIBLE_CONFIRM_MS && ++this.invisibleScans >= INVISIBLE_SCANS;
    if (!invalid) return; // ждём, пока стакан точно обновится
    this.log(`${jumped.toFixed(2)} выше потолка (${stale
      ? `стакан ${scan.at - applied.at} мс показывает старую цену`
      : "не видна, лучше всех видимых"})`);
    if (this.high === null || this.better(this.high, jumped)) this.high = jumped;
    const next = this.clamp(this.up(this.low!));
    if (this.better(jumped, next) && this.probes < MAX_PROBES) {
      // Проба перелетела больше чем на копейку — пропущенную копейку проверяет
      // та же проба (она и так уже вне рынка). Держатель остаётся на
      // проверенной цене — снимать его с потолка нельзя.
      this.setProbe(next, scan.at);
      this.log(`проверяю пропущенную ${next.toFixed(2)}: ${this.short(this.prober)} встаёт на неё, ` +
        `${this.short(this.holder)} остаётся на ${this.low!.toFixed(2)}`);
      return;
    }
    this.finish(`потолок ${this.low!.toFixed(2)}`);
  }

  private finish(reason: string): void {
    this.pendingHold = null;
    this.hedgeActive = false;
    // "Потолок" больше чем на шаг выше текущего топ-1, и ни одного нашего
    // объявления на нём в стакане не видно — значит, он взялся из старого
    // снимка (или курс уже упал). Не останавливаемся на нём, а сразу ищем
    // потолок заново от текущего топ-1 — не ждём сторожа (~3,5 с, лог 01.10 07:29).
    const scan = this.lastScan;
    if (scan && scan.top1 !== null && this.low !== null &&
        this.better(this.low, this.clamp(this.up(scan.top1)))) {
      const seenOnLow = [this.a, this.b].some((id) => {
        const hit = scan.hits.get(id);
        const tolerance = this.isFloating(id) ? FLOATING_TOLERANCE : EPS;
        return hit !== undefined && hit !== null && Math.abs(hit - this.low!) < tolerance;
      });
      if (!seenOnLow) {
        this.log(`"потолок" ${this.low.toFixed(2)} выше топ-1 ${scan.top1.toFixed(2)} больше чем на шаг, ` +
          `и нас на нём не видно — ищу потолок заново от ${scan.top1.toFixed(2)}`);
        this.mode = "settled";
        this.settleTop = null;
        this.start(scan);
        return;
      }
    }
    const ceiling = this.low!;
    this.setTarget(this.a, ceiling);
    this.setTarget(this.b, ceiling);
    this.settle(reason);
  }

  private settle(reason: string): void {
    this.mode = "settled";
    this.probeTarget = null;
    this.settleTop = this.lastTop1;
    this.log(`стоп: ${reason}, прыжков ${this.probes} — оба встают на ${this.low!.toFixed(2)}, ` +
      `дальше стоят до смены топ-1`);
  }

  private short(itemId: string): string {
    return itemId.length > 6 ? `…${itemId.slice(-4)}` : itemId;
  }

  private log(message: string): void {
    this.options.log?.(`[pair] ${message}`);
  }
}
