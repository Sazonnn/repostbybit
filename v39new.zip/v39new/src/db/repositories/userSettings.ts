import { query } from "../pool.js";
import { config } from "../../config.js";

export interface UserSettingsRow {
  chat_id: string;
  token_id: string;
  currency_id: string;
  side: "0" | "1";
  ad_mode: "single" | "manual";
  connection_mode: "session" | "api";
  primary_price_type: "fixed" | "floating";
  price_mode: "auto" | "fixed";
  price_step: string;
  price_fixed: string | null;
  price_min: string;
  price_max: string;
  page_size: number;
  payment_password: string | null;
  bourse_verification_filter: number;
  bourse_sort_type: "OVERALL_RANKING" | "PRICE" | "TRADE_COUNT";
  bourse_can_trade: boolean;
  bourse_bulk_maker: boolean;
  bourse_trade_with: boolean;
  bourse_top_n: number;
  working_ads_enabled: boolean;
  working_ads_interval_ms: number;
  working_ads_update_interval_ms: number;
  working_ads_follow_interval_ms: number;
  dual_ads_premium_mode: "auto" | "manual";
  dual_ads_premium_manual: string;
  created_at: Date;
  updated_at: Date;
}

export async function ensureSettings(chatId: number): Promise<UserSettingsRow> {
  const existing = await getSettings(chatId);
  if (existing) return existing;
  const { rows } = await query<UserSettingsRow>(
    `INSERT INTO user_settings
       (chat_id, token_id, currency_id, side, price_mode,
        price_step, price_min, price_max, page_size, bourse_top_n, connection_mode)
     VALUES ($1,$2,$3,$4,'auto',$5,$6,$7,$8,$9,'api')
     RETURNING *`,
    [
      chatId,
      config.p2p.tokenId,
      config.p2p.currencyId,
      config.p2p.side,
      String(config.p2p.priceStep),
      String(config.p2p.priceMin),
      String(config.p2p.priceMax),
      config.p2p.pageSize,
      40,
    ],
  );
  return rows[0]!;
}

export async function getSettings(chatId: number): Promise<UserSettingsRow | null> {
  const { rows } = await query<UserSettingsRow>(
    `SELECT * FROM user_settings WHERE chat_id = $1`,
    [chatId],
  );
  return rows[0] ?? null;
}

export async function hasUsersUsingSessionConnection(): Promise<boolean> {
  const { rows } = await query<{ found: number }>(
    `SELECT 1 AS found FROM user_settings
     WHERE connection_mode = 'session'
     LIMIT 1`,
  );
  return rows.length > 0;
}

export async function listWorkingAdsEnabledChatIds(): Promise<number[]> {
  const { rows } = await query<{ chat_id: number | string }>(
    `SELECT chat_id FROM user_settings
     WHERE working_ads_enabled = 1
     ORDER BY chat_id`,
  );
  return rows
    .map((row) => Number(row.chat_id))
    .filter((chatId) => Number.isSafeInteger(chatId));
}

export async function updateSettings(
  chatId: number,
  patch: Partial<{
    tokenId: string;
    currencyId: string;
    side: "0" | "1";
    adMode: "single" | "manual";
    connectionMode: "session" | "api";
    primaryPriceType: "fixed" | "floating";
    priceMode: "auto" | "fixed";
    priceStep: string;
    priceFixed: string | null;
    priceMin: string;
    priceMax: string;
    pageSize: number;
    paymentPassword: string | null;
    bourseVerificationFilter: number;
    bourseSortType: "OVERALL_RANKING" | "PRICE" | "TRADE_COUNT";
    bourseCanTrade: boolean;
    bourseBulkMaker: boolean;
    bourseTradeWith: boolean;
    bourseTopN: number;
    workingAdsEnabled: boolean;
    workingAdsIntervalMs: number;
    workingAdsUpdateIntervalMs: number;
    workingAdsFollowIntervalMs: number;
    dualAdsPremiumMode: "auto" | "manual";
    dualAdsPremiumManual: string;
  }>,
): Promise<UserSettingsRow> {
  const map: Record<string, string> = {
    tokenId: "token_id",
    currencyId: "currency_id",
    side: "side",
    adMode: "ad_mode",
    connectionMode: "connection_mode",
    primaryPriceType: "primary_price_type",
    priceMode: "price_mode",
    priceStep: "price_step",
    priceFixed: "price_fixed",
    priceMin: "price_min",
    priceMax: "price_max",
    pageSize: "page_size",
    paymentPassword: "payment_password",
    bourseVerificationFilter: "bourse_verification_filter",
    bourseSortType: "bourse_sort_type",
    bourseCanTrade: "bourse_can_trade",
    bourseBulkMaker: "bourse_bulk_maker",
    bourseTradeWith: "bourse_trade_with",
    bourseTopN: "bourse_top_n",
    workingAdsEnabled: "working_ads_enabled",
    workingAdsIntervalMs: "working_ads_interval_ms",
    workingAdsUpdateIntervalMs: "working_ads_update_interval_ms",
    workingAdsFollowIntervalMs: "working_ads_follow_interval_ms",
    dualAdsPremiumMode: "dual_ads_premium_mode",
    dualAdsPremiumManual: "dual_ads_premium_manual",
  };
  const sets: string[] = ["updated_at = CURRENT_TIMESTAMP"];
  const values: unknown[] = [];
  let i = 1;
  for (const [k, v] of Object.entries(patch)) {
    const col = map[k];
    if (!col) continue;
    sets.push(`${col} = $${i++}`);
    values.push(v);
  }
  if (values.length === 0) {
    return ensureSettings(chatId);
  }
  values.push(chatId);
  const { rows } = await query<UserSettingsRow>(
    `UPDATE user_settings SET ${sets.join(", ")} WHERE chat_id = $${i} RETURNING *`,
    values,
  );
  return rows[0]!;
}
