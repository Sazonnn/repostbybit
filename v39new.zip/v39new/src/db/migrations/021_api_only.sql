UPDATE user_settings SET connection_mode = 'api';
