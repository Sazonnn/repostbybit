import type { Context } from "grammy";
import { InlineKeyboard } from "grammy";
import { config } from "../config.js";
import { ensureSettings } from "../db/repositories/userSettings.js";
import type { WorkingAdRow } from "../db/repositories/workingAds.js";
import type {
  WorkingAdsManager,
  WorkingAdSyncResult,
} from "../services/workingAdsManager.js";

const PENDING_TTL_MS = 5 * 60_000;
type PendingInput = "add" | "interval" | "update_interval" | "follow" | "follow_interval";
const pending = new Map<
  number,
  { kind: PendingInput; until: number; adId?: number }
>();

function chatIdOf(ctx: Context): number {
  const id = ctx.chat?.id;
  if (!id) throw new Error("No chat");
  return id;
}

export function buildWorkingAdsHandlers(manager: WorkingAdsManager) {
  async function show(ctx: Context, edit = false): Promise<void> {
    const chatId = chatIdOf(ctx);
    const [settings, ads] = await Promise.all([
      ensureSettings(chatId),
      manager.list(chatId),
    ]);
    const enabledCount = ads.filter((ad) => ad.enabled).length;
    const lines = [
      `💼 <b>Мои объявления</b>`,
      ``,
      `Статус: <b>${settings.working_ads_enabled ? "🟢 работает" : "⚪️ на паузе"}</b>`,
      `📡 Опрос рынка: каждые <b>${workingAdsIntervalSeconds(settings)} сек</b>`,
      `🔗 Сверка пары: каждые <b>${formatIntervalSeconds(Math.max(10, Number(settings.working_ads_follow_interval_ms ?? 1000)))} сек</b>`,
      `✏️ Пауза между правками: <b>${workingAdsUpdateIntervalSeconds(settings)} сек</b>`,
      `🧮 Расчёт: <b>${priceModeLabel(settings)}</b>`,
      `📋 В работе: <b>${enabledCount} из ${ads.length}</b>`,
      ``,
      `Меняется только цена или наценка — сами объявления остаются на месте.`,
    ];
    if (ads.length === 0) {
      lines.push(``, `Список пуст — добавьте ID объявления кнопкой ниже.`);
    } else {
      lines.push(``, ...ads.map((ad, index) => adLine(ad, index)));
    }

    const keyboard = new InlineKeyboard()
      .text(
        settings.working_ads_enabled
          ? "⏸ Поставить на паузу"
          : "▶️ Запустить",
        "wa:toggle",
      )
      .row()
      .text("➕ Новое объявление", "wa:add")
      .text("🔄 Пересчитать", "wa:sync")
      .row()
      .text("📡 Опрос рынка", "wa:interval")
      .text("🔗 Сверка пары", "wa:follow_interval")
      .row()
      .text("✏️ Пауза между правками", "wa:update_interval");
    for (const ad of ads) {
      keyboard
        .row()
        .text(
          `${ad.enabled ? "✅" : "⏸"} ${shortId(ad.item_id)}`,
          `wa:item:${ad.id}`,
        )
        .text(ad.follow_item_id ? "🔗✓" : "🔗", `wa:follow:${ad.id}`)
        .text("🗑", `wa:del:${ad.id}`);
    }
    keyboard.row().text("⚙️ Параметры", "settings_open").text("⬅️ Меню", "menu_open");

    const text = lines.join("\n");
    if (edit && ctx.callbackQuery?.message) {
      await ctx
        .editMessageText(text, {
          parse_mode: "HTML",
          reply_markup: keyboard,
        })
        .catch(async () => {
          await ctx.reply(text, {
            parse_mode: "HTML",
            reply_markup: keyboard,
          });
        });
      return;
    }
    await ctx.reply(text, { parse_mode: "HTML", reply_markup: keyboard });
  }

  async function callback(ctx: Context): Promise<void> {
    const data = ctx.callbackQuery?.data;
    if (!data) return;
    await ctx.answerCallbackQuery().catch(() => {});
    const chatId = chatIdOf(ctx);

    try {
      if (data === "wa:toggle") {
        const settings = await ensureSettings(chatId);
        await manager.setEnabled(chatId, !settings.working_ads_enabled);
        await show(ctx, true);
        return;
      }
      if (data === "wa:add") {
        pending.set(chatId, { kind: "add", until: Date.now() + PENDING_TTL_MS });
        await ctx.reply(
          `Отправь <b>ID своего активного объявления Bybit</b> цифрами.\n\n` +
            `Бот сначала только проверит объявление и добавит его в список. ` +
            `Максимум 10 ID.\n\n/cancel — отменить`,
          { parse_mode: "HTML" },
        );
        return;
      }
      if (data === "wa:interval") {
        pending.set(chatId, {
          kind: "interval",
          until: Date.now() + PENDING_TTL_MS,
        });
        await ctx.reply(
          `Как часто опрашивать рынок (в секундах)?\n\n` +
            `Например: <code>0,2</code> или <code>0,5</code>\n` +
            `Минимум настройки: <b>0,01 сек</b>. ` +
            `Опрос стакана ограничен 8 запросами/сек на все рабочие объявления этого процесса; фактическая частота зависит от ответа Bybit.\n` +
            `Редактирование: не более 10 попыток за 5 минут на объявление.\n\n/cancel — отменить`,
          { parse_mode: "HTML" },
        );
        return;
      }
      if (data === "wa:update_interval") {
        pending.set(chatId, {
          kind: "update_interval",
          until: Date.now() + PENDING_TTL_MS,
        });
        await ctx.reply(
          `Какую паузу держать между правками цены одного объявления (в секундах)?\n\n` +
            `Например: <code>0,01</code>, <code>0,5</code> или <code>30</code>.\n` +
            `Диапазон: <b>0,01–86400 сек</b>.\n` +
            `Опрос рынка при этом не останавливается. По окончании паузы цена изменится только при необходимости.\n` +
            `Пауза действует и для «Пересчитать». Лимит 10 попыток за 5 минут сохраняется.\n\n/cancel — отменить`,
          { parse_mode: "HTML" },
        );
        return;
      }
      if (data === "wa:sync") {
        const results = await manager.syncNow(chatId);
        await ctx.reply(formatSyncSummary(results), { parse_mode: "HTML" });
        await show(ctx, true);
        return;
      }
      if (data.startsWith("wa:item:")) {
        const id = Number(data.slice("wa:item:".length));
        if (Number.isSafeInteger(id)) await manager.toggleAd(chatId, id);
        await show(ctx, true);
        return;
      }
      if (data === "wa:follow_interval") {
        pending.set(chatId, {
          kind: "follow_interval",
          until: Date.now() + PENDING_TTL_MS,
        });
        await ctx.reply(
          `Как часто сверять связанное объявление с главным (в секундах)?\n\n` +
            `Например: <code>0,2</code> или <code>0,5</code>. Минимум <b>0,01 сек</b>.\n` +
            `Сверка не бывает чаще опроса рынка, ` +
            `а все чтения стакана вместе ограничены 8 запросами в секунду.\n` +
            `Одна сверка — один запрос: видно ли главное объявление на страницах 1–5.\n\n/cancel — отменить`,
          { parse_mode: "HTML" },
        );
        return;
      }
      if (data.startsWith("wa:follow:")) {
        const id = Number(data.slice("wa:follow:".length));
        if (!Number.isSafeInteger(id)) return;
        pending.set(chatId, {
          kind: "follow",
          until: Date.now() + PENDING_TTL_MS,
          adId: id,
        });
        await ctx.reply(
          `Пришлите <b>ID главного объявления</b> из этого же списка, ` +
            `— это объявление будет повторять его цену, не считая свою от рынка.\n\n` +
            `Пришлите <code>-</code>, чтобы отвязать и вернуть обычный расчёт.\n\n/cancel — отменить`,
          { parse_mode: "HTML" },
        );
        return;
      }
      if (data.startsWith("wa:del:")) {
        const id = Number(data.slice("wa:del:".length));
        if (Number.isSafeInteger(id)) await manager.remove(chatId, id);
        await show(ctx, true);
      }
    } catch (error) {
      await ctx.reply(`❌ ${escapeHtml((error as Error).message)}`, {
        parse_mode: "HTML",
      });
    }
  }

  async function consumeInput(ctx: Context): Promise<boolean> {
    const chatId = chatIdOf(ctx);
    const state = pending.get(chatId);
    if (!state) return false;
    if (state.until < Date.now()) {
      pending.delete(chatId);
      return false;
    }
    const text = ctx.message?.text?.trim();
    if (!text || text.startsWith("/")) return false;

    try {
      if (state.kind === "interval" || state.kind === "update_interval") {
        const seconds = Number(text.replace(",", "."));
        const updateInterval = state.kind === "update_interval";
        if (updateInterval) await manager.setUpdateIntervalSeconds(chatId, seconds);
        else await manager.setIntervalSeconds(chatId, seconds);
        pending.delete(chatId);
        const label = updateInterval ? "Пауза между правками" : "Опрос рынка";
        await ctx.reply(
          `✅ ${label}: <b>${formatIntervalSeconds(Math.round(seconds * 1000))} сек</b>`,
          { parse_mode: "HTML" },
        );
        await show(ctx);
        return true;
      }

      if (state.kind === "follow_interval") {
        const seconds = Number(text.replace(",", "."));
        await manager.setFollowIntervalSeconds(chatId, seconds);
        pending.delete(chatId);
        await ctx.reply(
          `✅ Сверка пары: каждые <b>${formatIntervalSeconds(Math.round(seconds * 1000))} сек</b>`,
          { parse_mode: "HTML" },
        );
        await show(ctx);
        return true;
      }

      if (state.kind === "follow") {
        if (state.adId === undefined) throw new Error("Не выбрано объявление.");
        const followItemId = text === "-" ? null : text;
        await manager.setFollow(chatId, state.adId, followItemId);
        pending.delete(chatId);
        await ctx.reply(
          followItemId
            ? `✅ Связано: повторяет цену <code>${followItemId}</code>.`
            : `✅ Связь снята, цена снова считается от рынка.`,
          { parse_mode: "HTML" },
        );
        await show(ctx);
        return true;
      }

      const ad = await manager.add(chatId, text);
      pending.delete(chatId);
      await ctx.reply(
        `✅ Объявление добавлено в список:\n` +
          `<code>${ad.item_id}</code> · ${ad.token_id}/${ad.currency_id} · ` +
          `${ad.side === "1" ? "SELL" : "BUY"} · ` +
          `${ad.price_type === "1" ? "floating" : "fixed"}`,
        { parse_mode: "HTML" },
      );
      await show(ctx);
    } catch (error) {
      const retryHint =
        state.kind === "interval" || state.kind === "update_interval" || state.kind === "follow_interval"
          ? `Отправь интервал ещё раз или /cancel.`
          : `Отправь правильный ID ещё раз или /cancel.`;
      await ctx.reply(
        `❌ ${escapeHtml((error as Error).message)}\n\n` +
          retryHint,
        { parse_mode: "HTML" },
      );
    }
    return true;
  }

  function cancelInput(chatId: number): boolean {
    return pending.delete(chatId);
  }

  return { show, callback, consumeInput, cancelInput };
}

function adLine(ad: WorkingAdRow, index: number): string {
  const status = ad.enabled ? "🟢" : "⚪️";
  const type = ad.price_type === "1" ? "floating" : "fixed";
  const follow = ad.follow_item_id
    ? `\n   🔗 повторяет <code>${ad.follow_item_id}</code>`
    : "";
  const error = ad.last_error
    ? `\n   ⚠️ ${escapeHtml(ad.last_error)}`
    : "";
  return (
    `${index + 1}. ${status} <code>${ad.item_id}</code>\n` +
    `   ${ad.token_id}/${ad.currency_id} · ${ad.side === "1" ? "SELL" : "BUY"} · ${type} · ` +
    `${ad.last_price ?? "цена —"}${follow}${error}`
  );
}

function priceModeLabel(
  settings: Awaited<ReturnType<typeof ensureSettings>>,
): string {
  if (settings.price_mode === "fixed") {
    return `фиксированный курс ${settings.price_fixed ?? "—"}`;
  }
  return `от лучшей цены, шаг ${settings.price_step}`;
}

function workingAdsIntervalSeconds(
  settings: Awaited<ReturnType<typeof ensureSettings>>,
): string {
  return formatIntervalSeconds(
    Math.max(
      10,
      Number(settings.working_ads_interval_ms || config.cycle.intervalMs),
    ),
  );
}

function formatIntervalSeconds(intervalMs: number): string {
  return (intervalMs / 1000).toString().replace(".", ",");
}

function workingAdsUpdateIntervalSeconds(
  settings: Awaited<ReturnType<typeof ensureSettings>>,
): string {
  return formatIntervalSeconds(Math.max(10, Number(settings.working_ads_update_interval_ms ?? 250)));
}

function formatSyncSummary(results: WorkingAdSyncResult[]): string {
  if (results.length === 0) {
    return "ℹ️ В работе нет ни одного объявления.";
  }
  const changed = results.filter((result) => result.changed);
  const errors = results.filter((result) => result.error);
  const deferred = results.filter((result) => result.deferredUntil && !result.error);
  if (changed.length === 0 && errors.length === 0 && deferred.length === 0) {
    return "✅ Цены и так на месте, менять нечего.";
  }
  const lines = ["🔄 <b>Пересчёт готов</b>"];
  for (const result of changed) {
    lines.push(
      `✅ <code>${result.ad.item_id}</code>: ${result.previousPrice ?? "—"} → <b>${result.targetPrice}</b>`,
    );
  }
  for (const result of errors) {
    lines.push(
      `⚠️ <code>${result.ad.item_id}</code>: ${escapeHtml(result.error ?? "")}`,
    );
  }
  for (const result of deferred) {
    const seconds = Math.max(0, Math.ceil((result.deferredUntil! - Date.now()) / 1000));
    lines.push(
      `<code>${result.ad.item_id}</code>: пауза между правками, ещё ${seconds} сек. Опрос рынка идёт.`,
    );
  }
  return lines.join("\n");
}

function shortId(itemId: string): string {
  return itemId.length <= 12
    ? itemId
    : `${itemId.slice(0, 6)}…${itemId.slice(-4)}`;
}

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}
