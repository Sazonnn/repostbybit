import { InlineKeyboard } from "grammy";

// Одно главное меню: только объявления, настройки и API-ключ.
export const mainKeyboard = new InlineKeyboard()
  .text("💼 Мои объявления", "working_ads_open")
  .row()
  .text("⚙️ Параметры", "settings_open")
  .text("🔑 API-ключ", "connection_open");

// Старые имена оставлены, чтобы не ломать импорты: все показывают одно меню.
export const idleKeyboard = mainKeyboard;
export const manualKeyboard = mainKeyboard;
export const runningKeyboard = mainKeyboard;
export const monitoringKeyboard = mainKeyboard;
