import type { Context } from "grammy";
import { InlineKeyboard } from "grammy";
import {
  UserSettingsRow,
  ensureSettings,
  updateSettings,
} from "../db/repositories/userSettings.js";
import {
  SideSettingsRow,
  ensureSideSettings,
  updateSideSettings,
} from "../db/repositories/sideSettings.js";
import {
  PaymentMethod,
  isPaymentUsable,
  listPostAdPayments,
  paymentLabel,
  withBybitConnection,
} from "../bybit/index.js";

interface PendingInput {
  field: InputField;
  until: number;
  returnSection: SettingsSection;
}
type SettingsSection =
  | "main"
  | "mode"
  | "market"
  | "price"
  | "ad"
  | "safety";
type InputField =
  | "qty"
  | "range"
  | "step"
  | "fixed"
  | "period"
  | "token"
  | "currency"
  | "remark"
  | "bounds"
  | "topn"
  | "paypass"
  | "floating_premium";

const PENDING_TTL_MS = 5 * 60_000;
const pending = new Map<number, PendingInput>();

const PROMPTS: Record<InputField, string> = {
  qty: "Напиши объём в монетах (например <code>10</code>) или <code>auto</code> — тогда бот посчитает сам.",
  range:
    "Напиши сумму одной сделки: от и до, через пробел или дефис.\nНапример: <code>500 1000</code> или <code>500-1000</code>",
  step:
    "Напиши отступ от лучшей цены, например <code>0.01</code>.\n<code>0</code> — ставить ровно по лучшей цене.",
  fixed:
    "Напиши свою цену, например <code>75.50</code>. Бот перестанет подстраиваться под рынок.",
  period: "Напиши время на оплату в минутах, например <code>15</code>",
  token: "Напиши монету, например <code>USDT</code>",
  currency: "Напиши валюту, например <code>RUB</code>",
  remark: "Напиши примечание к объявлению. Чтобы убрать — отправь <code>.</code>",
  bounds:
    "Напиши нижнюю и верхнюю границу цены через пробел.\nНапример: <code>60 90</code>",
  topn:
    "Введи целевой топ, на котором бот остановится и оставит объявление активным.\nНапример: <code>10</code>, <code>20</code> или <code>40</code>.",
  paypass:
    "Введи свой <b>платёжный пароль Bybit</b> (нужен для авто-2FA при создании объявления).\n\n⚠️ Сообщение с паролем удалится сразу после сохранения.\nЕсли хочешь стереть текущий — введи <code>.</code>",
  floating_premium:
    "Напиши наценку в процентах.\n<code>100.00</code> — ровно по курсу Bybit, <code>99.99</code> — чуть ниже, <code>100.01</code> — чуть выше.",
};

// Простой кэш payment-list, чтобы не дёргать Bybit каждый клик
const paymentsCache = new Map<
  string,
  { at: number; list: PaymentMethod[] }
>();
const PAYMENTS_TTL_MS = 60_000;
async function getPaymentsCached(
  mode: UserSettingsRow["connection_mode"],
  chatId: number,
  force = false,
): Promise<PaymentMethod[]> {
  const cacheKey = `${chatId}:${mode}`;
  const cached = paymentsCache.get(cacheKey);
  if (!force && cached && Date.now() - cached.at < PAYMENTS_TTL_MS) {
    return cached.list;
  }
  const list = await withBybitConnection(
    mode,
    () => listPostAdPayments(),
    chatId,
  );
  paymentsCache.set(cacheKey, { at: Date.now(), list });
  return list;
}

export function clearPaymentsCache(chatId: number): void {
  paymentsCache.delete(`${chatId}:session`);
  paymentsCache.delete(`${chatId}:api`);
}

function chatIdOf(ctx: Context): number {
  const id = ctx.chat?.id;
  if (!id) throw new Error("No chat");
  return id;
}

function modeLabel(mode: UserSettingsRow["ad_mode"]): string {
  if (mode === "manual") return "ручное создание";
  return "автоцикл: 1 объявление";
}

function priceModeLabel(s: UserSettingsRow): string {
  if (s.price_mode === "fixed") return `своя цена ${s.price_fixed ?? "—"}`;
  return `от лучшей цены ${s.side === "1" ? "−" : "+"} ${s.price_step}`;
}

function priceTypeLabel(type: UserSettingsRow["primary_price_type"]): string {
  return type === "floating" ? "плавающая" : "фиксированная";
}

function usesFloatingSettings(s: UserSettingsRow): boolean {
  return s.primary_price_type === "floating";
}

function fmt(
  s: UserSettingsRow,
  side: SideSettingsRow,
  payments: PaymentMethod[],
): string {
  const sideLabel = s.side === "1" ? "SELL" : "BUY";
  const paymentNames = side.payment_ids.map((id) => {
    const p = payments.find((x) => String(x.id) === String(id));
    return p ? paymentLabel(p) : id;
  });
  const lines = [
    `⚙️ <b>Параметры</b>`,
    ``,
    `📈 Рынок: <b>${s.token_id}/${s.currency_id}</b> · ${s.side === "1" ? "продажа" : "покупка"}`,
    `🧮 Расчёт цены: <b>${priceModeLabel(s)}</b>`,
    `🏷 Вид цены: <b>${priceTypeLabel(s.primary_price_type)}</b>`,
    usesFloatingSettings(s)
      ? `％ Наценка: <b>${s.dual_ads_premium_mode === "auto" ? "подбирается сама" : `${s.dual_ads_premium_manual}%`}</b>`
      : null,
    `🛡 Коридор цены: <b>${s.price_min} … ${s.price_max}</b>`,
    ``,
    `💳 Сумма: ${side.quantity_auto ? "авто" : side.quantity} ${s.token_id} · лимит ${side.min_amount}–${side.max_amount} ${s.currency_id} · ${side.payment_period} мин`,
    `Реквизиты: ${paymentNames.length ? paymentNames.join(", ") : "не выбраны"}`,
  ].filter((line): line is string => line !== null);
  return lines.join("\n");
}

function keyboard(
  s: UserSettingsRow,
  side: SideSettingsRow,
): InlineKeyboard {
  const kb = new InlineKeyboard()
    .text(`📈 ${s.token_id}/${s.currency_id} · ${s.side === "1" ? "продажа" : "покупка"}`, "sm:market")
    .row()
    .text("🧮 Расчёт цены", "sm:price")
    .text("🛡 Коридор цены", "sm:safety")
    .row()
    .text("💳 Сумма и реквизиты", "sm:ad")
    .row()
    .text("💼 Мои объявления", "working_ads_open")
    .text("⬅️ Меню", "menu_open");
  return kb;
}

async function loadAll(chatId: number): Promise<{
  user: UserSettingsRow;
  side: SideSettingsRow;
  payments: PaymentMethod[];
}> {
  const user = await ensureSettings(chatId);
  const side = await ensureSideSettings(chatId, user.side);
  let payments: PaymentMethod[] = [];
  try {
    payments = await getPaymentsCached(user.connection_mode, chatId);
  } catch (err) {
    console.warn("listPostAdPayments failed:", err);
  }
  return { user, side, payments };
}

async function sendSettingsView(
  ctx: Context,
  text: string,
  replyMarkup: InlineKeyboard,
  edit: boolean,
): Promise<void> {
  if (edit && ctx.callbackQuery?.message) {
    await ctx
      .editMessageText(text, { parse_mode: "HTML", reply_markup: replyMarkup })
      .catch(async () => {
        await ctx.reply(text, { parse_mode: "HTML", reply_markup: replyMarkup });
      });
    return;
  }
  await ctx.reply(text, { parse_mode: "HTML", reply_markup: replyMarkup });
}

async function showSettings(
  ctx: Context,
  edit = false,
  section: SettingsSection = "main",
): Promise<void> {
  const { user, side, payments } = await loadAll(chatIdOf(ctx));
  if (section === "main") {
    await sendSettingsView(
      ctx,
      fmt(user, side, payments),
      keyboard(user, side),
      edit,
    );
    return;
  }
  const view = sectionView(section, user, side);
  await sendSettingsView(ctx, view.text, view.keyboard, edit);
}

export async function handleSettingsShow(ctx: Context): Promise<void> {
  await showSettings(ctx, false);
}

function backButton(kb: InlineKeyboard): InlineKeyboard {
  return kb.row().text("↩️ К параметрам", "sm:main");
}

function sectionView(
  section: Exclude<SettingsSection, "main">,
  s: UserSettingsRow,
  side: SideSettingsRow,
): { text: string; keyboard: InlineKeyboard } {
  if (section === "mode") {
    const kb = new InlineKeyboard()
      .text(`${s.ad_mode === "single" ? "✓ " : ""}Автоцикл 1`, "s:mode:single")
      .text(`${s.ad_mode === "manual" ? "✓ " : ""}Ручное создание`, "s:mode:manual");
    return {
      text: `🎛 <b>Режим работы</b>\n\nСейчас: <b>${modeLabel(s.ad_mode)}</b>`,
      keyboard: backButton(kb),
    };
  }

  if (section === "market") {
    const kb = new InlineKeyboard()
      .text(`${s.side === "0" ? "✅ " : ""}🟢 Покупаю`, "s:side:0")
      .text(`${s.side === "1" ? "✅ " : ""}🔴 Продаю`, "s:side:1")
      .row()
      .text(`🔁 Монета и валюта: ${s.token_id}/${s.currency_id}`, "s:in:pair");
    return {
      text: `📈 <b>Рынок</b>\n\nМонета / валюта: <b>${s.token_id} / ${s.currency_id}</b>\nНаправление: <b>${s.side === "1" ? "продаю" : "покупаю"}</b>`,
      keyboard: backButton(kb),
    };
  }

  if (section === "price") {
    const kb = new InlineKeyboard()
      .text(`${s.price_mode === "auto" ? "✅ " : ""}🤖 По рынку`, "s:auto")
      .text(
        `${s.price_mode === "fixed" ? "✅ " : ""}✍️ Своя цена${s.price_fixed ? `: ${s.price_fixed}` : ""}`,
        "s:in:fixed",
      );
    if (s.price_mode === "auto") {
      kb.row().text(`↕️ Отступ от лучшей цены: ${s.price_step}`, "s:in:step");
    }
    kb.row()
      .text(
        `${s.primary_price_type === "fixed" ? "✅ " : ""}📌 Фиксированная`,
        "s:ptype:fixed",
      )
      .text(
        `${s.primary_price_type === "floating" ? "✅ " : ""}📊 Плавающая`,
        "s:ptype:floating",
      );
    if (usesFloatingSettings(s)) {
      kb.row().text(
        `${s.dual_ads_premium_mode === "auto" ? "✅ " : ""}🤖 Наценка сама`,
        "s:floating:premium:auto",
      );
      kb.text(
        `${s.dual_ads_premium_mode === "manual" ? "✅ " : ""}✍️ Своя наценка`,
        "s:floating:premium:manual",
      );
      if (s.dual_ads_premium_mode === "manual") {
        kb.row().text(
          `％ Наценка: ${s.dual_ads_premium_manual}%`,
          "s:in:floating_premium",
        );
      }
    }
    const format = priceTypeLabel(s.primary_price_type);
    const premium = usesFloatingSettings(s)
      ? `\nНаценка: <b>${s.dual_ads_premium_mode === "auto" ? "подбирается сама" : `${s.dual_ads_premium_manual}%`}</b>`
      : "";
    return {
      text:
        `🧮 <b>Расчёт цены</b>\n\n` +
        `Способ: <b>${priceModeLabel(s)}</b>\n` +
        `Вид цены: <b>${format}</b>${premium}`,
      keyboard: backButton(kb),
    };
  }

  if (section === "ad") {
    const kb = new InlineKeyboard()
      .text(`💰 Объём: ${side.quantity_auto ? "авто" : side.quantity}`, "s:in:qty")
      .text(`↔️ Сделка: ${side.min_amount}–${side.max_amount}`, "s:in:range")
      .row()
      .text(`⏱ На оплату: ${side.payment_period} мин`, "s:in:period")
      .text(`🏦 Способы оплаты (${side.payment_ids.length})`, "s:payments")
      .row()
      .text(side.remark ? "📝 Примечание ✏️" : "📝 Примечание", "s:in:remark");
    if (s.connection_mode === "session") {
      kb.row().text(
        s.payment_password ? "Плат. пароль: ✓" : "Плат. пароль: не задан",
        "s:in:paypass",
      );
    }
    return {
      text:
        `💳 <b>Сумма и реквизиты</b>\n\n` +
        `Объём: <b>${side.quantity_auto ? "авто" : side.quantity} ${s.token_id}</b>\n` +
        `Сумма одной сделки: <b>от ${side.min_amount} до ${side.max_amount} ${s.currency_id}</b>\n` +
        `Время на оплату: <b>${side.payment_period} мин</b>\n` +
        `Способов оплаты: <b>${side.payment_ids.length}</b>\n` +
        `Примечание: ${side.remark || "—"}`,
      keyboard: backButton(kb),
    };
  }

  if (section === "safety") {
    const kb = new InlineKeyboard()
      .text(`✏️ Изменить: ${s.price_min} … ${s.price_max}`, "s:in:bounds");
    return {
      text:
        `🛡 <b>Коридор цены</b>\n\n` +
        `Бот не поставит цену ниже <b>${s.price_min}</b> и выше <b>${s.price_max}</b>.`,
      keyboard: backButton(kb),
    };
  }

  throw new Error(`Неизвестный раздел настроек: ${section}`);
}

async function showPaymentsPicker(ctx: Context, edit = true): Promise<void> {
  const chatId = chatIdOf(ctx);
  const { user, side } = await loadAll(chatId);
  let payments: PaymentMethod[];
  try {
    payments = await getPaymentsCached(user.connection_mode, chatId, true);
  } catch (err) {
    await ctx.reply(`❌ Не удалось получить список платёжек: ${(err as Error).message}`);
    return;
  }

  // Sanitize: выкидываем из БД ID которых нет в актуальном списке (мусор от seed-а или удалённые в Bybit).
  const validIds = new Set(payments.map((p) => String(p.id)));
  const cleaned = side.payment_ids.filter((id) => validIds.has(String(id)));
  if (cleaned.length !== side.payment_ids.length) {
    await updateSideSettings(chatId, user.side, { paymentIds: cleaned });
    side.payment_ids = cleaned;
  }

  const selected = new Set(side.payment_ids.map(String));
  const usableCount = payments.filter(isPaymentUsable).length;
  let statusLine: string;
  if (payments.length === 0) {
    statusLine =
      "У тебя нет реквизитов в Bybit. Добавь карту/СБП в <b>Profile → Payment Methods</b>, потом переоткрой /settings.";
  } else if (usableCount === 0) {
    statusLine = `Найдено ${payments.length} реквизитов, но все помечены ⚠️ (offline/не верифицированы). Включи Online и пройди верификацию в Bybit, потом переоткрой /settings.`;
  } else {
    statusLine =
      "Нажми на способ, чтобы включить или выключить.\n⚠️ — способ выключен или не подтверждён, Bybit его не примет.";
  }
  const text = [
    `🏦 <b>Способы оплаты · ${user.side === "1" ? "продаю" : "покупаю"}</b>`,
    ``,
    statusLine,
  ].join("\n");

  const kb = new InlineKeyboard();
  for (const p of payments) {
    const id = String(p.id);
    const checked = selected.has(id);
    const usable = isPaymentUsable(p);
    const prefix = checked ? "✅ " : "";
    const suffix = usable ? "" : " ⚠️";
    kb.text(`${prefix}${paymentLabel(p)}${suffix}`, `p:t:${id}`).row();
  }
  kb.text("✅ Готово", "p:done");

  if (edit && ctx.callbackQuery?.message) {
    await ctx.editMessageText(text, { parse_mode: "HTML", reply_markup: kb })
      .catch(async () => {
        await ctx.reply(text, { parse_mode: "HTML", reply_markup: kb });
      });
  } else {
    await ctx.reply(text, { parse_mode: "HTML", reply_markup: kb });
  }
}

export async function handleSettingsCallback(ctx: Context): Promise<void> {
  const data = ctx.callbackQuery?.data;
  if (!data) return;
  await ctx.answerCallbackQuery().catch(() => {});
  const chatId = chatIdOf(ctx);

  if (data.startsWith("sm:")) {
    const section = data.slice("sm:".length) as SettingsSection;
    if (
      ["main", "mode", "market", "price", "ad", "safety"].includes(
        section,
      )
    ) {
      await showSettings(ctx, true, section);
    }
    return;
  }

  if (data === "s:side:0" || data === "s:side:1") {
    const newSide: "0" | "1" = data === "s:side:1" ? "1" : "0";
    await updateSettings(chatId, { side: newSide });
    await ensureSideSettings(chatId, newSide);
    pending.delete(chatId);
    await showSettings(ctx, true, "market");
    return;
  }
  if (data === "s:auto") {
    await updateSettings(chatId, { priceMode: "auto", priceFixed: null });
    pending.delete(chatId);
    await showSettings(ctx, true, "price");
    return;
  }
  if (
    data === "s:mode:single" ||
    data === "s:mode:manual"
  ) {
    const mode = data.slice("s:mode:".length) as "single" | "manual";
    await updateSettings(chatId, {
      adMode: mode,
    });
    pending.delete(chatId);
    await showSettings(ctx, true, "mode");
    return;
  }
  if (data === "s:ptype:fixed" || data === "s:ptype:floating") {
    const primaryPriceType =
      data === "s:ptype:floating" ? "floating" : "fixed";
    await updateSettings(chatId, { primaryPriceType });
    pending.delete(chatId);
    await showSettings(ctx, true, "price");
    return;
  }
  if (
    data === "s:floating:premium:auto" ||
    data === "s:floating:premium:manual"
  ) {
    const dualAdsPremiumMode =
      data === "s:floating:premium:auto"
        ? "auto"
        : "manual";
    await updateSettings(chatId, {
      dualAdsPremiumMode,
    });
    pending.delete(chatId);
    await showSettings(ctx, true, "price");
    return;
  }
  if (data === "s:in:pair") {
    pending.set(chatId, {
      field: "token",
      until: Date.now() + PENDING_TTL_MS,
      returnSection: "market",
    });
    await ctx.reply("Сначала введи токен (USDT). После этого попрошу валюту.");
    return;
  }
  if (data === "s:payments") {
    await showPaymentsPicker(ctx, true);
    return;
  }
  if (data === "p:done") {
    await showSettings(ctx, true, "ad");
    return;
  }
  if (data.startsWith("p:t:")) {
    const id = data.slice("p:t:".length);
    const user = await ensureSettings(chatId);
    const side = await ensureSideSettings(chatId, user.side);
    const set = new Set(side.payment_ids.map(String));
    if (set.has(id)) set.delete(id);
    else set.add(id);
    await updateSideSettings(chatId, user.side, { paymentIds: [...set] });
    await showPaymentsPicker(ctx, true);
    return;
  }
  if (data.startsWith("s:in:")) {
    const field = data.slice("s:in:".length) as InputField;
    if (!(field in PROMPTS)) return;
    pending.set(chatId, {
      field,
      until: Date.now() + PENDING_TTL_MS,
      returnSection: sectionForInput(field),
    });
    await ctx.reply(PROMPTS[field] + "\n\n/cancel — отменить", {
      parse_mode: "HTML",
    });
    return;
  }
}

export async function handleCancelInput(ctx: Context): Promise<void> {
  pending.delete(chatIdOf(ctx));
  await ctx.reply("Отменено.");
}

export async function consumePendingInput(ctx: Context): Promise<boolean> {
  const chatId = chatIdOf(ctx);
  const p = pending.get(chatId);
  if (!p) return false;
  if (p.until < Date.now()) {
    pending.delete(chatId);
    return false;
  }
  const text = ctx.message?.text;
  if (!text) return false;
  if (text.startsWith("/")) return false;

  try {
    const next = await applyValue(chatId, p.field, text.trim());
    // Сообщение с паролем стираем чтобы не висело в чате.
    if (p.field === "paypass") {
      await ctx.deleteMessage().catch(() => {});
    }
    if (next) {
      pending.set(chatId, {
        field: next,
        until: Date.now() + PENDING_TTL_MS,
        returnSection: p.returnSection,
      });
      await ctx.reply(PROMPTS[next] + "\n\n/cancel — отменить", {
        parse_mode: "HTML",
      });
    } else {
      pending.delete(chatId);
      await showSettings(ctx, false, p.returnSection);
    }
  } catch (err) {
    await ctx.reply(`❌ ${(err as Error).message}`);
  }
  return true;
}

function sectionForInput(field: InputField): SettingsSection {
  if (field === "token" || field === "currency") return "market";
  if (field === "step" || field === "fixed" || field === "floating_premium") {
    return "price";
  }
  if (field === "bounds" || field === "topn") return "safety";
  return "ad";
}

async function applyValue(
  chatId: number,
  field: InputField,
  value: string,
): Promise<InputField | null> {
  const user = await ensureSettings(chatId);
  const requirePositive = (s: string): number => {
    const n = Number(s);
    if (!Number.isFinite(n) || n <= 0) throw new Error(`Не число или ≤ 0: ${s}`);
    return n;
  };

  switch (field) {
    // Side-specific:
    case "qty":
      if (value.toLowerCase() === "auto") {
        await updateSideSettings(chatId, user.side, { quantityAuto: true });
        return null;
      }
      requirePositive(value);
      await updateSideSettings(chatId, user.side, {
        quantity: value,
        quantityAuto: false,
      });
      return null;
    case "range": {
      // Принимаем любые разделители: пробел, запятая, тире, дефис
      const parts = value
        .split(/[\s,\-–—]+/)
        .map((s) => s.trim())
        .filter(Boolean);
      if (parts.length !== 2)
        throw new Error("Нужно два числа: min и max (например `500 1000`)");
      const min = requirePositive(parts[0]!);
      const max = requirePositive(parts[1]!);
      if (min >= max) throw new Error("min должен быть < max");
      await updateSideSettings(chatId, user.side, {
        minAmount: String(min),
        maxAmount: String(max),
      });
      return null;
    }
    case "period":
      requirePositive(value);
      await updateSideSettings(chatId, user.side, { paymentPeriod: value });
      return null;
    case "remark": {
      const remark = value === "." ? "" : value;
      await updateSideSettings(chatId, user.side, { remark });
      return null;
    }
    // Global:
    case "step": {
      const n = Number(value);
      if (!Number.isFinite(n) || n < 0)
        throw new Error("Шаг должен быть ≥ 0 (0 = ставить как у топа)");
      await updateSettings(chatId, { priceStep: value, priceMode: "auto" });
      return null;
    }
    case "fixed":
      requirePositive(value);
      await updateSettings(chatId, { priceMode: "fixed", priceFixed: value });
      return null;
    case "token":
      if (!/^[a-z0-9]{2,10}$/i.test(value)) throw new Error("Странный токен");
      await updateSettings(chatId, { tokenId: value.toUpperCase() });
      return "currency";
    case "currency":
      if (!/^[a-z]{3,5}$/i.test(value)) throw new Error("Странная валюта");
      await updateSettings(chatId, { currencyId: value.toUpperCase() });
      return null;
    case "bounds": {
      const parts = value.split(/\s+/);
      if (parts.length !== 2) throw new Error("Нужно два числа через пробел");
      const min = Number(parts[0]);
      const max = Number(parts[1]);
      if (!Number.isFinite(min) || !Number.isFinite(max) || min >= max) {
        throw new Error("Невалидные min/max");
      }
      await updateSettings(chatId, {
        priceMin: String(min),
        priceMax: String(max),
      });
      return null;
    }
    case "topn": {
      const n = Number(value);
      if (!Number.isSafeInteger(n) || n < 1 || n > 200) {
        throw new Error("Top должен быть целым числом от 1 до 200");
      }
      await updateSettings(chatId, { bourseTopN: n });
      return null;
    }
    case "paypass": {
      const paymentPassword = value === "." ? null : value;
      await updateSettings(chatId, { paymentPassword });
      return null;
    }
    case "floating_premium": {
      const n = Number(value);
      if (!Number.isFinite(n) || n <= 0) {
        throw new Error("Premium должен быть числом > 0, например 100.00");
      }
      await updateSettings(chatId, {
        dualAdsPremiumManual: n.toFixed(2),
        dualAdsPremiumMode: "manual",
      });
      return null;
    }
  }
}
