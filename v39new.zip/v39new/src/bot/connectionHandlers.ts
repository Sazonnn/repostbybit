import type { Context } from "grammy";
import { InlineKeyboard } from "grammy";
import {
  checkOfficialApi,
  hasOfficialApiCredentials,
  maskApiKey,
  withBybitConnection,
  withOfficialApiCredentials,
} from "../bybit/index.js";
import {
  activateApiAccount,
  deleteApiAccount,
  getActiveApiAccount,
  listApiAccounts,
  saveApiAccount,
} from "../db/repositories/apiAccounts.js";
import { getActiveCycleByChat } from "../db/repositories/cycles.js";
import { listActiveManualAds } from "../db/repositories/manualAds.js";
import {
  ensureSettings,
  updateSettings,
} from "../db/repositories/userSettings.js";
import { clearPaymentsCache } from "./settingsHandlers.js";

type ApiInputStep = "name" | "key" | "secret";

interface PendingApiAccount {
  step: ApiInputStep;
  until: number;
  name?: string;
  apiKey?: string;
}

const INPUT_TTL_MS = 5 * 60_000;
const pendingApiAccounts = new Map<number, PendingApiAccount>();

function setPendingApiAccount(
  chatId: number,
  value: Omit<PendingApiAccount, "until">,
): void {
  const until = Date.now() + INPUT_TTL_MS;
  pendingApiAccounts.set(chatId, { ...value, until });
  const timer = setTimeout(() => {
    const current = pendingApiAccounts.get(chatId);
    if (current?.until === until) pendingApiAccounts.delete(chatId);
  }, INPUT_TTL_MS + 1000);
  timer.unref();
}

function chatIdOf(ctx: Context): number {
  const id = ctx.chat?.id;
  if (!id) throw new Error("No chat");
  return id;
}

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

async function hasActiveWork(chatId: number): Promise<boolean> {
  const [cycle, manualAds] = await Promise.all([
    getActiveCycleByChat(chatId),
    listActiveManualAds(chatId),
  ]);
  return Boolean(cycle || manualAds.length > 0);
}

async function requireIdle(ctx: Context): Promise<boolean> {
  if (!(await hasActiveWork(chatIdOf(ctx)))) return true;
  await ctx.reply(
    "⛔️ Сначала останови цикл и сними ручные объявления. Подключение и API-аккаунт нельзя менять во время активной работы.",
  );
  return false;
}

async function renderConnection(ctx: Context, edit: boolean): Promise<void> {
  const chatId = chatIdOf(ctx);
  const [settings, accounts, activeApi] = await Promise.all([
    ensureSettings(chatId),
    listApiAccounts(chatId),
    getActiveApiAccount(chatId),
  ]);
  if (settings.connection_mode !== "api") {
    await updateSettings(chatId, { connectionMode: "api" });
    clearPaymentsCache(chatId);
  }
  const apiStatus = activeApi
    ? `<b>${escapeHtml(activeApi.name)}</b> · <code>${escapeHtml(activeApi.keyHint)}</code>`
    : hasOfficialApiCredentials()
      ? `резервный ключ сервера ${maskApiKey()}`
      : "ключ ещё не добавлен";
  const keyboard = new InlineKeyboard();
  for (const account of accounts.slice(0, 10)) {
    keyboard
      .text(
        `${account.isActive ? "✓ " : ""}${account.name} · ${account.keyHint}`,
        `c:account:${account.id}`,
      )
      .text("🗑", `c:delete:${account.id}`)
      .row();
  }
  keyboard
    .text("➕ Добавить ключ", "c:add")
    .text("🩺 Проверить", "c:test")
    .row()
    .text("⬅️ Меню", "menu_open");

  const text = [
    "🔑 <b>API-ключ Bybit</b>",
    "",
    `Активный: ${apiStatus}`,
    "",
    "Ключ и секрет вводятся прямо в чате: сообщения сразу удаляются, данные хранятся только на сервере в зашифрованном виде.",
    "Нужен HMAC-ключ с правами P2P, без права вывода.",
  ].join("\n");
  if (edit && ctx.callbackQuery?.message) {
    await ctx
      .editMessageText(text, { parse_mode: "HTML", reply_markup: keyboard })
      .catch(async () => {
        await ctx.reply(text, { parse_mode: "HTML", reply_markup: keyboard });
      });
    return;
  }
  await ctx.reply(text, { parse_mode: "HTML", reply_markup: keyboard });
}

export async function handleConnectionShow(ctx: Context): Promise<void> {
  await renderConnection(ctx, false);
}

export async function handleConnectionCallback(ctx: Context): Promise<void> {
  const data = ctx.callbackQuery?.data;
  if (!data) return;
  await ctx.answerCallbackQuery().catch(() => {});
  const chatId = chatIdOf(ctx);

  if (data === "c:add") {
    if (!(await requireIdle(ctx))) return;
    setPendingApiAccount(chatId, {
      step: "name",
    });
    await ctx.reply(
      "Введи название аккаунта, которое будет видно только в панели.\nНапример: <code>Основной RUB</code>\n\n/cancel — отменить",
      { parse_mode: "HTML" },
    );
    return;
  }

  if (data.startsWith("c:account:")) {
    if (!(await requireIdle(ctx))) return;
    const accountId = Number(data.slice("c:account:".length));
    if (!Number.isSafeInteger(accountId)) return;
    await activateApiAccount(chatId, accountId);
    await updateSettings(chatId, { connectionMode: "api" });
    clearPaymentsCache(chatId);
    await renderConnection(ctx, true);
    return;
  }

  if (data.startsWith("c:delete:")) {
    if (!(await requireIdle(ctx))) return;
    const accountId = Number(data.slice("c:delete:".length));
    if (!Number.isSafeInteger(accountId)) return;
    const account = (await listApiAccounts(chatId)).find(
      (item) => item.id === accountId,
    );
    if (!account) return;
    const keyboard = new InlineKeyboard()
      .text("Удалить", `c:delete_confirm:${accountId}`)
      .text("Отмена", "c:back");
    await ctx.reply(
      `Удалить API-аккаунт <b>${escapeHtml(account.name)}</b>?\nКлюч и Secret будут удалены из базы.`,
      { parse_mode: "HTML", reply_markup: keyboard },
    );
    return;
  }

  if (data.startsWith("c:delete_confirm:")) {
    if (!(await requireIdle(ctx))) return;
    const accountId = Number(data.slice("c:delete_confirm:".length));
    if (!Number.isSafeInteger(accountId)) return;
    await deleteApiAccount(chatId, accountId);
    const remaining = await getActiveApiAccount(chatId);
    void remaining;
    clearPaymentsCache(chatId);
    await renderConnection(ctx, true);
    return;
  }

  if (data === "c:back") {
    await renderConnection(ctx, true);
    return;
  }

  if (data === "c:test") {
    const settings = await ensureSettings(chatId);
    await ctx.reply("🩺 Проверяю ключ, аккаунт, стакан и объявления…");
    try {
      const result = await withBybitConnection(
        "api",
        () =>
          checkOfficialApi({
            tokenId: settings.token_id,
            currencyId: settings.currency_id,
            side: settings.side,
          }),
        chatId,
      );
      await ctx.reply(
        [
          "✅ <b>Ключ работает</b>",
          `uid: ${String(result.account.userId ?? "?")}`,
          `ник: ${String(result.account.nickName ?? "?")}`,
          `в стакане получено: ${result.onlineAds}`,
          `ваших объявлений: ${result.ownAds}`,
          `реквизитов: ${result.payments}`,
        ].join("\n"),
        { parse_mode: "HTML" },
      );
    } catch (err) {
      await ctx.reply(`❌ Проверка не пройдена: ${(err as Error).message}`);
    }
  }
}

export async function consumeApiAccountInput(
  ctx: Context,
): Promise<boolean> {
  const chatId = chatIdOf(ctx);
  const pending = pendingApiAccounts.get(chatId);
  if (!pending) return false;
  if (pending.until < Date.now()) {
    pendingApiAccounts.delete(chatId);
    return false;
  }
  const text = ctx.message?.text?.trim();
  if (!text || text.startsWith("/")) return false;

  if (pending.step === "name") {
    if (text.length < 1 || text.length > 40) {
      await ctx.reply("Название должно быть длиной от 1 до 40 символов.");
      return true;
    }
    setPendingApiAccount(chatId, {
      step: "key",
      name: text,
    });
    await ctx.reply(
      "Теперь отправь <b>API Key</b>. Нужен системный HMAC-ключ Bybit с разрешением P2P. Сообщение будет сразу удалено.\n\n/cancel — отменить",
      { parse_mode: "HTML" },
    );
    return true;
  }

  const deleted = await ctx
    .deleteMessage()
    .then(() => true)
    .catch(() => false);

  if (pending.step === "key") {
    if (text.length < 8 || text.length > 200) {
      await ctx.reply("API Key выглядит некорректно. Отправь его ещё раз.");
      return true;
    }
    setPendingApiAccount(chatId, {
      step: "secret",
      name: pending.name,
      apiKey: text,
    });
    await ctx.reply(
      `${deleted ? "✅ Сообщение с ключом удалено." : "⚠️ Telegram не дал удалить сообщение с ключом. Удали его вручную."}\nТеперь отправь <b>API Secret</b>. Он тоже будет удалён.\n\n/cancel — отменить`,
      { parse_mode: "HTML" },
    );
    return true;
  }

  if (!pending.name || !pending.apiKey) {
    pendingApiAccounts.delete(chatId);
    await ctx.reply("❌ Данные ввода потерялись. Начни добавление заново.");
    return true;
  }
  if (text.length < 8 || text.length > 300) {
    await ctx.reply("API Secret выглядит некорректно. Отправь его ещё раз.");
    return true;
  }

  await ctx.reply(
    `${deleted ? "✅ Сообщение с секретом удалено." : "⚠️ Telegram не дал удалить сообщение с секретом. Удали его вручную."}\n🔎 Проверяю ключ через Bybit без создания объявлений…`,
  );

  try {
    const settings = await ensureSettings(chatId);
    await withOfficialApiCredentials(
      { apiKey: pending.apiKey, apiSecret: text },
      () =>
        checkOfficialApi({
          tokenId: settings.token_id,
          currencyId: settings.currency_id,
          side: settings.side,
        }),
      chatId,
    );
  } catch (err) {
    await ctx.reply(
      `❌ Bybit не принял API-аккаунт: ${(err as Error).message}\nCredentials не сохранены. Проверь права P2P, тип ключа HMAC, IP-ограничения и отправь Secret ещё раз либо /cancel.`,
    );
    return true;
  }

  let account;
  try {
    account = await saveApiAccount({
      chatId,
      name: pending.name,
      apiKey: pending.apiKey,
      apiSecret: text,
    });
  } catch (err) {
    await ctx.reply(
      `❌ Не удалось зашифровать или сохранить API-аккаунт: ${(err as Error).message}\nОтправь Secret ещё раз или /cancel.`,
    );
    return true;
  }
  pendingApiAccounts.delete(chatId);
  await updateSettings(chatId, { connectionMode: "api" });
  clearPaymentsCache(chatId);
  await ctx.reply(
    `✅ API-аккаунт прошёл проверку, сохранён и выбран.\nАккаунт: <b>${escapeHtml(account.name)}</b>\nКлюч: <code>${escapeHtml(account.keyHint)}</code>.\n\nСоздание объявлений во время проверки не выполнялось.`,
    { parse_mode: "HTML" },
  );
  await renderConnection(ctx, false);
  return true;
}

export function cancelApiAccountInput(chatId: number): boolean {
  return pendingApiAccounts.delete(chatId);
}
