import { buildBot } from "./bot/index.js";
import { closeHttpSession } from "./bybit/client.js";
import { runMigrations } from "./db/migrate.js";
import { pool } from "./db/pool.js";
import { hasUsersUsingSessionConnection } from "./db/repositories/userSettings.js";
import { readPanelConfig } from "./web/auth.js";
import { startPanel } from "./web/server.js";
import { createPanelAdapter } from "./web/adapter.js";
import { PanelTelemetry } from "./web/telemetry.js";
import { startLoopLagDiag } from "./diag/loopLag.js";

async function main() {
  startLoopLagDiag();
  console.log("Running migrations…");
  await runMigrations();

  const panelConfig = readPanelConfig();
  const telemetry = panelConfig ? new PanelTelemetry(panelConfig.chatId) : null;
  const { bot, runner, sessionWatcher, workingAdsManager } = buildBot(event => telemetry?.observe(event));
  // Bind before resuming trading: a second web-enabled process must fail before starting workers.
  const panel = panelConfig ? await startPanel(panelConfig,
    createPanelAdapter(panelConfig.chatId, workingAdsManager, telemetry!)) : null;
  if (panelConfig) console.log(`Web panel: ${panelConfig.origin}`);

  // Если в существующей сессии ника нет — подтянем при старте.
  try {
    if (await hasUsersUsingSessionConnection()) {
      const { authService } = await import("./auth/authService.js");
      const s = await authService.getCurrent();
      if (s && !s.nickname) {
        const { getMyMerchantInfo } = await import("./bybit/profile.js");
        const info = await getMyMerchantInfo();
        if (info.nickName) {
          await authService.setNickname(s.id, info.nickName);
          console.log(`Подтянут ник профиля: ${info.nickName}`);
        }
      }
    }
  } catch (err) {
    console.warn("Не удалось подтянуть ник на старте:", err);
  }

  await runner.resumeAll();
  await workingAdsManager.resumeAll();
  sessionWatcher.start();

  const shutdown = async () => {
    console.log("Shutting down…");
    sessionWatcher.stop();
    workingAdsManager.stopAll();
    await panel?.close();
    await bot.stop();
    await closeHttpSession();
    await pool.end();
    process.exit(0);
  };
  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);

  console.log("Starting bybit_bot…");
  await bot.start({
    onStart: (info) => console.log(`Bot @${info.username} is running`),
  });
}

main().catch((err) => {
  console.error("Fatal:", err);
  process.exit(1);
});
