// ---- Несколько адресов стакана + несколько запросов за одно чтение ----
//
// Замер 04.10 (stakan-race): новый топ-1 расходится по узлам Bybit за 0,6–0,8 с.
// Всё это время одни ответы показывают новую цену, другие — старую, причём
// "быстрый" адрес каждый раз другой (и даже один адрес отвечает то новой, то
// старой ценой). Поэтому в окне смены курса бот за одно чтение шлёт сразу
// несколько запросов — с разных IP на разные адреса — и берёт первый ответ с
// НОВЫМ топ-1. Ответ со старым топ-1 от отставшего узла не используется, пока
// есть ответ с текущим.
//
// .env:
//   STAKAN_HOSTS=www.bybit.com,api2.bybit.com,api2.bytick.com,www.bytick.com,www.bybitglobal.com
//       адреса стакана (через запятую). Нет переменной — только www.bybit.com,
//       поведение как раньше.
//   STAKAN_FANOUT=3
//       сколько запросов за одно чтение в окне смены курса (1..6). По умолчанию
//       3, если адресов больше одного, иначе 1 (как раньше). Вне окна — всегда 1.
import { inRateWindow } from "./stakanSources.js";

export interface StakanHost {
  name: string;
  url: string;
  origin: string;
}

export const DEFAULT_STAKAN_HOST = "www.bybit.com";

function hostEntry(name: string): StakanHost {
  const domain = name.split(".").slice(-2).join(".");
  return {
    name,
    // api2.* отдаёт тот же стакан без префикса /x-api.
    url: name.startsWith("api2.") ? `https://${name}/fiat/otc/item/online` : `https://${name}/x-api/fiat/otc/item/online`,
    origin: `https://www.${domain}`,
  };
}

let hostsCache: StakanHost[] | null = null;

/** Адреса стакана из STAKAN_HOSTS (www.bybit.com есть всегда и идёт первым). */
export function stakanHosts(): StakanHost[] {
  if (hostsCache) return hostsCache;
  const names = [DEFAULT_STAKAN_HOST];
  for (const raw of (process.env.STAKAN_HOSTS ?? "").split(",")) {
    const name = raw.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
    if (!name) continue;
    if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(name)) {
      console.warn(`[stakan] STAKAN_HOSTS: пропускаю "${raw.trim()}" — это не имя сайта`);
      continue;
    }
    if (!names.includes(name)) names.push(name);
  }
  hostsCache = names.map(hostEntry);
  return hostsCache;
}

let sizeCache: number | null = null;

/** Сколько запросов за одно чтение в окне смены курса (STAKAN_FANOUT). */
export function stakanFanoutSize(): number {
  if (sizeCache !== null) return sizeCache;
  const raw = process.env.STAKAN_FANOUT;
  const value = Number(raw);
  sizeCache = raw !== undefined && raw.trim() !== "" && Number.isInteger(value) && value >= 1 && value <= 6
    ? value
    : stakanHosts().length > 1 ? 3 : 1;
  if (sizeCache > 1 || stakanHosts().length > 1) {
    console.log(`[stakan] адреса стакана: ${stakanHosts().map((host) => host.name).join(", ")}; в окне смены курса — ` +
      `${sizeCache} запрос(а) за одно чтение с разных IP на разные адреса (STAKAN_FANOUT=${sizeCache}), ` +
      `беру первый ответ с новым топ-1`);
  }
  return sizeCache;
}

/** Сейчас читаем стакан несколькими запросами сразу. */
export function stakanFanoutActive(now = Date.now()): boolean {
  return stakanFanoutSize() > 1 && inRateWindow(now);
}

/** Во сколько раз одно чтение сейчас "тяжелее" обычного (для расчёта интервала на IP). */
export function stakanFanoutFactor(now = Date.now()): number {
  return stakanFanoutActive(now) ? stakanFanoutSize() : 1;
}

// ---- Паузы адресов ----
// Сбой дополнительного запроса не трогает IP целиком: на паузу уходит только
// этот адрес (для всех IP — если он не отдаёт стакан вообще, или для одного
// IP — если лимит/обрыв связи именно на этой паре).
const hostPause = new Map<string, number>();
const pairPause = new Map<string, number>();
const pauseLogAt = new Map<string, number>();
const PAUSE_LOG_EVERY_MS = 30_000;
let hostCursor = 0;

/** Адрес стакана на паузу. sourceLabel=null — для всех IP. */
export function pauseStakanHost(host: string, sourceLabel: string | null, ms: number, reason: string): void {
  const now = Date.now();
  const key = sourceLabel === null ? host : `${sourceLabel}|${host}`;
  const map = sourceLabel === null ? hostPause : pairPause;
  map.set(key, Math.max(map.get(key) ?? 0, now + ms));
  if (now - (pauseLogAt.get(key) ?? 0) >= PAUSE_LOG_EVERY_MS) {
    pauseLogAt.set(key, now);
    console.warn(`[stakan] адрес ${host}${sourceLabel === null ? "" : ` через ${sourceLabel}`}: ${reason} — ` +
      `не использую ${ms >= 60_000 ? `${Math.round(ms / 60_000)} мин` : `${Math.round(ms / 1000)} с`}` +
      ` (основное чтение www.bybit.com не затронуто)`);
  }
}

/** Следующий по кругу адрес для дополнительного запроса; taken — уже занятые в этой пачке. */
export function nextStakanHost(sourceLabel: string, taken?: Set<string>, now = Date.now()): StakanHost | null {
  const hosts = stakanHosts();
  for (let step = 0; step < hosts.length; step += 1) {
    const host = hosts[(hostCursor + step) % hosts.length]!;
    if (taken?.has(host.name)) continue;
    if ((hostPause.get(host.name) ?? 0) > now) continue;
    if ((pairPause.get(`${sourceLabel}|${host.name}`) ?? 0) > now) continue;
    hostCursor = (hostCursor + step + 1) % hosts.length;
    return host;
  }
  return null;
}

// ---- Что считать новостью ----
const EPS = 0.005;
// Топ-1, который был текущим меньше стольких мс назад, считаем "прошлым":
// ответ с ним — скорее всего отставший узел (в замере узлы отставали до ~1 с).
const RECENT_MS = 3_000;
// Ответ с новым топ-1, пришедший ПОСЛЕ того, как чтение уже отдало результат,
// ждёт следующего чтения не дольше этого.
const PENDING_MAX_MS = 400;
// Первый ответ без новостей придерживаем до стольких мс от начала чтения —
// вдруг другой запрос этой же пачки принесёт новый топ-1. Следующее чтение всё
// равно начнётся не раньше, чем через интервал чтения, поэтому ждём почти весь
// интервал (но отдаём сразу, как только ответили все запросы пачки).
let graceMs = 50;

/** Интервал между чтениями стакана сейчас (от него считается ожидание пачки). */
export function setStakanFanoutSpacing(spacingMs: number): void {
  graceMs = Math.max(40, Math.min(120, Math.round(spacingMs) - 15));
}
// Если ответа с текущим топ-1 нет (все показывают прошлый) — дольше не ждём.
const DEADLINE_MS = 400;
// Столько чтений подряд все запросы показали один и тот же прошлый топ-1 —
// значит, топ-1 действительно вернулся.
const STALE_ACCEPT_BATCHES = 3;

export interface FanoutAnswer<T> {
  value: T;
  // Топ-1 по чужим объявлениям в этом ответе.
  top: number | null;
  label: string;
  host: string;
  extra: boolean;
}

type AnswerClass = "news" | "same" | "stale";

interface MarketState {
  current: number | null;
  recent: Map<string, number>;
  pending: { bodyKey: string; answer: FanoutAnswer<unknown>; at: number } | null;
  staleRun: { top: number; count: number } | null;
}

const markets = new Map<string, MarketState>();

function marketState(key: string): MarketState {
  let state = markets.get(key);
  if (!state) {
    state = { current: null, recent: new Map(), pending: null, staleRun: null };
    markets.set(key, state);
  }
  return state;
}

function classify(state: MarketState, top: number | null, now: number): AnswerClass {
  if (top === null || state.current === null) return "same";
  if (Math.abs(top - state.current) < EPS) return "same";
  const leftAt = state.recent.get(top.toFixed(2));
  return leftAt !== undefined && now - leftAt <= RECENT_MS ? "stale" : "news";
}

function accept(state: MarketState, top: number | null, now: number): void {
  state.staleRun = null;
  if (top === null) return;
  if (state.current !== null && Math.abs(top - state.current) >= EPS) {
    state.recent.set(state.current.toFixed(2), now);
    for (const [key, at] of state.recent) if (now - at > RECENT_MS) state.recent.delete(key);
  }
  state.recent.delete(top.toFixed(2));
  state.current = top;
}

/** Чем был бы ответ с таким топ-1 прямо сейчас (для фильтра по серверному времени). */
export function stakanAnswerClass(marketKey: string, top: number | null, now = Date.now()): AnswerClass {
  return classify(marketState(marketKey), top, now);
}

// ---- Статистика за минуту ----
const stats = {
  startedAt: Date.now(), batches: 0, newsPrimary: 0, newsExtra: 0, newsPending: 0, staleHeld: 0, staleSettled: 0,
  hosts: new Map<string, { ok: number; fail: number; totalMs: number }>(),
};

/** Учёт дополнительного запроса на адрес (для строки статистики). */
export function noteStakanHostRead(host: string, ms: number, ok: boolean): void {
  const entry = stats.hosts.get(host) ?? { ok: 0, fail: 0, totalMs: 0 };
  if (ok) { entry.ok += 1; entry.totalMs += ms; } else { entry.fail += 1; }
  stats.hosts.set(host, entry);
}

function statsTick(now: number): void {
  if (now - stats.startedAt < 60_000) return;
  if (stats.batches > 0) {
    const hosts = [...stats.hosts].map(([name, entry]) =>
      `${name}: ${entry.ok} чт.${entry.ok ? `, ср ${Math.round(entry.totalMs / entry.ok)} мс` : ""}` +
      (entry.fail ? `, сбоев ${entry.fail}` : "")).join("; ");
    console.log(`[stakan] несколько адресов за ${Math.round((now - stats.startedAt) / 1000)} с: чтений ${stats.batches}; ` +
      `новый топ-1 первым принёс основной запрос ${stats.newsPrimary} раз, дополнительный ${stats.newsExtra} раз` +
      (stats.newsPending ? `, из них с опозданием (к следующему чтению) ${stats.newsPending}` : "") +
      `; ответов с прошлым топ-1 отсеяно ${stats.staleHeld}` +
      (stats.staleSettled ? `, отдано боту (все запросы показали прошлый топ-1) ${stats.staleSettled}` : "") +
      (hosts ? `. Доп. запросы — ${hosts}` : ""));
  }
  Object.assign(stats, { startedAt: now, batches: 0, newsPrimary: 0, newsExtra: 0, newsPending: 0, staleHeld: 0, staleSettled: 0 });
  stats.hosts.clear();
}

/** Новый топ-1, пришедший после конца прошлого чтения (если он ещё новость). */
export function takePendingStakanNews<T>(marketKey: string, bodyKey: string, now = Date.now()): FanoutAnswer<T> | null {
  const state = marketState(marketKey);
  const pending = state.pending;
  if (!pending) return null;
  state.pending = null;
  if (pending.bodyKey !== bodyKey || now - pending.at > PENDING_MAX_MS) return null;
  if (classify(state, pending.answer.top, now) !== "news") return null;
  accept(state, pending.answer.top, now);
  stats.newsPending += 1;
  if (pending.answer.extra) stats.newsExtra += 1; else stats.newsPrimary += 1;
  return pending.answer as FanoutAnswer<T>;
}

/**
 * Одно чтение стакана несколькими запросами. launch[0] — основной запрос
 * (может завершиться ошибкой), остальные — дополнительные (null = не удался).
 *
 * Правила:
 *  - ответ с новым топ-1 — отдаём сразу;
 *  - ответ с текущим топ-1 — отдаём, когда ответили все или прошло graceMs
 *    (вдруг другой запрос пачки принесёт новый топ-1);
 *  - ответ с прошлым топ-1 (отставший узел) — отдаём, только если ни один
 *    запрос не показал текущий (тогда решает защита пары от "возвратов").
 */
export function runStakanFanout<T>(args: {
  marketKey: string;
  bodyKey: string;
  launch: Array<() => Promise<FanoutAnswer<T> | null>>;
}): Promise<FanoutAnswer<T>> {
  const state = marketState(args.marketKey);
  const total = args.launch.length;
  stats.batches += 1;
  statsTick(Date.now());
  return new Promise<FanoutAnswer<T>>((resolve, reject) => {
    let settled = false;
    let done = 0;
    let graceOver = false;
    let deadlineOver = false;
    let sameHeld: FanoutAnswer<T> | null = null;
    let staleHeld: FanoutAnswer<T> | null = null;
    let failure: unknown = null;
    const settle = (answer: FanoutAnswer<T>, kind: AnswerClass) => {
      if (settled) return;
      settled = true;
      clearTimeout(graceTimer);
      clearTimeout(deadlineTimer);
      const now = Date.now();
      if (kind === "stale") {
        // Текущий топ-1 не меняем: если это отставшие узлы, следующий ответ с
        // настоящим топ-1 не должен выглядеть "прошлым". Но несколько чтений
        // подряд с одним и тем же прошлым топ-1 — уже настоящий возврат.
        stats.staleSettled += 1;
        const top = answer.top!;
        state.staleRun = state.staleRun && Math.abs(state.staleRun.top - top) < EPS
          ? { top, count: state.staleRun.count + 1 } : { top, count: 1 };
        if (state.staleRun.count >= STALE_ACCEPT_BATCHES) accept(state, top, now);
      } else {
        if (kind === "news") { if (answer.extra) stats.newsExtra += 1; else stats.newsPrimary += 1; }
        accept(state, answer.top, now);
      }
      resolve(answer);
    };
    const finishIfDone = () => {
      if (settled || done < total) return;
      if (sameHeld) settle(sameHeld, "same");
      else if (staleHeld) settle(staleHeld, "stale");
      else {
        settled = true;
        clearTimeout(graceTimer);
        clearTimeout(deadlineTimer);
        reject(failure ?? new Error("Bybit public P2P: ни один запрос стакана не ответил"));
      }
    };
    const graceTimer = setTimeout(() => {
      graceOver = true;
      if (sameHeld) settle(sameHeld, "same");
    }, graceMs);
    const deadlineTimer = setTimeout(() => {
      deadlineOver = true;
      if (sameHeld) settle(sameHeld, "same");
      else if (staleHeld) settle(staleHeld, "stale");
    }, DEADLINE_MS);
    const onAnswer = (answer: FanoutAnswer<T> | null) => {
      done += 1;
      if (!answer) { finishIfDone(); return; }
      const now = Date.now();
      const kind = classify(state, answer.top, now);
      if (settled) {
        // Чтение уже отдало результат, а этот ответ принёс новый топ-1 —
        // оставляем его следующему чтению (оно отдаст его без запроса).
        if (kind === "news") state.pending = { bodyKey: args.bodyKey, answer: answer as FanoutAnswer<unknown>, at: now };
        return;
      }
      if (kind === "news") { settle(answer, "news"); return; }
      if (kind === "same") {
        sameHeld ??= answer;
        if (graceOver || done >= total) settle(sameHeld, "same");
        return;
      }
      stats.staleHeld += 1;
      staleHeld ??= answer;
      if (deadlineOver) settle(staleHeld, "stale");
      else finishIfDone();
    };
    args.launch.forEach((start, index) => {
      let promise: Promise<FanoutAnswer<T> | null>;
      try { promise = start(); } catch (error) { promise = Promise.reject(error); }
      promise.then(onAnswer, (error: unknown) => {
        if (index === 0 || failure === null) failure = error;
        done += 1;
        finishIfDone();
      });
    });
  });
}

/** Только для тестов: сбросить состояние. */
export function resetStakanFanoutForTests(): void {
  markets.clear();
  hostPause.clear();
  pairPause.clear();
  pauseLogAt.clear();
  hostCursor = 0;
  hostsCache = null;
  sizeCache = null;
}
