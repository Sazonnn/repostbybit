// ---- Диагностика: какой IP первым показал новый топ-1 ----
// В окне смены курса для каждого ответа стакана (в том числе отброшенного как
// устаревший) запоминаем, какой топ-1 он показал. Когда топ-1 меняется, через
// STAKAN_IP_WATCH_MS пишем одну строку: какой IP показал новый топ первым и
// какие IP после этого ЕЩЁ показывали старый (это и есть отставание узла).
//
// Зачем: конкуренты в части смен видят новый топ на 0,5–1 с раньше нас. Если
// прокси из одной сети всегда видят топ одновременно и отстают от основного IP
// (или наоборот) — часть адресов стоит заменить.
//
// На гонку не влияет: запросов не добавляет, работает с уже полученным
// ответом (несколько сравнений), строку пишет с задержкой в несколько секунд.
// В .env: STAKAN_IP_DIAG=0 — выключить (по умолчанию включено).
import { inRateWindow, stakanSources } from "./stakanSources.js";
import { DEFAULT_STAKAN_HOST, stakanHosts } from "./stakanFanout.js";

const ENABLED = process.env.STAKAN_IP_DIAG !== "0";
// Сколько после первого показа нового топ-1 собирать ответы остальных IP.
const WATCH_MS = 3_000;
// "Возврат" к прошлому топ-1 в течение этого времени после итога — устаревший
// снимок, новое событие из-за него не начинаем.
const REVERT_IGNORE_MS = 10_000;
const EPS = 0.005;

let ownUserId: string | undefined;
let ownItemIds = new Set<string>();

/** Свои объявления (чтобы топ-1 считался по чужим, как в гонке). */
export function setStakanDiagOwn(userId: string | undefined, itemIds: string[]): void {
  ownUserId = userId === undefined ? undefined : String(userId);
  if (itemIds.length !== ownItemIds.size || itemIds.some((id) => !ownItemIds.has(id))) {
    ownItemIds = new Set(itemIds.map(String));
  }
}

interface Seen { at: number }
interface Old { at: number; top: number; count: number }
interface TopEvent {
  from: number;
  top: number;
  firstAt: number;
  firstLabel: string;
  seen: Map<string, Seen>;
  // Адреса стакана (STAKAN_HOSTS): какой первым показал новый топ и когда остальные.
  firstHost: string;
  hostSeen: Map<string, number>;
  // Последний раз, когда IP после первого показа ещё показывал НЕ новый топ.
  old: Map<string, Old>;
  timer: ReturnType<typeof setTimeout>;
  // Ответ, отброшенный как "устаревший", показал этот топ-1 РАНЬШЕ первого
  // принятого — значит, фильтр устаревших снимков стоил нам времени.
  discardedEarlier: { label: string; at: number } | null;
}

let stableTop: number | null = null;
let event: TopEvent | null = null;
let lastClosed: { from: number; at: number } | null = null;
// Последний отброшенный ("устаревший") ответ с топ-1, которого ещё никто не показывал.
let discardedHint: { label: string; top: number; at: number } | null = null;
const DISCARDED_HINT_MS = 3_000;

const time = (ms: number) => new Date(ms).toISOString().slice(11, 23);

/** Топ-1 по чужим объявлениям в сыром ответе стакана (свои — по setStakanDiagOwn). */
export function stakanTopOf(items: unknown): number | null {
  return Array.isArray(items) ? topOf(items as Array<Record<string, unknown>>) : null;
}

function topOf(items: Array<Record<string, unknown>>): number | null {
  for (const item of items) {
    const price = Number(item.price);
    if (!(price > 0)) continue;
    const id = String(item.id ?? item.itemId ?? "");
    if (ownItemIds.has(id)) continue;
    if (ownUserId !== undefined && String(item.userId ?? "") === ownUserId) continue;
    return Math.round(price * 100) / 100;
  }
  return null;
}

function closeEvent(): void {
  const current = event;
  if (!current) return;
  event = null;
  clearTimeout(current.timer);
  stableTop = current.top;
  lastClosed = { from: current.from, at: Date.now() };
  const now = Date.now();
  const parts: string[] = [];
  let lagging = 0;
  for (const source of stakanSources()) {
    const label = source.label;
    if (label === current.firstLabel) continue;
    const seen = current.seen.get(label);
    const old = current.old.get(label);
    const oldNote = old
      ? `ещё показывал ${old.top.toFixed(2)} в +${old.at - current.firstAt} мс` +
        (old.count > 1 ? ` (чтений со старым топом: ${old.count})` : "")
      : "";
    if (old) lagging += 1;
    if (seen) {
      parts.push(`${label} +${seen.at - current.firstAt} мс` + (oldNote ? ` — ОТСТАЛ: ${oldNote}` : ""));
    } else if (old) {
      parts.push(`${label} — ОТСТАЛ: за ${Math.round(WATCH_MS / 1000)} с новый топ не показал, ${oldNote}`);
    } else {
      parts.push(`${label} — не читался` + (source.cooldownUntil > now ? " (на паузе)" : ""));
    }
  }
  console.log(`[stakan-ip] топ-1 ${current.from.toFixed(2)}→${current.top.toFixed(2)}: первым показал ` +
    `${current.firstLabel} в ${time(current.firstAt)}; ${parts.join("; ") || "других IP нет"}` +
    `. Отстали: ${lagging} из ${Math.max(0, stakanSources().length - 1)} ` +
    `("+N мс" без пометки — просто очередь чтения, IP читаются по кругу)` +
    hostsNote(current) +
    (current.discardedEarlier
      ? `. ВНИМАНИЕ: ответ ${current.discardedEarlier.label}, отброшенный как устаревший, показал ` +
        `${current.top.toFixed(2)} на ${current.firstAt - current.discardedEarlier.at} мс раньше`
      : ""));
}

function hostsNote(current: TopEvent): string {
  const hosts = stakanHosts();
  if (hosts.length <= 1) return "";
  const parts = hosts.filter((host) => host.name !== current.firstHost).map((host) => {
    const at = current.hostSeen.get(host.name);
    return at === undefined ? `${host.name} — за ${Math.round(WATCH_MS / 1000)} с не показал` : `${host.name} +${at - current.firstAt} мс`;
  });
  return `. Адреса: первым ${current.firstHost}; ${parts.join("; ")}`;
}

/**
 * Запомнить ответ стакана. at — когда запрос ушёл; stale — ответ отброшен как
 * устаревший (по серверному времени) и в гонку не попал.
 */
export function noteStakanTop(
  label: string, items: unknown, at: number, stale: boolean, host: string = DEFAULT_STAKAN_HOST,
): void {
  if (!ENABLED || !Array.isArray(items)) return;
  try {
    const top = topOf(items as Array<Record<string, unknown>>);
    if (top === null) return;
    if (!inRateWindow(at)) {
      if (!event) stableTop = top;
      return;
    }
    if (event) {
      if (Math.abs(top - event.top) < EPS) {
        if (!event.seen.has(label)) event.seen.set(label, { at });
        if (!event.hostSeen.has(host)) event.hostSeen.set(host, at);
      } else if (Math.abs(top - event.from) < EPS || stale) {
        if (at >= event.firstAt) {
          const prev = event.old.get(label);
          event.old.set(label, { at, top, count: (prev?.count ?? 0) + 1 });
        }
      } else {
        // Третье значение — топ-1 сменился ещё раз: подводим итог и начинаем заново.
        const from = event.top;
        closeEvent();
        startEvent(from, top, label, at, host);
      }
      if (event && at - event.firstAt >= WATCH_MS) closeEvent();
      return;
    }
    if (stableTop === null) { stableTop = top; return; }
    if (Math.abs(top - stableTop) < EPS) return;
    if (stale) {
      // Отброшенный ответ показывает другой топ-1: запомним — вдруг это новый.
      if (!discardedHint || Math.abs(discardedHint.top - top) >= EPS) discardedHint = { label, top, at };
      return;
    }
    // Возврат к прошлому топ-1 сразу после итога — устаревший снимок, не событие.
    if (lastClosed && Math.abs(top - lastClosed.from) < EPS && Date.now() - lastClosed.at < REVERT_IGNORE_MS) return;
    startEvent(stableTop, top, label, at, host);
  } catch {
    // Диагностика не должна мешать чтению стакана.
  }
}

function startEvent(from: number, top: number, label: string, at: number, host: string): void {
  const timer = setTimeout(closeEvent, WATCH_MS + 500);
  timer.unref?.();
  const hint = discardedHint && Math.abs(discardedHint.top - top) < EPS &&
    discardedHint.at < at && at - discardedHint.at < DISCARDED_HINT_MS
    ? { label: discardedHint.label, at: discardedHint.at } : null;
  discardedHint = null;
  event = {
    from, top, firstAt: at, firstLabel: label,
    seen: new Map([[label, { at }]]), old: new Map(), timer, discardedEarlier: hint,
    firstHost: host, hostSeen: new Map([[host, at]]),
  };
}
