import http from "node:http";
import https from "node:https";
import tls from "node:tls";

/**
 * Несколько IP для чтения публичного стакана (www.bybit.com/x-api/...).
 *
 * Лимит стакана у Bybit — по IP (~7 запросов за 5 с). Если читать стакан по
 * очереди с нескольких IP, каждый IP укладывается в свой лимит, а бот видит
 * стакан в N раз чаще. Изменение цены и всё, что идёт по API-ключу, сюда НЕ
 * относится — это всегда основной IP сервера.
 *
 * Настройка в .env (через запятую, порядок не важен):
 *   STAKAN_SOURCES=direct,local:203.0.113.5,http://user:pass@198.51.100.7:3128
 *     direct                 — основной IP сервера (как раньше);
 *     local:<IP>             — дополнительный IPv4, добавленный этому серверу;
 *     http://[user:pass@]host:port — HTTP-прокси (метод CONNECT).
 * Если переменной нет — только direct, поведение как раньше.
 */

export interface StakanSource {
  label: string;
  kind: "direct" | "local" | "proxy";
  agent?: https.Agent;
  // Диспетчер встроенного fetch для этого источника (создаётся при первом запросе).
  dispatcher?: unknown;
  proxyUrl?: URL;
  localAddress?: string;
  // До этого момента источник не используем (лимит, 403 или обрыв связи).
  cooldownUntil: number;
  lastUsedAt: number;
  // Статистика скорости за текущую минуту (для строки [stakan] за минуту).
  stats?: { count: number; totalMs: number; maxMs: number; slow: number; errors: number; stale: number; lastSlowLogAt: number };
  // Когда этот IP присылал устаревший стакан (за последние STALE_WINDOW_MS).
  staleTimes?: number[];
}

// Таймаут одного чтения стакана через доп. IP или прокси. Обычный ответ —
// 0,05–0,1 с. Пока запрос висит, бот не видит стакан, поэтому долго не ждём:
// по таймауту источник уходит на паузу, стакан сразу читается с другого IP.
export const EXTRA_SOURCE_TIMEOUT_MS = 1_500;

// ---- Устаревшие снимки ----
// IP, который STALE_BAN_COUNT раз за STALE_WINDOW_MS прислал старый стакан,
// отключаем на STALE_BAN_MS. Одиночный случай — пауза STALE_SHORT_MS.
// В момент смены курса Bybit рассылает старые снимки почти со всех узлов (в т.ч.
// на основной IP), поэтому одиночный старый снимок — не повод отключать IP:
// его ответ просто не используется. Отключаем только IP, который шлёт старые
// снимки заметно чаще остальных: STALE_BAN_COUNT раз за STALE_WINDOW_MS.
const STALE_WINDOW_MS = 10 * 60_000;
const STALE_BAN_COUNT = 12;
const STALE_BAN_MS = 10 * 60_000;

// ---- Окно смены курса ----
// По логам курс меняется около :24–:31 каждого часа. RATE_WINDOW в .env —
// минуты часа "с-по" (по умолчанию 23-32). RATE_WINDOW=off — режим выключен.
let windowCache: { from: number; to: number } | null | undefined;

export function rateWindow(): { from: number; to: number } | null {
  if (windowCache !== undefined) return windowCache;
  const raw = (process.env.RATE_WINDOW ?? "23-32").trim().toLowerCase();
  const match = /^(\d{1,2})\s*-\s*(\d{1,2})$/.exec(raw);
  if (raw === "off" || raw === "0" || !match) {
    if (raw !== "off" && raw !== "0") console.warn(`[window] RATE_WINDOW="${raw}" не понял — режим окна выключен`);
    windowCache = null;
  } else {
    windowCache = { from: Number(match[1]) % 60, to: Number(match[2]) % 60 };
  }
  return windowCache;
}

function minuteIn(minute: number, from: number, to: number): boolean {
  return from <= to ? minute >= from && minute < to : minute >= from || minute < to;
}

/** Сейчас окно смены курса. */
export function inRateWindow(now = Date.now()): boolean {
  const window = rateWindow();
  return window !== null && minuteIn(new Date(now).getUTCMinutes(), window.from, window.to);
}

/** Сейчас минута перед окном — время подготовиться. */
export function beforeRateWindow(now = Date.now()): boolean {
  const window = rateWindow();
  return window !== null && new Date(now).getUTCMinutes() === (window.from + 59) % 60;
}

let lastServed: StakanSource | null = null;
// Страховочные запросы за текущую минуту: сколько раз отправляли и сколько
// раз страховочный ответ пришёл первым.
let hedgesSent = 0;
let hedgesWon = 0;

export function noteHedge(won: boolean): void {
  if (won) hedgesWon += 1;
  else hedgesSent += 1;
}

/** Какой IP отдал последний успешно прочитанный стакан. */
export function lastServedStakanSource(): string | null {
  return lastServed?.label ?? null;
}

export function noteServedStakanSource(source: StakanSource): void {
  lastServed = source;
}

/** IP прислал устаревший снимок стакана (по времени Bybit или по содержимому). */
export function reportStaleStakan(sourceOrLabel: StakanSource | string, reason: string): void {
  // Метка дополнительного запроса — "IP → адрес стакана": IP — часть до стрелки.
  const source = typeof sourceOrLabel === "string"
    ? stakanSources().find((entry) => entry.label === sourceOrLabel.split(" → ")[0])
    : sourceOrLabel;
  if (!source) return;
  const now = Date.now();
  const stats = source.stats ??= { count: 0, totalMs: 0, maxMs: 0, slow: 0, errors: 0, stale: 0, lastSlowLogAt: 0 };
  stats.stale += 1;
  const times = (source.staleTimes ??= []).filter((at) => now - at < STALE_WINDOW_MS);
  times.push(now);
  source.staleTimes = times;
  if (stakanSources().length <= 1) {
    console.warn(`[stakan] ${source.label}: ${reason}`);
    return;
  }
  // Не отключаем, если после этого останется меньше двух рабочих IP.
  const others = stakanSources().filter((entry) => entry !== source && entry.cooldownUntil <= now).length;
  if (times.length >= STALE_BAN_COUNT && others >= 2) {
    source.staleTimes = [];
    coolDownStakanSource(source, STALE_BAN_MS,
      `${reason}; устаревший стакан ${STALE_BAN_COUNT} раз за ${STALE_WINDOW_MS / 60_000} мин`);
  } else {
    console.log(`[stakan] ${source.label}: ${reason} — ответ не использован (IP остаётся в работе)`);
  }
}

// ---- Скорость чтения стакана по каждому IP ----
// Раз в минуту — строка со средним и максимальным временем ответа каждого IP.
// Отдельное чтение дольше SLOW_READ_MS — сразу строка "медленно" (не чаще
// раза в 10 с на IP), чтобы было видно, какой прокси тормозит.
const STATS_EVERY_MS = 60_000;
const SLOW_READ_MS = 300;
let statsStartedAt = Date.now();

function recordRead(source: StakanSource, ms: number, failed: boolean): void {
  const now = Date.now();
  const stats = source.stats ??= { count: 0, totalMs: 0, maxMs: 0, slow: 0, errors: 0, stale: 0, lastSlowLogAt: 0 };
  if (failed) {
    stats.errors += 1;
  } else {
    stats.count += 1;
    stats.totalMs += ms;
    stats.maxMs = Math.max(stats.maxMs, ms);
    if (ms >= SLOW_READ_MS) {
      stats.slow += 1;
      if (now - stats.lastSlowLogAt >= 10_000) {
        stats.lastSlowLogAt = now;
        console.log(`[stakan] медленно: ${source.label} — ${ms} мс`);
      }
    }
  }
  if (now - statsStartedAt < STATS_EVERY_MS) return;
  const parts = stakanSources().map((entry) => {
    const s = entry.stats;
    if (!s || (s.count === 0 && s.errors === 0 && s.stale === 0)) {
      return entry.cooldownUntil > now
        ? `${entry.label}: отключён ещё ${Math.ceil((entry.cooldownUntil - now) / 60_000)} мин` : `${entry.label}: 0`;
    }
    const avg = s.count > 0 ? Math.round(s.totalMs / s.count) : 0;
    return `${entry.label}: ${s.count} чт., ср ${avg} мс, макс ${s.maxMs} мс` +
      (s.slow > 0 ? `, медленных ${s.slow}` : "") + (s.errors > 0 ? `, ошибок ${s.errors}` : "") +
      (s.stale > 0 ? `, устаревших ${s.stale}` : "");
  });
  console.log(`[stakan] за ${Math.round((now - statsStartedAt) / 1000)} с: ${parts.join("; ")}` +
    (hedgesSent > 0 ? `; страховочных запросов ${hedgesSent} (пришли первыми ${hedgesWon})` : ""));
  hedgesSent = 0;
  hedgesWon = 0;
  statsStartedAt = now;
  for (const entry of stakanSources()) {
    if (entry.stats) Object.assign(entry.stats, { count: 0, totalMs: 0, maxMs: 0, slow: 0, errors: 0, stale: 0 });
  }
}

export interface SourceResponse {
  status: number;
  ok: boolean;
  headers: { get(name: string): string | null };
  text: string;
}

/** https.Agent, который открывает соединение через HTTP-прокси (CONNECT). */
class ProxyTunnelAgent extends https.Agent {
  constructor(private readonly proxy: URL, options: https.AgentOptions) {
    super(options);
  }

  // Node вызывает createConnection(options, callback); если вернуть undefined,
  // сокет можно отдать позже через callback.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  override createConnection(options: any, callback: any): any {
    const host = String(options.host ?? options.hostname);
    const port = Number(options.port ?? 443);
    const headers: Record<string, string> = { host: `${host}:${port}` };
    if (this.proxy.username) {
      const auth = `${decodeURIComponent(this.proxy.username)}:${decodeURIComponent(this.proxy.password)}`;
      headers["proxy-authorization"] = `Basic ${Buffer.from(auth).toString("base64")}`;
    }
    const request = http.request({
      host: this.proxy.hostname,
      port: Number(this.proxy.port || 80),
      method: "CONNECT",
      path: `${host}:${port}`,
      headers,
    });
    let done = false;
    const finish = (error: Error | null, socket?: unknown) => {
      if (done) return;
      done = true;
      callback(error, socket);
    };
    request.setTimeout(EXTRA_SOURCE_TIMEOUT_MS, () => request.destroy(new Error(`прокси не ответил за ${EXTRA_SOURCE_TIMEOUT_MS} мс`)));
    request.once("connect", (response, socket) => {
      if (response.statusCode !== 200) {
        socket.destroy();
        finish(new Error(`прокси ответил ${response.statusCode} на CONNECT`));
        return;
      }
      finish(null, tls.connect({ socket, servername: options.servername ?? host, ALPNProtocols: ["http/1.1"] }));
    });
    request.once("error", (error) => finish(error));
    request.end();
    return undefined;
  }
}

let sources: StakanSource[] | null = null;

function parseSources(): StakanSource[] {
  const raw = (process.env.STAKAN_SOURCES ?? "").trim();
  const list: StakanSource[] = [];
  const agentOptions: https.AgentOptions = { keepAlive: true, keepAliveMsecs: 1_000, maxSockets: 4 };
  for (const entry of raw.split(",").map((value) => value.trim()).filter(Boolean)) {
    try {
      if (entry === "direct" || entry === "main") {
        list.push({ label: "основной IP", kind: "direct", cooldownUntil: 0, lastUsedAt: 0 });
      } else if (entry.startsWith("local:")) {
        const ip = entry.slice("local:".length).trim();
        if (!ip) throw new Error("не указан IP");
        list.push({
          label: ip, kind: "local", cooldownUntil: 0, lastUsedAt: 0, localAddress: ip,
          agent: new https.Agent({ ...agentOptions, localAddress: ip }),
        });
      } else if (/^https?:\/\//i.test(entry)) {
        const url = new URL(entry);
        list.push({
          label: `прокси ${url.hostname}:${url.port || 80}`, kind: "proxy", cooldownUntil: 0, lastUsedAt: 0,
          proxyUrl: url,
          agent: new ProxyTunnelAgent(url, agentOptions),
        });
      } else {
        throw new Error("непонятный формат");
      }
    } catch (error) {
      console.warn(`[stakan] STAKAN_SOURCES: пропускаю "${entry.replace(/\/\/[^@]*@/, "//***@")}" — ${(error as Error).message}`);
    }
  }
  if (list.length === 0) list.push({ label: "основной IP", kind: "direct", cooldownUntil: 0, lastUsedAt: 0 });
  if (list.length > 1) {
    console.log(`[stakan] читаю стакан по очереди с ${list.length} IP: ${list.map((s) => s.label).join(", ")}`);
  }
  return list;
}

export function stakanSources(): StakanSource[] {
  if (!sources) sources = parseSources();
  return sources;
}

/** Сколько источников сейчас можно использовать (не на паузе). Минимум 1. */
export function healthyStakanSourceCount(now = Date.now()): number {
  return Math.max(1, stakanSources().filter((source) => source.cooldownUntil <= now).length);
}

// STAKAN_CONFIRM_FASTEST=1 в .env — для подтверждающих чтений (когда нужно исключить
// IP, давший подозрительный снимок) брать самый быстрый по средней задержке IP,
// а не тот, что дольше всех отдыхал. Чтобы не перегрузить один IP, берём самый
// быстрый из тех, кого не трогали дольше STAKAN_CONFIRM_IDLE_MS (по умолчанию 300 мс).
const CONFIRM_FASTEST = process.env.STAKAN_CONFIRM_FASTEST === "1";
const CONFIRM_IDLE_MS = (() => {
  const raw = process.env.STAKAN_CONFIRM_IDLE_MS;
  const value = Number(raw);
  return raw !== undefined && raw.trim() !== "" && Number.isFinite(value) && value >= 0 && value <= 2_000
    ? Math.round(value) : 300;
})();
const MIN_LATENCY_SAMPLES = 5;

function averageMs(source: StakanSource): number | null {
  const stats = source.stats;
  return stats && stats.count >= MIN_LATENCY_SAMPLES ? stats.totalMs / stats.count : null;
}

/** Источник для следующего запроса: тот, что дольше всех не использовался. */
export function pickStakanSource(exclude?: StakanSource, now = Date.now()): StakanSource | null {
  if (CONFIRM_FASTEST && exclude) {
    let fastest: StakanSource | null = null;
    let fastestMs = Infinity;
    for (const source of stakanSources()) {
      if (source === exclude || source.cooldownUntil > now) continue;
      if (now - source.lastUsedAt < CONFIRM_IDLE_MS) continue;
      const avg = averageMs(source);
      if (avg === null) continue;
      if (avg < fastestMs) { fastest = source; fastestMs = avg; }
    }
    if (fastest) return fastest;
  }
  let best: StakanSource | null = null;
  for (const source of stakanSources()) {
    if (source === exclude || source.cooldownUntil > now) continue;
    if (!best || source.lastUsedAt < best.lastUsedAt) best = source;
  }
  if (best || exclude) return best;
  // Все на паузе — берём тот, у которого пауза кончится раньше.
  return [...stakanSources()].sort((x, y) => x.cooldownUntil - y.cooldownUntil)[0] ?? null;
}

export function coolDownStakanSource(source: StakanSource, ms: number, reason: string): void {
  source.cooldownUntil = Math.max(source.cooldownUntil, Date.now() + ms);
  if (stakanSources().length > 1) {
    console.warn(`[stakan] ${source.label}: ${reason} — не использую ${Math.round(ms / 1000)} с`);
  }
}

// ---- Встроенный fetch через другой IP / прокси ----
// Защита Bybit (Akamai) отличает запросы разных HTTP-клиентов: запрос через
// node:https получал "Access Denied", а тот же запрос через fetch — нет.
// Поэтому для доп. IP и прокси используем тот же встроенный fetch, что и для
// основного IP, только со своим "диспетчером" соединений. Класс диспетчера
// берём у встроенного fetch (отдельная библиотека не нужна).

type DispatcherClass = new (options: unknown) => unknown;
let dispatcherClass: DispatcherClass | null | undefined;

async function getDispatcherClass(): Promise<DispatcherClass | null> {
  if (dispatcherClass !== undefined) return dispatcherClass;
  const key = Symbol.for("undici.globalDispatcher.1");
  const read = () => (globalThis as Record<symbol, { constructor?: DispatcherClass } | undefined>)[key]?.constructor;
  if (!read()) {
    // Глобальный диспетчер появляется после первого вызова fetch.
    await fetch("http://127.0.0.1:9/", { signal: AbortSignal.timeout(200) }).catch(() => {});
  }
  dispatcherClass = read() ?? null;
  if (!dispatcherClass) console.warn("[stakan] встроенный fetch недоступен для доп. IP — использую node:https");
  return dispatcherClass;
}

/** Соединение через HTTP-прокси (CONNECT) + TLS — для диспетчера fetch. */
function proxyConnector(proxy: URL) {
  return (options: { hostname: string; host?: string; port?: string; protocol?: string; servername?: string | null },
    callback: (error: Error | null, socket: unknown) => void) => {
    const host = options.hostname;
    const port = Number(options.port) || (options.protocol === "http:" ? 80 : 443);
    const headers: Record<string, string> = { host: `${host}:${port}` };
    if (proxy.username) {
      const auth = `${decodeURIComponent(proxy.username)}:${decodeURIComponent(proxy.password)}`;
      headers["proxy-authorization"] = `Basic ${Buffer.from(auth).toString("base64")}`;
    }
    let done = false;
    const finish = (error: Error | null, socket: unknown) => {
      if (done) return;
      done = true;
      callback(error, socket);
    };
    const request = http.request({
      host: proxy.hostname, port: Number(proxy.port || 80), method: "CONNECT", path: `${host}:${port}`, headers,
    });
    request.setTimeout(EXTRA_SOURCE_TIMEOUT_MS, () => request.destroy(new Error(`прокси не ответил за ${EXTRA_SOURCE_TIMEOUT_MS} мс`)));
    request.once("connect", (response, socket) => {
      if (response.statusCode !== 200) {
        socket.destroy();
        finish(new Error(`прокси ответил ${response.statusCode} на CONNECT`), null);
        return;
      }
      if (options.protocol === "http:") {
        finish(null, socket);
        return;
      }
      const secure = tls.connect({
        socket, servername: options.servername || host, ALPNProtocols: ["http/1.1"],
      });
      secure.once("secureConnect", () => finish(null, secure));
      secure.once("error", (error) => finish(error, null));
    });
    request.once("error", (error) => finish(error, null));
    request.end();
  };
}

async function dispatcherFor(source: StakanSource): Promise<unknown> {
  if (source.dispatcher !== undefined) return source.dispatcher;
  const Dispatcher = await getDispatcherClass();
  if (!Dispatcher) {
    source.dispatcher = null;
    return null;
  }
  source.dispatcher = source.kind === "proxy" && source.proxyUrl
    ? new Dispatcher({ connect: proxyConnector(source.proxyUrl), keepAliveTimeout: 10_000 })
    : new Dispatcher({ connect: { localAddress: source.localAddress }, keepAliveTimeout: 10_000 });
  return source.dispatcher;
}

/** POST с выбранного источника. */
export async function postFromSource(
  source: StakanSource,
  url: string,
  headers: Record<string, string>,
  body: string,
  timeoutMs: number,
): Promise<SourceResponse> {
  const startedAt = Date.now();
  try {
    const response = await postFromSourceRaw(source, url, headers, body, timeoutMs);
    recordRead(source, Date.now() - startedAt, !response.ok);
    return response;
  } catch (error) {
    recordRead(source, Date.now() - startedAt, true);
    throw error;
  }
}

async function postFromSourceRaw(
  source: StakanSource,
  url: string,
  headers: Record<string, string>,
  body: string,
  timeoutMs: number,
): Promise<SourceResponse> {
  source.lastUsedAt = Date.now();
  if (source.kind === "direct") {
    const response = await fetch(url, {
      method: "POST", headers, body, signal: AbortSignal.timeout(timeoutMs),
    });
    return { status: response.status, ok: response.ok, headers: response.headers, text: await response.text() };
  }
  const dispatcher = await dispatcherFor(source);
  if (dispatcher) {
    // Тот же fetch, что и для основного IP, — запрос неотличим от прямого.
    const response = await fetch(url, {
      method: "POST", headers, body, signal: AbortSignal.timeout(timeoutMs), dispatcher,
    } as RequestInit);
    return { status: response.status, ok: response.ok, headers: response.headers, text: await response.text() };
  }
  // Запасной путь, если встроенный fetch не дал диспетчер.
  return new Promise<SourceResponse>((resolve, reject) => {
    const target = new URL(url);
    const request = https.request({
      protocol: target.protocol,
      hostname: target.hostname,
      port: target.port || 443,
      path: `${target.pathname}${target.search}`,
      method: "POST",
      headers: { ...headers, "content-length": String(Buffer.byteLength(body)) },
      agent: source.agent,
    }, (response) => {
      const chunks: Buffer[] = [];
      response.on("data", (chunk: Buffer) => chunks.push(chunk));
      response.on("end", () => {
        const status = response.statusCode ?? 0;
        resolve({
          status,
          ok: status >= 200 && status < 300,
          headers: {
            get: (name: string) => {
              const value = response.headers[name.toLowerCase()];
              return value === undefined ? null : Array.isArray(value) ? value.join(", ") : String(value);
            },
          },
          text: Buffer.concat(chunks).toString("utf8"),
        });
      });
      response.on("error", reject);
    });
    request.setTimeout(timeoutMs, () => request.destroy(new Error(`${source.label}: нет ответа за ${timeoutMs} мс`)));
    request.on("error", reject);
    request.end(body);
  });
}
