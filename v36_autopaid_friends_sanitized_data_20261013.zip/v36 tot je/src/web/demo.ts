import { hashPassword } from "./auth.js";
import { startPanel, PanelError } from "./server.js";

// This entry point deliberately imports no bot, database, credentials or Bybit modules.
const port = Number(process.env.PANEL_DEMO_PORT || 8790);
const origin = `http://127.0.0.1:${port}`;
const password = "Demo-RepostG-Local-Only";
const now = Date.now();
let revision = 1;
const settings = { enabled: true, monitor: 0.1, edit: 0.01, mode: "auto", step: "0", min: "70", max: "120", fixed: null as string | null };
const ads = [
  {id:1,itemId:"1111111111111111111",pair:"USDT/RUB",side:"BUY",type:"fixed",enabled:true,price:"90.07",target:"90.07",error:null,checkedAt:new Date(now).toISOString(),updatedAt:new Date(now-4000).toISOString(),attempts:2},
  {id:2,itemId:"2222222222222222222",pair:"USDT/RUB",side:"BUY",type:"floating",enabled:true,price:"90.06",target:"90.07",error:null,checkedAt:new Date(now).toISOString(),updatedAt:new Date(now-6000).toISOString(),attempts:1},
];
const telemetry = {
  series: Array.from({length:80},(_,i)=>({at:now-(79-i)*10_000,itemId:ads[0]!.itemId,top:i<20?89.82:i<40?89.91:i<58?90:90.07,price:i<21?89.82:i<41?89.91:i<59?90:90.07,target:90.07})),
  updates: [
    {at:now-70_000,itemId:ads[0]!.itemId,price:"90.00",marketMs:63,prepareMs:140,seenToSendMs:140,apiMs:500},
    {at:now-4_000,itemId:ads[0]!.itemId,price:"90.07",marketMs:62,prepareMs:47,seenToSendMs:47,apiMs:453},
  ],
  events: [
    {at:now-700_000,kind:"info",message:"Демонстрационный сеанс запущен"},
    {at:now-4_000,kind:"info",message:"Тестовый ответ API: цена 90.07, 453 мс"},
  ],
};
const server = await startPanel({version:1,chatId:123456789,port,origin,passwordHash:await hashPassword(password)}, {
  async snapshot() { return {version:"web-1",demo:true,now:Date.now(),startedAt:now,chatId:123456789,revision:String(revision),account:{name:"Демо-аккаунт",mode:"api",configured:true},settings,ads,telemetry,cycle:null}; },
  async command(input) {
    if(input.revision!==String(revision))throw new PanelError(409,"Данные изменились. Повтори команду.");
    if(input.action==="enable")settings.enabled=Boolean(input.enabled);
    else if(input.action==="ad-enable") {const ad=ads.find(a=>a.id===input.id);if(ad)ad.enabled=Boolean(input.enabled);}
    else if(input.action==="ad-remove") {const index=ads.findIndex(a=>a.id===input.id);if(index>=0)ads.splice(index,1);}
    else if(input.action==="ad-add") {
      if(typeof input.itemId!=="string"||!/^\d{6,30}$/.test(input.itemId))throw new PanelError(400,"Неверный ID объявления.");
      if(ads.some(a=>a.itemId===input.itemId)||ads.length>=10)throw new PanelError(400,"Объявление уже добавлено или достигнут лимит.");
      ads.push({id:Date.now(),itemId:input.itemId,pair:"USDT/RUB",side:"BUY",type:"fixed",enabled:true,price:"90.07",target:"90.07",error:null,checkedAt:new Date().toISOString(),updatedAt:new Date().toISOString(),attempts:0});
    } else if(input.action==="settings") {
      for(const key of ["monitor","edit"] as const) {const value=Number(String(input[key]).replace(",","."));if(!Number.isFinite(value)||value<.01||value>86_400)throw new PanelError(400,"Интервал: от 0,01 до 86400 секунд.");}
      settings.monitor=Number(String(input.monitor).replace(",","."));settings.edit=Number(String(input.edit).replace(",","."));
      for(const key of ["step","min","max","mode"] as const)settings[key]=String(input[key]);
      settings.fixed=input.fixed===null?null:String(input.fixed);
    } else if(input.action!=="sync")throw new PanelError(400,"Неизвестная команда.");
    revision++;telemetry.events.push({at:Date.now(),kind:"info",message:"Демо: "+String(input.action)});
    return {ok:true,message:"Изменение применено к демо-данным"};
  },
});
console.log(`Demo panel: ${origin}\nDemo password: ${password}\nNo Bybit or Telegram connection.`);
for(const signal of ["SIGINT","SIGTERM"] as const)process.on(signal,()=>void server.close().then(()=>process.exit(0)));
