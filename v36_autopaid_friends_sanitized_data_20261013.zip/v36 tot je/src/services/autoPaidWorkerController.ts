import { fork, type ChildProcess } from "node:child_process";
import { fileURLToPath } from "node:url";

interface Notice { type: "notify"; chatId: number; text: string; }

export class AutoPaidWorkerController {
  private child: ChildProcess | null = null;
  private stopping = false;
  private restartTimer: NodeJS.Timeout | null = null;

  constructor(private readonly notify: (chatId: number, text: string) => Promise<void>) {}

  start(): void {
    if (this.child || this.stopping) return;
    const child = fork(fileURLToPath(new URL("./autoPaidWorkerProcess.ts", import.meta.url)), [], {
      execArgv: ["--import", "tsx"],
      stdio: ["ignore", "inherit", "inherit", "ipc"],
    });
    this.child = child;
    child.on("message", message => {
      if (!message || typeof message !== "object") return;
      const notice = message as Partial<Notice>;
      if (notice.type === "notify" && Number.isSafeInteger(notice.chatId) && typeof notice.text === "string") {
        void this.notify(notice.chatId!, notice.text);
      }
    });
    child.on("exit", (code, signal) => {
      if (this.child !== child) return;
      this.child = null;
      if (this.stopping) return;
      console.warn(`[auto-paid] worker exited code=${code} signal=${signal}; restarting`);
      this.restartTimer = setTimeout(() => { this.restartTimer = null; this.start(); }, 2_000);
    });
  }

  async stop(): Promise<void> {
    this.stopping = true;
    if (this.restartTimer) clearTimeout(this.restartTimer);
    const child = this.child;
    if (!child) return;
    await new Promise<void>(resolve => {
      child.once("exit", () => resolve());
      child.send({ type: "stop" });
      setTimeout(() => { if (this.child === child) child.kill(); }, 20_000).unref();
    });
  }
}
