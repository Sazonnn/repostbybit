import assert from "node:assert/strict";
import { test } from "node:test";

process.env.TELEGRAM_BOT_TOKEN ||= "test-token";
process.env.SQLITE_PATH ||= `/tmp/bybit-auto-paid-test-${process.pid}.db`;
process.env.BYBIT_API_KEY = "auto-paid-test-key";
process.env.BYBIT_API_SECRET = "auto-paid-test-secret";

test("auto-paid accepts only unpaid BUY orders and extracts the selected payment method", async () => {
  const { isPayableBuy, paymentPair } = await import("./autoPaidLogic.js");
  const order = { id: "123456789", side: 0, status: 10, transferDate: "0",
    paymentType: 0, paymentId: "123", confirmedPayTerm: { id: "456" },
    paymentTermList: [{ id: "456", paymentType: "90" }] };
  assert.equal(isPayableBuy(order), true);
  assert.deepEqual(paymentPair(order), { paymentType: "90", paymentId: "456" });
  assert.equal(isPayableBuy({ ...order, side: 1 }), false);
  assert.equal(isPayableBuy({ ...order, status: 20 }), false);
  assert.equal(isPayableBuy({ ...order, transferDate: "123" }), false);
  assert.equal(isPayableBuy({ ...order, id: "<b>" }), false);
  assert.equal(paymentPair({ ...order, confirmedPayTerm: { id: "-1", paymentType: 377 } }), null);
});

test("auto-paid waits from first sight, verifies details, writes once and persists completion", async () => {
  const { runMigrations } = await import("../db/migrate.js");
  const { getAutoPaidSettings, setAutoPaidEnabled, setAutoPaidDelay } = await import("../db/repositories/autoPaid.js");
  const { AutoPaidProcessor, autoPaidSourceKey } = await import("./autoPaidProcessor.js");
  await runMigrations();
  const chatId = 90101;
  let now = 1_800_000_000_000;
  const notices: string[] = [];
  const calls: string[] = [];
  const pending = { id: "123456789", side: 0, status: 10, transferDate: "0" };
  const api = {
    pending: async () => { calls.push("pending"); return { items: [pending], count: 1 }; },
    detail: async () => { calls.push("detail"); return { ...pending,
      confirmedPayTerm: { id: "456", paymentType: "90" } }; },
    markPaid: async (id: string, type: string, paymentId: string) => {
      calls.push(`pay:${id}:${type}:${paymentId}`); return { success: true };
    },
  };
  const worker = new AutoPaidProcessor((_id, text) => notices.push(text), () => now);
  const key = autoPaidSourceKey(process.env.BYBIT_API_KEY!);
  assert.equal(getAutoPaidSettings(chatId).enabled, false);
  await worker.runOnce(chatId, key, api);
  assert.equal(calls.length, 0);
  setAutoPaidDelay(chatId, 30);
  setAutoPaidEnabled(chatId, true);
  await worker.runOnce(chatId, key, api);
  assert.equal(calls.join(","), "pending");
  now += 29_000;
  await worker.runOnce(chatId, key, api);
  assert.equal(calls.includes("detail"), false);
  now += 1_000;
  await worker.runOnce(chatId, key, api);
  assert.equal(calls.filter(call => call.startsWith("pay:")).length, 1);
  assert.equal(notices.length, 1);
  await new AutoPaidProcessor(() => {}, () => now).runOnce(chatId, key, api);
  assert.equal(calls.filter(call => call.startsWith("pay:")).length, 1);
  setAutoPaidEnabled(chatId, false);
});

test("auto-paid final check blocks a changed order and unsupported balance payment", async () => {
  const { runMigrations } = await import("../db/migrate.js");
  const { setAutoPaidEnabled, setAutoPaidDelay } = await import("../db/repositories/autoPaid.js");
  const { AutoPaidProcessor, autoPaidSourceKey } = await import("./autoPaidProcessor.js");
  await runMigrations();
  const chatId = 90102;
  const key = autoPaidSourceKey(process.env.BYBIT_API_KEY!);
  setAutoPaidDelay(chatId, 0);
  setAutoPaidEnabled(chatId, true);
  let paid = 0;
  const pending = { id: "987654321", side: 0, status: 10, transferDate: "0" };
  const api = {
    pending: async () => ({ items: [pending], count: 1 }),
    detail: async () => ({ ...pending, status: 20 }),
    markPaid: async () => { paid++; return {}; },
  };
  await new AutoPaidProcessor(() => {}).runOnce(chatId, key, api);
  assert.equal(paid, 0);
  api.detail = async () => ({ ...pending, status: 10, confirmedPayTerm: { id: "-1", paymentType: 377 } });
  setAutoPaidEnabled(chatId, true);
  await new AutoPaidProcessor(() => {}).runOnce(chatId, key, api);
  assert.equal(paid, 0);
  setAutoPaidEnabled(chatId, false);
});

test("auto-paid uses the existing signed transport for the Bybit pay endpoint", async t => {
  const { withOfficialApiCredentials } = await import("../bybit/connectionContext.js");
  const { officialP2pOrderCall } = await import("../bybit/officialClient.js");
  let request: { url: string; method: string | undefined; body: Record<string, unknown>; key: string | null } | null = null;
  t.mock.method(globalThis, "fetch", async (input: string, init?: RequestInit) => {
    const headers = new Headers(init?.headers);
    request = { url: String(input), method: init?.method,
      body: JSON.parse(String(init?.body)), key: headers.get("x-bapi-api-key") };
    return Response.json({ ret_code: 0, ret_msg: "SUCCESS", result: null });
  });
  await withOfficialApiCredentials({ apiKey: "test-order-key", apiSecret: "test-order-secret" },
    () => officialP2pOrderCall("/v5/p2p/order/pay",
      { orderId: "123456789", paymentType: "90", paymentId: "456" }));
  assert.match(request!.url, /\/v5\/p2p\/order\/pay$/);
  assert.equal(request!.method, "POST");
  assert.equal(request!.key, "test-order-key");
  assert.deepEqual(request!.body, { orderId: "123456789", paymentType: "90", paymentId: "456" });
});

test("auto-paid checks the switch again before sending a payment claim", async () => {
  const { runMigrations } = await import("../db/migrate.js");
  const { setAutoPaidEnabled, setAutoPaidDelay } = await import("../db/repositories/autoPaid.js");
  const { AutoPaidProcessor, autoPaidSourceKey } = await import("./autoPaidProcessor.js");
  await runMigrations();
  const chatId = 90103;
  const pending = { id: "567890123", side: 0, status: 10, transferDate: "0" };
  let paid = 0;
  setAutoPaidDelay(chatId, 0);
  setAutoPaidEnabled(chatId, true);
  await new AutoPaidProcessor(() => {}).runOnce(chatId,
    autoPaidSourceKey(process.env.BYBIT_API_KEY!), {
      pending: async () => ({ items: [pending], count: 1 }),
      detail: async () => {
        setAutoPaidEnabled(chatId, false);
        return { ...pending, confirmedPayTerm: { id: "456", paymentType: "90" } };
      },
      markPaid: async () => { paid++; return {}; },
    });
  assert.equal(paid, 0);
});
