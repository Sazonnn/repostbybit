export interface P2POrder {
  id?: unknown;
  orderId?: unknown;
  side?: unknown;
  status?: unknown;
  transferDate?: unknown;
  needBuyerExamineCancel?: unknown;
  paymentType?: unknown;
  paymentId?: unknown;
  paymentTermId?: unknown;
  confirmedPayTerm?: unknown;
  paymentTermList?: unknown;
}

function value(input: unknown): string {
  return input === null || input === undefined ? "" : String(input).trim();
}

export function orderId(order: P2POrder): string {
  return value(order.id) || value(order.orderId);
}

export function isPayableBuy(order: P2POrder): boolean {
  return /^\d+$/.test(orderId(order)) && Number(order.side) === 0 && Number(order.status) === 10 &&
    (value(order.transferDate) === "" || value(order.transferDate) === "0") &&
    !order.needBuyerExamineCancel;
}

export function paymentPair(order: P2POrder): { paymentType: string; paymentId: string } | null {
  const confirmed = order.confirmedPayTerm && typeof order.confirmedPayTerm === "object"
    ? order.confirmedPayTerm as Record<string, unknown> : null;
  let paymentType = value(confirmed?.paymentType);
  let paymentId = value(confirmed?.id) || value(confirmed?.paymentId);
  const terms = [order.paymentTermList, (order as Record<string, unknown>).paymentList]
    .filter(Array.isArray).flat();
  if (paymentId) {
    const matching = terms.find(term => term && typeof term === "object" &&
      (value(term.id) || value(term.paymentId)) === paymentId) as Record<string, unknown> | undefined;
    if (matching && value(matching.paymentType)) paymentType = value(matching.paymentType);
  }
  if (!paymentType) paymentType = value(order.paymentType);
  if (!paymentId) paymentId = value(order.paymentId) || value(order.paymentTermId);
  if (!paymentType || !paymentId || paymentType === "377" || paymentId === "-1" ||
      [paymentType, paymentId].some(part => /^(none|null)$/i.test(part))) return null;
  return { paymentType, paymentId };
}
