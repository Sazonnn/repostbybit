import { listEnabledAutoPaidChats } from "../db/repositories/autoPaid.js";
import { pool } from "../db/pool.js";
import { AutoPaidProcessor, autoPaidCredentials } from "./autoPaidProcessor.js";
import { ensureSettings } from "../db/repositories/userSettings.js";

let stopped = false;
process.on("message", message => {
  if (message && typeof message === "object" && "type" in message && message.type === "stop") stopped = true;
});
process.on("disconnect", () => { stopped = true; });

const processor = new AutoPaidProcessor((chatId, text) => {
  if (process.connected) process.send?.({ type: "notify", chatId, text });
});
const lastWarningAt = new Map<number, number>();

function warn(chatId: number, message: string): void {
  console.warn(`[auto-paid] chat=${chatId}: ${message}`);
  const now = Date.now();
  if (now - (lastWarningAt.get(chatId) ?? 0) < 60_000) return;
  lastWarningAt.set(chatId, now);
  if (process.connected) process.send?.({ type: "notify", chatId, text: `⚠️ Автоотметка: ${escapeHtml(message)}` });
}

function escapeHtml(value: string): string {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
}

async function run(): Promise<void> {
  while (!stopped) {
    const started = Date.now();
    const sourceKeys = new Set<string>();
    try {
      for (const chatId of listEnabledAutoPaidChats()) {
        if (stopped) break;
        try {
          if ((await ensureSettings(chatId)).connection_mode !== "api") {
            warn(chatId, "выбран не API-режим подключения.");
            continue;
          }
          const credentials = await autoPaidCredentials(chatId);
          if (!credentials) {
            warn(chatId, "API-ключ Bybit не найден.");
            continue;
          }
          if (sourceKeys.has(credentials.sourceKey)) continue;
          sourceKeys.add(credentials.sourceKey);
          await processor.runOnce(chatId, credentials.sourceKey);
        } catch (error) {
          warn(chatId, (error as Error).message);
        }
      }
    } catch (error) {
      console.warn(`[auto-paid] scan: ${(error as Error).message}`);
    }
    const wait = Math.max(0, 2_000 - (Date.now() - started));
    if (!stopped) await new Promise<void>(resolve => setTimeout(resolve, wait));
  }
  await pool.end();
  if (process.connected) process.disconnect();
}

void run().catch(error => {
  console.error("[auto-paid] worker stopped:", error);
  process.exitCode = 1;
});
