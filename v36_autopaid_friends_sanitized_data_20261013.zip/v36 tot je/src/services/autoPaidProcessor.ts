import { createHash } from "node:crypto";
import { config } from "../config.js";
import { withBybitConnection } from "../bybit/connectionContext.js";
import { officialP2pOrderCall } from "../bybit/officialClient.js";
import { getActiveApiCredentials } from "../db/repositories/apiAccounts.js";
import { firstSeenAutoPaidOrder, getAutoPaidSettings, setAutoPaidOrderStatus } from "../db/repositories/autoPaid.js";
import { isPayableBuy, orderId, paymentPair, type P2POrder } from "./autoPaidLogic.js";

interface PendingOrders { count?: number; items?: P2POrder[]; }
type Notify = (chatId: number, text: string) => void;

export interface AutoPaidApi {
  pending(page: number): Promise<PendingOrders>;
  detail(id: string): Promise<P2POrder>;
  markPaid(id: string, paymentType: string, paymentId: string): Promise<unknown>;
}

export function autoPaidSourceKey(apiKey: string): string {
  return createHash("sha256").update(apiKey).digest("hex").slice(0, 24);
}

export async function autoPaidCredentials(chatId: number): Promise<{ apiKey: string; sourceKey: string } | null> {
  const stored = await getActiveApiCredentials(chatId);
  const apiKey = stored?.apiKey ?? config.bybit.apiKey;
  const secret = stored?.apiSecret ?? config.bybit.apiSecret;
  return apiKey && secret ? { apiKey, sourceKey: autoPaidSourceKey(apiKey) } : null;
}

export function autoPaidApi(chatId: number): AutoPaidApi {
  const call = <T>(path: Parameters<typeof officialP2pOrderCall>[0], body: unknown) =>
    withBybitConnection("api", () => officialP2pOrderCall<T>(path, body), chatId);
  return {
    pending: page => call<PendingOrders>("/v5/p2p/order/pending/simplifyList", { page, size: 30, side: 0, status: 10 }),
    detail: id => call<P2POrder>("/v5/p2p/order/info", { orderId: id }),
    markPaid: (id, paymentType, paymentId) => call<unknown>("/v5/p2p/order/pay", { orderId: id, paymentType, paymentId }),
  };
}

export class AutoPaidProcessor {
  private readonly errorNotices = new Map<string, number>();

  constructor(private readonly notify: Notify, private readonly now = () => Date.now()) {}

  async runOnce(chatId: number, sourceKey: string, api: AutoPaidApi = autoPaidApi(chatId)): Promise<void> {
    const settings = getAutoPaidSettings(chatId);
    if (!settings.enabled) return;
    for (let page = 1; page <= 10; page++) {
      const response = await api.pending(page);
      const items = Array.isArray(response.items) ? response.items : [];
      for (const pending of items) {
        if (!isPayableBuy(pending)) continue;
        const id = orderId(pending);
        const now = this.now();
        const seen = firstSeenAutoPaidOrder(chatId, sourceKey, id, now);
        if (seen.status === "done" || now - seen.firstSeenMs < settings.delaySeconds * 1_000 ||
            ((seen.status === "retry" || seen.status === "sending") && now - (seen.lastAttemptMs ?? 0) < 10_000)) continue;
        await this.processOrder(chatId, sourceKey, id, api);
      }
      if (items.length < 30 || page * 30 >= Number(response.count ?? Infinity)) break;
    }
  }

  private async processOrder(chatId: number, sourceKey: string, id: string, api: AutoPaidApi): Promise<void> {
    try {
      const detail = await api.detail(id);
      if (orderId(detail) !== id || !isPayableBuy(detail)) {
        setAutoPaidOrderStatus(chatId, sourceKey, id, "done", this.now());
        return;
      }
      const pair = paymentPair(detail);
      if (!pair) {
        setAutoPaidOrderStatus(chatId, sourceKey, id, "retry", this.now(), "Не найден допустимый способ оплаты.");
        return;
      }
      if (!getAutoPaidSettings(chatId).enabled || (await autoPaidCredentials(chatId))?.sourceKey !== sourceKey) return;
      setAutoPaidOrderStatus(chatId, sourceKey, id, "sending", this.now());
      const result = await api.markPaid(id, pair.paymentType, pair.paymentId);
      if (result && typeof result === "object" && "success" in result && result.success === false) {
        throw new Error("Bybit вернул success=false.");
      }
      setAutoPaidOrderStatus(chatId, sourceKey, id, "done", this.now());
      console.log(`[auto-paid] chat=${chatId} order=${id} marked as paid`);
      this.notify(chatId, `✅ Сделка <code>${id}</code>: отмечена «Оплачено» в Bybit.`);
    } catch (error) {
      const message = (error as Error).message;
      setAutoPaidOrderStatus(chatId, sourceKey, id, "retry", this.now(), message.slice(0, 500));
      console.warn(`[auto-paid] chat=${chatId} order=${id}: ${message}`);
      const noticeKey = `${chatId}:${id}:${message}`;
      if (this.now() - (this.errorNotices.get(noticeKey) ?? 0) >= 60_000) {
        this.errorNotices.set(noticeKey, this.now());
        this.notify(chatId, `⚠️ Не удалось отметить сделку <code>${id}</code> оплаченной: ${escapeHtml(message)}`);
      }
    }
  }
}

function escapeHtml(value: string): string {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
}
