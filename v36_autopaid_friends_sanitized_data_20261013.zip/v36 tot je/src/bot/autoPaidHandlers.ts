import type { Context } from "grammy";
import { InlineKeyboard } from "grammy";
import { getAutoPaidSettings, listEnabledAutoPaidChats, setAutoPaidDelay, setAutoPaidEnabled } from "../db/repositories/autoPaid.js";
import { ensureSettings } from "../db/repositories/userSettings.js";
import { autoPaidCredentials } from "../services/autoPaidProcessor.js";

const waitingForDelay = new Set<number>();

function menu(chatId: number) {
  const settings = getAutoPaidSettings(chatId);
  const text = `✅ Автоотметка «Оплачено»\n\nСтатус: <b>${settings.enabled ? "включена" : "выключена"}</b>` +
    `\nВремя после обнаружения сделки: <b>${settings.delaySeconds} сек</b>` +
    "\n\nТолько BUY-сделки, ожидающие оплату. Бот не проверяет банковский перевод: включай только если фактически оплачиваешь сделки.";
  const keyboard = new InlineKeyboard()
    .text(settings.enabled ? "⏹ Выключить" : "▶️ Включить", "ap:toggle")
    .row().text("⏱ Изменить секунды", "ap:delay");
  return { text, keyboard };
}

export async function showAutoPaid(ctx: Context, edit = false): Promise<void> {
  const chatId = ctx.chat?.id;
  if (!chatId) return;
  const { text, keyboard } = menu(chatId);
  if (edit) await ctx.editMessageText(text, { parse_mode: "HTML", reply_markup: keyboard });
  else await ctx.reply(text, { parse_mode: "HTML", reply_markup: keyboard });
}

export async function autoPaidCallback(ctx: Context): Promise<void> {
  const chatId = ctx.chat?.id;
  if (!chatId) return;
  await ctx.answerCallbackQuery();
  const action = ctx.callbackQuery?.data;
  if (action === "ap:delay") {
    waitingForDelay.add(chatId);
    await ctx.reply("Введи целое число секунд от 0 до 86400. /cancel — отмена.");
    return;
  }
  if (action !== "ap:toggle") return;
  const enabled = getAutoPaidSettings(chatId).enabled;
  if (!enabled) {
    if ((await ensureSettings(chatId)).connection_mode !== "api") {
      await ctx.reply("Сначала выбери API-режим через /connection.");
      return;
    }
    const credentials = await autoPaidCredentials(chatId);
    if (!credentials) {
      await ctx.reply("Нет API-ключа Bybit. Добавь его через /connection или .env.");
      return;
    }
    for (const otherChatId of listEnabledAutoPaidChats()) {
      if (otherChatId !== chatId && (await autoPaidCredentials(otherChatId))?.sourceKey === credentials.sourceKey) {
        await ctx.reply("Для этого Bybit API-ключа автоотметка уже включена в другом Telegram-чате.");
        return;
      }
    }
  }
  setAutoPaidEnabled(chatId, !enabled);
  await showAutoPaid(ctx, true);
}

export async function consumeAutoPaidInput(ctx: Context): Promise<boolean> {
  const chatId = ctx.chat?.id;
  if (!chatId || !waitingForDelay.has(chatId)) return false;
  const text = ctx.message?.text?.trim() ?? "";
  if (!/^\d+$/.test(text) || Number(text) > 86_400) {
    await ctx.reply("Введи целое число секунд от 0 до 86400 или /cancel.");
    return true;
  }
  waitingForDelay.delete(chatId);
  setAutoPaidDelay(chatId, Number(text));
  await showAutoPaid(ctx);
  return true;
}

export function cancelAutoPaidInput(chatId: number): boolean {
  return waitingForDelay.delete(chatId);
}
