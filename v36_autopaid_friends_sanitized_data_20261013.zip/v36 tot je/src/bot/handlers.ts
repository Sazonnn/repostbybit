import type { Context } from "grammy";
import { config } from "../config.js";
import {
  BybitApiError,
  findMyRankInStack,
  getOrderBookLevel,
  getMyMerchantInfo,
  listOnline,
  rankFromOrderBook,
  withBybitConnection,
} from "../bybit/index.js";
import { getActiveCycleByChat } from "../db/repositories/cycles.js";
import { ensureSettings } from "../db/repositories/userSettings.js";
import { ensureSideSettings } from "../db/repositories/sideSettings.js";
import { computeTargetPrice } from "../services/price.js";
import { CycleRunner } from "../services/cycleRunner.js";
import {
  cancelActiveManualAds,
  listManualAds,
  replaceManualAd,
} from "../services/manualAds.js";
import { authService, describeSession } from "../auth/authService.js";
import { runLoginFlow } from "../auth/loginFlow.js";
import {
  idleKeyboard,
  manualKeyboard,
  monitoringKeyboard,
  runningKeyboard,
} from "./keyboards.js";

export interface BotDeps {
  runner: CycleRunner;
}

export function buildHandlers(deps: BotDeps) {
  const { runner } = deps;

  async function chatId(ctx: Context): Promise<number> {
    const id = ctx.chat?.id;
    if (!id) throw new Error("No chat in context");
    return id;
  }

  async function handleStart(ctx: Context): Promise<void> {
    const settings = ctx.chat?.id ? await ensureSettings(ctx.chat.id) : null;
    const isManual = settings?.ad_mode === "manual";
    await ctx.reply(
      [
        "👋 Панель управления Bybit P2P.",
        "",
        isManual
          ? "Режим: ручное создание. Кнопка снимает прошлое ручное объявление и ставит новое."
          : `Режим: автоцикл. Пересчет каждые ${config.cycle.intervalMs / 1000}с.`,
        isManual
          ? null
          : "Автоцикл сам пересоздает объявление, пока оно не попадет в целевой топ.",
        settings
          ? `Пара: ${settings.token_id}/${settings.currency_id} · ${settings.side === "1" ? "SELL" : "BUY"}`
          : null,
        "",
        "/settings — настройки (пара, side, диапазон, курс)",
        "/connection — сессия браузера или официальный API",
        "/filters — фильтры биржи (Verified, сортировка)",
        "/stack — посмотреть стакан",
        "/work_ads — автокурс рабочих объявлений по их ID",
        "/auto_paid — автоотметка «Оплачено» в BUY-сделках",
        settings?.connection_mode === "api"
          ? "API выбран: вход через Chrome не требуется"
          : "/auth_refresh — обновить сессию Bybit",
        "",
        isManual
          ? "➕ Создать новое — снять прошлое ручное и поставить новое"
          : "▶️ Старт — запустить цикл создания/проверки",
        "⏹ Стоп — снять объявление и остановить",
        "🔁 Polling — вкл/выкл мониторинг",
      ]
        .filter(Boolean)
        .join("\n"),
      { parse_mode: "HTML", reply_markup: isManual ? manualKeyboard : idleKeyboard },
    );
  }

  async function handleStartCycle(ctx: Context): Promise<void> {
    const id = await chatId(ctx);
    const settings = await ensureSettings(id);
    if (settings.ad_mode === "manual") {
      await handleManualCreate(ctx);
      return;
    }
    let started: Awaited<ReturnType<typeof runner.start>>;
    try {
      started = await runner.start(id);
    } catch (err) {
      await ctx.reply(`❌ ${(err as Error).message}\n\n/settings`);
      return;
    }
    const { cycle, created, workStatus } = started;
    const restWarn =
      workStatus === "REST"
        ? "\n\n⚠️ Аккаунт в REST mode — объявления будут создаваться, но в стакан не попадут. Включи Online в Bybit, чтобы цикл реально работал."
        : "";
    await ctx.reply(
      (created
        ? `▶️ Цикл #${cycle.id} запущен. Жди итерации (~${config.cycle.intervalMs / 1000}с).`
        : `Цикл #${cycle.id} уже запущен (статус: ${cycle.status}).`) + restWarn,
      { reply_markup: runningKeyboard },
    );
  }

  async function handleStopCycle(ctx: Context): Promise<void> {
    const id = await chatId(ctx);
    const cycle = await getActiveCycleByChat(id);
    if (!cycle) {
      await ctx.reply("Активного цикла нет.", { reply_markup: idleKeyboard });
      return;
    }
    await runner.stop(id, { cancelItem: true });
    const cancelled = cycle.current_item_id;
    await ctx.reply(
      `⏹ Цикл #${cycle.id} остановлен. ${
        cancelled ? `Снято объявление: ${cancelled}.` : "Объявление не было создано."
      }`,
      { reply_markup: idleKeyboard },
    );
  }

  async function handleTogglePoll(ctx: Context): Promise<void> {
    const id = await chatId(ctx);
    const result = await runner.togglePolling(id);
    if (!result.cycle) {
      await ctx.reply("Активного цикла нет — нечего переключать.", {
        reply_markup: idleKeyboard,
      });
      return;
    }
    await ctx.reply(
      result.nowMonitoring
        ? "🔁 Polling включён."
        : "⏸ Polling остановлен (объявление осталось активным).",
      { reply_markup: monitoringKeyboard },
    );
  }

  async function handleManualCreate(ctx: Context): Promise<void> {
    const id = await chatId(ctx);
    try {
      const result = await replaceManualAd(id);
      const place =
        result.rank !== null
          ? `№${result.rank} · стр. ${result.page}`
          : "позиция пока не найдена";
      const warnings = result.cancelWarnings.length
        ? `\n⚠️ Не всё снялось перед созданием:\n${result.cancelWarnings.join("\n")}`
        : "";
      await ctx.reply(
        `✅ Ручное объявление создано.\n` +
          `itemId: <code>${result.itemId}</code>\n` +
          `Тип: <b>${result.priceType === "1" ? "floating" : "fixed"}</b>\n` +
          `Цена: <b>${result.price}</b>` +
          (result.premium ? ` · premium ${result.premium}%` : "") +
          ` (топ ${result.topPrice ?? "?"})\n` +
          `В стакане: ${place}\n` +
          `Снято прошлых ручных: ${result.cancelled}${warnings}`,
        { parse_mode: "HTML", reply_markup: manualKeyboard },
      );
    } catch (err) {
      await ctx.reply(formatError(err), { reply_markup: manualKeyboard });
    }
  }

  async function handleManualList(ctx: Context): Promise<void> {
    const id = await chatId(ctx);
    try {
      const ads = await listManualAds(id);
      if (ads.length === 0) {
        await ctx.reply("Ручных активных объявлений нет.", {
          reply_markup: manualKeyboard,
        });
        return;
      }
      const lines = ads.map(
        (ad) =>
          `${ad.price_type === "1" ? "Floating" : "Fixed"} <code>${ad.item_id}</code> · ${ad.token_id}/${ad.currency_id} · ${ad.side === "1" ? "SELL" : "BUY"} · ${ad.price}`,
      );
      await ctx.reply(`📋 Активные ручные:\n${lines.join("\n")}`, {
        parse_mode: "HTML",
        reply_markup: manualKeyboard,
      });
    } catch (err) {
      await ctx.reply(formatError(err), { reply_markup: manualKeyboard });
    }
  }

  async function handleManualCancel(ctx: Context): Promise<void> {
    const id = await chatId(ctx);
    try {
      const result = await cancelActiveManualAds(id);
      const warnings = result.warnings.length
        ? `\n⚠️ Ошибки:\n${result.warnings.join("\n")}`
        : "";
      await ctx.reply(`🧹 Снято ручных объявлений: ${result.cancelled}${warnings}`, {
        reply_markup: manualKeyboard,
      });
    } catch (err) {
      await ctx.reply(formatError(err), { reply_markup: manualKeyboard });
    }
  }

  async function handleStatus(ctx: Context): Promise<void> {
    const id = await chatId(ctx);
    const cycle = await getActiveCycleByChat(id);
    if (!cycle) {
      await ctx.reply("Активных циклов нет.", { reply_markup: idleKeyboard });
      return;
    }
    const settings = await ensureSettings(id);
    const topN = settings.bourse_top_n;
    const nick = await connectionIdentityLabel(
      settings.connection_mode,
      cycle.user_id,
      id,
    );
    const primaryLabel = cycle.current_price_type === "1" ? "Floating" : "Fixed";
    const primaryPrice = `${cycle.current_price ?? "?"}${
      cycle.current_price_type === "1" && cycle.current_premium
        ? ` · premium ${cycle.current_premium}%`
        : ""
    }`;
    const fixedLine = cycle.current_item_id
      ? cycle.last_rank !== null
        ? `${primaryLabel}: ✅ ${nick} № ${cycle.last_rank} · стр. ${cycle.last_page} · ${primaryPrice}`
        : `${primaryLabel}: ❌ ${nick} не нашёлся в топ-${topN} · ${primaryPrice}`
      : `${primaryLabel}: — не создано`;
    const lines = [
      `Цикл #${cycle.id} · <b>${cycle.status}</b>`,
      `Пара: ${cycle.token_id}/${cycle.currency_id} · ${cycle.side === "1" ? "SELL" : "BUY"}`,
      `Цель: топ-${topN}`,
      fixedLine,
      `Попыток: ${cycle.attempts}`,
      cycle.last_error ? `Последняя ошибка: ${cycle.last_error}` : null,
    ].filter(Boolean);
    const kb =
      cycle.status === "running" ? runningKeyboard : monitoringKeyboard;
    await ctx.reply(lines.join("\n"), { parse_mode: "HTML", reply_markup: kb });
  }

  async function handleCheck(ctx: Context): Promise<void> {
    const id = await chatId(ctx);
    const cycle = await getActiveCycleByChat(id);
    if (!cycle || !cycle.current_item_id) {
      await ctx.reply(
        "Нечего проверять — нет активного объявления. Запусти ▶️ Старт.",
      );
      return;
    }
    try {
      const checkSettings = await ensureSettings(id);
      const topN = checkSettings.bourse_top_n;
      const pageSize = config.p2p.pageSize;
      const maxPages = Math.max(1, Math.ceil(topN / pageSize));
      const slots = [
        {
          label: cycle.current_price_type === "1" ? "Floating" : "Fixed",
          itemId: cycle.current_item_id,
          price: cycle.current_price,
          premium: cycle.current_premium,
        },
      ] as Array<{
        label: string;
        itemId: string;
        price: string | null;
        premium: string | null;
      }>;
      const checked: Array<{
        label: string;
        price: string | null;
        premium: string | null;
        rank: number | null;
        page: number | null;
        scannedPages: number;
        scannedItems: number;
        total: number | null;
        nickName: string | null;
      }> = [];
      for (const slot of slots) {
        const found = await withBybitConnection(
          checkSettings.connection_mode,
          () =>
            findMyRankInStack({
              itemId: slot.itemId,
              tokenId: cycle.token_id,
              currencyId: cycle.currency_id,
              side: cycle.side as "0" | "1",
              pageSize,
              maxPages,
              verificationFilter: checkSettings.bourse_verification_filter,
            }),
          id,
        );
        checked.push({ ...slot, ...found });
      }
      const foundNick = checked.find((x) => x.nickName)?.nickName ?? null;
      const accountNick =
        foundNick ??
        (checkSettings.connection_mode === "api"
          ? (
              await withBybitConnection(
                "api",
                () => getMyMerchantInfo(),
                id,
              ).catch(() => null)
            )?.nickName ?? null
          : (await authService.getCurrent())?.nickname ?? null);
      const nick = accountNick ? `@${accountNick}` : `uid ${cycle.user_id}`;
      const result = checked
        .map((slot) =>
          slot.rank !== null
            ? `✅ ${slot.label} ${nick}: №${slot.rank} · стр. ${slot.page} · ${slot.price}${slot.premium ? ` · premium ${slot.premium}%` : ""}`
            : `❌ ${slot.label} ${nick} не в топ-${topN} · ${slot.price ?? "?"}${slot.premium ? ` · premium ${slot.premium}%` : ""} (просмотрено ${slot.scannedPages} стр. / ${slot.scannedItems} объявл.; всего ${slot.total ?? "?"})`,
        )
        .join("\n");
      await ctx.reply(
        `📊 ${cycle.token_id}/${cycle.currency_id}\n${result}`,
      );
    } catch (err) {
      await ctx.reply(formatError(err));
    }
  }

  async function handleAuthStatus(ctx: Context): Promise<void> {
    const s = await authService.getCurrent();
    if (!s) {
      await ctx.reply(
        "🔐 Сессии нет. Запусти /auth_refresh — откроется окно chromium на хосте бота, залогинься в Bybit, бот сохранит сессию.",
      );
      return;
    }
    await ctx.reply(
      [
        `🔐 Активная сессия #${s.id}`,
        `   uid: ${s.bybitUid ?? "?"}`,
        `   ${describeSession(s)}`,
      ].join("\n"),
    );
  }

  async function handleAuthRefresh(ctx: Context): Promise<void> {
    await ctx.reply("🔓 Открываю chromium на хосте бота. Залогинься в окне (до 5 минут).");
    try {
      const session = await runLoginFlow({
        onWindowOpen: async () => {
          await ctx.reply("✅ Окно открыто. После логина окно само закроется.");
        },
      });
      await ctx.reply(
        `✅ Сессия #${session.id} сохранена. ${describeSession(session)}.`,
      );
    } catch (err) {
      await ctx.reply(`❌ Login flow упал: ${(err as Error).message}`);
    }
  }

  async function handleStack(ctx: Context): Promise<void> {
    const id = await chatId(ctx);
    const user = await ensureSettings(id);
    const sideSettings = await ensureSideSettings(id, user.side);
    const session = await authService.getCurrent();
    const apiProfile =
      user.connection_mode === "api"
        ? await withBybitConnection(
            "api",
            () => getMyMerchantInfo(),
            id,
          ).catch(() => null)
        : null;
    const ownUid =
      user.connection_mode === "api"
        ? apiProfile?.userId
        : session?.bybitUid;

    try {
      const result = await withBybitConnection(
        user.connection_mode,
        () =>
          listOnline({
            tokenId: user.token_id,
            currencyId: user.currency_id,
            side: user.side,
            size: 10,
            page: 1,
            userId: ownUid ?? undefined,
            verificationFilter: user.bourse_verification_filter,
            canTrade: user.bourse_can_trade,
            bulkMaker: user.bourse_bulk_maker,
            tradeWith: user.bourse_trade_with,
            sortType: user.bourse_sort_type,
          }),
        id,
      );
      const items = result.items ?? [];
      if (items.length === 0) {
        await ctx.reply("📭 Стакан пуст или Bybit вернул 0 объявлений.");
        return;
      }
      const myUid = ownUid;
      const sortLabel =
        user.bourse_sort_type === "PRICE"
          ? "по цене"
          : user.bourse_sort_type === "TRADE_COUNT"
            ? "по числу сделок"
            : "общий рейтинг";
      const lines = [
        `📊 <b>${user.token_id}/${user.currency_id} · ${user.side === "1" ? "SELL" : "BUY"}</b> · ${sortLabel} · топ ${items.length}`,
        ``,
      ];
      items.forEach((it, i) => {
        const isMine =
          myUid &&
          (String(it.userId) === String(myUid) ||
            String(it.accountId ?? "") === String(myUid));
        const rank = i + 1;
        const price = it.price ?? "?";
        const qty = it.lastQuantity ?? it.quantity ?? "?";
        const range = `${it.minAmount ?? "?"}-${it.maxAmount ?? "?"}`;
        const nick = it.nickName ?? "—";
        const stats =
          it.finishNum !== undefined
            ? ` · ${it.finishNum} ords / ${it.recentExecuteRate ?? "?"}%`
            : "";
        lines.push(
          `${rank.toString().padStart(2, " ")}. ${isMine ? "⭐ " : ""}<b>${price}</b> · ${qty} · ${range} · <i>${nick}</i>${stats}`,
        );
      });
      lines.push(``);
      lines.push(`<i>всего в стакане: ${result.count ?? "?"}</i>`);

      // Своё объявление: ищем его в целевом топ-N из настроек.
      const cycle = await getActiveCycleByChat(id);
      const accountNick =
        user.connection_mode === "api"
          ? apiProfile?.nickName
            ? `@${apiProfile.nickName}`
            : `uid ${apiProfile?.userId ?? "?"}`
          : session?.nickname
            ? `@${session.nickname}`
            : `uid ${session?.bybitUid ?? "?"}`;
      const stackTopN = user.bourse_top_n;
      const stackMaxPages = Math.max(1, Math.ceil(stackTopN / user.page_size));
      lines.push(``);
      const mySlots = [
        cycle?.current_item_id && {
          label: cycle.current_price_type === "1" ? "Floating" : "Fixed",
          itemId: cycle.current_item_id,
          price: cycle.current_price,
          premium: cycle.current_premium,
        },
      ].filter(Boolean) as Array<{
        label: string;
        itemId: string;
        price: string | null;
        premium: string | null;
      }>;
      if (mySlots.length > 0) {
        for (const slot of mySlots) {
          try {
            const mine = await withBybitConnection(
              user.connection_mode,
              () =>
                findMyRankInStack({
                  itemId: slot.itemId,
                  tokenId: user.token_id,
                  currencyId: user.currency_id,
                  side: user.side,
                  pageSize: user.page_size,
                  maxPages: stackMaxPages,
                  verificationFilter: user.bourse_verification_filter,
                }),
              id,
            );
            const priceInfo = `${slot.price ?? "?"}${slot.premium ? ` · premium ${slot.premium}%` : ""}`;
            if (mine.rank !== null) {
              const inTarget = mine.rank <= stackTopN ? " ✅" : "";
              lines.push(
                `${slot.label} (${accountNick}): №${mine.rank} · стр. ${mine.page} · ${priceInfo}${inTarget}`,
              );
            } else {
              lines.push(
                `${slot.label} (${accountNick}): не в топ-${stackTopN}. Цена ${priceInfo}. Просмотрено ${mine.scannedPages} стр. / ${mine.scannedItems} объявл.; всего ${mine.total ?? "?"}.`,
              );
            }
          } catch (err) {
            lines.push(`${slot.label}: не удалось проверить (${(err as Error).message}).`);
          }
        }
      } else {
        lines.push(`Твоё (${accountNick}): объявление не создано.`);
      }

      // Где бы встал я с моей ценой (гипотетика по price-only)?
      const top = items[0]?.price;
      if (top) {
        const target = computeTargetPrice({
          topPrice: String(top),
          side: user.side,
          step: Number(user.price_step),
          min: Number(user.price_min),
          max: Number(user.price_max),
          mode: user.price_mode,
          fixedPrice: user.price_fixed,
        });
        if (target.ok) {
          try {
            const ob = await withBybitConnection(
              user.connection_mode,
              () =>
                getOrderBookLevel({
                  tokenId: user.token_id,
                  currencyId: user.currency_id,
                  side: user.side,
                  price: target.price,
                }),
              id,
            );
            const info = rankFromOrderBook(ob, user.page_size);
            lines.push(
              `Если бы выставить ${target.price} → ~№${info.rank ?? "?"} (по цене)`,
            );
          } catch {}
        }
      }

      await ctx.reply(lines.join("\n"), { parse_mode: "HTML" });
    } catch (err) {
      await ctx.reply(formatError(err));
    }
  }

  return {
    handleStart,
    handleStartCycle,
    handleStopCycle,
    handleTogglePoll,
    handleManualCreate,
    handleManualList,
    handleManualCancel,
    handleStatus,
    handleCheck,
    handleAuthStatus,
    handleAuthRefresh,
    handleStack,
  };
}

async function connectionIdentityLabel(
  mode: "session" | "api",
  fallbackUid: string | number,
  chatId?: number,
): Promise<string> {
  if (mode === "api") {
    const profile = await withBybitConnection(
      "api",
      () => getMyMerchantInfo(),
      chatId,
    ).catch(() => null);
    return profile?.nickName
      ? `@${profile.nickName}`
      : `uid ${String(profile?.userId ?? fallbackUid)}`;
  }
  const session = await authService.getCurrent();
  return session?.nickname
    ? `@${session.nickname}`
    : `uid ${String(session?.bybitUid ?? fallbackUid)}`;
}

function formatError(err: unknown): string {
  if (err instanceof BybitApiError) {
    return `❌ Bybit API ${err.code}: ${err.message}`;
  }
  if (err instanceof Error) return `❌ ${err.message}`;
  return `❌ ${String(err)}`;
}
