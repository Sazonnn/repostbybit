CREATE TABLE auto_paid_settings (
  chat_id TEXT PRIMARY KEY,
  enabled INTEGER NOT NULL DEFAULT 0 CHECK (enabled IN (0, 1)),
  delay_seconds INTEGER NOT NULL DEFAULT 30 CHECK (delay_seconds BETWEEN 0 AND 86400)
);

CREATE TABLE auto_paid_orders (
  chat_id TEXT NOT NULL,
  source_key TEXT NOT NULL,
  order_id TEXT NOT NULL,
  first_seen_ms INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'seen',
  last_attempt_ms INTEGER,
  last_error TEXT,
  PRIMARY KEY (chat_id, source_key, order_id)
);
