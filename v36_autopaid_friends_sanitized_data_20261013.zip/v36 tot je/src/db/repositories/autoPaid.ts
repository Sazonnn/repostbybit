import { db } from "../pool.js";

export interface AutoPaidSettings {
  enabled: boolean;
  delaySeconds: number;
}

export interface AutoPaidOrder {
  firstSeenMs: number;
  status: "seen" | "sending" | "retry" | "done";
  lastAttemptMs: number | null;
}

export function getAutoPaidSettings(chatId: number): AutoPaidSettings {
  const row = db.prepare("SELECT enabled, delay_seconds FROM auto_paid_settings WHERE chat_id = ?")
    .get(String(chatId)) as { enabled: number; delay_seconds: number } | undefined;
  return { enabled: row?.enabled === 1, delaySeconds: row?.delay_seconds ?? 30 };
}

export function setAutoPaidEnabled(chatId: number, enabled: boolean): void {
  db.prepare(`INSERT INTO auto_paid_settings(chat_id, enabled) VALUES(?, ?)
    ON CONFLICT(chat_id) DO UPDATE SET enabled = excluded.enabled`)
    .run(String(chatId), enabled ? 1 : 0);
  if (enabled) {
    db.prepare("DELETE FROM auto_paid_orders WHERE chat_id = ? AND status <> 'done'").run(String(chatId));
  }
}

export function setAutoPaidDelay(chatId: number, seconds: number): void {
  if (!Number.isInteger(seconds) || seconds < 0 || seconds > 86_400) {
    throw new Error("Время до отметки должно быть целым числом от 0 до 86400 секунд.");
  }
  db.prepare(`INSERT INTO auto_paid_settings(chat_id, delay_seconds) VALUES(?, ?)
    ON CONFLICT(chat_id) DO UPDATE SET delay_seconds = excluded.delay_seconds`)
    .run(String(chatId), seconds);
}

export function listEnabledAutoPaidChats(): number[] {
  return (db.prepare("SELECT chat_id FROM auto_paid_settings WHERE enabled = 1").all() as { chat_id: string }[])
    .map(row => Number(row.chat_id)).filter(Number.isSafeInteger);
}

export function firstSeenAutoPaidOrder(chatId: number, sourceKey: string, orderId: string, now: number): AutoPaidOrder {
  db.prepare(`INSERT OR IGNORE INTO auto_paid_orders(chat_id, source_key, order_id, first_seen_ms)
    VALUES(?, ?, ?, ?)`).run(String(chatId), sourceKey, orderId, now);
  const row = db.prepare(`SELECT first_seen_ms, status, last_attempt_ms FROM auto_paid_orders
    WHERE chat_id = ? AND source_key = ? AND order_id = ?`)
    .get(String(chatId), sourceKey, orderId) as {
      first_seen_ms: number;
      status: AutoPaidOrder["status"];
      last_attempt_ms: number | null;
    };
  return { firstSeenMs: row.first_seen_ms, status: row.status, lastAttemptMs: row.last_attempt_ms };
}

export function setAutoPaidOrderStatus(chatId: number, sourceKey: string, orderId: string,
  status: AutoPaidOrder["status"], now: number, error: string | null = null): void {
  db.prepare(`UPDATE auto_paid_orders SET status = ?, last_attempt_ms = ?, last_error = ?
    WHERE chat_id = ? AND source_key = ? AND order_id = ?`)
    .run(status, now, error, String(chatId), sourceKey, orderId);
}
