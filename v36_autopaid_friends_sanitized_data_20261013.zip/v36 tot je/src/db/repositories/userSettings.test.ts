import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

const directory = mkdtempSync(join(tmpdir(), "v36-friend-settings-"));
process.env.TELEGRAM_BOT_TOKEN ||= "test-token";
process.env.SQLITE_PATH = join(directory, "bot.db");

test("fresh users receive only safe friend settings and do not auto-trade", async () => {
  const { runMigrations } = await import("../migrate.js");
  const { db } = await import("../pool.js");
  const { ensureSettings } = await import("./userSettings.js");
  try {
    await runMigrations();
    const plain = await ensureSettings(111111);
    assert.equal(plain.working_ads_interval_ms, 30000);

    db.prepare(`INSERT INTO friend_settings_template (
      token_id, currency_id, side, price_mode, price_step, price_min,
      price_max, page_size, bourse_verification_filter, bourse_sort_type,
      bourse_can_trade, bourse_bulk_maker, bourse_trade_with, bourse_top_n,
      connection_mode, primary_price_type, working_ads_interval_ms,
      working_ads_update_interval_ms, working_ads_follow_interval_ms
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      "USDT", "RUB", "0", "auto", "0.01", "0", "999999", 10,
      0, "OVERALL_RANKING", 1, 1, 1, 40, "api", "fixed", 10, 250, 300,
    );

    const friend = await ensureSettings(222222);
    assert.equal(friend.side, "0");
    assert.equal(friend.connection_mode, "api");
    assert.equal(friend.working_ads_interval_ms, 10);
    assert.equal(friend.working_ads_update_interval_ms, 250);
    assert.equal(friend.working_ads_follow_interval_ms, 300);
    assert.equal(friend.working_ads_enabled, false);
    assert.equal(db.prepare("SELECT COUNT(*) AS n FROM working_ads").get()!.n, 0);
    assert.equal(db.prepare("SELECT COUNT(*) AS n FROM bybit_api_accounts").get()!.n, 0);
    assert.equal((await ensureSettings(111111)).working_ads_interval_ms, 30000);
  } finally {
    db.close();
    rmSync(directory, { recursive: true, force: true });
  }
});
