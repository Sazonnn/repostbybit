// Учёт работы, которая останавливает программу, пока не закончится: запись в
// консоль и запросы к базе данных (SQLite здесь синхронный). Сами по себе эти
// цифры ничего не меняют — их читает диагностика замираний (loopLag.ts).
export type SyncKind = "console" | "db";

export interface SyncBucket {
  ms: number;
  count: number;
  maxMs: number;
  maxLabel: string;
}

function empty(): SyncBucket {
  return { ms: 0, count: 0, maxMs: 0, maxLabel: "" };
}

let tick: Record<SyncKind, SyncBucket> = { console: empty(), db: empty() };
let minute: Record<SyncKind, SyncBucket> = { console: empty(), db: empty() };

/** Отметить синхронную работу: сколько мс заняла и что это было. */
export function noteSyncWork(kind: SyncKind, ms: number, label: string): void {
  for (const bucket of [tick[kind], minute[kind]]) {
    bucket.ms += ms;
    bucket.count += 1;
    if (ms > bucket.maxMs) {
      bucket.maxMs = ms;
      bucket.maxLabel = label;
    }
  }
}

/** Что накопилось с прошлого вызова (для привязки к одному замиранию). */
export function takeTickSyncWork(): Record<SyncKind, SyncBucket> {
  const taken = tick;
  tick = { console: empty(), db: empty() };
  return taken;
}

/** Что накопилось за минуту. */
export function takeMinuteSyncWork(): Record<SyncKind, SyncBucket> {
  const taken = minute;
  minute = { console: empty(), db: empty() };
  return taken;
}
