// ---- Диагностика замираний программы ----
// Лог 04.10 21:26: в момент смены курса бот несколько раз на 0,2–0,9 с
// переставал и читать стакан, и отправлять цены (все IP разом "медленно",
// дыра в чтении ~1 с, отправка через 219 и 915 мс после "увидел"). Так
// выглядит остановка самой программы. Здесь измеряем, была ли остановка и на
// что ушло время:
//   - запись в окно консоли (Windows ждёт, пока консоль отрисует строку);
//   - запросы к базе данных (SQLite синхронный, ждёт диск);
//   - сборка мусора Node;
//   - остальное: процессор занят своим кодом или система не давала работать.
//
// Как меряем: таймер раз в 20 мс. Если он сработал позже, чем должен, на
// LAG_MIN_MS и больше — программа всё это время стояла. На работу бота не
// влияет: проверка занимает микросекунды, строка [lag] пишется с задержкой.
// .env: LOOP_LAG_DIAG=0 — выключить (по умолчанию включено).
import { performance, PerformanceObserver } from "node:perf_hooks";
import { inRateWindow } from "../bybit/stakanSources.js";
import { noteSyncWork, takeMinuteSyncWork, takeTickSyncWork, type SyncBucket, type SyncKind } from "./syncTime.js";

const TICK_MS = 20;
// В окне смены курса пишем о замираниях от 100 мс, вне окна — только о долгих.
const LAG_MIN_WINDOW_MS = 100;
const LAG_MIN_IDLE_MS = 500;
// Строку пишем не сразу: данные о сборке мусора приходят с опозданием, а сама
// запись в консоль не должна попадать в горячий момент.
const REPORT_DELAY_MS = 400;
const MAX_LINES_PER_MINUTE = 30;

interface Stall {
  startPerf: number;
  endPerf: number;
  wallStart: number;
  ms: number;
  work: Record<SyncKind, SyncBucket>;
  cpuMs: number;
}

let started = false;

const clock = (ms: number) => new Date(ms).toISOString().slice(11, 23);
const round = (ms: number) => Math.round(ms);

function part(name: string, bucket: SyncBucket, unit: string): string {
  if (bucket.count === 0) return `${name} 0 мс`;
  return `${name} ${round(bucket.ms)} мс (${bucket.count} ${unit}` +
    (bucket.maxMs >= 20 ? `, самая долгая ${round(bucket.maxMs)} мс: "${bucket.maxLabel}"` : "") + ")";
}

/** Запустить измерение замираний. Вызывать один раз при старте. */
export function startLoopLagDiag(): void {
  if (started || process.env.LOOP_LAG_DIAG === "0") return;
  started = true;

  // Время, которое программа проводит внутри записи в консоль.
  const rawLog = console.log.bind(console);
  for (const name of ["log", "info", "warn", "error"] as const) {
    const raw = console[name].bind(console);
    console[name] = (...args: unknown[]) => {
      const startedAt = performance.now();
      try {
        raw(...args);
      } finally {
        noteSyncWork("console", performance.now() - startedAt, String(args[0] ?? "").slice(0, 48));
      }
    };
  }

  // Сборка мусора: длительности приходят позже, храним последние.
  const gc: Array<{ start: number; end: number }> = [];
  try {
    new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) gc.push({ start: entry.startTime, end: entry.startTime + entry.duration });
      while (gc.length > 500) gc.shift();
    }).observe({ entryTypes: ["gc"] });
  } catch {
    // Нет данных о сборке мусора — она попадёт в "остальное".
  }
  const gcWithin = (from: number, to: number) => {
    let total = 0;
    for (const entry of gc) total += Math.max(0, Math.min(entry.end, to) - Math.max(entry.start, from));
    return total;
  };

  const pending: Stall[] = [];
  let reportTimer: ReturnType<typeof setTimeout> | null = null;
  const minute = { startedAt: Date.now(), startPerf: performance.now(), stalls: 0, stallMs: 0, lines: 0, wasWindow: false };

  const report = () => {
    reportTimer = null;
    for (const stall of pending.splice(0)) {
      if (minute.lines >= MAX_LINES_PER_MINUTE) continue;
      minute.lines += 1;
      const gcMs = gcWithin(stall.startPerf, stall.endPerf);
      const known = stall.work.console.ms + stall.work.db.ms + gcMs;
      const rest = Math.max(0, stall.ms - known);
      // Процессор занят почти всё время остановки — программа сама что-то
      // считала. Почти не занят — она ждала систему (диск, консоль, процессор
      // сервера отдан другому).
      const restNote = rest < 50 ? ""
        : stall.cpuMs >= rest * 0.6 ? " — программа была занята своими вычислениями"
          : " — программа ждала систему (процессор сервера был занят другим или завис ввод-вывод)";
      rawLog(`[lag] бот стоял ${round(stall.ms)} мс с ${clock(stall.wallStart)}: ` +
        `${part("консоль", stall.work.console, "строк")}; ${part("база", stall.work.db, "запросов")}; ` +
        `сборка мусора ${round(gcMs)} мс; остальное ${round(rest)} мс${restNote}; ` +
        `процессор работал ${round(stall.cpuMs)} мс`);
    }
  };

  let last = performance.now();
  let cpu = process.cpuUsage();
  const timer = setInterval(() => {
    const now = performance.now();
    const drift = now - last - TICK_MS;
    last = now;
    const used = process.cpuUsage(cpu);
    cpu = process.cpuUsage();
    const work = takeTickSyncWork();
    const wall = Date.now();
    const windowNow = inRateWindow(wall);
    if (windowNow) minute.wasWindow = true;
    if (drift >= (windowNow ? LAG_MIN_WINDOW_MS : LAG_MIN_IDLE_MS)) {
      minute.stalls += 1;
      minute.stallMs += drift;
      pending.push({
        startPerf: now - drift - TICK_MS, endPerf: now, wallStart: wall - drift, ms: drift, work,
        cpuMs: (used.user + used.system) / 1000,
      });
      reportTimer ??= setTimeout(report, REPORT_DELAY_MS);
    }
    // Итог за минуту — только для минут окна смены курса.
    if (wall - minute.startedAt >= 60_000) {
      const total = takeMinuteSyncWork();
      if (minute.wasWindow) {
        const gcMs = gcWithin(minute.startPerf, now);
        rawLog(`[lag] за ${round((wall - minute.startedAt) / 1000)} с: замираний от ${LAG_MIN_WINDOW_MS} мс — ${minute.stalls}` +
          (minute.stalls ? ` (всего ${round(minute.stallMs)} мс)` : "") +
          `; ${part("консоль", total.console, "строк")}; ${part("база", total.db, "запросов")}; ` +
          `сборка мусора ${round(gcMs)} мс`);
      }
      Object.assign(minute, { startedAt: wall, startPerf: now, stalls: 0, stallMs: 0, lines: 0, wasWindow: false });
    }
  }, TICK_MS);
  timer.unref?.();
  rawLog(`[lag] измерение замираний включено: строка [lag] появится, если бот в окне смены курса стоял ` +
    `${LAG_MIN_WINDOW_MS} мс и дольше (LOOP_LAG_DIAG=0 — выключить)`);
}
