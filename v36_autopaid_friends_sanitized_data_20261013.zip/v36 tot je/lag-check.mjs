// Проверка сервера: замирает ли на нём даже пустая программа.
// К боту не относится и ничего не меняет. Бота останавливать не нужно.
// Запуск:  node lag-check.mjs        (2 минуты)
//          node lag-check.mjs 10     (10 минут — чтобы захватить окно смены курса)
// Итог — на экране и в файле lag-check.txt рядом со скриптом.
import os from "node:os";
import { writeFileSync } from "node:fs";

const minutes = Math.min(60, Math.max(0.2, Number(process.argv[2] ?? 2) || 2));
const TICK_MS = 20;
const MIN_MS = 100;
const lines = [];
const say = (text = "") => { console.log(text); lines.push(text); };
const clock = (ms) => new Date(ms).toISOString().slice(11, 23);

// Загрузка процессора всего сервера (все ядра) между двумя замерами, в процентах.
const cpuTimes = () => os.cpus().reduce((sum, cpu) => {
  const t = cpu.times;
  return { busy: sum.busy + t.user + t.sys + t.irq + t.nice, total: sum.total + t.user + t.sys + t.irq + t.nice + t.idle };
}, { busy: 0, total: 0 });

const cores = os.cpus();
say(`Проверка сервера, ${new Date().toISOString().slice(0, 19).replace("T", " ")} UTC, ${minutes} мин`);
say(`Процессор: ${cores[0]?.model?.trim() ?? "?"}, ядер: ${cores.length}; память: свободно ` +
  `${Math.round(os.freemem() / 1048576)} МБ из ${Math.round(os.totalmem() / 1048576)} МБ`);
say("");

const stalls = [];
const loads = [];
let prevCpu = cpuTimes();
let lastLoad = 0;
let last = performance.now();
let secondAt = Date.now();
const endAt = Date.now() + minutes * 60_000;

const timer = setInterval(() => {
  const now = performance.now();
  const drift = now - last - TICK_MS;
  last = now;
  const wall = Date.now();
  if (wall - secondAt >= 1000) {
    const cpu = cpuTimes();
    const total = cpu.total - prevCpu.total;
    lastLoad = total > 0 ? Math.round(100 * (cpu.busy - prevCpu.busy) / total) : 0;
    loads.push(lastLoad);
    prevCpu = cpu;
    secondAt = wall;
  }
  if (drift >= MIN_MS) {
    stalls.push({ at: wall - drift, ms: Math.round(drift), load: lastLoad });
    say(`${clock(wall - drift)}  пустая программа стояла ${Math.round(drift)} мс; процессор сервера перед этим был занят на ${lastLoad}%`);
  }
  if (wall >= endAt) {
    clearInterval(timer);
    const total = stalls.reduce((sum, stall) => sum + stall.ms, 0);
    const avgLoad = loads.length ? Math.round(loads.reduce((x, y) => x + y, 0) / loads.length) : 0;
    const maxLoad = loads.length ? Math.max(...loads) : 0;
    const busySeconds = loads.filter((value) => value >= 90).length;
    say("");
    say(`ИТОГ за ${minutes} мин: замираний от ${MIN_MS} мс — ${stalls.length}, всего ${total} мс` +
      (stalls.length ? `, самое долгое ${Math.max(...stalls.map((stall) => stall.ms))} мс` : ""));
    say(`Загрузка процессора сервера: в среднем ${avgLoad}%, максимум ${maxLoad}%, секунд с загрузкой от 90% — ${busySeconds} из ${loads.length}`);
    if (stalls.length === 0) {
      say("Вывод: пустая программа не замирает. Значит, бота останавливает что-то в нём самом (скорее всего вывод в консоль).");
    } else if (busySeconds >= loads.length * 0.2 || avgLoad >= 70) {
      say("Вывод: серверу не хватает процессора — он занят почти полностью. Смотрите в Диспетчере задач, какая программа его занимает.");
    } else {
      say("Вывод: пустая программа замирает, хотя процессор сервера не загружен. Так бывает, когда сам сервер");
      say("       приостанавливается хостером (соседи по железу). Это лечится только сменой тарифа или хостера.");
    }
    try {
      writeFileSync(new URL("./lag-check.txt", import.meta.url), lines.join("\r\n") + "\r\n", "utf8");
      console.log("\nИтог сохранён в файл lag-check.txt");
    } catch { /* не страшно */ }
  }
}, TICK_MS);
