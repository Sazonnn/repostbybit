This distribution contains a sanitized SQLite database with a safe settings
template. It has no original Telegram IDs, ad IDs, API credentials, payment
methods or trading history. The new owner's settings are created on /start.
The API credential key is generated locally when new credentials are saved.
Never replace this database with somebody else's database or api-master.key.
