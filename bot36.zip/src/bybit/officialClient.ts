import { createHmac } from "node:crypto";
import { config } from "../config.js";
import { getActiveApiCredentials } from "../db/repositories/apiAccounts.js";
import { noteAccountUpdateAnswered } from "../db/repositories/workingAdUpdateAttempts.js";
import { BybitApiError, BybitAuthError } from "./client.js";
import {
  currentConnectionChatId,
  currentConnectionCredentials,
} from "./connectionContext.js";
import { SecurityChallengeRequiredError } from "./createAd.js";
import {
  coolDownStakanSource,
  EXTRA_SOURCE_TIMEOUT_MS,
  inRateWindow,
  noteHedge,
  noteServedStakanSource,
  pickStakanSource,
  stakanSources,
  reportStaleStakan,
  postFromSource,
  type StakanSource,
} from "./stakanSources.js";
import type {
  CreateAdRequest,
  LastPriceResult,
  OrderBookLevelResult,
  Side,
  UpdateAdRequest,
} from "./types.js";

interface OfficialEnvelope<T> {
  retCode?: number;
  retMsg?: string;
  ret_code?: number;
  ret_msg?: string;
  result: T;
  retExtInfo?: unknown;
  ext_info?: unknown;
  time?: number;
  time_now?: string;
}

interface OfficialOnlineItem {
  id?: string;
  itemId?: string;
  userId?: string | number;
  priceType?: string | number;
  price?: string;
  premium?: string;
  [key: string]: unknown;
}

interface OfficialOnlineResult {
  count?: number;
  items?: OfficialOnlineItem[];
  [key: string]: unknown;
}

interface OfficialAccountInfo {
  userId?: string | number;
  nickName?: string;
  isOnline?: boolean;
  canSubOnline?: boolean;
  [key: string]: unknown;
}

const PUBLIC_P2P_URL =
  "https://www.bybit.com/x-api/fiat/otc/item/online";

function resultListLength(value: unknown): number {
  if (Array.isArray(value)) return value.length;
  if (!value || typeof value !== "object") return 0;
  const obj = value as Record<string, unknown>;
  if (Array.isArray(obj.items)) return obj.items.length;
  if (Array.isArray(obj.list)) return obj.list.length;
  return 0;
}

// ---- Диагностика лимитов: какие запросы уходили к Bybit за последние 5 с ----
const recentRequests: { at: number; path: string }[] = [];

function noteRequest(path: string): void {
  const now = Date.now();
  recentRequests.push({ at: now, path });
  while (recentRequests.length > 0 && now - recentRequests[0]!.at > 5_000) recentRequests.shift();
}

/** Помечает ошибку адресом запроса — боту важно, лимит стакана это или API аккаунта. */
function withEndpoint<E extends Error>(error: E, endpoint: string): E {
  (error as E & { endpoint?: string }).endpoint = endpoint;
  return error;
}

function isRateLimit(code: number, message: string): boolean {
  return code === 10006 || code === 429 || /too many|rate.?limit|access too frequent/i.test(message);
}

function reportRateLimit(path: string, code: number, message: string, headers?: { get(name: string): string | null }): void {
  const now = Date.now();
  const byPath = new Map<string, { s1: number; s5: number }>();
  for (const entry of recentRequests) {
    const stat = byPath.get(entry.path) ?? { s1: 0, s5: 0 };
    stat.s5 += 1;
    if (now - entry.at <= 1_000) stat.s1 += 1;
    byPath.set(entry.path, stat);
  }
  const summary = [...byPath.entries()]
    .map(([name, stat]) => `${name}: ${stat.s1} за 1 с, ${stat.s5} за 5 с`).join("; ");
  const limit = headers?.get("x-bapi-limit");
  const status = headers?.get("x-bapi-limit-status");
  const reset = headers?.get("x-bapi-limit-reset-timestamp");
  console.warn(
    `[bybit-diag] отказ ${code} на ${path} (${message.slice(0, 80)})` +
      (limit ? `; лимит адреса ${limit}, осталось ${status ?? "?"}` +
        (reset ? `, сброс через ${Math.max(0, Number(reset) - now)} мс` : "") : "") +
      `. Запросы: ${summary || "—"}`,
  );
}

// Самое новое серверное время (time_now) среди ответов стакана. Ответ со
// временем заметно старше — устаревший снимок (кэш на пути или отстающий узел
// Bybit): такой стакан показывает прошлое состояние и сбивает чехарду.
let newestStakanServerTime = 0;
// .env: STALE_STAKAN_TOLERANCE_S (0..5, по умолчанию 0.5) — насколько серверное время
// ответа может отставать от самого нового, чтобы ответ считался свежим.
const STALE_STAKAN_TOLERANCE_S = (() => {
  const raw = process.env.STALE_STAKAN_TOLERANCE_S;
  const value = Number(raw);
  return raw !== undefined && raw.trim() !== "" && Number.isFinite(value) && value >= 0 && value <= 5 ? value : 0.5;
})();

// ---- Страховочный запрос ----
// Если стакан с выбранного IP не пришёл за HEDGE_AFTER_MS (обычно ответ за
// 40–90 мс), параллельно читаем его с другого IP и берём тот ответ, что придёт
// первым. Так редкие ответы по 200–300 мс (новое соединение, промах кэша
// Bybit) не задерживают бота. Страховку не шлём на IP, который использовался
// меньше HEDGE_MIN_IDLE_MS назад, — чтобы не превысить его лимит.
const HEDGE_AFTER_MS = 150;
// В окне смены курса страхуемся раньше. Можно поменять в .env:
// STAKAN_HEDGE_MS=80 (от 40 до 500) — через сколько мс ждать ответа стакана,
// прежде чем параллельно спросить другой IP.
const HEDGE_AFTER_WINDOW_MS = (() => {
  const value = Number(process.env.STAKAN_HEDGE_MS);
  return process.env.STAKAN_HEDGE_MS && Number.isFinite(value) && value >= 40 && value <= 500
    ? Math.round(value) : 100;
})();
const HEDGE_MIN_IDLE_MS = 300;

function postPublicP2pMarketHedged<T>(body: unknown): Promise<T> {
  const primary = stakanSources().length > 1 ? pickStakanSource() : null;
  if (!primary) return postPublicP2pMarket<T>(body);
  return new Promise<T>((resolve, reject) => {
    let done = false;
    let pending = 1;
    const finish = (promise: Promise<T>, isHedge: boolean) => {
      promise.then((value) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        if (isHedge) noteHedge(true);
        resolve(value);
      }, (error: unknown) => {
        pending -= 1;
        // Ошибку отдаём, только когда не осталось ни одного запроса в пути.
        if (!done && pending === 0) {
          done = true;
          clearTimeout(timer);
          reject(error);
        }
      });
    };
    const timer = setTimeout(() => {
      if (done) return;
      const backup = pickStakanSource(primary);
      if (!backup || Date.now() - backup.lastUsedAt < HEDGE_MIN_IDLE_MS) return;
      pending += 1;
      noteHedge(false);
      finish(postPublicP2pMarket<T>(body, primary, backup), true);
    }, inRateWindow() ? HEDGE_AFTER_WINDOW_MS : HEDGE_AFTER_MS);
    finish(postPublicP2pMarket<T>(body, undefined, primary), false);
  });
}

async function postPublicP2pMarket<T>(body: unknown, exclude?: StakanSource, forced?: StakanSource): Promise<T> {
  // Стакан читаем по очереди с нескольких IP (STAKAN_SOURCES в .env), если
  // они заданы. Если у одного IP лимит или обрыв — сразу пробуем другой.
  const source = forced ?? pickStakanSource(exclude);
  if (!source) throw new Error("Bybit public P2P: нет доступных IP для чтения стакана");
  const label = source.kind === "direct" ? "стакан (www.bybit.com)" : `стакан (${source.label})`;
  const retryElsewhere = (ms: number, reason: string): Promise<T> | null => {
    coolDownStakanSource(source, ms, reason);
    if (exclude || !pickStakanSource(source)) return null;
    return postPublicP2pMarket<T>(body, source);
  };
  noteRequest(label);
  let response: Awaited<ReturnType<typeof postFromSource>>;
  try {
    response = await postFromSource(source, PUBLIC_P2P_URL, {
      accept: "application/json",
      "accept-language": "en",
      // Просим не отдавать сохранённый (кэшированный) ответ — только свежий.
      // Устаревшие снимки идут от узлов Bybit; если часть из них — кэш на
      // пути (CDN), эти заголовки его обходят. Вреда нет.
      "cache-control": "no-cache, no-store, max-age=0",
      pragma: "no-cache",
      "content-type": "application/json;charset=UTF-8",
      origin: "https://www.bybit.com",
      referer: "https://www.bybit.com/fiat/trade/otc/",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    }, JSON.stringify(body), source.kind === "direct" ? 15_000 : EXTRA_SOURCE_TIMEOUT_MS);
  } catch (error) {
    // Обрыв связи через доп. IP/прокси — этот источник на паузу, читаем с другого.
    if (source.kind !== "direct") {
      const retry = retryElsewhere(30_000, `ошибка связи (${(error as Error).message})`);
      if (retry) return retry;
    }
    throw error;
  }
  const rawText = response.text;
  if (!response.ok) {
    if (response.status === 429 || response.status === 403) {
      reportRateLimit(label, response.status, rawText.slice(0, 80), response.headers);
      const retry = retryElsewhere(response.status === 403 ? 600_000 : 5_000, `HTTP ${response.status}`);
      if (retry) return retry;
    }
    throw new Error(
      `Bybit public P2P HTTP ${response.status}: ${rawText.slice(0, 300)}`,
    );
  }

  let envelope: OfficialEnvelope<T>;
  try {
    envelope = JSON.parse(rawText) as OfficialEnvelope<T>;
  } catch {
    throw new Error(
      `Bybit public P2P вернул не JSON: ${rawText.slice(0, 200)}`,
    );
  }
  const code = envelope.retCode ?? envelope.ret_code ?? -1;
  const message = envelope.retMsg ?? envelope.ret_msg ?? "unknown";
  if (code !== 0) {
    if (isRateLimit(code, message)) {
      reportRateLimit(label, code, message, response.headers);
      const retry = retryElsewhere(5_000, `лимит стакана (${code})`);
      if (retry) return retry;
    }
    throw withEndpoint(new BybitApiError(code, message, envelope), "stakan");
  }
  const serverTime = Number(envelope.time_now ?? 0);
  if (Number.isFinite(serverTime) && serverTime > 0) {
    if (serverTime < newestStakanServerTime - STALE_STAKAN_TOLERANCE_S) {
      const lag = (newestStakanServerTime - serverTime).toFixed(1);
      reportStaleStakan(source, `устаревший стакан (на ${lag} с старше последнего)`);
      if (!exclude && pickStakanSource(source)) return postPublicP2pMarket<T>(body, source);
      console.warn(`[stakan] ${source.label}: устаревший стакан, других IP нет — использую как есть`);
    } else {
      newestStakanServerTime = Math.max(newestStakanServerTime, serverTime);
    }
  }
  noteServedStakanSource(source);
  // Помечаем, с какого IP прочитан стакан (для защиты от устаревших снимков).
  const result = envelope.result as T & { stakanSource?: string; stakanServerTime?: number };
  if (result && typeof result === "object") {
    result.stakanSource = source.label;
    // Серверное время снимка (для замера свежести, STAKAN_TEST).
    if (Number.isFinite(serverTime) && serverTime > 0) result.stakanServerTime = serverTime;
  }
  return result;
}

/**
 * ЗАМЕР (STAKAN_TEST): один запрос стакана с заданными параметрами. На основное
 * чтение не влияет: не участвует в проверке "устаревший снимок", ничего не
 * повторяет. IP берётся тот же способом (дольше всех отдыхавший), лимит и
 * блокировку IP учитываем как обычно. null — запрос не удался.
 */
export async function readStakanVariant(body: Record<string, unknown>): Promise<{
  items: Array<Record<string, unknown>>; serverTime: number; source: string; receivedAt: number;
} | null> {
  const source = pickStakanSource();
  if (!source) return null;
  const label = source.kind === "direct" ? "стакан (www.bybit.com)" : `стакан (${source.label})`;
  noteRequest(label);
  let response: Awaited<ReturnType<typeof postFromSource>>;
  try {
    response = await postFromSource(source, PUBLIC_P2P_URL, {
      accept: "application/json",
      "accept-language": "en",
      "cache-control": "no-cache, no-store, max-age=0",
      pragma: "no-cache",
      "content-type": "application/json;charset=UTF-8",
      origin: "https://www.bybit.com",
      referer: "https://www.bybit.com/fiat/trade/otc/",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    }, JSON.stringify(body), source.kind === "direct" ? 5_000 : EXTRA_SOURCE_TIMEOUT_MS);
  } catch {
    return null;
  }
  const receivedAt = Date.now();
  if (!response.ok) {
    if (response.status === 429 || response.status === 403) {
      reportRateLimit(label, response.status, response.text.slice(0, 80), response.headers);
      coolDownStakanSource(source, response.status === 403 ? 600_000 : 5_000, `HTTP ${response.status} (замер)`);
    }
    return null;
  }
  let envelope: OfficialEnvelope<{ items?: Array<Record<string, unknown>> }>;
  try {
    envelope = JSON.parse(response.text) as OfficialEnvelope<{ items?: Array<Record<string, unknown>> }>;
  } catch {
    return null;
  }
  const code = envelope.retCode ?? envelope.ret_code ?? -1;
  if (code !== 0) {
    const message = envelope.retMsg ?? envelope.ret_msg ?? "unknown";
    if (isRateLimit(code, message)) {
      reportRateLimit(label, code, message, response.headers);
      coolDownStakanSource(source, 5_000, `лимит стакана (${code}, замер)`);
    }
    return null;
  }
  const serverTime = Number(envelope.time_now ?? 0);
  return {
    items: envelope.result?.items ?? [],
    serverTime: Number.isFinite(serverTime) ? serverTime : 0,
    source: source.label,
    receivedAt,
  };
}

export class OfficialApiNotConfiguredError extends Error {
  constructor() {
    super(
      "Официальный API не настроен. Добавь API-аккаунт через /connection или заполни BYBIT_API_KEY и BYBIT_API_SECRET в .env.",
    );
    this.name = "OfficialApiNotConfiguredError";
  }
}

async function requireCredentials(): Promise<{
  apiKey: string;
  apiSecret: string;
}> {
  const override = currentConnectionCredentials();
  if (override) return override;
  const chatId = currentConnectionChatId();
  if (chatId !== null) {
    const stored = await getActiveApiCredentials(chatId);
    if (stored) {
      return {
        apiKey: stored.apiKey,
        apiSecret: stored.apiSecret,
      };
    }
  }
  if (config.bybit.apiKey && config.bybit.apiSecret) {
    return {
      apiKey: config.bybit.apiKey,
      apiSecret: config.bybit.apiSecret,
    };
  }
  throw new OfficialApiNotConfiguredError();
}

export function hasOfficialApiCredentials(): boolean {
  return Boolean(config.bybit.apiKey && config.bybit.apiSecret);
}

export function maskApiKey(): string {
  const key = config.bybit.apiKey;
  if (!key) return "не задан";
  if (key.length <= 8) return `${key.slice(0, 2)}…${key.slice(-2)}`;
  return `${key.slice(0, 4)}…${key.slice(-4)}`;
}

export function signOfficialRequest(input: {
  timestamp: string;
  apiKey: string;
  recvWindow: string;
  payload: string;
  apiSecret: string;
}): string {
  const plain =
    input.timestamp + input.apiKey + input.recvWindow + input.payload;
  return createHmac("sha256", input.apiSecret)
    .update(plain, "utf8")
    .digest("hex");
}

// ---- Адрес API для изменения цены ----
// У Bybit два официальных адреса одного API: api.bybit.com и api.bytick.com
// (разные входы CloudFront). Изменения цены по очереди отправляем через оба и
// считаем время ответа — чтобы понять, какой быстрее/стабильнее.
// API_UPDATE_HOSTS в .env: список через запятую (например, "api.bytick.com"),
// по умолчанию — оба.
const UPDATE_PATH = "/v5/p2p/item/update";
let updateHostsCache: string[] | null = null;
let updateHostIndex = 0;
let lastUpdateHostName = "";
const updateHostStats = new Map<string, { count: number; totalMs: number; maxMs: number; failed: number }>();
let updatesSinceSummary = 0;
const UPDATE_SUMMARY_EVERY = 10;

function hostLabel(base: string): string {
  return base.replace(/^https?:\/\//, "").replace(/\/.*$/, "");
}

export function apiUpdateHosts(): string[] {
  if (updateHostsCache) return updateHostsCache;
  const base = config.bybit.apiBaseUrl.replace(/\/+$/, "");
  const raw = (process.env.API_UPDATE_HOSTS ?? "").trim();
  let hosts: string[];
  if (raw) {
    hosts = raw.split(",").map((value) => value.trim()).filter(Boolean)
      .map((value) => (/^https?:\/\//.test(value) ? value : `https://${value}`).replace(/\/+$/, ""));
  } else if (/\/\/api\.bybit\.com$/.test(base)) {
    hosts = [base, "https://api.bytick.com"];
  } else {
    hosts = [base];
  }
  updateHostsCache = hosts.length > 0 ? hosts : [base];
  if (updateHostsCache.length > 1) {
    console.log(`[api-host] изменения цены по очереди через: ${updateHostsCache.map(hostLabel).join(", ")}`);
  }
  return updateHostsCache;
}

/** Через какой адрес ушло последнее изменение цены. */
// Серверное время Bybit из ответа на изменение цены (по id объявления). Нужно,
// чтобы видеть, в какую СЕКУНДУ по часам Bybit принята цена: по версии
// "секунда + id" порядок при равной цене зависит от секунды, а не от мс.
const updateServerTimeMs = new Map<string, number>();
export function lastUpdateServerTime(itemId: string): number | null {
  return updateServerTimeMs.get(itemId) ?? null;
}

export function lastUpdateHost(): string {
  return lastUpdateHostName;
}

function noteUpdateTiming(host: string, ms: number, failed: boolean): void {
  const stats = updateHostStats.get(host) ?? { count: 0, totalMs: 0, maxMs: 0, failed: 0 };
  if (failed) stats.failed += 1;
  else {
    stats.count += 1;
    stats.totalMs += ms;
    stats.maxMs = Math.max(stats.maxMs, ms);
  }
  updateHostStats.set(host, stats);
  updatesSinceSummary += 1;
  if (updatesSinceSummary < UPDATE_SUMMARY_EVERY || apiUpdateHosts().length < 2) return;
  updatesSinceSummary = 0;
  const parts = [...updateHostStats.entries()].map(([name, s]) =>
    `${name}: ${s.count} шт., ср ${s.count ? Math.round(s.totalMs / s.count) : 0} мс, макс ${s.maxMs} мс` +
      (s.failed ? `, отказов ${s.failed}` : ""));
  console.log(`[api-host] изменения цены (с запуска): ${parts.join("; ")}`);
}

// ---- Прогрев соединения с API в окне смены курса ----
// Между сменами бот почти не обращается к API, и соединение закрывается.
// Первое изменение цены после смены курса открывало его заново (TCP + TLS) —
// по логам первый запрос смены шёл 485–610 мс против 437–500 мс у следующих.
// В окне смены курса (и за минуту до него) держим соединения открытыми:
// раз в API_WARM_MS делаем лёгкий запрос "время сервера" (без ключа, на лимит
// изменений цены не влияет). Два запроса разом — чтобы тёплыми были два
// соединения: прыжок и страховка уходят одновременно.
// .env: API_WARM_MS=1500 (от 500 до 10000; 0 — выключить).
const API_WARM_MS = (() => {
  const raw = process.env.API_WARM_MS;
  const value = Number(raw);
  if (raw !== undefined && raw.trim() === "0") return 0;
  return raw !== undefined && raw.trim() !== "" && Number.isFinite(value) && value >= 500 && value <= 10_000
    ? Math.round(value) : 1_500;
})();
const API_WARM_CONNECTIONS = 2;
const API_WARM_PATH = "/v5/market/time";
let apiWarmBusy = false;
let apiWarmWasActive = false;
const apiWarmStats = { count: 0, totalMs: 0, maxMs: 0, firstMs: -1, failed: 0 };

async function apiWarmTick(): Promise<void> {
  const now = Date.now();
  const active = inRateWindow(now) || inRateWindow(now + 60_000);
  if (!active) {
    if (apiWarmWasActive) {
      apiWarmWasActive = false;
      const s = apiWarmStats;
      if (s.count > 0 || s.failed > 0) {
        console.log(`[api-warm] окно закончилось: соединение с ${apiUpdateHosts().map(hostLabel).join(", ")} держал открытым — ` +
          `${s.count} запр., первое соединение ${s.firstMs >= 0 ? `${s.firstMs} мс` : "-"}, ` +
          `дальше в среднем ${s.count > 1 ? Math.round((s.totalMs - Math.max(0, s.firstMs)) / (s.count - 1)) : 0} мс, ` +
          `макс ${s.maxMs} мс${s.failed ? `, ошибок ${s.failed}` : ""}`);
      }
      apiWarmStats.count = 0; apiWarmStats.totalMs = 0; apiWarmStats.maxMs = 0;
      apiWarmStats.firstMs = -1; apiWarmStats.failed = 0;
    }
    return;
  }
  if (apiWarmBusy) return;
  apiWarmBusy = true;
  if (!apiWarmWasActive) {
    apiWarmWasActive = true;
    console.log(`[api-warm] окно смены курса: держу соединение с API открытым (запрос раз в ${API_WARM_MS} мс, API_WARM_MS)`);
  }
  try {
    const requests: Promise<void>[] = [];
    for (const base of apiUpdateHosts()) {
      for (let i = 0; i < API_WARM_CONNECTIONS; i++) {
        const startedAt = Date.now();
        requests.push(fetch(`${base}${API_WARM_PATH}`, { method: "GET", signal: AbortSignal.timeout(3_000) })
          .then(async (response) => {
            await response.text(); // дочитать ответ — иначе соединение не вернётся в пул
            const ms = Date.now() - startedAt;
            if (apiWarmStats.firstMs < 0) apiWarmStats.firstMs = ms;
            apiWarmStats.count += 1;
            apiWarmStats.totalMs += ms;
            apiWarmStats.maxMs = Math.max(apiWarmStats.maxMs, ms);
          })
          .catch(() => { apiWarmStats.failed += 1; }));
      }
    }
    await Promise.all(requests);
  } finally {
    apiWarmBusy = false;
  }
}

if (API_WARM_MS > 0) {
  const timer = setInterval(() => { void apiWarmTick().catch(() => {}); }, API_WARM_MS);
  timer.unref?.();
}

async function postOfficial<T>(path: string, body: unknown): Promise<T> {
  let base = config.bybit.apiBaseUrl;
  if (path === UPDATE_PATH) {
    const hosts = apiUpdateHosts();
    base = hosts[updateHostIndex % hosts.length]!;
    updateHostIndex += 1;
    lastUpdateHostName = hostLabel(base);
    const startedAt = Date.now();
    const updatedItemId = String((body as { id?: unknown } | null)?.id ?? "");
    try {
      const result = await postOfficialAt<T>(base, path, body).finally(() => {
        noteAccountUpdateAnswered(updatedItemId);
      });
      noteUpdateTiming(lastUpdateHostName, Date.now() - startedAt, false);
      return result;
    } catch (error) {
      noteUpdateTiming(hostLabel(base), Date.now() - startedAt, true);
      throw error;
    }
  }
  return postOfficialAt<T>(base, path, body);
}

async function postOfficialAt<T>(base: string, path: string, body: unknown): Promise<T> {
  const { apiKey, apiSecret } = await requireCredentials();
  const timestamp = String(Date.now());
  const recvWindow = String(config.bybit.apiRecvWindow);
  const payload = JSON.stringify(body ?? {});
  const signature = signOfficialRequest({
    timestamp,
    apiKey,
    recvWindow,
    payload,
    apiSecret,
  });
  noteRequest(path);
  const response = await fetch(`${base}${path}`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "X-BAPI-API-KEY": apiKey,
      "X-BAPI-TIMESTAMP": timestamp,
      "X-BAPI-RECV-WINDOW": recvWindow,
      "X-BAPI-SIGN": signature,
    },
    body: payload,
    signal: AbortSignal.timeout(15_000),
  });
  const rawText = await response.text();
  if (!response.ok) {
    if (response.status === 429 || response.status === 403) {
      reportRateLimit(path, response.status, rawText.slice(0, 80), response.headers);
    }
    if (response.status === 401 || response.status === 403) {
      throw new BybitAuthError(response.status, "api");
    }
    throw new Error(`Bybit official API HTTP ${response.status}: ${rawText.slice(0, 300)}`);
  }

  let envelope: OfficialEnvelope<T>;
  try {
    envelope = JSON.parse(rawText) as OfficialEnvelope<T>;
  } catch {
    throw new Error(`Bybit official API вернул не JSON: ${rawText.slice(0, 200)}`);
  }
  const code = envelope.retCode ?? envelope.ret_code ?? -1;
  const message = envelope.retMsg ?? envelope.ret_msg ?? "unknown";
  if (path === UPDATE_PATH && code === 0) {
    const itemId = String((body as { id?: unknown } | null)?.id ?? "");
    const fromSeconds = Number(envelope.time_now ?? 0);
    const serverMs = Number(envelope.time ?? 0) > 0 ? Number(envelope.time)
      : Number.isFinite(fromSeconds) && fromSeconds > 0 ? Math.round(fromSeconds * 1_000) : 0;
    if (itemId && serverMs > 0) updateServerTimeMs.set(itemId, serverMs);
    else if (itemId) updateServerTimeMs.delete(itemId);
  }
  if (code !== 0) {
    if (
      code === 10003 ||
      code === 10004 ||
      code === 10005 ||
      code === 10007 ||
      /api key|signature|auth|permission|expired/i.test(message)
    ) {
      throw new BybitAuthError(code, "api");
    }
    if (isRateLimit(code, message)) reportRateLimit(path, code, message, response.headers);
    throw withEndpoint(new BybitApiError(code, message, envelope), path);
  }
  return envelope.result;
}

async function getOfficialAccountInfo(force = false): Promise<OfficialAccountInfo> {
  void force;
  return postOfficial<OfficialAccountInfo>(
    "/v5/p2p/user/personal/info",
    {},
  );
}

function sanitizePreferences(
  value: CreateAdRequest["tradingPreferenceSet"],
): Record<string, string> {
  const allowed = [
    "hasUnPostAd",
    "isKyc",
    "isEmail",
    "isMobile",
    "hasRegisterTime",
    "registerTimeThreshold",
    "orderFinishNumberDay30",
    "completeRateDay30",
    "nationalLimit",
    "hasOrderFinishNumberDay30",
    "hasCompleteRateDay30",
    "hasNationalLimit",
  ] as const;
  const result: Record<string, string> = {};
  for (const key of allowed) {
    const v = value[key];
    if (v !== undefined) result[key] = String(v);
  }
  return result;
}

async function officialOnline(
  body: Record<string, unknown>,
): Promise<OfficialOnlineResult> {
  const requestedSize = Math.max(1, Number(body.size ?? 10));
  const ownUid = body.userId ? String(body.userId) : null;
  const topOnly = ownUid !== null && requestedSize === 1;
  const fetchSize = topOnly ? 10 : ownUid
    ? Math.min(300, Math.max(requestedSize + 20, 50))
    : requestedSize;
  const publicBody = {
    userId: ownUid ? Number(ownUid) : null,
    tokenId: String(body.tokenId ?? ""),
    currencyId: String(body.currencyId ?? ""),
    payment: Array.isArray(body.payment) ? body.payment : [],
    side: String(body.side ?? ""),
    size: String(fetchSize),
    page: String(body.page ?? "1"),
    amount: String(body.amount ?? ""),
    vaMaker: body.vaMaker ?? true,
    bulkMaker: body.bulkMaker ?? false,
    canTrade: body.canTrade ?? true,
    verificationFilter: body.verificationFilter ?? 0,
    sortType: body.sortType ?? "OVERALL_RANKING",
    paymentPeriod: Array.isArray(body.paymentPeriod)
      ? body.paymentPeriod
      : [],
    itemRegion: body.itemRegion ?? 1,
    countryCode: String(body.countryCode ?? ""),
    tradeWith: body.tradeWith ?? false,
  };
  let result = await postPublicP2pMarketHedged<OfficialOnlineResult>(publicBody);
  if (!ownUid) return result;
  const excludeOwn = (value: OfficialOnlineResult) => (value.items ?? [])
    .filter((item) => String(item.userId ?? "") !== ownUid)
    .slice(0, requestedSize);
  let items = excludeOwn(result);
  if (topOnly && items.length === 0 && (result.items?.length ?? 0) > 0) {
    // Preserve the previous 50-row search if the smaller page contains only own ads.
    result = await postPublicP2pMarketHedged<OfficialOnlineResult>({ ...publicBody, size: "50" });
    items = excludeOwn(result);
  }
  return { ...result, items };
}

async function inferReferencePrice(
  tokenId: string,
  currencyId: string,
): Promise<LastPriceResult> {
  const own = await postOfficial<OfficialOnlineResult>(
    "/v5/p2p/item/personal/list",
    { tokenId, currencyId, page: "1", size: "50" },
  ).catch(() => ({ items: [] }));
  const pools: OfficialOnlineItem[][] = [own.items ?? []];
  for (const side of ["0", "1"] as const) {
    const online = await postOfficial<OfficialOnlineResult>(
      "/v5/p2p/item/online",
      { tokenId, currencyId, side, page: "1", size: "300" },
    );
    pools.push(online.items ?? []);
  }
  for (const item of pools.flat()) {
    if (String(item.priceType) !== "1") continue;
    const price = Number(item.price);
    const premium = Number(item.premium);
    if (!Number.isFinite(price) || !Number.isFinite(premium) || premium <= 0) {
      continue;
    }
    return { price: String(price * 100 / premium) };
  }
  throw new Error(
    "API не смог определить reference price для floating: в доступных объявлениях нет плавающей цены. Используй premium вручную или режим по сессии.",
  );
}

async function estimateOrderBookLevel(
  body: Record<string, unknown>,
): Promise<OrderBookLevelResult> {
  const side = String(body.side) as Side;
  const target = Number(body.price);
  const online = await postOfficial<OfficialOnlineResult>(
    "/v5/p2p/item/online",
    {
      tokenId: String(body.tokenId ?? ""),
      currencyId: String(body.currencyId ?? ""),
      side,
      page: "1",
      size: "300",
    },
  );
  const prices = (online.items ?? [])
    .map((item) => Number(item.price))
    .filter(Number.isFinite);
  const ahead = prices.filter((price) =>
    side === "1" ? price < target : price > target,
  ).length;
  return {
    orderBookLevel: ahead + 1,
    total: online.count ?? prices.length,
  };
}

export async function officialApiCall<T>(
  path: string,
  body?: unknown,
): Promise<T> {
  const input = (body && typeof body === "object"
    ? body
    : {}) as Record<string, unknown>;

  switch (path) {
    case "/x-api/fiat/otc/item/online":
    case "/v5/p2p/item/online":
      return officialOnline(input) as Promise<T>;
    case "/x-api/fiat/otc/item/create": {
      const source = input as unknown as CreateAdRequest;
      const result = await postOfficial<{
        itemId?: string;
        needSecurityRisk?: boolean;
        securityRiskToken?: string;
        riskTokenType?: string;
      }>("/v5/p2p/item/create", {
        tokenId: source.tokenId,
        currencyId: source.currencyId,
        side: source.side,
        priceType: source.priceType,
        premium: source.premium,
        price: source.price,
        minAmount: source.minAmount,
        maxAmount: source.maxAmount,
        remark: source.remark,
        tradingPreferenceSet: sanitizePreferences(source.tradingPreferenceSet),
        paymentIds: source.paymentIds,
        quantity: source.quantity,
        paymentPeriod: source.paymentPeriod,
        itemType: source.itemType,
      });
      if (result.needSecurityRisk) {
        throw new SecurityChallengeRequiredError(
          result.securityRiskToken ?? "",
          result.riskTokenType ?? "official-api",
          result,
        );
      }
      return result as T;
    }
    case "/x-api/fiat/otc/item/cancel":
      return postOfficial<T>("/v5/p2p/item/cancel", {
        itemId: String(input.itemId ?? ""),
      });
    case "/x-api/fiat/otc/item/update": {
      const source = input as unknown as UpdateAdRequest;
      const result = await postOfficial<{
        needSecurityRisk?: boolean;
        securityRiskToken?: string;
        riskTokenType?: string;
      }>("/v5/p2p/item/update", {
        id: source.id || source.itemId,
        priceType: source.priceType,
        premium: source.premium,
        price: source.price,
        minAmount: source.minAmount,
        maxAmount: source.maxAmount,
        remark: source.remark,
        tradingPreferenceSet: sanitizePreferences(
          source.tradingPreferenceSet,
        ),
        paymentIds: source.paymentIds,
        actionType: source.actionType,
        quantity: source.quantity,
        paymentPeriod: source.paymentPeriod,
      });
      if (result.needSecurityRisk) {
        throw new SecurityChallengeRequiredError(
          result.securityRiskToken ?? "",
          result.riskTokenType ?? "official-api",
          result,
        );
      }
      return result as T;
    }
    case "/x-api/fiat/otc/item/personal/list":
      return postOfficial<T>("/v5/p2p/item/personal/list", {
        itemId: input.itemId,
        status: input.status,
        side: input.side,
        tokenId: input.tokenId,
        page: String(input.page ?? "1"),
        size: String(input.size ?? "10"),
        currencyId: input.currencyId,
      });
    case "/x-api/fiat/otc/item/info":
      return postOfficial<T>("/v5/p2p/item/info", {
        itemId: String(input.itemId ?? ""),
      });
    case "/x-api/fiat/otc/user/payment/list":
      return postOfficial<T>("/v5/p2p/user/payment/list", {});
    case "/x-api/fiat/otc/user/personal/info":
      return getOfficialAccountInfo() as Promise<T>;
    case "/x-api/fiat/otc/maker/work-config/get": {
      const info = await getOfficialAccountInfo();
      return {
        userId: String(info.userId ?? ""),
        workStatus: "WORKING",
        isOnline: info.isOnline,
      } as T;
    }
    case "/x-api/fiat/otc/item/last_price":
      return inferReferencePrice(
        String(input.tokenId ?? ""),
        String(input.currencyId ?? ""),
      ) as Promise<T>;
    case "/x-api/fiat/p2p/item/price/orderBook-level":
      return estimateOrderBookLevel(input) as Promise<T>;
    default:
      throw new Error(
        `Официальный API-режим пока не поддерживает внутренний метод ${path}`,
      );
  }
}

export async function checkOfficialApi(input: {
  tokenId: string;
  currencyId: string;
  side: Side;
}): Promise<{
  account: OfficialAccountInfo;
  payments: number;
  onlineAds: number;
  ownAds: number;
}> {
  const account = await getOfficialAccountInfo(true);
  const [payments, online, own] = await Promise.all([
    postOfficial<unknown>("/v5/p2p/user/payment/list", {}),
    postOfficial<OfficialOnlineResult>("/v5/p2p/item/online", {
      tokenId: input.tokenId,
      currencyId: input.currencyId,
      side: input.side,
      page: "1",
      size: "10",
    }),
    postOfficial<OfficialOnlineResult>("/v5/p2p/item/personal/list", {
      tokenId: input.tokenId,
      currencyId: input.currencyId,
      side: input.side,
      page: "1",
      size: "10",
    }),
  ]);
  return {
    account,
    payments: resultListLength(payments),
    onlineAds: online.items?.length ?? 0,
    ownAds: own.items?.length ?? 0,
  };
}
