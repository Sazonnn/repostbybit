'use strict';
const $ = id => document.getElementById(id);
const icons = () => window.lucide?.createIcons();
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = value => value === null || value === undefined || !Number.isFinite(Number(value)) ? '—' : Number(value).toLocaleString('ru-RU', {minimumFractionDigits:2,maximumFractionDigits:2});
const clock = value => value ? new Date(value).toLocaleTimeString('ru-RU', {hour:'2-digit',minute:'2-digit',second:'2-digit'}) : '—';
const seconds = value => Number(value).toLocaleString('ru-RU', {maximumFractionDigits:3}) + ' сек';
let state = null, csrf = '', online = false, busy = false, dirty = false, formRevision = '', view = 'ads', loading = false;
let modalCommand = null, toastTimer = null, installEvent = null;

async function api(path, options = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), options.method === 'POST' ? 22_000 : 8_000);
  try {
    const response = await fetch(path, {credentials:'same-origin', cache:'no-store', ...options, signal:controller.signal,
      headers:{'Content-Type':'application/json', ...(csrf ? {'X-CSRF-Token':csrf} : {}), ...options.headers}});
    const data = await response.json();
    if (!response.ok) {
      if (response.status === 401 && path !== '/api/login') showLogin();
      const error = new Error(data.error || 'Не удалось выполнить запрос.'); error.status = response.status; throw error;
    }
    return data;
  } catch (error) {
    if (error.name === 'AbortError') throw new Error(options.method === 'POST'
      ? 'Ответ не получен. Команда могла выполниться; проверь состояние перед повтором.' : 'Сервер не отвечает.');
    throw error;
  } finally { clearTimeout(timeout); }
}
function toast(message) {
  $('toast').textContent = message; $('toast').hidden = false; clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { $('toast').hidden = true; }, 6500);
}
function showLogin() {
  csrf = ''; state = null; dirty = false; online = false;
  $('shell').hidden = true; $('login').hidden = false;
  if ($('modal').open) $('modal').close();
  $('password').value = '';
}
function connection(ok) {
  online = ok;
  $('offline-banner').hidden = ok;
  $('connection-state').classList.toggle('offline', !ok);
  $('connection-state').innerHTML = '<span class="small-dot"></span>' + (ok ? 'Сервер на связи' : 'Нет связи');
  controls();
}
function controls() {
  document.querySelectorAll('.mutation').forEach(button => { button.disabled = busy || !online; });
  $('sync').disabled = busy || !online || !state?.settings.enabled;
  $('confirm-modal').disabled = busy || !online;
  $('logout').disabled = busy;
}
async function refresh() {
  if (!csrf || loading) return;
  loading = true;
  try { state = await api('/api/state'); connection(true); render(); }
  catch (error) { if (csrf) connection(false); }
  finally { loading = false; }
}
function route() {
  const names = {ads:'Объявления',settings:'Настройки',journal:'Журнал',connection:'Подключение'};
  view = location.hash.slice(1); if (!names[view]) view = 'ads';
  document.querySelectorAll('.view').forEach(el => { el.hidden = el.id !== 'view-' + view; });
  document.querySelectorAll('nav a').forEach(el => { el.classList.toggle('active', el.dataset.view === view); });
  $('breadcrumb-current').textContent = names[view];
  if (view === 'ads') requestAnimationFrame(drawChart);
}
function render() {
  if (!state) return;
  const s = state.settings, ads = state.ads, telemetry = state.telemetry;
  $('demo-banner').hidden = !state.demo;
  $('nav-count').textContent = ads.length;
  $('account-caption').textContent = state.account.name + ' · Telegram ID ' + state.chatId;
  $('metric-ads').textContent = ads.length;
  $('metric-active').textContent = ads.filter(ad => ad.enabled).length + ' включено в автокурс';
  $('metric-monitor').textContent = seconds(s.monitor);
  $('metric-edit').textContent = seconds(s.edit);
  const last = telemetry.updates.at(-1);
  $('metric-api').textContent = last ? last.apiMs + ' мс' : '—';
  $('metric-api-at').textContent = last ? 'последний замер в ' + clock(last.at) : 'нет замеров';
  $('enable-main').innerHTML = '<i data-lucide="' + (s.enabled ? 'pause' : 'play') + '"></i><span>' + (s.enabled ? 'Приостановить' : 'Включить автокурс') + '</span>';
  $('enable-main').classList.toggle('primary', !s.enabled);
  $('ads-count').textContent = ads.length;
  $('monitor-state').textContent = s.enabled ? 'Автокурс включён' : 'Автокурс на паузе';
  $('last-refresh').textContent = 'Данные сервера · ' + clock(state.now);
  renderAds(); renderJournal(); renderConnection();
  const selected = $('chart-ad').value;
  const choices = ads.map(ad => '<option value="' + esc(ad.itemId) + '">' + esc(ad.pair) + ' · ' + esc(ad.type) + ' · ' + esc(ad.itemId.slice(-5)) + '</option>').join('');
  if ($('chart-ad').innerHTML !== choices) { $('chart-ad').innerHTML = choices; if (ads.some(ad => ad.itemId === selected)) $('chart-ad').value = selected; }
  if (!dirty) fillSettings();
  $('settings-conflict').hidden = !dirty || formRevision === state.revision;
  controls(); icons(); requestAnimationFrame(drawChart);
}
function renderAds() {
  if (!state.ads.length) {
    $('ads-table').innerHTML = '<div class="empty"><i data-lucide="rows-3"></i><strong>Нет рабочих объявлений</strong><span>0 объявлений под управлением</span></div>'; return;
  }
  $('ads-table').innerHTML = '<div class="table-scroll"><table class="ads-grid-table"><thead><tr><th>Объявление</th><th>Тип</th><th>Последняя цена</th><th>Цель</th><th>Автокурс</th><th>Попытки / 5 мин</th><th></th></tr></thead><tbody>' + state.ads.map(ad => {
    const running = state.settings.enabled && ad.enabled;
    return '<tr><td><strong>' + esc(ad.pair) + '</strong> <span class="badge ' + (ad.side === 'SELL' ? 'sell' : '') + '">' + esc(ad.side) + '</span><span class="ad-id">' + esc(ad.itemId) + '</span></td><td><span class="type-tag">' + esc(ad.type) + '</span></td><td><strong>' + money(ad.price) + '</strong><small>' + clock(ad.updatedAt) + '</small></td><td><strong>' + money(ad.target) + '</strong></td><td><span class="badge ' + (ad.error ? 'error' : running ? '' : 'neutral') + '" title="' + esc(ad.error || '') + '">' + (ad.error ? 'Ошибка' : running ? 'Включён' : 'Пауза') + '</span></td><td>' + ad.attempts + ' / 10</td><td><div class="row-actions"><button class="icon-button mutation" data-action="toggle" data-id="' + ad.id + '" title="' + (ad.enabled ? 'Приостановить объявление' : 'Включить объявление') + '" aria-label="' + (ad.enabled ? 'Приостановить объявление' : 'Включить объявление') + '"><i data-lucide="' + (ad.enabled ? 'pause' : 'play') + '"></i></button><button class="icon-button mutation" data-action="remove" data-id="' + ad.id + '" title="Убрать из автокурса" aria-label="Убрать из автокурса"><i data-lucide="trash-2"></i></button></div></td></tr>';
  }).join('') + '</tbody></table></div>';
}
function renderJournal() {
  const updates = [...state.telemetry.updates].reverse();
  $('latency-table').innerHTML = updates.length ? '<div class="table-scroll"><table><thead><tr><th>Время</th><th>Объявление</th><th>Цена</th><th>Стакан</th><th>Подготовка</th><th>До отправки</th><th>Ответ API</th></tr></thead><tbody>' + updates.map(u => '<tr><td>' + clock(u.at) + '</td><td>' + esc(u.itemId) + '</td><td>' + money(u.price) + '</td><td>' + u.marketMs + '</td><td>' + u.prepareMs + '</td><td>' + u.seenToSendMs + '</td><td>' + u.apiMs + '</td></tr>').join('') + '</tbody></table></div>' : '<div class="empty">Обновлений fixed пока нет</div>';
  const filter = $('log-filter').value;
  const events = [...state.telemetry.events].reverse().filter(e => filter === 'all' || e.kind === filter);
  $('event-list').innerHTML = events.length ? events.map(e => '<div class="event ' + esc(e.kind) + '"><time>' + clock(e.at) + '</time><div><p>' + esc(e.message) + '</p>' + (e.itemId ? '<small>' + esc(e.itemId) + '</small>' : '') + '</div></div>').join('') : '<div class="empty">Событий пока нет</div>';
}
function renderConnection() {
  $('connection-account').textContent = state.account.name;
  const pairs = [['Аккаунт',state.account.name],['Подключение Bybit',state.account.mode === 'api' ? 'Официальный API' : 'Сессия браузера'],['Ключи настроены',state.account.configured ? 'Да' : 'Нет'],['Telegram ID',state.chatId],['Адрес панели',location.origin],['Защита соединения',location.protocol === 'https:' ? 'HTTPS' : 'Локальное подключение'],['Запуск сервера',new Date(state.startedAt).toLocaleString('ru-RU')],['Автоцикл Telegram',state.cycle ? state.cycle.status : 'Не запущен']];
  $('connection-details').innerHTML = pairs.map(([a,b]) => '<div><dt>' + esc(a) + '</dt><dd>' + esc(b) + '</dd></div>').join('');
}
function fillSettings() {
  if (!state) return;
  const form = $('settings-form');
  for (const key of ['monitor','edit','step','min','max','fixed']) form.elements.namedItem(key).value = state.settings[key] ?? '';
  form.elements.namedItem('mode').value = state.settings.mode;
  formRevision = state.revision; dirty = false; modeField();
}
function modeField() { $('settings-form').elements.namedItem('fixed').disabled = $('settings-form').elements.namedItem('mode').value !== 'fixed'; }
function drawChart() {
  if (!state || $('view-ads').hidden) return;
  const canvas = $('price-chart'), box = canvas.getBoundingClientRect(), ratio = Math.min(devicePixelRatio || 1, 2);
  if (!box.width) return;
  canvas.width = Math.round(box.width * ratio); canvas.height = Math.round(box.height * ratio);
  const ctx = canvas.getContext('2d'); ctx.scale(ratio,ratio);
  const width = box.width, height = box.height, id = $('chart-ad').value;
  const series = state.telemetry.series.filter(s => s.itemId === id);
  const ad = state.ads.find(ad => ad.itemId === id);
  $('chart-price').textContent = money(series.at(-1)?.top ?? ad?.target);
  $('chart-currency').textContent = ad?.pair.split('/')[1] ?? 'RUB';
  $('chart-empty').hidden = series.length >= 2;
  ctx.font = '10px system-ui'; ctx.fillStyle = '#97a39d'; ctx.strokeStyle = '#e7ece9'; ctx.lineWidth = 1;
  const values = series.flatMap(p => [p.top,p.price]).filter(v => v !== null && Number.isFinite(v));
  let low = values.length ? Math.min(...values) : 0, high = values.length ? Math.max(...values) : 1;
  const pad = Math.max((high-low)*.18,.02); low -= pad; high += pad;
  const left = 0, right = width-51, top = 12, bottom = height-27;
  for (let i=0;i<4;i++) {
    const y=top+(bottom-top)*i/3;ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(right,y);ctx.stroke();
    ctx.fillText(values.length ? (high-(high-low)*i/3).toFixed(2) : '—',right+9,y+3);
  }
  if (series.length < 2) return;
  const first=series[0].at, last=series.at(-1).at;
  const x=p=>left+(right-left)*(p.at-first)/Math.max(1,last-first), y=v=>bottom-(v-low)/(high-low)*(bottom-top);
  const line=(key,color)=>{ctx.beginPath();let active=false;for(const p of series){if(p[key]===null||!Number.isFinite(p[key])){active=false;continue;}if(!active){ctx.moveTo(x(p),y(p[key]));active=true;}else ctx.lineTo(x(p),y(p[key]));}ctx.strokeStyle=color;ctx.lineWidth=1.7;ctx.stroke();};
  line('top','#168d74');line('price','#c18b37');
  ctx.fillStyle='#97a39d';ctx.fillText(clock(first),0,height-3);ctx.textAlign='right';ctx.fillText(clock(last),right,height-3);ctx.textAlign='left';
}
function ask(title,text,command,confirm='Подтвердить',danger=false) {
  modalCommand = {...command,revision:state.revision};
  $('modal-title').textContent=title; $('modal-text').textContent=text;
  $('item-id-label').hidden=command.action!=='ad-add'; $('item-id').required=command.action==='ad-add'; $('item-id').value='';
  $('modal-error').textContent=''; $('confirm-modal').textContent=confirm;
  $('confirm-modal').classList.toggle('danger',danger);
  $('modal').showModal(); controls();
}
async function command(input) {
  busy=true;controls();
  try {
    const result=await api('/api/command',{method:'POST',headers:{'Idempotency-Key':crypto.randomUUID()},body:JSON.stringify(input)});
    if (input.action==='settings') dirty=false;
    toast(result.message || 'Готово');
    await refresh();return true;
  } catch(error) {
    if ($('modal').open) $('modal-error').textContent=error.message; else toast(error.message);
    await refresh();return false;
  } finally {busy=false;controls();}
}
$('login-form').addEventListener('submit',async event=>{
  event.preventDefault(); const button=event.submitter;button.disabled=true;$('login-error').textContent='';
  try {
    const result=await api('/api/login',{method:'POST',body:JSON.stringify({password:$('password').value})});
    csrf=result.csrf;$('password').value='';$('login').hidden=true;$('shell').hidden=false;route();await refresh();
  } catch(error){$('login-error').textContent=error.message;}finally{button.disabled=false;}
});
$('show-password').addEventListener('click',()=>{const show=$('password').type==='password';$('password').type=show?'text':'password';$('show-password').title=show?'Скрыть пароль':'Показать пароль';$('show-password').setAttribute('aria-label',$('show-password').title);});
$('logout').addEventListener('click',async()=>{try{await api('/api/logout',{method:'POST',body:'{}'});showLogin();}catch(error){toast('Выход не подтверждён сервером. '+error.message);}});
$('refresh').addEventListener('click',()=>void refresh());
$('enable-main').addEventListener('click',()=>ask(state.settings.enabled?'Приостановить автокурс?':'Включить автокурс?',state.settings.enabled?'Новые изменения цены остановятся. Объявления останутся на Bybit; уже отправленный запрос может завершиться.':'Бот начнёт менять цены включённых рабочих объявлений по сохранённым настройкам.',{action:'enable',enabled:!state.settings.enabled},state.settings.enabled?'Приостановить':'Включить'));
$('add-ad').addEventListener('click',()=>ask('Добавить объявление','Будет добавлено существующее активное объявление выбранного аккаунта. Если автокурс включён, его цена начнёт обновляться.',{action:'ad-add'},'Добавить'));
$('sync').addEventListener('click',()=>ask('Проверить цены сейчас?','Проверка может изменить цены объявлений. Сохранённые интервалы и ограничения продолжают действовать.',{action:'sync'},'Проверить'));
$('ads-table').addEventListener('click',event=>{
  const button=event.target.closest('button[data-action]');if(!button||button.disabled)return;
  const ad=state.ads.find(a=>a.id===Number(button.dataset.id));if(!ad)return;
  if(button.dataset.action==='remove')ask('Убрать из автокурса?',ad.itemId+' останется на Bybit. Бот больше не будет управлять его ценой.',{action:'ad-remove',id:ad.id},'Убрать',true);
  else ask(ad.enabled?'Приостановить объявление?':'Включить объявление?',ad.itemId+(ad.enabled?' останется на Bybit без новых автоматических изменений цены.':' будет участвовать в автокурсе, когда общий переключатель включён.'),{action:'ad-enable',id:ad.id,enabled:!ad.enabled},ad.enabled?'Приостановить':'Включить');
});
for(const id of ['close-modal','cancel-modal'])$(id).addEventListener('click',()=>{if(!busy)$('modal').close();});
$('modal').addEventListener('cancel',event=>{if(busy)event.preventDefault();});
$('modal-form').addEventListener('submit',async event=>{event.preventDefault();if(busy||!online)return;const input={...modalCommand};if(input.action==='ad-add')input.itemId=$('item-id').value.trim();if(await command(input))$('modal').close();});
$('settings-form').addEventListener('input',()=>{dirty=true;modeField();});
$('settings-form').addEventListener('submit',async event=>{
  event.preventDefault();if(busy||!online)return;
  const data=Object.fromEntries(new FormData(event.currentTarget));
  if(!('fixed' in data))data.fixed=state.settings.fixed;
  ask('Сохранить настройки курса?','Новые значения будут применены к рабочим объявлениям. Общие настройки цены также изменятся в Telegram.',{action:'settings',...data},'Сохранить');
  modalCommand.revision=formRevision;
});
$('reset-settings').addEventListener('click',()=>{fillSettings();$('settings-conflict').hidden=true;});
$('chart-ad').addEventListener('change',drawChart);
$('log-filter').addEventListener('change',()=>{if(state)renderJournal();});
$('export-log').addEventListener('click',()=>{if(!state)return;const blob=new Blob([JSON.stringify({exportedAt:new Date().toISOString(),...state.telemetry},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download='repostg-journal-'+Date.now()+'.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
window.addEventListener('hashchange',route);window.addEventListener('resize',drawChart);
window.addEventListener('offline',()=>connection(false));window.addEventListener('online',()=>void refresh());
document.addEventListener('visibilitychange',()=>{if(!document.hidden)void refresh();});
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();installEvent=event;$('install').hidden=false;});
$('install').addEventListener('click',async()=>{if(!installEvent)return;await installEvent.prompt();installEvent=null;$('install').hidden=true;});
window.addEventListener('appinstalled',()=>{$('install').hidden=true;});
setInterval(()=>{if(!document.hidden)void refresh();},2000);
icons();route();
if('serviceWorker' in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>{});
void (async()=>{try{const result=await api('/api/session');csrf=result.csrf;$('login').hidden=true;$('shell').hidden=false;await refresh();}catch{showLogin();}})();
