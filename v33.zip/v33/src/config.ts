import "dotenv/config";

function required(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var: ${name}`);
  return v;
}

function optional(name: string, def = ""): string {
  return process.env[name] ?? def;
}

export const config = {
  database: {
    /** Путь к файлу SQLite. По умолчанию ./data/bybit_bot.db. */
    path: optional("SQLITE_PATH"),
  },
  telegram: {
    botToken: required("TELEGRAM_BOT_TOKEN"),
    allowedUserIds: optional("ALLOWED_TG_USER_IDS")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean)
      .map(Number),
  },
  bybit: {
    /**
     * Платёжный пароль Bybit. Используется для авто-прохождения 2FA challenge
     * при создании объявления (sha256 → /risk/verify).
     */
    paymentPassword: optional("BYBIT_PAYMENT_PASSWORD"),
    /** userId на Bybit (если задан, используется при листинге стакана для исключения своих объявлений). */
    userId: optional("BYBIT_USER_ID"),
    /** Официальный P2P Open API. Ключи хранятся только в .env. */
    apiKey: optional("BYBIT_API_KEY"),
    apiSecret: optional("BYBIT_API_SECRET"),
    apiBaseUrl: optional("BYBIT_API_BASE_URL", "https://api.bybit.com").replace(
      /\/+$/,
      "",
    ),
    apiRecvWindow: Number(optional("BYBIT_API_RECV_WINDOW", "5000")),
  },
  playwright: {
    userDataDir: optional("CHROMIUM_PROFILE_DIR"),
    /** "chrome" — реальный установленный Chrome (рекомендация patchright); "chromium" — патч-сборка. */
    channel: (optional("CHROMIUM_CHANNEL", "chrome") as
      | "chrome"
      | "msedge"
      | "chromium"),
    headless: optional("CHROMIUM_HEADLESS", "false") === "true",
  },
  p2p: {
    tokenId: optional("P2P_TOKEN_ID", "USDT"),
    currencyId: optional("P2P_CURRENCY_ID", "RUB"),
    side: optional("P2P_SIDE", "1") as "0" | "1",
    quantity: optional("P2P_QUANTITY", "10"),
    minAmount: optional("P2P_MIN_AMOUNT", "500"),
    maxAmount: optional("P2P_MAX_AMOUNT", "1000"),
    paymentPeriod: optional("P2P_PAYMENT_PERIOD", "30"),
    remark: optional("P2P_REMARK", ""),
    paymentIds: optional("P2P_PAYMENT_IDS", "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean),
    pageSize: Number(optional("P2P_PAGE_SIZE", "10")),
    priceStep: Number(optional("P2P_PRICE_STEP", "0.01")),
    priceMin: Number(optional("P2P_PRICE_MIN", "0")),
    priceMax: Number(optional("P2P_PRICE_MAX", "999999")),
  },
  cycle: {
    intervalMs: Number(optional("CYCLE_INTERVAL_MS", "30000")),
    /**
     * Фильтр стакана:
     *   0 = без фильтра, видны ВСЕ объявления (default — работает для не-Verified)
     *   1 = Verified Merchants only (для статуса Verified Merchant в Bybit)
     * Ставь 1 только если у тебя есть статус — иначе не найдёт даже своё.
     */
    verificationFilter: Number(optional("CYCLE_VERIFICATION_FILTER", "0")),
  },
} as const;

export type AppConfig = typeof config;
