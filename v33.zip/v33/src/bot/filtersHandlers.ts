import type { Context } from "grammy";
import { InlineKeyboard } from "grammy";
import {
  ensureSettings,
  updateSettings,
  UserSettingsRow,
} from "../db/repositories/userSettings.js";

function chatIdOf(ctx: Context): number {
  const id = ctx.chat?.id;
  if (!id) throw new Error("No chat");
  return id;
}

function fmt(s: UserSettingsRow): string {
  return [
    `🔍 <b>Фильтры биржи</b>`,
    ``,
    `<b>Сортировка</b>: ${sortLabel(s.bourse_sort_type)}`,
    `<b>Verified Merchants</b>: ${s.bourse_verification_filter === 1 ? "✓ Только Verified" : "Все"} <i>(сейчас сломан на стороне Bybit — count=0)</i>`,
    `<b>Доступные объявления</b>: ${s.bourse_can_trade ? "✓" : "✗"}`,
    `<b>Блочная торговля</b>: ${s.bourse_bulk_maker ? "✓" : "✗"}`,
    `<b>С кем торговал (6 мес)</b>: ${s.bourse_trade_with ? "✓" : "✗"}`,
    ``,
    `<i>⚠️ Фильтры применяются только к /stack. Поиск бота их игнорирует.</i>`,
  ].join("\n");
}

function tog(b: boolean): string {
  return b ? "✓ ON" : "✗ OFF";
}

function sortLabel(
  value: UserSettingsRow["bourse_sort_type"],
): string {
  if (value === "PRICE") return "По цене";
  if (value === "TRADE_COUNT") return "По числу сделок";
  return "Общий рейтинг";
}

function keyboard(s: UserSettingsRow): InlineKeyboard {
  return new InlineKeyboard()
    .text(`Сортировка: ${sortLabel(s.bourse_sort_type)}`, "f:sort:next")
    .row()
    .text(
      `Verified: ${s.bourse_verification_filter === 1 ? "✓" : "✗"}`,
      "f:vf:toggle",
    )
    .row()
    .text(`Доступные: ${tog(s.bourse_can_trade)}`, "f:ct:toggle")
    .row()
    .text(`Блочные: ${tog(s.bourse_bulk_maker)}`, "f:bm:toggle")
    .row()
    .text(`С кем торговал: ${tog(s.bourse_trade_with)}`, "f:tw:toggle");
}

async function show(ctx: Context, edit: boolean): Promise<void> {
  const s = await ensureSettings(chatIdOf(ctx));
  const text = fmt(s);
  const kb = keyboard(s);
  if (edit && ctx.callbackQuery?.message) {
    await ctx
      .editMessageText(text, { parse_mode: "HTML", reply_markup: kb })
      .catch(async () => {
        await ctx.reply(text, { parse_mode: "HTML", reply_markup: kb });
      });
  } else {
    await ctx.reply(text, { parse_mode: "HTML", reply_markup: kb });
  }
}

export async function handleFiltersShow(ctx: Context): Promise<void> {
  await show(ctx, false);
}

export async function handleFiltersCallback(ctx: Context): Promise<void> {
  const data = ctx.callbackQuery?.data;
  if (!data) return;
  await ctx.answerCallbackQuery().catch(() => {});
  if (data === "f:nop") return;
  const chatId = chatIdOf(ctx);
  const s = await ensureSettings(chatId);

  if (data === "f:sort:next") {
    const next =
      s.bourse_sort_type === "OVERALL_RANKING"
        ? "PRICE"
        : s.bourse_sort_type === "PRICE"
          ? "TRADE_COUNT"
          : "OVERALL_RANKING";
    await updateSettings(chatId, { bourseSortType: next });
    await show(ctx, true);
    return;
  }
  if (data === "f:vf:toggle") {
    await updateSettings(chatId, {
      bourseVerificationFilter: s.bourse_verification_filter === 1 ? 0 : 1,
    });
    await show(ctx, true);
    return;
  }
  if (data === "f:ct:toggle") {
    await updateSettings(chatId, { bourseCanTrade: !s.bourse_can_trade });
    await show(ctx, true);
    return;
  }
  if (data === "f:bm:toggle") {
    await updateSettings(chatId, { bourseBulkMaker: !s.bourse_bulk_maker });
    await show(ctx, true);
    return;
  }
  if (data === "f:tw:toggle") {
    await updateSettings(chatId, { bourseTradeWith: !s.bourse_trade_with });
    await show(ctx, true);
    return;
  }
}
