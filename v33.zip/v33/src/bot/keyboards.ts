import { InlineKeyboard } from "grammy";

export const idleKeyboard = new InlineKeyboard()
  .text("▶️ Старт цикла", "start_cycle")
  .row()
  .text("📊 Позиция", "check")
  .text("📚 Стакан", "stack_open")
  .row()
  .text("⚙️ Настройки", "settings_open")
  .text("🔎 Фильтры", "filters_open")
  .row()
  .text("💼 Рабочие объявления", "working_ads_open")
  .row()
  .text("🔌 Подключение", "connection_open")
  .text("🔐 Авторизация", "auth_status");

export const manualKeyboard = new InlineKeyboard()
  .text("➕ Создать новое", "manual_create")
  .row()
  .text("📋 Текущее ручное", "manual_list")
  .text("🧹 Снять ручное", "manual_cancel")
  .row()
  .text("📚 Стакан", "stack_open")
  .text("⚙️ Настройки", "settings_open")
  .row()
  .text("💼 Рабочие объявления", "working_ads_open")
  .row()
  .text("🔌 Подключение", "connection_open")
  .text("🔐 Авторизация", "auth_status");

export const runningKeyboard = new InlineKeyboard()
  .text("⏹ Стоп (снять)", "stop_cycle")
  .row()
  .text("📊 Статус", "status")
  .text("📚 Стакан", "stack_open")
  .row()
  .text("💼 Рабочие объявления", "working_ads_open");

export const monitoringKeyboard = new InlineKeyboard()
  .text("🔁 Мониторинг ON / OFF", "toggle_poll")
  .row()
  .text("⏹ Стоп (снять)", "stop_cycle")
  .text("📊 Статус", "status")
  .row()
  .text("📚 Стакан", "stack_open")
  .text("⚙️ Настройки", "settings_open")
  .row()
  .text("💼 Рабочие объявления", "working_ads_open");
