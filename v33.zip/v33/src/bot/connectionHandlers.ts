import type { Context } from "grammy";
import { InlineKeyboard } from "grammy";
import { authService, describeSession } from "../auth/authService.js";
import {
  checkOfficialApi,
  getMyMerchantInfo,
  hasOfficialApiCredentials,
  maskApiKey,
  withBybitConnection,
  withOfficialApiCredentials,
} from "../bybit/index.js";
import {
  activateApiAccount,
  deleteApiAccount,
  getActiveApiAccount,
  listApiAccounts,
  saveApiAccount,
} from "../db/repositories/apiAccounts.js";
import { getActiveCycleByChat } from "../db/repositories/cycles.js";
import { listActiveManualAds } from "../db/repositories/manualAds.js";
import {
  ensureSettings,
  updateSettings,
} from "../db/repositories/userSettings.js";
import { clearPaymentsCache } from "./settingsHandlers.js";

type ApiInputStep = "name" | "key" | "secret";

interface PendingApiAccount {
  step: ApiInputStep;
  until: number;
  name?: string;
  apiKey?: string;
}

const INPUT_TTL_MS = 5 * 60_000;
const pendingApiAccounts = new Map<number, PendingApiAccount>();

function setPendingApiAccount(
  chatId: number,
  value: Omit<PendingApiAccount, "until">,
): void {
  const until = Date.now() + INPUT_TTL_MS;
  pendingApiAccounts.set(chatId, { ...value, until });
  const timer = setTimeout(() => {
    const current = pendingApiAccounts.get(chatId);
    if (current?.until === until) pendingApiAccounts.delete(chatId);
  }, INPUT_TTL_MS + 1000);
  timer.unref();
}

function chatIdOf(ctx: Context): number {
  const id = ctx.chat?.id;
  if (!id) throw new Error("No chat");
  return id;
}

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

async function hasActiveWork(chatId: number): Promise<boolean> {
  const [cycle, manualAds] = await Promise.all([
    getActiveCycleByChat(chatId),
    listActiveManualAds(chatId),
  ]);
  return Boolean(cycle || manualAds.length > 0);
}

async function requireIdle(ctx: Context): Promise<boolean> {
  if (!(await hasActiveWork(chatIdOf(ctx)))) return true;
  await ctx.reply(
    "⛔️ Сначала останови цикл и сними ручные объявления. Подключение и API-аккаунт нельзя менять во время активной работы.",
  );
  return false;
}

async function renderConnection(ctx: Context, edit: boolean): Promise<void> {
  const chatId = chatIdOf(ctx);
  const [settings, session, accounts, activeApi] = await Promise.all([
    ensureSettings(chatId),
    authService.getCurrent(),
    listApiAccounts(chatId),
    getActiveApiAccount(chatId),
  ]);
  const sessionStatus = session
    ? `сессия #${session.id}, uid ${session.bybitUid ?? "?"}, ${describeSession(session)}`
    : "сессия не сохранена";
  const envFallback = hasOfficialApiCredentials()
    ? `резервный ENV-ключ ${maskApiKey()}`
    : "ENV-ключи не заданы";
  const apiStatus = activeApi
    ? `аккаунт <b>${escapeHtml(activeApi.name)}</b>, ключ <code>${escapeHtml(activeApi.keyHint)}</code>`
    : envFallback;
  const selected =
    settings.connection_mode === "api"
      ? "Официальный API"
      : "Сессия браузера";
  const sessionMark = settings.connection_mode === "session" ? "✓ " : "";
  const apiMark = settings.connection_mode === "api" ? "✓ " : "";
  const keyboard = new InlineKeyboard()
    .text(`${sessionMark}Сессия браузера`, "c:mode:session")
    .row()
    .text(`${apiMark}Официальный API`, "c:mode:api")
    .row();

  if (settings.connection_mode === "session") {
    keyboard
      .text("🔐 Статус сессии", "auth_status")
      .text("🔄 Обновить вход", "auth_refresh")
      .row();
  }

  for (const account of accounts.slice(0, 10)) {
    keyboard
      .text(
        `${account.isActive ? "✓ " : ""}${account.name} · ${account.keyHint}`,
        `c:account:${account.id}`,
      )
      .text("🗑", `c:delete:${account.id}`)
      .row();
  }
  keyboard
    .text("➕ Добавить API-аккаунт", "c:add")
    .row()
    .text("Проверить выбранное", "c:test")
    .row()
    .text("⬅️ Настройки", "settings_open");

  const text = [
    "🔌 <b>Подключение к Bybit</b>",
    "",
    `Сейчас: <b>${selected}</b>`,
    "",
    `<b>Сессия браузера</b>: ${sessionStatus}.`,
    `<b>Официальный API</b>: ${apiStatus}.`,
    "",
    "API Key и Secret можно ввести прямо здесь. Сообщения удаляются, данные хранятся локально в зашифрованном виде.",
    "Смена подключения не меняет расчёт цены, режим объявлений или top-N.",
  ].join("\n");
  if (edit && ctx.callbackQuery?.message) {
    await ctx
      .editMessageText(text, { parse_mode: "HTML", reply_markup: keyboard })
      .catch(async () => {
        await ctx.reply(text, { parse_mode: "HTML", reply_markup: keyboard });
      });
    return;
  }
  await ctx.reply(text, { parse_mode: "HTML", reply_markup: keyboard });
}

export async function handleConnectionShow(ctx: Context): Promise<void> {
  await renderConnection(ctx, false);
}

export async function handleConnectionCallback(ctx: Context): Promise<void> {
  const data = ctx.callbackQuery?.data;
  if (!data) return;
  await ctx.answerCallbackQuery().catch(() => {});
  const chatId = chatIdOf(ctx);

  if (data === "c:mode:session" || data === "c:mode:api") {
    if (!(await requireIdle(ctx))) return;
    const mode = data === "c:mode:api" ? "api" : "session";
    await updateSettings(chatId, { connectionMode: mode });
    clearPaymentsCache(chatId);
    await renderConnection(ctx, true);
    return;
  }

  if (data === "c:add") {
    if (!(await requireIdle(ctx))) return;
    setPendingApiAccount(chatId, {
      step: "name",
    });
    await ctx.reply(
      "Введи название аккаунта, которое будет видно только в панели.\nНапример: <code>Основной RUB</code>\n\n/cancel — отменить",
      { parse_mode: "HTML" },
    );
    return;
  }

  if (data.startsWith("c:account:")) {
    if (!(await requireIdle(ctx))) return;
    const accountId = Number(data.slice("c:account:".length));
    if (!Number.isSafeInteger(accountId)) return;
    await activateApiAccount(chatId, accountId);
    await updateSettings(chatId, { connectionMode: "api" });
    clearPaymentsCache(chatId);
    await renderConnection(ctx, true);
    return;
  }

  if (data.startsWith("c:delete:")) {
    if (!(await requireIdle(ctx))) return;
    const accountId = Number(data.slice("c:delete:".length));
    if (!Number.isSafeInteger(accountId)) return;
    const account = (await listApiAccounts(chatId)).find(
      (item) => item.id === accountId,
    );
    if (!account) return;
    const keyboard = new InlineKeyboard()
      .text("Удалить", `c:delete_confirm:${accountId}`)
      .text("Отмена", "c:back");
    await ctx.reply(
      `Удалить API-аккаунт <b>${escapeHtml(account.name)}</b>?\nКлюч и Secret будут удалены из базы.`,
      { parse_mode: "HTML", reply_markup: keyboard },
    );
    return;
  }

  if (data.startsWith("c:delete_confirm:")) {
    if (!(await requireIdle(ctx))) return;
    const accountId = Number(data.slice("c:delete_confirm:".length));
    if (!Number.isSafeInteger(accountId)) return;
    await deleteApiAccount(chatId, accountId);
    const remaining = await getActiveApiAccount(chatId);
    if (!remaining && !hasOfficialApiCredentials()) {
      await updateSettings(chatId, { connectionMode: "session" });
    }
    clearPaymentsCache(chatId);
    await renderConnection(ctx, true);
    return;
  }

  if (data === "c:back") {
    await renderConnection(ctx, true);
    return;
  }

  if (data === "c:test") {
    const settings = await ensureSettings(chatId);
    await ctx.reply(
      settings.connection_mode === "api"
        ? "🔎 Проверяю API-ключ, аккаунт, стакан, реквизиты и свои объявления…"
        : "🔎 Проверяю сохранённую браузерную сессию…",
    );
    try {
      if (settings.connection_mode === "api") {
        const result = await withBybitConnection(
          "api",
          () =>
            checkOfficialApi({
              tokenId: settings.token_id,
              currencyId: settings.currency_id,
              side: settings.side,
            }),
          chatId,
        );
        await ctx.reply(
          [
            "✅ <b>Официальный API работает</b>",
            `uid: ${String(result.account.userId ?? "?")}`,
            `ник: ${String(result.account.nickName ?? "?")}`,
            `стакан: получено ${result.onlineAds} объявл.`,
            `свои объявления: ${result.ownAds}`,
            `реквизиты: ${result.payments}`,
            "",
            "Создание объявления этой проверкой не выполнялось.",
          ].join("\n"),
          { parse_mode: "HTML" },
        );
      } else {
        const info = await withBybitConnection(
          "session",
          () => getMyMerchantInfo(),
          chatId,
        );
        await ctx.reply(
          `✅ Сессия работает. uid: ${String(info.userId ?? "?")}, ник: ${String(info.nickName ?? "?")}.`,
        );
      }
    } catch (err) {
      await ctx.reply(`❌ Проверка не пройдена: ${(err as Error).message}`);
    }
  }
}

export async function consumeApiAccountInput(
  ctx: Context,
): Promise<boolean> {
  const chatId = chatIdOf(ctx);
  const pending = pendingApiAccounts.get(chatId);
  if (!pending) return false;
  if (pending.until < Date.now()) {
    pendingApiAccounts.delete(chatId);
    return false;
  }
  const text = ctx.message?.text?.trim();
  if (!text || text.startsWith("/")) return false;

  if (pending.step === "name") {
    if (text.length < 1 || text.length > 40) {
      await ctx.reply("Название должно быть длиной от 1 до 40 символов.");
      return true;
    }
    setPendingApiAccount(chatId, {
      step: "key",
      name: text,
    });
    await ctx.reply(
      "Теперь отправь <b>API Key</b>. Нужен системный HMAC-ключ Bybit с разрешением P2P. Сообщение будет сразу удалено.\n\n/cancel — отменить",
      { parse_mode: "HTML" },
    );
    return true;
  }

  const deleted = await ctx
    .deleteMessage()
    .then(() => true)
    .catch(() => false);

  if (pending.step === "key") {
    if (text.length < 8 || text.length > 200) {
      await ctx.reply("API Key выглядит некорректно. Отправь его ещё раз.");
      return true;
    }
    setPendingApiAccount(chatId, {
      step: "secret",
      name: pending.name,
      apiKey: text,
    });
    await ctx.reply(
      `${deleted ? "✅ Сообщение с ключом удалено." : "⚠️ Telegram не дал удалить сообщение с ключом. Удали его вручную."}\nТеперь отправь <b>API Secret</b>. Он тоже будет удалён.\n\n/cancel — отменить`,
      { parse_mode: "HTML" },
    );
    return true;
  }

  if (!pending.name || !pending.apiKey) {
    pendingApiAccounts.delete(chatId);
    await ctx.reply("❌ Данные ввода потерялись. Начни добавление заново.");
    return true;
  }
  if (text.length < 8 || text.length > 300) {
    await ctx.reply("API Secret выглядит некорректно. Отправь его ещё раз.");
    return true;
  }

  await ctx.reply(
    `${deleted ? "✅ Сообщение с секретом удалено." : "⚠️ Telegram не дал удалить сообщение с секретом. Удали его вручную."}\n🔎 Проверяю ключ через Bybit без создания объявлений…`,
  );

  try {
    const settings = await ensureSettings(chatId);
    await withOfficialApiCredentials(
      { apiKey: pending.apiKey, apiSecret: text },
      () =>
        checkOfficialApi({
          tokenId: settings.token_id,
          currencyId: settings.currency_id,
          side: settings.side,
        }),
      chatId,
    );
  } catch (err) {
    await ctx.reply(
      `❌ Bybit не принял API-аккаунт: ${(err as Error).message}\nCredentials не сохранены. Проверь права P2P, тип ключа HMAC, IP-ограничения и отправь Secret ещё раз либо /cancel.`,
    );
    return true;
  }

  let account;
  try {
    account = await saveApiAccount({
      chatId,
      name: pending.name,
      apiKey: pending.apiKey,
      apiSecret: text,
    });
  } catch (err) {
    await ctx.reply(
      `❌ Не удалось зашифровать или сохранить API-аккаунт: ${(err as Error).message}\nОтправь Secret ещё раз или /cancel.`,
    );
    return true;
  }
  pendingApiAccounts.delete(chatId);
  await updateSettings(chatId, { connectionMode: "api" });
  clearPaymentsCache(chatId);
  await ctx.reply(
    `✅ API-аккаунт прошёл проверку, сохранён и выбран.\nАккаунт: <b>${escapeHtml(account.name)}</b>\nКлюч: <code>${escapeHtml(account.keyHint)}</code>.\n\nСоздание объявлений во время проверки не выполнялось.`,
    { parse_mode: "HTML" },
  );
  await renderConnection(ctx, false);
  return true;
}

export function cancelApiAccountInput(chatId: number): boolean {
  return pendingApiAccounts.delete(chatId);
}
