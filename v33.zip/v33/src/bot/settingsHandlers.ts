import type { Context } from "grammy";
import { InlineKeyboard } from "grammy";
import {
  UserSettingsRow,
  ensureSettings,
  updateSettings,
} from "../db/repositories/userSettings.js";
import {
  SideSettingsRow,
  ensureSideSettings,
  updateSideSettings,
} from "../db/repositories/sideSettings.js";
import {
  PaymentMethod,
  isPaymentUsable,
  listPostAdPayments,
  paymentLabel,
  withBybitConnection,
} from "../bybit/index.js";

interface PendingInput {
  field: InputField;
  until: number;
  returnSection: SettingsSection;
}
type SettingsSection =
  | "main"
  | "mode"
  | "market"
  | "price"
  | "ad"
  | "safety";
type InputField =
  | "qty"
  | "range"
  | "step"
  | "fixed"
  | "period"
  | "token"
  | "currency"
  | "remark"
  | "bounds"
  | "topn"
  | "paypass"
  | "floating_premium";

const PENDING_TTL_MS = 5 * 60_000;
const pending = new Map<number, PendingInput>();

const PROMPTS: Record<InputField, string> = {
  qty: "Введи количество (например 10) или <b>auto</b> чтобы пересчитывать автоматически из max/price.",
  range:
    "Введи диапазон min и max через пробел или дефис.\nНапример: <code>500 1000</code> или <code>500-1000</code>",
  step:
    "Введи шаг от топа стакана. Например <code>0.01</code>.\n<code>0</code> = ставить ровно как у топа.",
  fixed:
    "Введи ручной курс объявления (например 75.50). Режим курса переключится на ручной.",
  period: "Введи период оплаты в минутах (например 30)",
  token: "Введи токен (USDT)",
  currency: "Введи валюту (RUB)",
  remark: "Введи текст комментария к объявлению (или . для пустой строки)",
  bounds:
    "Введи safety-границы цены: min и max через пробел.\nНапример: <code>60 90</code>",
  topn:
    "Введи целевой топ, на котором бот остановится и оставит объявление активным.\nНапример: <code>10</code>, <code>20</code> или <code>40</code>.",
  paypass:
    "Введи свой <b>платёжный пароль Bybit</b> (нужен для авто-2FA при создании объявления).\n\n⚠️ Сообщение с паролем удалится сразу после сохранения.\nЕсли хочешь стереть текущий — введи <code>.</code>",
  floating_premium:
    "Введи floating premium в процентах.\n<code>100.00</code> = ровно reference price Bybit, <code>99.99</code> = чуть ниже, <code>100.01</code> = чуть выше.",
};

// Простой кэш payment-list, чтобы не дёргать Bybit каждый клик
const paymentsCache = new Map<
  string,
  { at: number; list: PaymentMethod[] }
>();
const PAYMENTS_TTL_MS = 60_000;
async function getPaymentsCached(
  mode: UserSettingsRow["connection_mode"],
  chatId: number,
  force = false,
): Promise<PaymentMethod[]> {
  const cacheKey = `${chatId}:${mode}`;
  const cached = paymentsCache.get(cacheKey);
  if (!force && cached && Date.now() - cached.at < PAYMENTS_TTL_MS) {
    return cached.list;
  }
  const list = await withBybitConnection(
    mode,
    () => listPostAdPayments(),
    chatId,
  );
  paymentsCache.set(cacheKey, { at: Date.now(), list });
  return list;
}

export function clearPaymentsCache(chatId: number): void {
  paymentsCache.delete(`${chatId}:session`);
  paymentsCache.delete(`${chatId}:api`);
}

function chatIdOf(ctx: Context): number {
  const id = ctx.chat?.id;
  if (!id) throw new Error("No chat");
  return id;
}

function modeLabel(mode: UserSettingsRow["ad_mode"]): string {
  if (mode === "manual") return "ручное создание";
  return "автоцикл: 1 объявление";
}

function priceModeLabel(s: UserSettingsRow): string {
  if (s.price_mode === "fixed") return `вручную ${s.price_fixed ?? "—"}`;
  return `от стакана: top ${s.side === "1" ? "−" : "+"} ${s.price_step}`;
}

function priceTypeLabel(type: UserSettingsRow["primary_price_type"]): string {
  return type === "floating" ? "floating" : "fixed";
}

function usesFloatingSettings(s: UserSettingsRow): boolean {
  return s.primary_price_type === "floating";
}

function fmt(
  s: UserSettingsRow,
  side: SideSettingsRow,
  payments: PaymentMethod[],
): string {
  const sideLabel = s.side === "1" ? "SELL" : "BUY";
  const paymentNames = side.payment_ids.map((id) => {
    const p = payments.find((x) => String(x.id) === String(id));
    return p ? paymentLabel(p) : id;
  });
  const lines = [
    `⚙️ <b>Настройки</b>`,
    ``,
    `Подключение: <b>${s.connection_mode === "api" ? "официальный API" : "сессия браузера"}</b>`,
    `Режим: <b>${modeLabel(s.ad_mode)}</b>`,
    `Рынок: <b>${s.token_id}/${s.currency_id} · ${sideLabel}</b>`,
    ``,
    `<b>Цена</b>`,
    `Цель: <b>${priceModeLabel(s)}</b>`,
    `Формат Bybit: <b>${priceTypeLabel(s.primary_price_type)}</b>`,
    usesFloatingSettings(s)
      ? `Floating premium: <b>${s.dual_ads_premium_mode === "auto" ? "подобрать под целевую цену" : `${s.dual_ads_premium_manual}% вручную`}</b>`
      : null,
    ``,
    `<b>Объявление</b>`,
    `Объём: <b>${side.quantity_auto ? "auto" : side.quantity} ${s.token_id}</b>`,
    `Лимиты: <b>${side.min_amount}–${side.max_amount} ${s.currency_id}</b> · ${side.payment_period} мин`,
    `Реквизиты: <b>${paymentNames.length ? paymentNames.join(", ") : "не выбраны"}</b>`,
    ``,
    `<b>Остановка</b>: топ-${s.bourse_top_n} · границы ${s.price_min}–${s.price_max}`,
  ].filter((line): line is string => line !== null);
  if (s.ad_mode === "manual") {
    lines.push(
      ``,
      `Ручная кнопка снимает прошлое ручное объявление и ставит новое.`,
    );
  }
  return lines.join("\n");
}

function keyboard(
  s: UserSettingsRow,
  side: SideSettingsRow,
): InlineKeyboard {
  const kb = new InlineKeyboard()
    .text(
      `🔌 ${s.connection_mode === "api" ? "Официальный API" : "Сессия браузера"}`,
      "connection_open",
    )
    .row()
    .text(`🎛 ${modeLabel(s.ad_mode)}`, "sm:mode")
    .row()
    .text(`💱 ${s.token_id}/${s.currency_id} · ${s.side === "1" ? "SELL" : "BUY"}`, "sm:market")
    .row()
    .text("💰 Цена объявления", "sm:price")
    .row()
    .text("📦 Объём и оплата", "sm:ad")
    .row()
    .text("🎯 Цель и безопасность", "sm:safety");
  return kb;
}

async function loadAll(chatId: number): Promise<{
  user: UserSettingsRow;
  side: SideSettingsRow;
  payments: PaymentMethod[];
}> {
  const user = await ensureSettings(chatId);
  const side = await ensureSideSettings(chatId, user.side);
  let payments: PaymentMethod[] = [];
  try {
    payments = await getPaymentsCached(user.connection_mode, chatId);
  } catch (err) {
    console.warn("listPostAdPayments failed:", err);
  }
  return { user, side, payments };
}

async function sendSettingsView(
  ctx: Context,
  text: string,
  replyMarkup: InlineKeyboard,
  edit: boolean,
): Promise<void> {
  if (edit && ctx.callbackQuery?.message) {
    await ctx
      .editMessageText(text, { parse_mode: "HTML", reply_markup: replyMarkup })
      .catch(async () => {
        await ctx.reply(text, { parse_mode: "HTML", reply_markup: replyMarkup });
      });
    return;
  }
  await ctx.reply(text, { parse_mode: "HTML", reply_markup: replyMarkup });
}

async function showSettings(
  ctx: Context,
  edit = false,
  section: SettingsSection = "main",
): Promise<void> {
  const { user, side, payments } = await loadAll(chatIdOf(ctx));
  if (section === "main") {
    await sendSettingsView(
      ctx,
      fmt(user, side, payments),
      keyboard(user, side),
      edit,
    );
    return;
  }
  const view = sectionView(section, user, side);
  await sendSettingsView(ctx, view.text, view.keyboard, edit);
}

export async function handleSettingsShow(ctx: Context): Promise<void> {
  await showSettings(ctx, false);
}

function backButton(kb: InlineKeyboard): InlineKeyboard {
  return kb.row().text("⬅️ Все настройки", "sm:main");
}

function sectionView(
  section: Exclude<SettingsSection, "main">,
  s: UserSettingsRow,
  side: SideSettingsRow,
): { text: string; keyboard: InlineKeyboard } {
  if (section === "mode") {
    const kb = new InlineKeyboard()
      .text(`${s.ad_mode === "single" ? "✓ " : ""}Автоцикл 1`, "s:mode:single")
      .text(`${s.ad_mode === "manual" ? "✓ " : ""}Ручное создание`, "s:mode:manual");
    return {
      text: `🎛 <b>Режим работы</b>\n\nСейчас: <b>${modeLabel(s.ad_mode)}</b>`,
      keyboard: backButton(kb),
    };
  }

  if (section === "market") {
    const kb = new InlineKeyboard()
      .text(`${s.side === "0" ? "✓ " : ""}BUY`, "s:side:0")
      .text(`${s.side === "1" ? "✓ " : ""}SELL`, "s:side:1")
      .row()
      .text(`Пара: ${s.token_id}/${s.currency_id}`, "s:in:pair");
    return {
      text: `💱 <b>Рынок</b>\n\nПара: <b>${s.token_id}/${s.currency_id}</b>\nСторона: <b>${s.side === "1" ? "SELL" : "BUY"}</b>`,
      keyboard: backButton(kb),
    };
  }

  if (section === "price") {
    const kb = new InlineKeyboard()
      .text(`${s.price_mode === "auto" ? "✓ " : ""}Курс авто`, "s:auto")
      .text(
        `${s.price_mode === "fixed" ? "✓ " : ""}Курс вручную${s.price_fixed ? `: ${s.price_fixed}` : ""}`,
        "s:in:fixed",
      );
    if (s.price_mode === "auto") {
      kb.row().text(`Шаг от топа: ${s.price_step}`, "s:in:step");
    }
    kb.row()
      .text(
        `${s.primary_price_type === "fixed" ? "✓ " : ""}Тип: fixed`,
        "s:ptype:fixed",
      )
      .text(
        `${s.primary_price_type === "floating" ? "✓ " : ""}Тип: floating`,
        "s:ptype:floating",
      );
    if (usesFloatingSettings(s)) {
      kb.row().text(
        `${s.dual_ads_premium_mode === "auto" ? "✓ " : ""}Premium auto`,
        "s:floating:premium:auto",
      );
      kb.text(
        `${s.dual_ads_premium_mode === "manual" ? "✓ " : ""}Premium вручную`,
        "s:floating:premium:manual",
      );
      if (s.dual_ads_premium_mode === "manual") {
        kb.row().text(
          `Значение: ${s.dual_ads_premium_manual}%`,
          "s:in:floating_premium",
        );
      }
    }
    const format = priceTypeLabel(s.primary_price_type);
    const premium = usesFloatingSettings(s)
      ? `\nPremium: <b>${s.dual_ads_premium_mode === "auto" ? "auto" : `${s.dual_ads_premium_manual}%`}</b>`
      : "";
    return {
      text:
        `💰 <b>Цена объявления</b>\n\n` +
        `Курс: <b>${priceModeLabel(s)}</b>\n` +
        `Тип Bybit: <b>${format}</b>${premium}`,
      keyboard: backButton(kb),
    };
  }

  if (section === "ad") {
    const kb = new InlineKeyboard()
      .text(`Количество: ${side.quantity_auto ? "auto" : side.quantity}`, "s:in:qty")
      .text(`Лимиты: ${side.min_amount}–${side.max_amount}`, "s:in:range")
      .row()
      .text(`Период: ${side.payment_period}м`, "s:in:period")
      .text(`Реквизиты (${side.payment_ids.length})`, "s:payments")
      .row()
      .text(side.remark ? "Комментарий ✏️" : "Комментарий", "s:in:remark");
    if (s.connection_mode === "session") {
      kb.row().text(
        s.payment_password ? "Плат. пароль: ✓" : "Плат. пароль: не задан",
        "s:in:paypass",
      );
    }
    return {
      text:
        `📦 <b>Объём и оплата</b>\n\n` +
        `Количество: <b>${side.quantity_auto ? "auto" : side.quantity} ${s.token_id}</b>\n` +
        `Лимиты: <b>${side.min_amount}–${side.max_amount} ${s.currency_id}</b>\n` +
        `Период: <b>${side.payment_period} мин</b>\n` +
        `Реквизитов выбрано: <b>${side.payment_ids.length}</b>\n` +
        `Комментарий: ${side.remark || "—"}`,
      keyboard: backButton(kb),
    };
  }

  if (section === "safety") {
    const kb = new InlineKeyboard()
      .text(`Остановка: топ-${s.bourse_top_n}`, "s:in:topn")
      .row()
      .text(`Границы: ${s.price_min}–${s.price_max}`, "s:in:bounds");
    return {
      text:
        `🎯 <b>Цель и безопасность</b>\n\n` +
        `Бот остановит цикл, когда объявление войдёт в <b>топ-${s.bourse_top_n}</b>.\n` +
        `Разрешённый курс: <b>${s.price_min}–${s.price_max}</b>.`,
      keyboard: backButton(kb),
    };
  }

  throw new Error(`Неизвестный раздел настроек: ${section}`);
}

async function showPaymentsPicker(ctx: Context, edit = true): Promise<void> {
  const chatId = chatIdOf(ctx);
  const { user, side } = await loadAll(chatId);
  let payments: PaymentMethod[];
  try {
    payments = await getPaymentsCached(user.connection_mode, chatId, true);
  } catch (err) {
    await ctx.reply(`❌ Не удалось получить список платёжек: ${(err as Error).message}`);
    return;
  }

  // Sanitize: выкидываем из БД ID которых нет в актуальном списке (мусор от seed-а или удалённые в Bybit).
  const validIds = new Set(payments.map((p) => String(p.id)));
  const cleaned = side.payment_ids.filter((id) => validIds.has(String(id)));
  if (cleaned.length !== side.payment_ids.length) {
    await updateSideSettings(chatId, user.side, { paymentIds: cleaned });
    side.payment_ids = cleaned;
  }

  const selected = new Set(side.payment_ids.map(String));
  const usableCount = payments.filter(isPaymentUsable).length;
  let statusLine: string;
  if (payments.length === 0) {
    statusLine =
      "У тебя нет реквизитов в Bybit. Добавь карту/СБП в <b>Profile → Payment Methods</b>, потом переоткрой /settings.";
  } else if (usableCount === 0) {
    statusLine = `Найдено ${payments.length} реквизитов, но все помечены ⚠️ (offline/не верифицированы). Включи Online и пройди верификацию в Bybit, потом переоткрой /settings.`;
  } else {
    statusLine =
      "Тыкай чтобы включить/выключить.\n⚠️ — метод offline или не верифицирован, Bybit его не примет в объявление.";
  }
  const text = [
    `💳 <b>Реквизиты основного объявления · ${user.side === "1" ? "SELL" : "BUY"}</b>`,
    ``,
    statusLine,
  ].join("\n");

  const kb = new InlineKeyboard();
  for (const p of payments) {
    const id = String(p.id);
    const checked = selected.has(id);
    const usable = isPaymentUsable(p);
    const prefix = checked ? "✓ " : "";
    const suffix = usable ? "" : " ⚠️";
    kb.text(`${prefix}${paymentLabel(p)}${suffix}`, `p:t:${id}`).row();
  }
  kb.text("⬅️ Назад", "p:done");

  if (edit && ctx.callbackQuery?.message) {
    await ctx.editMessageText(text, { parse_mode: "HTML", reply_markup: kb })
      .catch(async () => {
        await ctx.reply(text, { parse_mode: "HTML", reply_markup: kb });
      });
  } else {
    await ctx.reply(text, { parse_mode: "HTML", reply_markup: kb });
  }
}

export async function handleSettingsCallback(ctx: Context): Promise<void> {
  const data = ctx.callbackQuery?.data;
  if (!data) return;
  await ctx.answerCallbackQuery().catch(() => {});
  const chatId = chatIdOf(ctx);

  if (data.startsWith("sm:")) {
    const section = data.slice("sm:".length) as SettingsSection;
    if (
      ["main", "mode", "market", "price", "ad", "safety"].includes(
        section,
      )
    ) {
      await showSettings(ctx, true, section);
    }
    return;
  }

  if (data === "s:side:0" || data === "s:side:1") {
    const newSide: "0" | "1" = data === "s:side:1" ? "1" : "0";
    await updateSettings(chatId, { side: newSide });
    await ensureSideSettings(chatId, newSide);
    pending.delete(chatId);
    await showSettings(ctx, true, "market");
    return;
  }
  if (data === "s:auto") {
    await updateSettings(chatId, { priceMode: "auto", priceFixed: null });
    pending.delete(chatId);
    await showSettings(ctx, true, "price");
    return;
  }
  if (
    data === "s:mode:single" ||
    data === "s:mode:manual"
  ) {
    const mode = data.slice("s:mode:".length) as "single" | "manual";
    await updateSettings(chatId, {
      adMode: mode,
    });
    pending.delete(chatId);
    await showSettings(ctx, true, "mode");
    return;
  }
  if (data === "s:ptype:fixed" || data === "s:ptype:floating") {
    const primaryPriceType =
      data === "s:ptype:floating" ? "floating" : "fixed";
    await updateSettings(chatId, { primaryPriceType });
    pending.delete(chatId);
    await showSettings(ctx, true, "price");
    return;
  }
  if (
    data === "s:floating:premium:auto" ||
    data === "s:floating:premium:manual"
  ) {
    const dualAdsPremiumMode =
      data === "s:floating:premium:auto"
        ? "auto"
        : "manual";
    await updateSettings(chatId, {
      dualAdsPremiumMode,
    });
    pending.delete(chatId);
    await showSettings(ctx, true, "price");
    return;
  }
  if (data === "s:in:pair") {
    pending.set(chatId, {
      field: "token",
      until: Date.now() + PENDING_TTL_MS,
      returnSection: "market",
    });
    await ctx.reply("Сначала введи токен (USDT). После этого попрошу валюту.");
    return;
  }
  if (data === "s:payments") {
    await showPaymentsPicker(ctx, true);
    return;
  }
  if (data === "p:done") {
    await showSettings(ctx, true, "ad");
    return;
  }
  if (data.startsWith("p:t:")) {
    const id = data.slice("p:t:".length);
    const user = await ensureSettings(chatId);
    const side = await ensureSideSettings(chatId, user.side);
    const set = new Set(side.payment_ids.map(String));
    if (set.has(id)) set.delete(id);
    else set.add(id);
    await updateSideSettings(chatId, user.side, { paymentIds: [...set] });
    await showPaymentsPicker(ctx, true);
    return;
  }
  if (data.startsWith("s:in:")) {
    const field = data.slice("s:in:".length) as InputField;
    if (!(field in PROMPTS)) return;
    pending.set(chatId, {
      field,
      until: Date.now() + PENDING_TTL_MS,
      returnSection: sectionForInput(field),
    });
    await ctx.reply(PROMPTS[field] + "\n\n/cancel — отменить", {
      parse_mode: "HTML",
    });
    return;
  }
}

export async function handleCancelInput(ctx: Context): Promise<void> {
  pending.delete(chatIdOf(ctx));
  await ctx.reply("Отменено.");
}

export async function consumePendingInput(ctx: Context): Promise<boolean> {
  const chatId = chatIdOf(ctx);
  const p = pending.get(chatId);
  if (!p) return false;
  if (p.until < Date.now()) {
    pending.delete(chatId);
    return false;
  }
  const text = ctx.message?.text;
  if (!text) return false;
  if (text.startsWith("/")) return false;

  try {
    const next = await applyValue(chatId, p.field, text.trim());
    // Сообщение с паролем стираем чтобы не висело в чате.
    if (p.field === "paypass") {
      await ctx.deleteMessage().catch(() => {});
    }
    if (next) {
      pending.set(chatId, {
        field: next,
        until: Date.now() + PENDING_TTL_MS,
        returnSection: p.returnSection,
      });
      await ctx.reply(PROMPTS[next] + "\n\n/cancel — отменить", {
        parse_mode: "HTML",
      });
    } else {
      pending.delete(chatId);
      await showSettings(ctx, false, p.returnSection);
    }
  } catch (err) {
    await ctx.reply(`❌ ${(err as Error).message}`);
  }
  return true;
}

function sectionForInput(field: InputField): SettingsSection {
  if (field === "token" || field === "currency") return "market";
  if (field === "step" || field === "fixed" || field === "floating_premium") {
    return "price";
  }
  if (field === "bounds" || field === "topn") return "safety";
  return "ad";
}

async function applyValue(
  chatId: number,
  field: InputField,
  value: string,
): Promise<InputField | null> {
  const user = await ensureSettings(chatId);
  const requirePositive = (s: string): number => {
    const n = Number(s);
    if (!Number.isFinite(n) || n <= 0) throw new Error(`Не число или ≤ 0: ${s}`);
    return n;
  };

  switch (field) {
    // Side-specific:
    case "qty":
      if (value.toLowerCase() === "auto") {
        await updateSideSettings(chatId, user.side, { quantityAuto: true });
        return null;
      }
      requirePositive(value);
      await updateSideSettings(chatId, user.side, {
        quantity: value,
        quantityAuto: false,
      });
      return null;
    case "range": {
      // Принимаем любые разделители: пробел, запятая, тире, дефис
      const parts = value
        .split(/[\s,\-–—]+/)
        .map((s) => s.trim())
        .filter(Boolean);
      if (parts.length !== 2)
        throw new Error("Нужно два числа: min и max (например `500 1000`)");
      const min = requirePositive(parts[0]!);
      const max = requirePositive(parts[1]!);
      if (min >= max) throw new Error("min должен быть < max");
      await updateSideSettings(chatId, user.side, {
        minAmount: String(min),
        maxAmount: String(max),
      });
      return null;
    }
    case "period":
      requirePositive(value);
      await updateSideSettings(chatId, user.side, { paymentPeriod: value });
      return null;
    case "remark": {
      const remark = value === "." ? "" : value;
      await updateSideSettings(chatId, user.side, { remark });
      return null;
    }
    // Global:
    case "step": {
      const n = Number(value);
      if (!Number.isFinite(n) || n < 0)
        throw new Error("Шаг должен быть ≥ 0 (0 = ставить как у топа)");
      await updateSettings(chatId, { priceStep: value, priceMode: "auto" });
      return null;
    }
    case "fixed":
      requirePositive(value);
      await updateSettings(chatId, { priceMode: "fixed", priceFixed: value });
      return null;
    case "token":
      if (!/^[a-z0-9]{2,10}$/i.test(value)) throw new Error("Странный токен");
      await updateSettings(chatId, { tokenId: value.toUpperCase() });
      return "currency";
    case "currency":
      if (!/^[a-z]{3,5}$/i.test(value)) throw new Error("Странная валюта");
      await updateSettings(chatId, { currencyId: value.toUpperCase() });
      return null;
    case "bounds": {
      const parts = value.split(/\s+/);
      if (parts.length !== 2) throw new Error("Нужно два числа через пробел");
      const min = Number(parts[0]);
      const max = Number(parts[1]);
      if (!Number.isFinite(min) || !Number.isFinite(max) || min >= max) {
        throw new Error("Невалидные min/max");
      }
      await updateSettings(chatId, {
        priceMin: String(min),
        priceMax: String(max),
      });
      return null;
    }
    case "topn": {
      const n = Number(value);
      if (!Number.isSafeInteger(n) || n < 1 || n > 200) {
        throw new Error("Top должен быть целым числом от 1 до 200");
      }
      await updateSettings(chatId, { bourseTopN: n });
      return null;
    }
    case "paypass": {
      const paymentPassword = value === "." ? null : value;
      await updateSettings(chatId, { paymentPassword });
      return null;
    }
    case "floating_premium": {
      const n = Number(value);
      if (!Number.isFinite(n) || n <= 0) {
        throw new Error("Premium должен быть числом > 0, например 100.00");
      }
      await updateSettings(chatId, {
        dualAdsPremiumManual: n.toFixed(2),
        dualAdsPremiumMode: "manual",
      });
      return null;
    }
  }
}
