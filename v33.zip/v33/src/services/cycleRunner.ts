import { config } from "../config.js";
import {
  BybitApiError,
  BybitAuthError,
  SecurityChallengeRequiredError,
  cancelAd,
  createAd,
  findMyRankInStack,
  getLastPrice,
  getOwnAdDetails,
  getTopPrice,
  getWorkConfig,
  getMyMerchantInfo,
  withBybitConnection,
} from "../bybit/index.js";
import {
  AdCycleRow,
  CycleStatus,
  createCycle,
  getActiveCycleByChat,
  getCycleById,
  incrementAttempts,
  listActiveCycles,
  updateCycleState,
} from "../db/repositories/cycles.js";
import { recordAttempt } from "../db/repositories/attempts.js";
import { ensureSettings } from "../db/repositories/userSettings.js";
import { ensureSideSettings } from "../db/repositories/sideSettings.js";
import { authService } from "../auth/authService.js";
import {
  computeFloatingPremium,
  computeTargetPrice,
  estimateFloatingPrice,
} from "./price.js";
import {
  decideAfterRankCheck,
  nextCycleStatus,
} from "./decision.js";
import { classifyOfficialAdState } from "./officialAdState.js";

class ConfigError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ConfigError";
  }
}

export type Notify = (chatId: number, text: string) => Promise<void>;

interface RunnerHandle {
  cycleId: number;
  timer: NodeJS.Timeout;
  /** Защита от перекрытия тиков, если итерация длится дольше интервала */
  busy: boolean;
}

type SlotKind = "fixed" | "floating";

interface ActiveSlot {
  kind: SlotKind;
  itemId: string;
  price: string;
  premium?: string | null;
}

interface SlotRank extends ActiveSlot {
  rank: number | null;
  page: number | null;
  nickName: string | null;
  showStatus: "ONLINE" | "HIDDEN";
}

interface AdParamsSnapshot {
  quantity: string;
  quantity_auto: boolean;
  min_amount: string;
  max_amount: string;
  payment_period: string;
  payment_ids: string[];
  remark: string;
}

export class CycleRunner {
  private readonly handles = new Map<number, RunnerHandle>();
  /** Чтобы не спамить «объявление скрыто» каждые 10 сек, помним последнюю отправленную причину. */
  private readonly lastHiddenNotice = new Map<number, string>();

  constructor(private readonly notify: Notify) {}

  private async notifyHiddenOnce(
    cycleId: number,
    chatId: number,
    info: {
      showStatus: string | null;
      hiddenReason: string | null;
      targetPrice: string;
      topPrice: string | null;
      rank: number | null;
    },
  ): Promise<void> {
    const key = `${info.showStatus}:${info.hiddenReason}`;
    if (this.lastHiddenNotice.get(cycleId) === key) return;
    this.lastHiddenNotice.set(cycleId, key);
    const lines = [
      `⚠️ Объявление создано, но НЕ ВИДНО в стакане.`,
      `   showStatus: ${info.showStatus ?? "—"}, причина: ${info.hiddenReason ?? "—"}`,
      info.hiddenReason === "REST"
        ? `   У тебя мерчант в REST mode — включи Online в Bybit, иначе цикл не сможет добраться до 1-й страницы.`
        : `   Разберись с причиной в UI Bybit, потом продолжим.`,
      `   Гипотетический ранг при цене ${info.targetPrice} (топ ${info.topPrice ?? "?"}): №${info.rank ?? "?"}`,
    ];
    await this.notify(chatId, lines.join("\n"));
  }

  async resumeAll(): Promise<void> {
    const active = await listActiveCycles();
    for (const c of active) this.schedule(c.id);
    console.log(`Resumed ${active.length} cycle(s) from DB`);
  }

  async start(chatId: number): Promise<{
    cycle: AdCycleRow;
    created: boolean;
    workStatus?: string;
  }> {
    const existing = await getActiveCycleByChat(chatId);
    if (existing) return { cycle: existing, created: false };

    const settings = await ensureSettings(chatId);
    let workStatus: string | undefined;
    let apiUserId: string | undefined;
    try {
      const wc = await withBybitConnection(
        settings.connection_mode,
        () => getWorkConfig(),
        chatId,
      );
      workStatus = wc.workStatus;
      apiUserId = wc.userId;
    } catch (err) {
      if (settings.connection_mode === "api") {
        throw new Error(
          `Официальный API не прошёл проверку: ${(err as Error).message}. Открой /connection → Проверить выбранное.`,
        );
      }
      console.warn("getWorkConfig failed:", err);
    }
    if (workStatus === "REST") {
      throw new Error(
        "Аккаунт в REST mode — объявления будут скрыты, цикл не имеет смысла. Включи Online в Bybit, потом ▶️ Старт.",
      );
    }

    const sideSettings = await ensureSideSettings(chatId, settings.side);
    if (sideSettings.payment_ids.length === 0) {
      throw new Error(
        `Для ${settings.side === "1" ? "SELL" : "BUY"} не выбраны Payments. /settings → Payments.`,
      );
    }
    if (settings.ad_mode === "manual") {
      throw new Error(
        "Включен ручной режим создания объявлений. Нажми кнопку создания в боте или переключи /settings → Автоцикл 1.",
      );
    }
    const session = await authService.getCurrent();
    const bybitUid =
      (settings.connection_mode === "api"
        ? parseBybitUid(apiUserId, "Bybit API uid")
        : parseBybitUid(session?.bybitUid, "Bybit session uid") ??
          parseBybitUid(config.bybit.userId, "BYBIT_USER_ID")) ?? 0;
    const cycle = await createCycle({
      chatId,
      userId: bybitUid,
      tokenId: settings.token_id,
      currencyId: settings.currency_id,
      side: settings.side,
      quantity: sideSettings.quantity,
      quantityAuto: sideSettings.quantity_auto,
      minAmount: sideSettings.min_amount,
      maxAmount: sideSettings.max_amount,
      paymentPeriod: sideSettings.payment_period,
      paymentIds: sideSettings.payment_ids,
      remark: sideSettings.remark,
    });
    if (workStatus) {
      await updateCycleState(cycle.id, { workStatus });
    }
    this.schedule(cycle.id);
    return { cycle, created: true, workStatus };
  }

  async stop(chatId: number, opts: { cancelItem: boolean }): Promise<void> {
    const cycle = await getActiveCycleByChat(chatId);
    if (!cycle) return;
    const settings = await ensureSettings(chatId);
    this.unschedule(cycle.id);
    if (opts.cancelItem) {
      for (const itemId of [cycle.current_item_id, cycle.secondary_item_id]) {
        if (!itemId) continue;
        try {
          await withBybitConnection(
            settings.connection_mode,
            () => cancelAd(itemId),
            chatId,
          );
        } catch (err) {
          console.error(`cancel on stop failed (${itemId}):`, err);
        }
      }
    }
    await updateCycleState(cycle.id, {
      status: "stopped",
      stoppedAt: new Date(),
    });
  }

  async togglePolling(chatId: number): Promise<{
    nowMonitoring: boolean;
    cycle: AdCycleRow | null;
  }> {
    const cycle = await getActiveCycleByChat(chatId);
    if (!cycle) return { nowMonitoring: false, cycle: null };

    if (cycle.status === "monitoring" || cycle.status === "first_page") {
      this.unschedule(cycle.id);
      await updateCycleState(cycle.id, { status: "stopped", stoppedAt: new Date() });
      return { nowMonitoring: false, cycle: { ...cycle, status: "stopped" } };
    }
    await updateCycleState(cycle.id, { status: "monitoring", stoppedAt: null });
    this.schedule(cycle.id);
    return { nowMonitoring: true, cycle: { ...cycle, status: "monitoring" } };
  }

  private schedule(cycleId: number): void {
    if (this.handles.has(cycleId)) return;
    const timer = setInterval(() => {
      void this.tick(cycleId);
    }, config.cycle.intervalMs);
    this.handles.set(cycleId, { cycleId, timer, busy: false });
    setImmediate(() => void this.tick(cycleId));
  }

  private unschedule(cycleId: number): void {
    const h = this.handles.get(cycleId);
    if (!h) return;
    clearInterval(h.timer);
    this.handles.delete(cycleId);
    this.lastHiddenNotice.delete(cycleId);
  }

  private async tick(cycleId: number): Promise<void> {
    const handle = this.handles.get(cycleId);
    if (!handle || handle.busy) return;
    handle.busy = true;
    try {
      const cycle = await getCycleById(cycleId);
      if (!cycle) {
        this.unschedule(cycleId);
        return;
      }
      if (cycle.status === "stopped" || cycle.status === "failed") {
        this.unschedule(cycleId);
        return;
      }
      if (cycle.status === "monitoring" || cycle.status === "first_page") {
        const settings = await ensureSettings(Number(cycle.chat_id));
        await withBybitConnection(
          settings.connection_mode,
          async () => {
            await this.cleanupLegacySecondary(cycle);
            await this.monitorTick(cycle, settings);
          },
          Number(cycle.chat_id),
        );
      } else {
        const settings = await ensureSettings(Number(cycle.chat_id));
        await withBybitConnection(
          settings.connection_mode,
          async () => {
            await this.cleanupLegacySecondary(cycle);
            await this.runningTick(cycle, settings);
          },
          Number(cycle.chat_id),
        );
      }
    } catch (err) {
      console.error(`Tick error for cycle ${cycleId}:`, err);
    } finally {
      handle.busy = false;
    }
  }

  private activeSlots(cycle: AdCycleRow): ActiveSlot[] {
    const slots: ActiveSlot[] = [];
    if (cycle.current_item_id && cycle.current_price) {
      slots.push({
        kind: cycle.current_price_type === "1" ? "floating" : "fixed",
        itemId: cycle.current_item_id,
        price: cycle.current_price,
        premium: cycle.current_premium,
      });
    }
    return slots;
  }

  private async cleanupLegacySecondary(cycle: AdCycleRow): Promise<void> {
    if (!cycle.secondary_item_id) return;
    try {
      await cancelAd(cycle.secondary_item_id);
    } catch (err) {
      console.warn(
        `legacy secondary cancel failed (${cycle.secondary_item_id}):`,
        err,
      );
      throw new Error(
        `Не удалось снять второе объявление старой версии (${cycle.secondary_item_id}). Цикл не продолжен; бот повторит попытку через 30 секунд.`,
      );
    }
    cycle.secondary_item_id = null;
    cycle.secondary_price = null;
    cycle.secondary_premium = null;
    cycle.secondary_last_rank = null;
    cycle.secondary_last_page = null;
    await updateCycleState(cycle.id, {
      secondaryItemId: null,
      secondaryPrice: null,
      secondaryPremium: null,
      secondaryLastRank: null,
      secondaryLastPage: null,
    });
  }

  private async cancelCycleAds(cycle: AdCycleRow): Promise<void> {
    for (const slot of this.activeSlots(cycle)) {
      try {
        await cancelAd(slot.itemId);
      } catch (err) {
        console.warn(`cancel of ${slot.itemId} failed:`, err);
      }
    }
  }

  private async persistRankState(
    cycleId: number,
    ranks: SlotRank[],
    extra: Parameters<typeof updateCycleState>[1] = {},
  ): Promise<void> {
    const primary = ranks[0] ?? null;
    await updateCycleState(cycleId, {
      lastRank: primary?.rank ?? null,
      lastPage: primary?.page ?? null,
      secondaryLastRank: null,
      secondaryLastPage: null,
      showStatus: ranks.some((s) => s.rank !== null) ? "ONLINE" : "HIDDEN",
      hiddenReason: null,
      ...extra,
    });
  }

  private async runningTick(
    cycle: AdCycleRow,
    settings: Awaited<ReturnType<typeof ensureSettings>>,
  ): Promise<void> {
    await incrementAttempts(cycle.id);
    const topN = settings.bourse_top_n;
    const pageSize = config.p2p.pageSize;
    const maxPages = Math.max(1, Math.ceil(topN / pageSize));

    // Pre-check: если у нас УЖЕ есть объявление в целевом топе — цикл останавливается,
    // объявление НЕ удаляется. Защита от случайной отмены успешной объявы.
    //
    // КРИТИЧНО: если запрос к стакану упал — НЕ идём в cancel+create. Ждём следующий тик.
    // Сетевая ошибка не должна убивать успешное объявление.
    const preChecks: SlotRank[] = [];
    for (const slot of this.activeSlots(cycle)) {
      try {
        const found = await findMyRankInStack({
          itemId: slot.itemId,
          tokenId: cycle.token_id,
          currencyId: cycle.currency_id,
          side: cycle.side as "0" | "1",
          pageSize,
          maxPages,
          verificationFilter: settings.bourse_verification_filter,
        });
        preChecks.push({
          ...slot,
          rank: found.rank,
          page: found.page,
          nickName: found.nickName,
          showStatus: found.rank !== null ? "ONLINE" : "HIDDEN",
        });
      } catch (err) {
        console.warn(
          `pre-check rank failed for cycle ${cycle.id}, skipping tick:`,
          err,
        );
        await updateCycleState(cycle.id, {
          lastError: `pre-check failed: ${(err as Error).message}`,
        });
        return; // НЕ cancel-им. На следующем тике попробуем снова.
      }
    }

    const preHit = bestTopHit(preChecks, topN);
    if (preHit) {
      await this.persistRankState(cycle.id, preChecks, {
        status: "stopped",
        stoppedAt: new Date(),
        lastError: null,
      });
      this.unschedule(cycle.id);
      await this.notify(
        Number(cycle.chat_id),
        `✅ ${slotLabel(preHit.kind)} уже в топ-${topN} (№${preHit.rank} · стр. ${preHit.page}). Цикл остановлен, объявления активны.`,
      );
      return;
    }
    // keep_running → проваливаемся в основной flow (cancel + create)

    // Pre-flight: workStatus. Если REST — впустую крутиться нельзя.
    try {
      const wc = await getWorkConfig();
      if (wc.workStatus === "REST") {
        await updateCycleState(cycle.id, {
          status: "stopped",
          workStatus: "REST",
          lastError: "Аккаунт в REST mode — нет смысла крутить",
          stoppedAt: new Date(),
        });
        this.unschedule(cycle.id);
        await this.notify(
          Number(cycle.chat_id),
          `⏸ Цикл остановлен: workStatus = REST. Включи Online в Bybit и нажми ▶️ Старт.`,
        );
        return;
      }
    } catch (err) {
      if (err instanceof BybitAuthError) {
        const recovery =
          err.source === "api"
            ? "Проверь API-ключи и доступ P2P Open API в /connection"
            : "Запусти /auth_refresh";
        await updateCycleState(cycle.id, {
          status: "stopped",
          lastError: recovery,
          stoppedAt: new Date(),
        });
        this.unschedule(cycle.id);
        await this.notify(
          Number(cycle.chat_id),
          `🔐 Авторизация Bybit не прошла. ${recovery}, потом /go снова.`,
        );
        return;
      }
      console.warn("getWorkConfig in tick failed:", err);
    }

    let topPrice: string | null = null;
    let computedPrice: string | null = null;
    try {
      topPrice = await getTopPrice({
        tokenId: cycle.token_id,
        currencyId: cycle.currency_id,
        side: cycle.side as "0" | "1",
        userId: cycle.user_id ? String(cycle.user_id) : undefined,
      });
      if (!topPrice) throw new Error("Стакан пуст или не вернул цену");

      const target = computeTargetPrice({
        topPrice,
        side: cycle.side as "0" | "1",
        step: Number(settings.price_step),
        min: Number(settings.price_min),
        max: Number(settings.price_max),
        mode: settings.price_mode,
        fixedPrice: settings.price_fixed,
      });
      if (!target.ok) throw new Error(target.reason);
      computedPrice = target.price;

      const primaryParams = paramsFromCycle(cycle);
      const primaryFloating = settings.primary_price_type === "floating";
      const primaryPlan = primaryFloating
        ? await resolveFloatingPlan({
            tokenId: cycle.token_id,
            currencyId: cycle.currency_id,
            targetPrice: target.price,
            premiumMode: settings.dual_ads_premium_mode,
            premiumManual: settings.dual_ads_premium_manual,
            label: "primary floating",
          })
        : {
            priceType: "0" as const,
            price: target.price,
            premium: null as string | null,
            useFlexible: false,
          };
      const effectiveQty = effectiveQuantity(
        primaryParams,
        primaryPlan.price,
        primaryFloating ? "primary floating" : "fixed",
      );

      await this.cancelCycleAds(cycle);

      const paymentPassword =
        settings.payment_password || config.bybit.paymentPassword || undefined;
      const created = await createAd({
	        tokenId: cycle.token_id,
	        currencyId: cycle.currency_id,
	        side: cycle.side as "0" | "1",
	        priceType: primaryPlan.priceType,
	        price: primaryPlan.price,
	        premium: primaryPlan.premium ?? undefined,
	        quantity: effectiveQty,
	        minAmount: cycle.min_amount,
	        maxAmount: cycle.max_amount,
	        paymentPeriod: cycle.payment_period,
	        paymentIds: cycle.payment_ids,
	        remark: cycle.remark,
	        useFlexible: primaryPlan.useFlexible,
	        paymentPassword,
	      });
      const itemId = (created.itemId ?? created.id ?? null) as string | null;
      await updateCycleState(cycle.id, {
        currentItemId: itemId,
        currentPrice: primaryPlan.price,
        currentPriceType: primaryPlan.priceType,
        currentPremium: primaryPlan.premium,
        secondaryItemId: null,
        secondaryPrice: null,
        secondaryPremium: null,
        secondaryLastRank: null,
        secondaryLastPage: null,
      });

      // Ищем своё объявление в топ-N стакана. Это единственный источник правды о позиции.
      const postSlots: ActiveSlot[] = [];
      if (itemId) {
        postSlots.push({
          kind: primaryPlan.priceType === "1" ? "floating" : "fixed",
          itemId,
          price: primaryPlan.price,
          premium: primaryPlan.premium,
        });
      }
      const postChecks: SlotRank[] = [];
      for (const slot of postSlots) {
        try {
          const found = await findMyRankInStack({
            itemId: slot.itemId,
            tokenId: cycle.token_id,
            currencyId: cycle.currency_id,
            side: cycle.side as "0" | "1",
            pageSize,
            maxPages,
            verificationFilter: settings.bourse_verification_filter,
          });
          postChecks.push({
            ...slot,
            rank: found.rank,
            page: found.page,
            nickName: found.nickName,
            showStatus: found.rank !== null ? "ONLINE" : "HIDDEN",
          });
        } catch (err) {
          console.warn("findMyRankInStack failed:", err);
          postChecks.push({
            ...slot,
            rank: null,
            page: null,
            nickName: null,
            showStatus: "HIDDEN",
          });
        }
      }
      const primaryCheck =
        postChecks.find((s) => s.itemId === String(itemId ?? "")) ?? null;

      if (
        settings.connection_mode === "api" &&
        postChecks.length > 0 &&
        postChecks.every((slot) => slot.rank === null)
      ) {
        const hidden = await findHiddenOfficialAd(postChecks);
        if (hidden) {
          const reason =
            hidden.details.hiddenReason ||
            `status=${String(hidden.details.status ?? "unknown")}`;
          for (const slot of postChecks) {
            await recordAttempt({
              cycleId: cycle.id,
              itemId: slot.itemId,
              price: slot.price,
              topPrice,
              rank: null,
              page: null,
              ok: true,
              showStatus: "HIDDEN",
              hiddenReason: reason,
            });
          }
          await updateCycleState(cycle.id, {
            status: "stopped",
            stoppedAt: new Date(),
            lastRank: null,
            lastPage: null,
            secondaryLastRank: null,
            secondaryLastPage: null,
            showStatus: "HIDDEN",
            hiddenReason: reason,
            lastError: `Объявление скрыто Bybit: ${reason}`,
          });
          this.unschedule(cycle.id);
          await this.notify(
            Number(cycle.chat_id),
            `⏸ Цикл остановлен: ${slotLabel(hidden.slot.kind)} создано, но Bybit скрыл объявление.\n` +
              `Причина: ${reason}\n` +
              `itemId: ${hidden.slot.itemId}\n` +
              `Объявление не удалено. Проверь его в Bybit и после исправления снова нажми ▶️ Старт.`,
          );
          return;
        }
      }

      // Сохраняем ник в session если поймали в стакане и в БД ещё пусто.
      const foundNick = postChecks.find((s) => s.nickName)?.nickName ?? null;
      const accountNick = await resolveAccountNickname(
        settings.connection_mode,
        foundNick,
      );

      const hit = bestTopHit(postChecks, topN);
      const action = decideAfterRankCheck(
        { rank: hit?.rank ?? null, page: hit?.page ?? null },
        topN,
      );
      const isFirstPage = action.kind === "stop_recreate";
      const nickLabel = accountNick ? `@${accountNick}` : `uid ${cycle.user_id}`;

      for (const slot of postChecks) {
        await recordAttempt({
          cycleId: cycle.id,
          itemId: slot.itemId,
          price: slot.price,
          topPrice,
          rank: slot.rank,
          page: slot.page,
          ok: true,
          showStatus: slot.showStatus,
          hiddenReason: null,
        });
      }

      const nextStatus: CycleStatus = nextCycleStatus(action);
      await updateCycleState(cycle.id, {
        currentItemId: itemId,
        currentPrice: primaryPlan.price,
        currentPriceType: primaryPlan.priceType,
        currentPremium: primaryPlan.premium,
        secondaryItemId: null,
        secondaryPrice: null,
        secondaryPremium: null,
        lastRank: primaryCheck?.rank ?? null,
        lastPage: primaryCheck?.page ?? null,
        secondaryLastRank: null,
        secondaryLastPage: null,
        status: nextStatus,
        lastError: null,
        showStatus: postChecks.some((s) => s.rank !== null) ? "ONLINE" : "HIDDEN",
        hiddenReason: null,
        ...(isFirstPage ? { stoppedAt: new Date() } : {}),
      });

      if (isFirstPage) {
        this.unschedule(cycle.id);
        const hitLabel = hit ? slotLabel(hit.kind) : "Объявление";
        await this.notify(
          Number(cycle.chat_id),
          `✅ ${hitLabel} ${nickLabel} в топ-${topN} (№${hit?.rank}). Цикл остановлен, объявления активны.\n` +
            `${slotLabel(primaryPlan.priceType === "1" ? "floating" : "fixed")}: ${primaryPlan.price}` +
            (primaryPlan.premium ? ` · premium ${primaryPlan.premium}%` : "") +
            `\nТоп стакана: ${topPrice}`,
        );
      } else if (postChecks.some((s) => s.rank !== null)) {
        const changed = primaryCheck?.page !== cycle.last_page;
        if (changed) {
          await this.notify(
            Number(cycle.chat_id),
            `🔍 ${nickLabel}: ${formatSlotRanks(postChecks)}.`,
          );
        }
      } else {
        // Не нашли в первых maxPages страниц
        if (cycle.show_status === "ONLINE" || cycle.last_rank !== null) {
          await this.notify(
            Number(cycle.chat_id),
            `❌ ${nickLabel} не в топ-${topN}. ${slotLabel(primaryPlan.priceType === "1" ? "floating" : "fixed")} ${primaryPlan.price}` +
              (primaryPlan.premium ? ` · premium ${primaryPlan.premium}%` : "") +
              `, топ ${topPrice}.`,
          );
        }
      }
    } catch (err) {
      const baseMsg =
        err instanceof BybitApiError ? err.message : (err as Error).message;
      // Если 912300013 (payment method) — допишем какие IDs мы отправляли,
      // чтобы было сразу видно что не пускает.
      const isPaymentErr =
        err instanceof BybitApiError && err.code === 912300013;
      const msg = isPaymentErr
        ? `${baseMsg}\nОтправлены paymentIds: [${cycle.payment_ids.join(", ")}]\n→ /settings → Payments — выбери только онлайн+верифицированные.`
        : baseMsg;
      await recordAttempt({
        cycleId: cycle.id,
        price: computedPrice ?? "",
        topPrice,
        ok: false,
        error: msg,
      });
      if (err instanceof BybitAuthError) {
        const recovery =
          err.source === "api"
            ? "Проверь API-ключи и доступ P2P Open API в /connection"
            : "Запусти /auth_refresh";
        await updateCycleState(cycle.id, {
          lastError: recovery,
        });
        this.unschedule(cycle.id);
        await this.notify(
          Number(cycle.chat_id),
          `🔐 Авторизация Bybit не прошла. ${recovery}, потом /go снова.`,
        );
        return;
      }
      if (
        err instanceof BybitApiError &&
          (err.code === 912300013 ||
            err.code === 912120023 ||
          err.code === 912300012 ||
          err.code === 90043)
      ) {
        await updateCycleState(cycle.id, {
          status: "stopped",
          lastError: msg,
          stoppedAt: new Date(),
        });
        this.unschedule(cycle.id);
        await this.notify(
          Number(cycle.chat_id),
          `⏸ Цикл остановлен — Bybit отвергает запрос:\n${msg}`,
        );
        return;
      }
      if (err instanceof ConfigError) {
        await updateCycleState(cycle.id, {
          status: "stopped",
          lastError: msg,
          stoppedAt: new Date(),
        });
        this.unschedule(cycle.id);
        await this.notify(
          Number(cycle.chat_id),
          `⏸ Цикл остановлен — ошибка конфигурации:\n${msg}`,
        );
        return;
      }
      if (err instanceof SecurityChallengeRequiredError) {
        await updateCycleState(cycle.id, {
          status: "failed",
          lastError: "2FA challenge required (см. логи)",
          stoppedAt: new Date(),
        });
        this.unschedule(cycle.id);
        await this.notify(
          Number(cycle.chat_id),
          `🔐 Bybit требует 2FA для создания объявления. Цикл остановлен.\n` +
            `Поток подтверждения через бот пока не реализован — открой Bybit, создай объявление руками один раз, затем повтори ▶️ Старт.`,
        );
        return;
      }
      await updateCycleState(cycle.id, { lastError: msg });
      await this.notify(
        Number(cycle.chat_id),
        `⚠️ Ошибка итерации: ${msg}`,
      );
    }
  }

  private async monitorTick(
    cycle: AdCycleRow,
    monitorSettings: Awaited<ReturnType<typeof ensureSettings>>,
  ): Promise<void> {
    const slots = this.activeSlots(cycle);
    if (slots.length === 0) return;
    try {
      const monTopN = monitorSettings.bourse_top_n;
      const monPageSize = config.p2p.pageSize;
      const monMaxPages = Math.max(1, Math.ceil(monTopN / monPageSize));
      const checks: SlotRank[] = [];
      for (const slot of slots) {
        const found = await findMyRankInStack({
          itemId: slot.itemId,
          tokenId: cycle.token_id,
          currencyId: cycle.currency_id,
          side: cycle.side as "0" | "1",
          pageSize: monPageSize,
          maxPages: monMaxPages,
          verificationFilter: monitorSettings.bourse_verification_filter,
        });
        checks.push({
          ...slot,
          rank: found.rank,
          page: found.page,
          nickName: found.nickName,
          showStatus: found.rank !== null ? "ONLINE" : "HIDDEN",
        });
      }
      const foundNick = checks.find((s) => s.nickName)?.nickName ?? null;
      const accountNick = await resolveAccountNickname(
        monitorSettings.connection_mode,
        foundNick,
      );
      const nickLabel = accountNick
        ? `@${accountNick}`
        : `uid ${cycle.user_id}`;
      await this.persistRankState(cycle.id, checks, { status: "monitoring" });
      for (const slot of checks) {
        await recordAttempt({
          cycleId: cycle.id,
          itemId: slot.itemId,
          price: slot.price,
          rank: slot.rank,
          page: slot.page,
          ok: true,
          showStatus: slot.showStatus,
        });
        const wasRank = cycle.last_rank;
        const wasInTop =
          (wasRank != null && wasRank <= monTopN) || cycle.status === "first_page";
        const nowInTop = slot.rank != null && slot.rank <= monTopN;
        if (!wasInTop && nowInTop) {
          await this.notify(
            Number(cycle.chat_id),
            `✅ ${slotLabel(slot.kind)} ${nickLabel} вошёл в топ-${monTopN}: №${slot.rank} · стр. ${slot.page}.`,
          );
        }
        if (wasInTop && !nowInTop) {
          const where =
            slot.rank !== null
              ? `№${slot.rank} · стр. ${slot.page}`
              : `вообще не в топ-${monTopN}`;
          await this.notify(
            Number(cycle.chat_id),
            `📉 ${slotLabel(slot.kind)} ${nickLabel} выпал из топ-${monTopN} — сейчас ${where}.`,
          );
        }
      }
    } catch (err) {
      const msg = err instanceof BybitApiError ? err.message : (err as Error).message;
      for (const slot of slots) {
        await recordAttempt({
          cycleId: cycle.id,
          itemId: slot.itemId,
          price: slot.price,
          ok: false,
          error: msg,
        });
      }
      console.warn(`monitor tick error: ${msg}`);
    }
  }
}

async function resolveAccountNickname(
  mode: "session" | "api",
  foundNick: string | null,
): Promise<string | null> {
  if (foundNick) {
    if (mode === "session") {
      const session = await authService.getCurrent();
      if (session && !session.nickname) {
        await authService.setNickname(session.id, foundNick);
      }
    }
    return foundNick;
  }
  if (mode === "api") {
    try {
      const profile = await getMyMerchantInfo();
      return profile.nickName ?? null;
    } catch {
      return null;
    }
  }
  return (await authService.getCurrent())?.nickname ?? null;
}

async function findHiddenOfficialAd(
  slots: SlotRank[],
): Promise<{ slot: SlotRank; details: Awaited<ReturnType<typeof getOwnAdDetails>> } | null> {
  for (const slot of slots) {
    try {
      const details = await getOwnAdDetails(slot.itemId);
      const state = classifyOfficialAdState(details);
      if (state.hidden) {
        details.hiddenReason = state.reason ?? undefined;
        return { slot, details };
      }
    } catch (err) {
      console.warn(`official ad detail failed (${slot.itemId}):`, err);
    }
  }
  return null;
}

function parseBybitUid(value: string | null | undefined, label: string): number | null {
  if (!value) return null;
  const n = Number(value);
  if (!Number.isSafeInteger(n) || n <= 0) {
    throw new ConfigError(
      `${label} должен быть числовым UID Bybit, сейчас: ${value}. ` +
        `Оставь BYBIT_USER_ID пустым или укажи UID цифрами.`,
    );
  }
  return n;
}

function paramsFromCycle(cycle: AdCycleRow): AdParamsSnapshot {
  return {
    quantity: cycle.quantity,
    quantity_auto: cycle.quantity_auto,
    min_amount: cycle.min_amount,
    max_amount: cycle.max_amount,
    payment_period: cycle.payment_period,
    payment_ids: cycle.payment_ids,
    remark: cycle.remark,
  };
}

function effectiveQuantity(
  params: AdParamsSnapshot,
  price: string,
  label: string,
): string {
  const priceN = Number(price);
  const minF = Number(params.min_amount);
  const maxF = Number(params.max_amount);
  let qty = params.quantity;
  if (params.quantity_auto) {
    if (priceN <= 0) throw new ConfigError(`${label}: Bad price: ${price}`);
    // Округляем вверх, чтобы price × qty гарантированно покрывал max.
    qty = String(Math.ceil(maxF / priceN));
  }
  const qtyN = Number(qty);
  if (!Number.isFinite(qtyN) || qtyN <= 0) {
    throw new ConfigError(`${label}: Bad quantity: ${qty}`);
  }
  const totalFiat = priceN * qtyN;
  if (minF > totalFiat) {
    throw new ConfigError(
      `${label}: min (${minF}) > price × qty (${totalFiat.toFixed(2)}). Уменьши min или увеличь qty в /settings.`,
    );
  }
  if (maxF > totalFiat) {
    throw new ConfigError(
      `${label}: max (${maxF}) > price × qty (${totalFiat.toFixed(2)}). Уменьши max до ≤ ${Math.floor(totalFiat)} или увеличь qty.`,
    );
  }
  return qty;
}

function bestTopHit(ranks: SlotRank[], topN: number): SlotRank | null {
  return (
    ranks
      .filter((s) => s.rank !== null && s.rank <= topN)
      .sort((a, b) => Number(a.rank) - Number(b.rank))[0] ?? null
  );
}

function slotLabel(kind: SlotKind): string {
  return kind === "floating" ? "Floating" : "Fixed";
}

function formatSlotRanks(slots: SlotRank[]): string {
  return slots
    .map((slot) => {
      const place =
        slot.rank !== null ? `№${slot.rank} · стр. ${slot.page}` : "не найден";
      const premium = slot.premium ? ` · premium ${slot.premium}%` : "";
      return `${slotLabel(slot.kind)} ${place} · ${slot.price}${premium}`;
    })
    .join("; ");
}

async function resolveFloatingPlan(input: {
  tokenId: string;
  currencyId: string;
  targetPrice: string;
  premiumMode: "auto" | "manual";
  premiumManual: string;
  label: string;
}): Promise<{
  priceType: "1";
  price: string;
  premium: string;
  useFlexible: true;
}> {
  const ref = await getLastPrice(input.tokenId, input.currencyId);
  const referencePrice = ref.price ?? ref.lastPrice ?? null;
  if (!referencePrice) {
    throw new ConfigError(`${input.label}: Bybit не вернул reference price`);
  }
  const floating =
    input.premiumMode === "manual"
      ? estimateFloatingPrice(referencePrice, input.premiumManual)
      : computeFloatingPremium({
          targetPrice: input.targetPrice,
          referencePrice,
        });
  if (!floating.ok) {
    throw new ConfigError(`${input.label}: ${floating.reason}`);
  }
  return {
    priceType: "1",
    price: floating.estimatedPrice,
    premium: floating.premium,
    useFlexible: true,
  };
}
