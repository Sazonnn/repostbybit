import assert from "node:assert/strict";
import { before, describe, it, type TestContext } from "node:test";
import type { Context } from "grammy";
import type { WorkingAdEvent } from "../web/telemetry.js";

process.env.TELEGRAM_BOT_TOKEN ||= "test-token";
process.env.SQLITE_PATH ||= `/tmp/bybit-working-ads-single-test-${process.pid}.db`;
process.env.BYBIT_API_KEY = "test-key";
process.env.BYBIT_API_SECRET = "test-secret";
const realImmediate = globalThis.setImmediate;

describe("working ad details", () => {
  it("считает floating premium из фактической цены объявления, как bybit_bot_repost", async () => {
    const { computeStableFloatingPlan } = await import(
      "./workingAdsManager.js"
    );
    const plan = computeStableFloatingPlan({
      currentPrice: "75.00",
      currentPremium: "100.00",
      targetPrice: "74.50",
    });
    assert.equal(plan.basePrice, 75);
    assert.equal(plan.premium, "99.33");
    assert.equal(plan.changed, true);
  });

  it("не обновляет floating premium при изменении меньше половины шага округления", async () => {
    const { computeStableFloatingPlan } = await import(
      "./workingAdsManager.js"
    );
    const plan = computeStableFloatingPlan({
      currentPrice: "100.00",
      currentPremium: "100.00",
      targetPrice: "100.004",
    });
    assert.equal(plan.premium, "100.00");
    assert.equal(plan.changed, false);
  });

  it("сохраняет параметры объявления и использует оставшийся объём", async () => {
    const { normalizeWorkingAdDetails } = await import(
      "./workingAdsManager.js"
    );
    const details = normalizeWorkingAdDetails(
      {
        id: "1898988222063644672",
        tokenId: "USDT",
        currencyId: "RUB",
        side: 1,
        priceType: 0,
        price: "75.50",
        premium: "",
        quantity: "100",
        lastQuantity: "80",
        minAmount: "500",
        maxAmount: "1000",
        remark: "original",
        paymentPeriod: 30,
        payments: ["123", "456"],
        tradingPreferenceSet: { isKyc: 1, hasRegisterTime: 0 },
        status: 10,
      },
      "fallback",
    );
    assert.equal(details.quantity, "80");
    assert.equal(details.side, "1");
    assert.equal(details.priceType, "0");
    assert.deepEqual(details.paymentIds, ["123", "456"]);
    assert.deepEqual(details.tradingPreferenceSet, {
      isKyc: "1",
      hasRegisterTime: "0",
    });
    assert.equal(details.online, true);
  });

  it("понимает floating, объектные реквизиты и offline-статус", async () => {
    const { normalizeWorkingAdDetails } = await import(
      "./workingAdsManager.js"
    );
    const details = normalizeWorkingAdDetails(
      {
        itemId: "123456789",
        tokenId: "USDT",
        currencyId: "RUB",
        side: "0",
        priceType: "1",
        price: "75.49",
        premium: "99.99",
        quantity: "100",
        minAmount: "500",
        maxAmount: "1000",
        paymentPeriod: "15",
        payments: [{ id: "payment-account-id" }],
        status: 20,
      },
      "fallback",
    );
    assert.deepEqual(details.paymentIds, ["payment-account-id"]);
    assert.equal(details.priceType, "1");
    assert.equal(details.online, false);
  });

  it("для official API берёт ID реквизита из paymentTerms, а не тип из payments", async () => {
    const { normalizeWorkingAdDetails } = await import(
      "./workingAdsManager.js"
    );
    const details = normalizeWorkingAdDetails(
      {
        itemId: "2068042837788905472",
        tokenId: "USDT",
        currencyId: "RUB",
        side: "0",
        priceType: "1",
        price: "74.63",
        premium: "100.00",
        quantity: "100",
        minAmount: "500",
        maxAmount: "1000",
        paymentPeriod: "15",
        payments: ["21879437"],
        paymentTerms: [
          {
            id: "987654321012345678",
            paymentType: "21879437",
          },
        ],
        status: 10,
      },
      "fallback",
    );
    assert.deepEqual(details.paymentIds, ["987654321012345678"]);
  });
});

async function flush(): Promise<void> {
  await new Promise<void>((resolve) => realImmediate(resolve));
  await new Promise<void>((resolve) => realImmediate(resolve));
}

async function monitorFixture(t: TestContext, floating = false, initialItem: Record<string, unknown> = {}, observe?: (event: WorkingAdEvent) => void) {
  const { db } = await import("../db/pool.js");
  const { ensureSettings, updateSettings } = await import("../db/repositories/userSettings.js");
  const { saveWorkingAd } = await import("../db/repositories/workingAds.js");
  const { WorkingAdsManager } = await import("./workingAdsManager.js");
  db.exec("DELETE FROM working_ads; DELETE FROM working_ad_update_attempts;");
  const chatId = 456;
  await ensureSettings(chatId);
  await updateSettings(chatId, {
    connectionMode: "api", workingAdsEnabled: false, workingAdsIntervalMs: 200,
    workingAdsUpdateIntervalMs: 250,
    priceMode: "auto", priceStep: "0", priceMin: "1", priceMax: "1000",
  });
  await saveWorkingAd({
    chatId, itemId: "123456789", tokenId: "USDT", currencyId: "RUB",
    side: "0", priceType: floating ? "1" : "0", lastPrice: "100.00",
  });
  let market: string | null = "100.00";
  let marketError = 0;
  let item: Record<string, unknown> = {
    id: "123456789", tokenId: "USDT", currencyId: "RUB", side: 0,
    priceType: floating ? 1 : 0, price: "100.00", premium: floating ? "100.00" : "0",
    quantity: "100", lastQuantity: "80", minAmount: "500", maxAmount: "1000",
    remark: "keep", paymentPeriod: "15", paymentIds: ["payment-123"],
    tradingPreferenceSet: { isKyc: "1" }, status: 10,
    ...initialItem,
  };
  const counts = { market: 0, account: 0, details: 0, payments: 0 };
  const writes: Array<Record<string, unknown>> = [];
  const marketTimes: number[] = [];
  const writeTimes: number[] = [];
  const notices: string[] = [];
  const held = new Map<string, { promise: Promise<void>; release: () => void }>();
  const hold = (kind: string) => {
    let release!: () => void;
    const promise = new Promise<void>((resolve) => { release = resolve; });
    held.set(kind, { promise, release });
    return async () => { held.delete(kind); release(); await flush(); };
  };
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (input, init) => {
    const path = new URL(String(input)).pathname;
    const body = JSON.parse(String(init?.body ?? "{}"));
    let result: unknown;
    if (path === "/x-api/fiat/otc/item/online") {
      counts.market++;
      marketTimes.push(Date.now());
      if (marketError) return Response.json({ retCode: marketError, retMsg: "Too many visits!", result: {} });
      result = { count: market ? 1 : 0, items: market ? [{ id: "other-ad", userId: "99", price: market }] : [] };
      await held.get("market")?.promise;
    } else if (path === "/v5/p2p/user/personal/info") {
      counts.account++;
      result = { userId: "42", isOnline: true };
    } else if (path === "/v5/p2p/item/info") {
      counts.details++;
      await held.get("details")?.promise;
      result = item;
    } else if (path === "/v5/p2p/user/payment/list") {
      counts.payments++;
      result = [{ id: "payment-123", paymentType: "14" }];
    } else if (path === "/v5/p2p/item/update") {
      writes.push(body);
      writeTimes.push(Date.now());
      await held.get("update")?.promise;
      item = { ...item, price: body.price, premium: body.premium };
      result = {};
    } else {
      throw new Error(`Unexpected request: ${path}`);
    }
    return Response.json({ retCode: 0, retMsg: "OK", result });
  };
  t.mock.timers.enable({ apis: ["Date", "setTimeout", "setInterval", "setImmediate"], now: 1_800_000_000_000 });
  const manager = new WorkingAdsManager(async (_chatId, text) => {
    notices.push(text);
    await held.get("notification")?.promise;
  }, observe);
  t.after(async () => {
    manager.stopAll();
    for (const entry of held.values()) entry.release();
    held.clear();
    t.mock.timers.tick(3_000);
    await flush();
    t.mock.timers.reset();
    globalThis.fetch = originalFetch;
  });
  await manager.setEnabled(chatId, true);
  t.mock.timers.tick(0);
  await flush();
  return {
    manager, counts, writes, notices, marketTimes, writeTimes, chatId,
    setMarket(value: string | null) { market = value; },
    setMarketError(value: number) { marketError = value; },
    setItem(patch: Record<string, unknown>) { item = { ...item, ...patch }; },
    holdDetails: () => hold("details"),
    holdMarket: () => hold("market"),
    holdUpdate: () => hold("update"),
    holdNotification: () => hold("notification"),
    async advance(ms: number) { t.mock.timers.tick(ms); await flush(); },
  };
}

describe("fast working-ad monitor", () => {
  before(async () => {
    const { runMigrations } = await import("../db/migrate.js");
    await runMigrations();
  });

  it("ошибка наблюдателя веб-панели не прерывает мониторинг и отправку цены", async (t) => {
    const events: WorkingAdEvent[] = [];
    const f = await monitorFixture(t, false, {}, event => { events.push(event); throw new Error("observer failed"); });
    f.setMarket("101.00");
    await f.advance(200);
    assert.equal(f.writes.length, 1);
    assert.equal(f.writes[0]?.price, "101.00");
    assert.ok(events.some(e => e.kind === "market" && e.chatId === f.chatId));
    assert.ok(events.some(e => e.kind === "update" && e.sample.price === "101.00"));
    assert.equal(f.notices.length, 0);
  });

  it("проверяет рынок каждые 200 мс без повторного чтения аккаунта и объявления", async (t) => {
    const f = await monitorFixture(t);
    for (let i = 0; i < 5; i++) await f.advance(200);
    assert.equal(f.counts.market, 6);
    assert.equal(f.counts.account, 1);
    assert.equal(f.counts.details, 1);
    assert.equal(f.writes.length, 0);
  });

  it("после медленного ответа рынка не ждёт следующего тика и не создаёт параллельных запросов", async (t) => {
    const f = await monitorFixture(t);
    const start = Date.now();
    const release = f.holdMarket();
    await f.advance(200);
    await f.advance(250);
    assert.deepEqual(f.marketTimes.map(time => time - start), [0, 200]);
    await release();
    await f.advance(0);
    assert.deepEqual(f.marketTimes.map(time => time - start), [0, 200, 450]);
    await f.advance(199);
    assert.equal(f.counts.market, 3);
    await f.advance(1);
    assert.equal(f.counts.market, 4);
  });

  it("отправляет уже замеченный новый курс сразу после завершения предыдущей записи", async (t) => {
    const f = await monitorFixture(t);
    await f.manager.setUpdateIntervalSeconds(f.chatId, 0.01);
    const start = Date.now();
    const release = f.holdUpdate();
    f.setMarket("101.00");
    await f.advance(200);
    f.setMarket("102.00");
    await f.advance(200);
    assert.equal(f.writes.length, 1);
    await f.advance(50);
    await release();
    assert.deepEqual(f.writeTimes.map(time => time - start), [200, 450]);
    assert.deepEqual(f.writes.map(body => body.price), ["101.00", "102.00"]);
    assert.deepEqual(f.marketTimes.map(time => time - start), [0, 200, 400]);
    assert.equal(f.counts.payments, 0);
    await f.advance(150);
    assert.equal(f.writes.length, 2);
  });

  it("не отправляет следующий курс после отключения во время уже отправленной записи", async (t) => {
    const f = await monitorFixture(t);
    const release = f.holdUpdate();
    f.setMarket("101.00");
    await f.advance(200);
    f.setMarket("102.00");
    await f.advance(200);
    await f.manager.setEnabled(f.chatId, false);
    await release();
    await f.advance(1_000);
    assert.equal(f.writes.length, 1);
  });

  it("не задерживает мониторинг повторной проверкой неизменного UID через минуту", async (t) => {
    const f = await monitorFixture(t);
    await f.advance(60_200);
    assert.equal(f.counts.account, 1);
    assert.equal(f.counts.market, 2);
  });

  it("не переписывает состояние в SQLite на каждом тике неизменного рынка", async (t) => {
    const f = await monitorFixture(t);
    const { db } = await import("../db/pool.js");
    const changes = () => db.prepare("SELECT total_changes() AS n").get()!.n;
    const before = changes();
    for (let i = 0; i < 5; i++) await f.advance(200);
    assert.equal(changes(), before);
    assert.equal(f.counts.market, 6);
  });

  it("заранее сопоставляет старый формат реквизитов и использует кэш при смене цены", async (t) => {
    const f = await monitorFixture(t, false, { paymentIds: undefined, payments: ["14"] });
    assert.equal(f.counts.payments, 1);
    f.setMarket("101.00");
    await f.advance(200);
    assert.equal(f.writes.length, 1);
    assert.deepEqual(f.writes[0]!.paymentIds, ["payment-123"]);
    assert.equal(f.counts.payments, 1);
    assert.equal(f.counts.details, 2);
    await f.advance(60_000);
    assert.equal(f.counts.payments, 2);
  });

  it("медленная отправка ошибки в Telegram не блокирует возобновление мониторинга", async (t) => {
    const f = await monitorFixture(t);
    const release = f.holdNotification();
    f.setMarketError(10006);
    await f.advance(200);
    assert.equal(f.notices.length, 1);
    f.setMarketError(0);
    f.setMarket("101.00");
    await f.advance(10_000);
    assert.equal(f.counts.market, 3);
    assert.equal(f.writes.length, 1);
    await release();
  });

  it("пишет одну короткую строку с измеренными задержками без тела объявления", async (t) => {
    const f = await monitorFixture(t);
    const log = t.mock.method(console, "log", () => {});
    const releaseDetails = f.holdDetails();
    const releaseUpdate = f.holdUpdate();
    f.setMarket("101.00");
    await f.advance(200);
    await f.advance(50);
    await releaseDetails();
    await f.advance(50);
    await releaseUpdate();
    const lines = log.mock.calls.map(call => String(call.arguments[0]));
    assert.equal(lines.length, 1);
    assert.match(lines[0]!, /market_ms=0 prepare_ms=50 seen_to_send_ms=50 api_ms=50 result=api_ok$/);
    assert.doesNotMatch(lines[0]!, /test-secret|test-key|payment-123|remark|keep/);
  });

  it("продолжает мониторинг во время подтверждения floating и не дублирует запись", async (t) => {
    const f = await monitorFixture(t, true);
    f.setMarket("101.00");
    await f.advance(200);
    assert.equal(f.writes.length, 1);
    f.setMarket("102.00");
    for (let i = 0; i < 3; i++) await f.advance(200);
    assert.equal(f.writes.length, 1);
    assert.ok(f.counts.market >= 4);
    for (let i = 0; i < 4; i++) await f.advance(200);
    assert.equal(f.writes.length, 2);
    assert.equal(f.writes[1]!.price, "102.00");
  });

  it("использует последнюю цену и свежий остаток после медленного чтения объявления", async (t) => {
    const f = await monitorFixture(t);
    const release = f.holdDetails();
    f.setMarket("101.00");
    await f.advance(200);
    f.setMarket("103.00");
    f.setItem({ lastQuantity: "67" });
    await f.advance(200);
    assert.equal(f.writes.length, 0);
    await release();
    assert.equal(f.writes.length, 1);
    assert.equal(f.writes[0]!.price, "103.00");
    assert.equal(f.writes[0]!.quantity, "67");
  });

  it("не пишет по устаревшей цене, если рынок опустел", async (t) => {
    const f = await monitorFixture(t);
    const release = f.holdDetails();
    f.setMarket("101.00");
    await f.advance(200);
    f.setMarket(null);
    await f.advance(200);
    await release();
    assert.equal(f.writes.length, 0);
  });

  it("не отправляет отложенное изменение после выключения автокурса", async (t) => {
    const f = await monitorFixture(t);
    const release = f.holdDetails();
    f.setMarket("101.00");
    await f.advance(200);
    await f.manager.setEnabled(f.chatId, false);
    await release();
    assert.equal(f.writes.length, 0);
  });

  it("смена интервала во время запроса не создаёт второго писателя", async (t) => {
    const f = await monitorFixture(t, true);
    const release = f.holdDetails();
    f.setMarket("101.00");
    await f.advance(200);
    await f.manager.setIntervalSeconds(f.chatId, 0.1);
    await f.advance(200);
    assert.equal(f.writes.length, 0);
    await release();
    for (let i = 0; i < 5; i++) await f.advance(200);
    assert.equal(f.writes.length, 1);
  });

  it("перечитывает условия после изменения настроек и не отправляет старую цену", async (t) => {
    const f = await monitorFixture(t);
    const release = f.holdDetails();
    f.setMarket("101.00");
    await f.advance(200);
    const { updateSettings } = await import("../db/repositories/userSettings.js");
    await updateSettings(f.chatId, { priceMax: "100" });
    await release();
    assert.equal(f.writes.length, 0);
    await f.advance(200);
    assert.equal(f.writes.length, 0);
  });

  it("после освобождения лимита выбирает новую цену, а не очередь старых", async (t) => {
    const f = await monitorFixture(t);
    const { reserveWorkingAdUpdate } = await import("../db/repositories/workingAdUpdateAttempts.js");
    for (let i = 0; i < 10; i++) reserveWorkingAdUpdate("123456789", Date.now() - 10_000 + i * 1_000);
    f.setMarket("101.00");
    await f.advance(200);
    assert.equal(f.writes.length, 0);
    const count = f.counts.market;
    f.setMarket("102.00");
    await f.advance(200);
    assert.ok(f.counts.market > count);
    assert.equal(f.writes.length, 0);
    f.setMarket("105.00");
    await f.advance(300_000);
    assert.equal(f.writes.length, 1);
    assert.equal(f.writes[0]!.price, "105.00");
  });

  it("миграции сохраняют настройки и интервал при повторном запуске", async (t) => {
    const f = await monitorFixture(t);
    const { runMigrations } = await import("../db/migrate.js");
    const { ensureSettings } = await import("../db/repositories/userSettings.js");
    const beforeSettings = await ensureSettings(f.chatId);
    await runMigrations();
    assert.deepEqual(await ensureSettings(f.chatId), beforeSettings);
  });

  it("не догоняет пропущенные тики и ограничивает частоту при настройке 0,01", async (t) => {
    const f = await monitorFixture(t);
    await f.manager.setIntervalSeconds(f.chatId, 0.01);
    for (let i = 0; i < 100; i++) await f.advance(10);
    for (let i = 1; i < f.marketTimes.length; i++) {
      assert.ok(f.marketTimes[i]! - f.marketTimes[i - 1]! >= 125);
    }
    assert.ok(f.counts.market <= 9);
  });

  it("делает паузу после 10006 и не повторяет запрос каждый тик", async (t) => {
    const f = await monitorFixture(t);
    f.setMarketError(10006);
    await f.advance(200);
    const count = f.counts.market;
    for (let i = 0; i < 20; i++) await f.advance(200);
    assert.equal(f.counts.market, count);
    assert.equal(f.notices.length, 1);
  });

  it("ограничивает попытки записи в скользящем окне, сохраняя историю в БД", async () => {
    const { db } = await import("../db/pool.js");
    const { reserveWorkingAdUpdate, WorkingAdUpdateDeferred } = await import("../db/repositories/workingAdUpdateAttempts.js");
    db.exec("DELETE FROM working_ad_update_attempts;");
    const now = Date.now();
    for (let i = 0; i < 10; i++) reserveWorkingAdUpdate("limited-item", now + i * 1_000);
    assert.throws(() => reserveWorkingAdUpdate("limited-item", now + 10_000), WorkingAdUpdateDeferred);
    const { DatabaseSync } = await import("node:sqlite");
    const second = new DatabaseSync(process.env.SQLITE_PATH!);
    try {
      assert.equal(second.prepare("SELECT COUNT(*) AS n FROM working_ad_update_attempts").get()!.n, 10);
    } finally { second.close(); }
    assert.throws(() => reserveWorkingAdUpdate("limited-item", now + 299_999), WorkingAdUpdateDeferred);
    reserveWorkingAdUpdate("limited-item", now + 300_000);
    assert.throws(() => reserveWorkingAdUpdate("another-item", now + 300_001), WorkingAdUpdateDeferred);
    reserveWorkingAdUpdate("another-item", now + 300_010);
  });

  it("при минимуме 0,01 отправляет следующую цену раньше прежних 250 мс", async (t) => {
    const f = await monitorFixture(t);
    await f.manager.setUpdateIntervalSeconds(f.chatId, 0.01);
    await f.manager.setIntervalSeconds(f.chatId, 0.125);
    f.setMarket("101.00");
    await f.advance(125);
    assert.equal(f.writes.length, 1);
    f.setMarket("102.00");
    await f.advance(125);
    assert.equal(f.writes.length, 2);
    assert.equal(f.writeTimes[1]! - f.writeTimes[0]!, 125);
    assert.equal(f.notices.length, 0);
  });

  it("соблюдает границу 10 мс без скрытого минимума 250 мс", async () => {
    const { db } = await import("../db/pool.js");
    const { reserveWorkingAdUpdate, WorkingAdUpdateDeferred } = await import("../db/repositories/workingAdUpdateAttempts.js");
    db.exec("DELETE FROM working_ad_update_attempts;");
    const now = Date.now();
    for (const invalid of [NaN, Infinity, -1, 0, 9, 10.5, 86_400_001]) {
      assert.throws(() => reserveWorkingAdUpdate("minimum", now, invalid), /от 0,01/);
    }
    reserveWorkingAdUpdate("minimum", now, 10);
    assert.throws(() => reserveWorkingAdUpdate("minimum", now + 9, 10),
      (error: unknown) => error instanceof WorkingAdUpdateDeferred && error.retryAt === now + 10);
    reserveWorkingAdUpdate("minimum", now + 10, 10);
    reserveWorkingAdUpdate("minimum", now + 20, 10);
    assert.equal(db.prepare("SELECT COUNT(*) AS n FROM working_ad_update_attempts").get()!.n, 3);
  });

  it("при интервале 10 мс сохраняет общий предел четырёх попыток за скользящую секунду", async () => {
    const { db } = await import("../db/pool.js");
    const { reserveWorkingAdUpdate, WorkingAdUpdateDeferred } = await import("../db/repositories/workingAdUpdateAttempts.js");
    db.exec("DELETE FROM working_ad_update_attempts;");
    const now = Date.now();
    for (let i = 0; i < 4; i++) reserveWorkingAdUpdate(`burst-${i}`, now + i * 10, 10);
    for (const delay of [40, 999]) {
      assert.throws(() => reserveWorkingAdUpdate("next", now + delay, 10),
        (error: unknown) => error instanceof WorkingAdUpdateDeferred && error.retryAt === now + 1_000);
    }
    assert.equal(db.prepare("SELECT COUNT(*) AS n FROM working_ad_update_attempts").get()!.n, 4);
    reserveWorkingAdUpdate("next", now + 1_000, 10);
    assert.throws(() => reserveWorkingAdUpdate("next", now + 1_009, 10),
      (error: unknown) => error instanceof WorkingAdUpdateDeferred && error.retryAt === now + 1_010);
    reserveWorkingAdUpdate("next", now + 1_010, 10);
  });

  it("редактирует fixed не чаще заданного интервала, продолжая мониторинг", async (t) => {
    const f = await monitorFixture(t);
    await f.manager.setUpdateIntervalSeconds(f.chatId, 3);
    f.setMarket("101.00");
    await f.advance(200);
    assert.equal(f.writes.length, 1);
    f.setMarket("102.00");
    for (let i = 0; i < 14; i++) await f.advance(200);
    assert.equal(f.writes.length, 1);
    assert.ok(f.counts.market >= 16);
    f.setMarket("105.00");
    await f.advance(200);
    assert.equal(f.writes.length, 2);
    assert.equal(f.writes[1]!.price, "105.00");
    assert.equal(f.writeTimes[1]! - f.writeTimes[0]!, 3_000);
    assert.equal(f.notices.length, 0);
  });

  it("соблюдает отдельный интервал для floating после подтверждения premium", async (t) => {
    const f = await monitorFixture(t, true);
    await f.manager.setUpdateIntervalSeconds(f.chatId, 4);
    f.setMarket("101.00");
    await f.advance(200);
    f.setMarket("102.00");
    for (let i = 0; i < 19; i++) await f.advance(200);
    assert.equal(f.writes.length, 1);
    await f.advance(200);
    assert.equal(f.writes.length, 2);
    assert.equal(f.writeTimes[1]! - f.writeTimes[0]!, 4_000);
    assert.equal(f.writes[1]!.premium, "102.00");
  });

  it("сокращает ожидание при уменьшении интервала без перезапуска мониторинга", async (t) => {
    const f = await monitorFixture(t);
    await f.manager.setUpdateIntervalSeconds(f.chatId, 30);
    f.setMarket("101.00");
    await f.advance(200);
    f.setMarket("102.00");
    await f.advance(200);
    await f.manager.setUpdateIntervalSeconds(f.chatId, 1);
    for (let i = 0; i < 4; i++) await f.advance(200);
    assert.equal(f.writes.length, 2);
    assert.equal(f.writeTimes[1]! - f.writeTimes[0]!, 1_000);
    assert.equal(f.counts.account, 1);
  });

  it("учитывает увеличение интервала во время чтения параметров объявления", async (t) => {
    const f = await monitorFixture(t);
    f.setMarket("101.00");
    await f.advance(200);
    const release = f.holdDetails();
    f.setMarket("102.00");
    await f.advance(200);
    await f.manager.setUpdateIntervalSeconds(f.chatId, 30);
    await f.advance(200);
    await release();
    for (let i = 0; i < 10; i++) await f.advance(200);
    assert.equal(f.writes.length, 1);
  });

  it("Обновить сейчас не обходит интервал редактирования и сообщает об ожидании", async (t) => {
    const f = await monitorFixture(t);
    await f.manager.setUpdateIntervalSeconds(f.chatId, 30);
    f.setMarket("101.00");
    await f.advance(200);
    f.setMarket("102.00");
    await f.advance(200);
    const { buildWorkingAdsHandlers } = await import("../bot/workingAdsHandlers.js");
    const handlers = buildWorkingAdsHandlers(f.manager);
    const replies: string[] = [];
    const context = {
      chat: { id: f.chatId }, callbackQuery: { data: "wa:sync" },
      answerCallbackQuery: async () => {},
      reply: async (text: string) => { replies.push(text); },
    } as unknown as Context;
    const completion = handlers.callback(context);
    await flush();
    await f.advance(200);
    await completion;
    assert.equal(f.writes.length, 1);
    assert.ok(replies.some((text) => text.includes("ожидание интервала или лимита")));
    assert.ok(!replies.some((text) => text.includes("цены уже актуальны")));
  });

  it("новый экземпляр менеджера сохраняет интервал и время последней попытки", async (t) => {
    const f = await monitorFixture(t);
    await f.manager.setUpdateIntervalSeconds(f.chatId, 3);
    f.setMarket("101.00");
    await f.advance(200);
    f.manager.stopAll();
    const { WorkingAdsManager } = await import("./workingAdsManager.js");
    const manager = new WorkingAdsManager(async () => {});
    t.after(() => manager.stopAll());
    await manager.resumeAll();
    f.setMarket("102.00");
    for (let i = 0; i < 14; i++) await f.advance(200);
    assert.equal(f.writes.length, 1);
    await f.advance(200);
    assert.equal(f.writes.length, 2);
    assert.equal(f.writeTimes[1]! - f.writeTimes[0]!, 3_000);
  });

  it("кнопки мониторинга и редактирования сохраняют разные значения с запятой", async (t) => {
    const f = await monitorFixture(t);
    const { ensureSettings } = await import("../db/repositories/userSettings.js");
    const { buildWorkingAdsHandlers } = await import("../bot/workingAdsHandlers.js");
    const handlers = buildWorkingAdsHandlers(f.manager);
    t.after(() => { handlers.cancelInput(f.chatId); });
    const replies: Array<{ text: string; options?: { reply_markup?: { inline_keyboard: Array<Array<{ text: string; callback_data?: string }>> } } }> = [];
    const context = (data?: string, text?: string) => ({
      chat: { id: f.chatId }, callbackQuery: data ? { data } : undefined,
      message: text ? { text } : undefined,
      answerCallbackQuery: async () => {},
      reply: async (text: string, options?: typeof replies[number]["options"]) => { replies.push({ text, options }); },
    } as unknown as Context);
    await handlers.show(context());
    const buttons = replies.at(-1)!.options!.reply_markup!.inline_keyboard.flat();
    assert.ok(buttons.some((b) => b.callback_data === "wa:interval" && b.text.includes("мониторинга")));
    assert.ok(buttons.some((b) => b.callback_data === "wa:update_interval" && b.text.includes("редактирования")));
    await handlers.callback(context("wa:update_interval"));
    assert.equal(await handlers.consumeInput(context(undefined, "0,75")), true);
    let settings = await ensureSettings(f.chatId);
    assert.equal(settings.working_ads_interval_ms, 200);
    assert.equal(settings.working_ads_update_interval_ms, 750);
    await handlers.callback(context("wa:interval"));
    assert.equal(await handlers.consumeInput(context(undefined, "0,5")), true);
    settings = await ensureSettings(f.chatId);
    assert.equal(settings.working_ads_interval_ms, 500);
    assert.equal(settings.working_ads_update_interval_ms, 750);
    await handlers.callback(context("wa:update_interval"));
    await handlers.consumeInput(context(undefined, "0,009"));
    assert.match(replies.at(-1)!.text, /от 0,01/);
    assert.equal((await ensureSettings(f.chatId)).working_ads_update_interval_ms, 750);
    assert.equal(await handlers.consumeInput(context(undefined, "0,01")), true);
    assert.match(replies.at(-1)!.text, /Мин\. интервал редактирования: <b>0,01 сек<\/b>/);
    settings = await ensureSettings(f.chatId);
    assert.equal(settings.working_ads_update_interval_ms, 10);
    assert.equal(settings.working_ads_interval_ms, 500);
    await handlers.callback(context("wa:update_interval"));
    assert.equal(await handlers.consumeInput(context(undefined, "0.01")), true);
    assert.equal((await ensureSettings(f.chatId)).working_ads_update_interval_ms, 10);
  });

  it("проверяет диапазон редактирования отдельно от диапазона мониторинга", async (t) => {
    const f = await monitorFixture(t);
    for (const invalid of [NaN, Infinity, -1, 0, 0.009, 86_400.001]) {
      await assert.rejects(f.manager.setUpdateIntervalSeconds(f.chatId, invalid), /от 0,01/);
    }
    await f.manager.setUpdateIntervalSeconds(f.chatId, 86_400);
    const { ensureSettings } = await import("../db/repositories/userSettings.js");
    const saved = await ensureSettings(f.chatId);
    assert.equal(saved.working_ads_update_interval_ms, 86_400_000);
    assert.equal(saved.working_ads_interval_ms, 200);
  });

  it("сохраняет интервалы длиннее пяти минут при очистке истории запросов", async () => {
    const { db } = await import("../db/pool.js");
    const { reserveWorkingAdUpdate, WorkingAdUpdateDeferred } = await import("../db/repositories/workingAdUpdateAttempts.js");
    db.exec("DELETE FROM working_ad_update_attempts;");
    const now = Date.now();
    reserveWorkingAdUpdate("long-interval", now, 600_000);
    reserveWorkingAdUpdate("another-item", now + 300_001);
    assert.throws(() => reserveWorkingAdUpdate("long-interval", now + 599_999, 600_000),
      (error: unknown) => error instanceof WorkingAdUpdateDeferred && error.retryAt === now + 600_000);
    reserveWorkingAdUpdate("long-interval", now + 600_000, 600_000);
    reserveWorkingAdUpdate("day-interval", now + 600_250, 86_400_000);
    assert.throws(() => reserveWorkingAdUpdate("day-interval", now + 600_250 + 86_399_999, 86_400_000), WorkingAdUpdateDeferred);
    reserveWorkingAdUpdate("day-interval", now + 600_250 + 86_400_000, 86_400_000);
  });

  it("интервал редактирования применяется к каждому объявлению отдельно", async () => {
    const { db } = await import("../db/pool.js");
    const { reserveWorkingAdUpdate, WorkingAdUpdateDeferred } = await import("../db/repositories/workingAdUpdateAttempts.js");
    db.exec("DELETE FROM working_ad_update_attempts;");
    const now = Date.now();
    reserveWorkingAdUpdate("first", now, 30_000);
    reserveWorkingAdUpdate("second", now + 250, 30_000);
    assert.throws(() => reserveWorkingAdUpdate("first", now + 500, 30_000), WorkingAdUpdateDeferred);
    reserveWorkingAdUpdate("first", now + 30_000, 30_000);
  });

  it("миграция нового интервала не изменяет настройки и счётчик предыдущей версии", async () => {
    const { DatabaseSync } = await import("node:sqlite");
    const { readdir, readFile } = await import("node:fs/promises");
    const directory = new URL("../db/migrations/", import.meta.url);
    const database = new DatabaseSync(":memory:");
    try {
      const files = (await readdir(directory)).filter((file) => file.endsWith(".sql")).sort();
      for (const file of files.filter((file) => file < "017_")) {
        database.exec(await readFile(new URL(file, directory), "utf8"));
      }
      database.prepare("INSERT INTO user_settings (chat_id, working_ads_interval_ms, price_step) VALUES (777, 200, '0.07')").run();
      database.prepare("INSERT INTO working_ad_update_attempts (item_id, sent_at_ms) VALUES ('preserved', 1234)").run();
      const previous = database.prepare("SELECT * FROM user_settings WHERE chat_id = 777").get()!;
      database.exec(await readFile(new URL("017_working_ads_update_interval.sql", directory), "utf8"));
      const { working_ads_update_interval_ms, ...remaining } = database.prepare("SELECT * FROM user_settings WHERE chat_id = 777").get()!;
      assert.equal(working_ads_update_interval_ms, 250);
      assert.deepEqual(remaining, { ...previous });
      assert.equal(database.prepare("SELECT sent_at_ms FROM working_ad_update_attempts WHERE item_id = 'preserved'").get()!.sent_at_ms, 1234);
    } finally { database.close(); }
  });

  it("миграция 018 разрешает минимум 10 мс и сохраняет прежние данные и значение по умолчанию", async () => {
    const { DatabaseSync } = await import("node:sqlite");
    const { readdir, readFile } = await import("node:fs/promises");
    const directory = new URL("../db/migrations/", import.meta.url);
    const database = new DatabaseSync(":memory:");
    try {
      const files = (await readdir(directory)).filter((file) => file.endsWith(".sql")).sort();
      for (const file of files.filter((file) => file < "018_")) {
        database.exec(await readFile(new URL(file, directory), "utf8"));
      }
      database.prepare("INSERT INTO user_settings (chat_id, working_ads_interval_ms, working_ads_update_interval_ms, price_step) VALUES (777, 200, 750, '0.07'), (778, 500, 30000, '0.02')").run();
      database.prepare("INSERT INTO working_ad_update_attempts (item_id, sent_at_ms) VALUES ('preserved', 1234)").run();
      const previous = database.prepare("SELECT * FROM user_settings ORDER BY chat_id").all();
      assert.throws(() => database.prepare("UPDATE user_settings SET working_ads_update_interval_ms = 10 WHERE chat_id = 777").run(), /CHECK constraint failed/);
      database.exec("BEGIN");
      database.exec(await readFile(new URL("018_working_ads_update_interval_min.sql", directory), "utf8"));
      database.exec("COMMIT");
      assert.deepEqual(database.prepare("SELECT * FROM user_settings ORDER BY chat_id").all(), previous);
      assert.equal(database.prepare("SELECT sent_at_ms FROM working_ad_update_attempts WHERE item_id = 'preserved'").get()!.sent_at_ms, 1234);
      database.prepare("UPDATE user_settings SET working_ads_update_interval_ms = 10 WHERE chat_id = 777").run();
      assert.equal(database.prepare("SELECT working_ads_update_interval_ms AS ms FROM user_settings WHERE chat_id = 777").get()!.ms, 10);
      for (const invalid of [9, 86_400_001]) {
        assert.throws(() => database.prepare("UPDATE user_settings SET working_ads_update_interval_ms = ? WHERE chat_id = 777").run(invalid), /CHECK constraint failed/);
      }
      database.prepare("INSERT INTO user_settings (chat_id) VALUES (779)").run();
      assert.equal(database.prepare("SELECT working_ads_update_interval_ms AS ms FROM user_settings WHERE chat_id = 779").get()!.ms, 250);
      assert.equal(database.prepare("PRAGMA integrity_check").get()!.integrity_check, "ok");
    } finally { database.close(); }
  });
});
