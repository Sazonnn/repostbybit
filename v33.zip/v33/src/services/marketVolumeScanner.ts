import { existsSync, readFileSync } from "node:fs";
import { appendFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import type { OnlineItem, OnlineListResult } from "../bybit/listing.js";

/**
 * Замер объёма рынка: периодически читает ВЕСЬ стакан и по приросту поля
 * "исполнено" у каждого объявления считает, сколько USDT прошло завершёнными
 * сделками и по какой цене. Отменённые сделки не увеличивают "исполнено",
 * поэтому в расчёт не попадают. В SUMMARY_MINUTE минут каждого часа пишет
 * итог за последний час: объём, средневзвешенную цену сделок и сравнение с
 * эталоном, топ-1 и максимумом стакана.
 */

export interface MarketReferenceMeasure {
  ref: number | null;
  top1: number | null;
  best: number | null;
}

export interface ScanContext {
  tokenId: string;
  currencyId: string;
  side: "0" | "1";
  fetchPage: (page: number, size: number) => Promise<OnlineListResult>;
  reference: () => MarketReferenceMeasure;
  // Разведчик сейчас работает (берёт топ-1, поднимается, только что менял
  // цену) — сканер в это время не делает запросов.
  isScoutActive: () => boolean;
  // Отправить сообщение в чат(ы) бота (HTML-разметка).
  notify: (text: string) => void;
}

interface ModelPoint {
  at: number;
  // Новый максимум / средняя цена сделок прошлого часа.
  kVwap: number;
  // Новый максимум / эталон перед сменой.
  kRef: number | null;
}

interface Snapshot {
  executed: number;
  price: number;
  missed: number;
}

interface Trade {
  at: number;
  volume: number;
  price: number;
  nick: string;
}

const SCAN_INTERVAL_MS = 180_000;
// Между страницами сканера: при общем чтении стакана раз в ~0,55 с это не
// больше одного запроса из четырёх — остальное остаётся автокурсу.
const PAGE_GAP_MS = 2_200;
// Тихое окно вокруг смены курса: с 18:00 до 35:00 каждого часа замеры не
// делают ни одного запроса к стакану, чтобы весь лимит чтения шёл паре
// объявлений и не было отказов 10006 перед сменой курса.
const QUIET_FROM_SEC = 18 * 60;
const QUIET_TO_SEC = 35 * 60;
// Во сколько записать максимум, установившийся после смены курса (после
// окна: к этому времени замер эталона успеет обновиться).
const AFTER_MINUTE = 36;
const WAIT_ACTIVE_MAX_MS = 60_000;
const MAX_PAGES = 60;
const SUMMARY_MINUTE = 25;
const HOUR_MS = 3_600_000;
const KEEP_TRADES_MS = 2 * HOUR_MS;
const SIZE_CANDIDATES = [300, 100, 50, 20];
const SUMMARY_FILE = resolve(process.cwd(), "data", "market-volume.csv");
const AFTER_FILE = resolve(process.cwd(), "data", "market-ceiling.csv");
const MODEL_FILE = resolve(process.cwd(), "data", "ceiling-model.json");
// Сколько последних смен курса учитывать в коэффициенте.
const MODEL_POINTS = 10;

function secondOfHour(at: number): number {
  const d = new Date(at);
  return d.getMinutes() * 60 + d.getSeconds();
}

/** Окно смены курса: здесь замеры не делают запросов к стакану. */
export function inRateChangeWindow(at = Date.now()): boolean {
  const sec = secondOfHour(at);
  return sec >= QUIET_FROM_SEC && sec < QUIET_TO_SEC;
}

function hourKey(at: number): string {
  const d = new Date(at);
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}-${d.getHours()}`;
}

function sleep(ms: number): Promise<void> {
  return new Promise((done) => setTimeout(done, ms));
}

function hhmm(at: number): string {
  const d = new Date(at);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

function volumeText(value: number): string {
  return Math.round(value).toLocaleString("ru-RU");
}

function executedOf(item: OnlineItem): number | null {
  if (item.executedQuantity === undefined || item.executedQuantity === null) return null;
  const value = Number(item.executedQuantity);
  return Number.isFinite(value) && value >= 0 ? value : null;
}

export class MarketVolumeScanner {
  private running = false;
  private lastScanAt = 0;
  private pageSize: number | null = null;
  private readonly snapshot = new Map<string, Snapshot>();
  private trades: Trade[] = [];
  private baselineAt = 0;
  private lastSummaryKey = "";
  private fieldWarned = false;
  private marketKey = "";
  // Средняя и эталон из последнего итога — для замера после смены курса.
  private lastSummary: {
    key: string; vwap: number | null; ref: number | null; best: number | null; partial: boolean;
  } | null = null;
  private history: ModelPoint[] | null = null;

  private loadHistory(): ModelPoint[] {
    if (this.history) return this.history;
    try {
      const parsed = JSON.parse(readFileSync(MODEL_FILE, "utf8")) as ModelPoint[];
      this.history = Array.isArray(parsed) ? parsed.filter((p) => Number.isFinite(p.kVwap)) : [];
    } catch {
      this.history = [];
    }
    return this.history;
  }

  private saveHistory(): void {
    const history = this.loadHistory().slice(-50);
    this.history = history;
    void writeFile(MODEL_FILE, JSON.stringify(history, null, 1), "utf8")
      .catch((error: unknown) => console.warn(`[market-volume] не записал модель: ${(error as Error).message}`));
  }

  /** Медиана коэффициента и разброс (макс. отклонение от медианы) по последним сменам. */
  private static coefficient(values: number[]): { k: number; spread: number; n: number } | null {
    const list = values.filter((v) => Number.isFinite(v) && v > 0).slice(-MODEL_POINTS);
    if (list.length === 0) return null;
    const sorted = [...list].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    const k = sorted.length % 2 ? sorted[mid]! : (sorted[mid - 1]! + sorted[mid]!) / 2;
    const spread = Math.max(...list.map((v) => Math.abs(v - k)));
    return { k, spread, n: list.length };
  }
  private lastAfterKey = "";

  maybeRun(ctx: ScanContext): void {
    const now = Date.now();
    this.maybeSummarize(ctx, now);
    this.maybeAfter(ctx, now);
    if (this.running || inRateChangeWindow(now) || ctx.isScoutActive()) return;
    if (now - this.lastScanAt < SCAN_INTERVAL_MS) return;
    this.running = true;
    this.lastScanAt = now;
    void this.scan(ctx)
      .catch((error: unknown) => console.warn(`[market-scan] пропуск: ${(error as Error).message}`))
      .finally(() => {
        this.running = false;
      });
  }

  /** Ждём, пока можно делать запрос. false — проход надо прервать. */
  private async mayRequest(ctx: ScanContext): Promise<boolean> {
    const startedAt = Date.now();
    for (;;) {
      if (inRateChangeWindow()) return false;
      if (!ctx.isScoutActive()) return true;
      if (Date.now() - startedAt > WAIT_ACTIVE_MAX_MS) return false;
      await sleep(500);
    }
  }

  private async scan(ctx: ScanContext): Promise<void> {
    const key = `${ctx.tokenId}|${ctx.currencyId}|${ctx.side}`;
    if (key !== this.marketKey) {
      this.marketKey = key;
      this.snapshot.clear();
      this.trades = [];
      this.baselineAt = 0;
      this.pageSize = null;
    }
    const scanStartedAt = Date.now();

    // Подбираем максимальный размер страницы, который отдаёт Bybit.
    let size = this.pageSize;
    let firstPage: OnlineListResult | null = null;
    if (size === null) {
      for (const candidate of SIZE_CANDIDATES) {
        if (!(await this.mayRequest(ctx))) {
          console.log("[market-scan] проход отложен: окно смены курса или разведчик работает");
          return;
        }
        try {
          const result = await ctx.fetchPage(1, candidate);
          const got = result.items?.length ?? 0;
          const count = typeof result.count === "number" ? result.count : null;
          if (got === candidate || (count !== null && got >= Math.min(candidate, count))) {
            size = candidate;
            firstPage = result;
            break;
          }
        } catch {
          // Такой размер не принят — пробуем меньше.
        }
        await sleep(PAGE_GAP_MS);
      }
      if (size === null) throw new Error("не удалось подобрать размер страницы стакана");
      this.pageSize = size;
      console.log(`[market-scan] размер страницы стакана: ${size}`);
    }

    const seen = new Map<string, OnlineItem>();
    let total: number | null = null;
    let page = 1;
    let interrupted = false;
    for (;;) {
      if (!(page === 1 && firstPage) && !(await this.mayRequest(ctx))) {
        interrupted = true;
        break;
      }
      const result = page === 1 && firstPage ? firstPage : await ctx.fetchPage(page, size);
      const items = result.items ?? [];
      if (typeof result.count === "number") total = result.count;
      for (const item of items) {
        const id = String(item.id ?? item.itemId ?? "");
        if (id) seen.set(id, item);
      }
      if (items.length < size || page >= MAX_PAGES || (total !== null && page * size >= total)) break;
      page += 1;
      await sleep(PAGE_GAP_MS);
    }

    const now = Date.now();
    const isBaseline = this.baselineAt === 0;
    let withField = 0;
    let scanVolume = 0;
    let scanValue = 0;
    for (const [id, item] of seen) {
      const executed = executedOf(item);
      const price = Number(item.price);
      if (executed === null || !Number.isFinite(price) || price <= 0) continue;
      withField += 1;
      const previous = this.snapshot.get(id);
      if (previous && !isBaseline) {
        const delta = executed - previous.executed;
        // delta < 0 — объявление пересоздали или счётчик сбросился: пропускаем.
        if (delta > 0) {
          const dealPrice = (previous.price + price) / 2;
          this.trades.push({
            at: now,
            volume: delta,
            price: dealPrice,
            nick: String(item.nickName ?? item.userId ?? "?"),
          });
          scanVolume += delta;
          scanValue += delta * dealPrice;
        }
      }
      this.snapshot.set(id, { executed, price, missed: 0 });
    }
    for (const [id, snap] of this.snapshot) {
      if (seen.has(id)) continue;
      snap.missed += 1;
      if (snap.missed > 3) this.snapshot.delete(id);
    }
    this.trades = this.trades.filter((trade) => now - trade.at <= KEEP_TRADES_MS);

    if (withField === 0 && seen.size > 0 && !this.fieldWarned) {
      this.fieldWarned = true;
      const sample = [...seen.values()][0]!;
      console.warn(
        `[market-scan] Bybit не отдаёт исполненный объём по объявлениям — посчитать сделки не получится. ` +
          `Поля объявления: ${Object.keys(sample).join(", ")}`,
      );
    }
    if (isBaseline && withField > 0) this.baselineAt = now;

    console.log(
      `[market-scan] объявлений ${seen.size}${total !== null ? ` из ${total}` : ""}, страниц ${page}` +
        (interrupted ? " (проход прерван: окно смены курса или разведчик работает — остальное досчитаю в следующий раз)" : "") +
        `, ` +
        `${((now - scanStartedAt) / 1000).toFixed(1)} с` +
        (isBaseline
          ? " — первый проход, запомнил базу"
          : `, прошло с прошлого прохода: ${volumeText(scanVolume)} USDT` +
            (scanVolume > 0 ? ` по средней ${(scanValue / scanVolume).toFixed(2)}` : "")),
    );
  }

  /** После смены курса: какой максимум установился относительно средней прошлого часа. */
  private maybeAfter(ctx: ScanContext, now: number): void {
    if (new Date(now).getMinutes() < AFTER_MINUTE) return;
    const key = hourKey(now);
    if (key === this.lastAfterKey || !this.lastSummary || this.lastSummary.key !== key) return;
    this.lastAfterKey = key;
    const { vwap, ref: refBefore, best: bestBefore, partial } = this.lastSummary;
    const { ref, top1, best } = ctx.reference();
    const changed = best !== null && bestBefore !== null && Math.abs(best - bestBefore) >= 0.005;
    if (!partial && changed && vwap !== null && best !== null) {
      // В модель берём только полные часы, в которых курс действительно сменился.
      this.loadHistory().push({ at: now, kVwap: best / vwap, kRef: refBefore !== null ? best / refBefore : null });
      this.saveHistory();
    }
    const pct = (value: number | null, base: number | null) =>
      value !== null && base !== null && base > 0 ? `${(value / base * 100).toFixed(3)}%` : "-";
    const fmt = (value: number | null, digits = 2) => (value === null ? "-" : value.toFixed(digits));
    console.log(
      `[market-volume] после смены курса ${hhmm(now)}: максимум ${fmt(bestBefore)} → ${fmt(best)}, ` +
        `это ${pct(best, vwap)} от средней прошлого часа (${fmt(vwap)}); эталон ${fmt(refBefore, 4)} → ${fmt(ref, 4)}, ` +
        `максимум = ${pct(best, ref)} от эталона; топ-1 ${fmt(top1)}`,
    );
    const row = [
      new Date(now).toISOString(),
      fmt(vwap, 4),
      fmt(bestBefore),
      fmt(best),
      vwap !== null && best !== null ? (best / vwap * 100).toFixed(4) : "",
      fmt(refBefore, 4),
      fmt(ref, 4),
      ref !== null && best !== null ? (best / ref * 100).toFixed(4) : "",
      fmt(top1),
    ].join(";");
    const header = existsSync(AFTER_FILE) ? "" :
      "time_utc;vwap_prev_hour;best_before;best_after;best_after_pct_of_vwap;ref_before;ref_after;best_after_pct_of_ref;top1_after\n";
    void appendFile(AFTER_FILE, header + row + "\n", "utf8")
      .catch((error: unknown) => console.warn(`[market-volume] не записал файл: ${(error as Error).message}`));
  }

  private sendForecast(
    ctx: ScanContext,
    now: number,
    data: { volume: number; vwap: number | null; ref: number | null; best: number | null; partial: boolean },
  ): void {
    const { volume, vwap, ref, best, partial } = data;
    const history = this.loadHistory();
    const byVwap = MarketVolumeScanner.coefficient(history.map((p) => p.kVwap));
    const byRef = MarketVolumeScanner.coefficient(
      history.map((p) => p.kRef).filter((v): v is number => v !== null));
    const fmt = (value: number | null, digits = 2) => (value === null ? "—" : value.toFixed(digits));
    const arrow = (next: number) => {
      if (best === null) return "";
      const diff = next - best;
      if (Math.abs(diff) < 0.005) return " (без изменений)";
      return diff > 0 ? ` (↑ +${diff.toFixed(2)})` : ` (↓ −${Math.abs(diff).toFixed(2)})`;
    };
    const lines = [
      `📈 <b>Прогноз курса</b> (${hhmm(now)})`,
      `Средняя цена сделок за час: <b>${fmt(vwap)}</b> (объём ${volumeText(volume)} USDT${partial ? ", неполный час" : ""})`,
      `Текущий максимум: <b>${fmt(best)}</b>`,
    ];
    if (vwap !== null && byVwap) {
      const next = vwap * byVwap.k;
      lines.push(
        `Ожидаемый новый максимум: <b>≈ ${next.toFixed(2)}</b>${arrow(next)}`,
        `  по средней × ${(byVwap.k * 100).toFixed(3)}% · разброс ±${(byVwap.spread * vwap).toFixed(2)} · смен в модели: ${byVwap.n}`,
      );
    }
    if (ref !== null && byRef) {
      const next = ref * byRef.k;
      lines.push(
        `По эталону: ≈ ${next.toFixed(2)}${arrow(next)}`,
        `  эталон ${ref.toFixed(4)} × ${(byRef.k * 100).toFixed(3)}% · разброс ±${(byRef.spread * ref).toFixed(2)}`,
      );
    }
    if (!byVwap) {
      lines.push(`Коэффициент пока неизвестен: нужна хотя бы одна полная смена курса с замером. ` +
        `Прогноз появится со следующего часа.`);
    } else if (byVwap.n < 3) {
      lines.push(`Мало данных (${byVwap.n} ${byVwap.n === 1 ? "смена" : "смены"}) — прогноз примерный.`);
    }
    if (byVwap && byRef && byVwap.n >= 3) {
      const errVwap = vwap !== null ? byVwap.spread * vwap : Infinity;
      const errRef = ref !== null ? byRef.spread * ref : Infinity;
      lines.push(errVwap <= errRef
        ? `Точнее пока модель «по средней цене сделок».`
        : `Точнее пока модель «по эталону».`);
    }
    ctx.notify(lines.join("\n"));
  }

  private maybeSummarize(ctx: ScanContext, now: number): void {
    const date = new Date(now);
    if (date.getMinutes() < SUMMARY_MINUTE) return;
    const key = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}-${date.getHours()}`;
    if (key === this.lastSummaryKey || this.running) return;
    this.lastSummaryKey = key;
    if (this.baselineAt === 0) {
      console.log(`[market-volume] итог ${hhmm(now)}: данных ещё нет — нужен хотя бы один полный проход стакана`);
      return;
    }

    const from = Math.max(now - HOUR_MS, this.baselineAt);
    const partial = from > now - HOUR_MS + 60_000;
    const window = this.trades.filter((trade) => trade.at > from);
    const volume = window.reduce((sum, trade) => sum + trade.volume, 0);
    const vwap = volume > 0 ? window.reduce((sum, trade) => sum + trade.volume * trade.price, 0) / volume : null;
    const { ref, top1, best } = ctx.reference();
    this.lastSummary = { key, vwap, ref, best, partial };
    const pct = (value: number | null, base: number | null) =>
      value !== null && base !== null && base > 0 ? `${(value / base * 100).toFixed(3)}%` : "-";
    const fmt = (value: number | null, digits = 2) => (value === null ? "-" : value.toFixed(digits));

    console.log(
      `[market-volume] итог ${hhmm(now)} за ${hhmm(from)}–${hhmm(now)}${partial ? " (неполный час)" : ""}: ` +
        `объём ${volumeText(volume)} USDT, средняя цена сделок ${fmt(vwap)}`,
    );
    console.log(
      `[market-volume] эталон ${fmt(ref, 4)}, топ-1 ${fmt(top1)}, максимум ${fmt(best)} → ` +
        `максимум = ${pct(best, vwap)} от средней, ${pct(best, ref)} от эталона; ` +
        `средняя = ${pct(vwap, ref)} от эталона`,
    );

    this.sendForecast(ctx, now, { volume, vwap, ref, best, partial });

    const byNick = new Map<string, { volume: number; value: number }>();
    for (const trade of window) {
      const entry = byNick.get(trade.nick) ?? { volume: 0, value: 0 };
      entry.volume += trade.volume;
      entry.value += trade.volume * trade.price;
      byNick.set(trade.nick, entry);
    }
    const leaders = [...byNick.entries()].sort((a, b) => b[1].volume - a[1].volume).slice(0, 5);
    if (leaders.length > 0) {
      console.log(
        `[market-volume] крупнейшие за час: ` +
          leaders.map(([nick, entry]) =>
            `${nick} ${volumeText(entry.volume)} USDT по ${(entry.value / entry.volume).toFixed(2)}`).join("; "),
      );
    }

    const row = [
      new Date(now).toISOString(),
      hhmm(from),
      hhmm(now),
      partial ? "1" : "0",
      volume.toFixed(2),
      fmt(vwap, 4),
      String(window.length),
      fmt(ref, 4),
      fmt(top1),
      fmt(best),
      vwap !== null && best !== null ? (best / vwap * 100).toFixed(4) : "",
      ref !== null && best !== null ? (best / ref * 100).toFixed(4) : "",
      ref !== null && vwap !== null ? (vwap / ref * 100).toFixed(4) : "",
    ].join(";");
    const header = existsSync(SUMMARY_FILE) ? "" :
      "time_utc;window_from;window_to;partial;volume_usdt;vwap;increments;ref;top1;best;" +
      "best_pct_of_vwap;best_pct_of_ref;vwap_pct_of_ref\n";
    void appendFile(SUMMARY_FILE, header + row + "\n", "utf8")
      .catch((error: unknown) => console.warn(`[market-volume] не записал файл: ${(error as Error).message}`));
  }
}
