import { existsSync } from "node:fs";
import { appendFile, mkdir } from "node:fs/promises";
import { resolve } from "node:path";
import { config } from "../config.js";
import { authService } from "../auth/authService.js";
import {
  BybitApiError,
  getOwnAdDetails,
  getTopPrice,
  listOnline,
  getWorkConfig,
  listPostAdPayments,
  updateAd,
  withBybitConnection,
  type PersonalItem,
} from "../bybit/index.js";
import type { TradingPreferenceSet } from "../bybit/types.js";
import {
  beforeRateWindow,
  healthyStakanSourceCount,
  inRateWindow,
  lastServedStakanSource,
  rateWindow,
  reportStaleStakan,
} from "../bybit/stakanSources.js";
import { apiUpdateHosts, lastUpdateHost } from "../bybit/officialClient.js";
import { getActiveCycleByChat } from "../db/repositories/cycles.js";
import { listActiveManualAds } from "../db/repositories/manualAds.js";
import { getActiveApiAccount } from "../db/repositories/apiAccounts.js";
import {
  accountUpdatesLeft,
  reserveWorkingAdUpdate,
  WorkingAdUpdateDeferred,
} from "../db/repositories/workingAdUpdateAttempts.js";
import {
  listWorkingAdsEnabledChatIds,
  ensureSettings,
  updateSettings,
} from "../db/repositories/userSettings.js";
import {
  deleteWorkingAd,
  getWorkingAd,
  listEnabledWorkingAds,
  listWorkingAds,
  saveWorkingAd,
  setWorkingAdEnabled,
  setWorkingAdFollow,
  updateWorkingAdState,
  type WorkingAdRow,
} from "../db/repositories/workingAds.js";
import { computeTargetPrice } from "./price.js";
import { PairRace, REVERT_CONFIRMATIONS } from "./pairRace.js";
import type { WorkingAdEvent } from "../web/telemetry.js";
import type { Notify } from "./cycleRunner.js";

const MAX_WORKING_ADS = 10;
// Bybit needs a short propagation window before the floating price can be read
// back. One second keeps the confirmation guard without adding a full extra
// market cycle of latency on every floating update.
const UPDATE_VERIFY_DELAY_MS = 1_000;
// Для разведчика шаг дополнительно подтверждается проверкой стакана,
// поэтому перечитываем объявление почти сразу.
const SCOUT_VERIFY_DELAY_MS = 150;
// Своё объявление перечитываем не чаще раза в 60 с: после каждого изменения
// цены данные и так обновляются, а частое чтение в момент смены курса давало
// отказы 10006 на /v5/p2p/item/info.
const DETAILS_CACHE_MS = 60_000;
// Floating: процент теперь считается от эталона, взятого прямо из стакана
// (свежий, без запросов к API аккаунта), поэтому его данные можно читать так
// же редко, как у fixed. Частые чтения съедали общий лимит P2P аккаунта, и
// Bybit отказывал в изменении цены в момент смены курса.
const FLOATING_DETAILS_CACHE_MS = 60_000;
// Эталон из стакана считаем свежим столько мс.
const STAKAN_REFERENCE_MAX_AGE_MS = 5_000;

function detailsTtl(raw: PersonalItem): number {
  return String((raw as { priceType?: unknown }).priceType ?? "") === "1"
    ? FLOATING_DETAILS_CACHE_MS
    : DETAILS_CACHE_MS;
}
// Как часто "греть" соединение с api.bybit.com (соединение закрывается после
// ~4 с простоя).
const WARM_INTERVAL_MS = 3_000;
// Повтор для объявления после таймаута сервера Bybit.
const TRANSIENT_RETRY_MS = 300;
// После отказа по лимиту (10006) повторять быстро нельзя — это только
// продлевает отказы. Ждём 1 с, при следующем отказе подряд 2, 4, до 8 с.
// Теперь настраивается в .env: LIMIT_RETRY_BASE_MS / LIMIT_RETRY_MAX_MS.
// По умолчанию 0 — своей паузы после 10006 нет, ждём только зазор
// API_UPDATE_GAP_MS. Вернуть старое поведение: BASE=1000, MAX=8000.
const envRetryMs = (name: string, fallback: number): number => {
  const value = Number(process.env[name]);
  return process.env[name] !== undefined && process.env[name] !== "" &&
    Number.isFinite(value) && value >= 0 && value <= 60_000 ? Math.round(value) : fallback;
};
// Общая читалка числовых настроек из .env (целое в пределах min..max, иначе fallback).
const envInt = (name: string, fallback: number, min: number, max: number): number => {
  const raw = process.env[name];
  const value = Number(raw);
  return raw !== undefined && raw.trim() !== "" && Number.isFinite(value) && value >= min && value <= max
    ? Math.round(value) : fallback;
};
const LIMIT_RETRY_BASE_MS = envRetryMs("LIMIT_RETRY_BASE_MS", 0);
const LIMIT_RETRY_MAX_MS = envRetryMs("LIMIT_RETRY_MAX_MS", 0);
// Разведчик считается "на рынке", пока он на страницах 1..FOLLOW_PAGES.
// Пропал с них — потолок найден (если его не перебили): стоп, ведомый
// остаётся на последней цене, при которой разведчик ещё был виден.
const FOLLOW_PAGES = 5;
// Страница стакана на сайте — 10 объявлений. Проверку делаем одним запросом
// на FOLLOW_PAGES × 10 объявлений, а не постранично.
const SITE_PAGE_SIZE = 10;
// Проверка — до FOLLOW_PAGES запросов, поэтому и когда разведчика нет,
// проверяем с тем же интервалом ведомого.
// После шага разведчика ждём, пока Bybit обновит стакан, и только потом
// верим проверке видимости (иначе можем увидеть ещё старую позицию).
// После шага разведчика: проверке стакана верим, только если она начата
// не раньше, чем через столько мс после шага. Для "разведчик виден" хватает
// короткой паузы (дополнительно сверяем, что стакан показывает уже новую
// цену). Для вывода "потолок" ждём дольше, чтобы не принять старый снимок
// стакана за исчезновение.
// .env: SCOUT_CONFIRM_MS (0..2000), SCOUT_CEILING_CONFIRM_MS (0..5000).
const SCOUT_CONFIRM_MS = envInt("SCOUT_CONFIRM_MS", 100, 0, 2_000);
const SCOUT_CEILING_CONFIRM_MS = envInt("SCOUT_CEILING_CONFIRM_MS", 400, 0, 5_000);
// Пока разведчик ждёт подтверждения шага — перепроверяем стакан так часто.
const SCOUT_RECHECK_MS = 100;
// Пока разведчик ждёт смены курса — проверка видимости почти не нужна.
const SCOUT_IDLE_LOOKUP_MS = 2_000;
const PAYMENTS_CACHE_MS = 60_000;
// Ники конкурентов для слежения (через запятую), например RIVAL_NICKS=KotSlardarkin.
const RIVAL_NICKS = (process.env.RIVAL_NICKS ?? "").split(",").map((value) => value.trim()).filter(Boolean);
// Через сколько после смены топ-1 подвести итог (кто и когда встал на новую цену).
const RIVAL_SUMMARY_AFTER_MS = 10_000;
// Разбор стакана для слежения за конкурентами — чуть позже, чтобы не стоять
// перед отправкой цены.
const RIVAL_FEED_DELAY_MS = 50;
// Сколько держать в памяти результат проверок перед изменением цены.
const ASSERT_CACHE_MS = 3_000;
// Второе объявление после ожидания лимита ждёт свежего стакана не дольше этого.
// .env: PROBE_FRESH_SCAN_WAIT_MS (0..2000; 0 — не ждать свежего стакана вообще).
// .env: FIRST_UPDATE_DELAY_MS (0..2000, по умолчанию 0 — выключено) — первое
// изменение цены после смены курса отправлять не сразу, а через столько мс.
const FIRST_UPDATE_DELAY_MS = envInt("FIRST_UPDATE_DELAY_MS", 0, 0, 2_000);
const PROBE_FRESH_SCAN_WAIT_MS = envInt("PROBE_FRESH_SCAN_WAIT_MS", 400, 0, 2_000);
// Floating-объявление пары "уплыло" с потолка (Bybit пересчитал цену по новому
// эталону) — возвращаем, но не раньше чем через столько после последнего
// изменения цены в паре и не чаще раза в столько на объявление.
// .env: FLOAT_DRIFT_QUIET_MS (0..30000), FLOAT_DRIFT_COOLDOWN_MS (0..120000).
const FLOAT_DRIFT_QUIET_MS = envInt("FLOAT_DRIFT_QUIET_MS", 3_000, 0, 30_000);
const FLOAT_DRIFT_COOLDOWN_MS = envInt("FLOAT_DRIFT_COOLDOWN_MS", 15_000, 0, 120_000);
// .env: STAKAN_LIMIT_PAUSE_MS (0..60000) — пауза всего бота, если публичный стакан ответил 10006.
const STAKAN_LIMIT_PAUSE_MS = envInt("STAKAN_LIMIT_PAUSE_MS", 5_000, 0, 60_000);
console.log(`[working-ads] задержки (.env): FIRST_UPDATE_DELAY_MS=${FIRST_UPDATE_DELAY_MS}, PROBE_FRESH_SCAN_WAIT_MS=${PROBE_FRESH_SCAN_WAIT_MS}, ` +
  `FLOAT_DRIFT_QUIET_MS=${FLOAT_DRIFT_QUIET_MS}, FLOAT_DRIFT_COOLDOWN_MS=${FLOAT_DRIFT_COOLDOWN_MS}, ` +
  `SCOUT_CONFIRM_MS=${SCOUT_CONFIRM_MS}, SCOUT_CEILING_CONFIRM_MS=${SCOUT_CEILING_CONFIRM_MS}, ` +
  `STAKAN_LIMIT_PAUSE_MS=${STAKAN_LIMIT_PAUSE_MS}`);
// ---- Диагностика: данные своего объявления в окне смены курса ----
// ITEM_PROBE_MS в .env (например 800, от 500 до 5000; нет или 0 — выключено):
// в окне смены курса бот раз в столько мс читает своё объявление через
// официальный API (по очереди оба объявления пары) и пишет в лог, какие поля
// изменились, а весь ответ — в data/item-probe.jsonl. Цель — понять, видно ли
// в данных объявления смену потолка раньше, чем её показывает стакан.
const ITEM_PROBE_MS = (() => {
  const value = Number(process.env.ITEM_PROBE_MS);
  return Number.isFinite(value) && value >= 500 && value <= 5_000 ? Math.round(value) : 0;
})();
const ITEM_PROBE_FILE = resolve(process.cwd(), "data", "item-probe.jsonl");
// Не читаем объявление, если изменение цены ушло меньше этого назад (чтобы
// запрос не встал у Bybit в очередь рядом с изменением цены).
const ITEM_PROBE_QUIET_MS = 700;

function flattenForDiff(value: unknown, prefix = "", out = new Map<string, string>()): Map<string, string> {
  if (value === null || typeof value !== "object") {
    out.set(prefix || "value", String(value));
    return out;
  }
  if (Array.isArray(value)) {
    out.set(prefix, JSON.stringify(value).slice(0, 200));
    return out;
  }
  for (const [key, inner] of Object.entries(value as Record<string, unknown>)) {
    flattenForDiff(inner, prefix ? `${prefix}.${key}` : key, out);
  }
  return out;
}
// Снимок стакана, принятый не раньше этого, считаем свежим — второе
// объявление после ожидания лимита отправляется сразу, без лишнего чтения.
const PROBE_FRESH_ENOUGH_MS = 100;
// В окне смены курса, пока пара ждёт, читаем стакан на столько объявлений.
const SMALL_STAKAN_SIZE = 20;
// В окне проверки перед отправкой обновляем в фоне, если они старше этого.
const WINDOW_ASSERT_REFRESH_MS = 2_000;
// ---- Диагностика: место среди объявлений с той же ценой ----
// Пока пара не в гонке, раз в DIAG_DEEP_EVERY_MS обычное чтение стакана
// разведчиком делается "глубоким": тот же один запрос, но на DIAG_DEEP_SIZE
// объявлений вместо 50. Лишних запросов нет. 0 — диагностика выключена.
const DIAG_DEEP_EVERY_MS = 0;
const DIAG_DEEP_SIZE = 200;
// Снимок группы "одинаковая цена" в data/ties.csv — не чаще раза в столько мс
// (и сразу, если наше место изменилось).
const DIAG_TIES_FILE_MS = 60_000;
const DIAG_TIES_FILE = resolve(process.cwd(), "data", "ties.csv");
// Поля объявления из стакана, которые пишем в ties.csv (если Bybit их отдаёт):
// по ним видно, как Bybit сортирует объявления с одинаковой ценой.
const DIAG_FIELDS = [
  "nickName", "userId", "recentOrderNum", "recentExecuteRate", "orderNum", "finishNum",
  "isOnline", "lastLogoutTime", "createDate", "updateDate", "version", "userType",
  "authStatus", "authTag", "recommend", "recommendTag", "itemType", "lastQuantity", "minAmount", "maxAmount",
] as const;
const READ_SPACING_MS = 125;
// Как часто (мс) писать в консоль, где стоят мои объявления и на каком месте.
// Данные берутся из уже прочитанного стакана — лишних запросов нет. В окне
// смены курса (RATE_WINDOW, по умолчанию 23-32 минуты) и во время гонки не
// пишется. .env: POSITION_LOG_EVERY_MS=30000 (0 — выключить).
const POSITION_LOG_EVERY_MS = (() => {
  const raw = process.env.POSITION_LOG_EVERY_MS;
  const value = Number(raw);
  return raw !== undefined && raw !== "" && Number.isFinite(value) && value >= 0 && value <= 3_600_000
    ? Math.round(value) : 30_000;
})();
// Публичный стакан Bybit (www.bybit.com/x-api/fiat/otc/item/online) отвечает
// 10006 уже примерно на 10 запросах за 5 секунд с одного IP. После 10006 бот
// уходит на паузу, поэтому держим чтение стакана чуть ниже этого лимита.
// ~7 запросов за 5 секунд: отказы 10006 начинались уже с 7–10 запросов.
// Как часто можно читать стакан с ОДНОГО IP. 700 мс — осторожная оценка
// (отказы 10006 начинались с ~7–10 запросов за 5 с). Можно поменять в .env:
// STAKAN_PER_IP_MS=600 (от 200 до 5000 мс). При отказе IP уходит на паузу,
// стакан читается с других — бот не останавливается.
const MARKET_READ_SPACING_MS = (() => {
  const value = Number(process.env.STAKAN_PER_IP_MS);
  return Number.isFinite(value) && value >= 200 && value <= 5_000 ? Math.round(value) : 700;
})();

// ---- Отложенный лог ----
// Запись в консоль Windows синхронная и может занимать миллисекунды. Строки,
// которые пишутся прямо перед отправкой новой цены (scout check, [pair],
// [rival]), выводим чуть позже — чтобы не задерживать отправку.
const DEFERRED_LOG_DELAY_MS = 30;
const deferredLogQueue: string[] = [];
let deferredLogTimer: NodeJS.Timeout | null = null;
function deferredLog(message: string): void {
  deferredLogQueue.push(message);
  if (deferredLogTimer) return;
  deferredLogTimer = setTimeout(() => {
    deferredLogTimer = null;
    const lines = deferredLogQueue.splice(0);
    if (lines.length) console.log(lines.join("\n"));
  }, DEFERRED_LOG_DELAY_MS);
}
// С несколькими IP (STAKAN_SOURCES) каждый IP читает не чаще раза в
// MARKET_READ_SPACING_MS, а все вместе — в N раз чаще. Не чаще раза в 200 мс.
// Нижний предел: чаще этого стакан не читаем, сколько бы ни было IP.
// Можно поменять в .env: STAKAN_MIN_INTERVAL_MS=170 (от 50 до 1000 мс).
const STAKAN_MIN_INTERVAL_MS = (() => {
  const value = Number(process.env.STAKAN_MIN_INTERVAL_MS);
  return Number.isFinite(value) && value >= 50 && value <= 1_000 ? Math.round(value) : 200;
})();
let loggedSpacing = -1;
function marketReadSpacingMs(): number {
  const count = healthyStakanSourceCount();
  const spacing = Math.max(STAKAN_MIN_INTERVAL_MS, Math.round(MARKET_READ_SPACING_MS / count));
  if (spacing !== loggedSpacing) {
    loggedSpacing = spacing;
    console.log(`[stakan] стакан читается раз в ${spacing} мс (IP в работе: ${count}, ` +
      `предел STAKAN_MIN_INTERVAL_MS=${STAKAN_MIN_INTERVAL_MS}, на каждый IP ~${MARKET_READ_SPACING_MS} мс)`);
  }
  return spacing;
}
// Чтение своего объявления (/v5/p2p/item/info): Bybit отказывает уже при 7–8
// чтениях за 5 с, хотя в заголовке пишет "лимит 10". Не чаще раза в секунду на
// весь бот — объявления и так читаются редко (данные хранятся в памяти).
const DETAILS_READ_SPACING_MS = 1_000;

interface ManagerHandle {
  chatId: number;
  timer: NodeJS.Timeout | null;
  busy: boolean;
  intervalMs: number;
}

type Settings = Awaited<ReturnType<typeof ensureSettings>>;
interface Observation {
  chatId: number;
  ad: WorkingAdRow;
  settings: Settings;
  topPrice: string;
  sourceKey: string;
  handle: ManagerHandle;
  observedAt: number;
  priceObservedAt: number;
  marketStartedAt: number;
  // Только для "ведомых" объявлений: цена лидера, если он СЕЙЧАС виден на
  // первой странице стакана (по его item_id), иначе null — сигнал
  // "разведчик вылетел со страницы, дальше не двигаемся".
  followLeaderPrice: string | null;
}

class ObservationExpired extends Error {}

export interface WorkingAdSyncResult {
  ad: WorkingAdRow;
  changed: boolean;
  previousPrice: string | null;
  targetPrice: string | null;
  error: string | null;
  notifyError?: boolean;
  deferredUntil?: number;
}

interface NormalizedAdDetails {
  itemId: string;
  tokenId: string;
  currencyId: string;
  side: "0" | "1";
  priceType: "0" | "1";
  price: string;
  premium: string;
  quantity: string;
  minAmount: string;
  maxAmount: string;
  remark: string;
  paymentPeriod: string;
  paymentIds: string[];
  tradingPreferenceSet: TradingPreferenceSet;
  online: boolean;
}

export interface StableFloatingPlan {
  basePrice: number;
  premium: string;
  numericPremium: number;
  changed: boolean;
  // Цена, которую покажет Bybit (известна, если процент считан от эталона).
  predictedPrice?: string;
}

/**
 * Повторяет устойчивый расчёт из bybit_bot_repost: reference price выводится
 * из фактических price/premium самого объявления, а не берётся отдельным
 * запросом, который может вернуть другой или запаздывающий рынок.
 */
export function computeStableFloatingPlan(input: {
  currentPrice: string | number;
  currentPremium: string | number;
  targetPrice: string | number;
}): StableFloatingPlan {
  const currentPrice = positiveNumber(input.currentPrice, "текущая цена");
  const currentPremium = positiveNumber(input.currentPremium, "текущий premium");
  const targetPrice = positiveNumber(input.targetPrice, "целевая цена");
  const basePrice = currentPrice / (currentPremium / 100);
  if (!Number.isFinite(basePrice) || basePrice <= 0) {
    throw new Error("Не удалось вычислить базовую цену floating-объявления");
  }
  const numericPremium = (targetPrice / basePrice) * 100;
  return {
    basePrice,
    premium: numericPremium.toFixed(2),
    numericPremium,
    changed: Math.abs(numericPremium - currentPremium) >= 0.005,
  };
}

/**
 * Процент floating-объявления от известного эталона (взятого из стакана).
 * Заодно заранее известна цена, которую покажет Bybit: эталон × процент / 100,
 * округлённая до копейки, — перечитывать объявление после изменения не нужно.
 */
export function floatingPlanFromReference(
  reference: number,
  currentPremium: string | number,
  targetPrice: string | number,
): StableFloatingPlan {
  const target = positiveNumber(targetPrice, "целевая цена");
  const current = Number(currentPremium);
  const numericPremium = (target / reference) * 100;
  const premium = numericPremium.toFixed(2);
  const predictedPrice = (Math.round(reference * Number(premium)) / 100).toFixed(2);
  return {
    basePrice: reference,
    premium,
    numericPremium,
    changed: !(current > 0) || Math.abs(numericPremium - current) >= 0.005,
    predictedPrice,
  };
}

export class WorkingAdsManager {
  private readonly handles = new Map<number, ManagerHandle>();
  private readonly lastChatError = new Map<number, string>();
  private readonly observations = new Map<string, Observation>();
  private readonly writers = new Map<string, Promise<WorkingAdSyncResult>>();
  // Диагностика ITEM_PROBE_MS: когда читали, чья очередь, прошлые ответы.
  private itemProbeAt = 0;
  private itemProbeTurn = 0;
  private itemProbeBusy = false;
  private itemProbeErrorAt = 0;
  private readonly itemProbeLast = new Map<string, Map<string, string>>();
  // Когда последний раз возвращали "уплывшее" floating-объявление на потолок.
  private readonly driftFixAt = new Map<string, number>();
  private lastWriteSentAt = 0;
  private readonly detailsCache = new Map<string, {
    raw: PersonalItem; sourceKey: string; expiresAt: number;
  }>();
  private readonly accounts = new Map<number, {
    sourceKey: string; userId: string | undefined;
  }>();
  private readonly paymentLists = new Map<number, {
    sourceKey: string; expiresAt: number; promise: ReturnType<typeof listPostAdPayments>;
  }>();
  private readonly retryAfter = new Map<string, number>();
  private readonly nextReadAt = new Map<string, number>();
  private pausedUntil = 0;
  // Разведчик ("chatId:itemId"): idle — ждёт смены курса (baseTop — топ-1,
  // при котором он остановился); climbing — один раз взял топ-1 и дальше
  // сам поднимает цену на шаг, пока виден в стакане.
  private readonly scoutModes = new Map<string, {
    mode: "idle" | "climbing"; baseTop: string | null; lastStepAt: number;
    // Топ-1, с которого начали текущий подъём (pendingTop — до подтверждения записи).
    startTop: string | null; pendingTop: string | null;
    pendingNote: string | null;
    // Текущая цена разведчика на Bybit (последняя прочитанная или поставленная).
    currentPrice: string | null;
    // Топ-1, который разведчик берёт при смене курса. Ведомый ставит его
    // одновременно с разведчиком, не дожидаясь подтверждения: это цена, которую
    // рынок уже показывает, значит она заведомо допустима.
    launchPrice: string | null;
    // Разведчика не видно на страницах 1-5 — потолок не ищем, держим топ-1 и
    // на каждой смене курса ставим новый топ-1.
    tracking: boolean;
    // Был ли разведчик хоть раз виден в текущем цикле (после взятия топ-1).
    visibleOnce: boolean;
  }>();
  // "chatId:itemId разведчика" -> последняя проверка его видимости в стакане.
  private readonly scoutVisibility = new Map<string, {
    at: number; found: boolean; price: string | null;
    // Лучшая цена чужих объявлений на страницах 1-5 (для BUY — самая
    // высокая, для SELL — самая низкая).
    bestOther: string | null;
  }>();
  // Чехарда пар "разведчик + ведомый" (ключ "chatId:itemId разведчика").
  private readonly races = new Map<string, PairRace>();
  // chatId -> item_id всех включённых объявлений (один аккаунт Bybit): для
  // лимита 4 изменения цены за 5 с на аккаунт.
  private readonly chatItemIds = new Map<number, string[]>();
  // Какой чат Telegram ведёт объявление Bybit (item_id -> chatId). Одно
  // объявление может вести только один чат: иначе два автокурса дерутся за цену.
  private readonly itemOwner = new Map<string, number>();
  private readonly ownerWarnedAt = new Map<string, number>();
  // Результат проверок перед отправкой (см. assertCanUpdate).
  private readonly assertCache = new Map<string, { at: number; settingsJson: string; sourceKey: string }>();
  private readonly windowRaceSeen = new Set<string>();
  // Слежение за конкурентами: последнее состояние каждого и текущая смена топ-1.
  private readonly rivalAds = new Map<string, { nick: string; price: number | null; rank: number | null; changedAt: number }>();
  private readonly rivalStarted = new Set<string>();
  // Цены объявлений конкурентов в момент смены топ-1 (для итога).
  private rivalAdsAtEvent = new Map<string, number | null>();
  private rivalEvent: {
    fromTop: number | null; top: number; at: number; logged: boolean;
    rivals: Map<string, { at: number; rank: number; beforeSmena: boolean; note: string }>;
    ours: { at: number; rank: number; itemId: string } | null;
  } | null = null;
  private rivalTop: number | null = null;
  // Окно смены курса: в каком состоянии чат (для подготовки и логов).
  private readonly windowState = new Map<number, {
    preparedHour: string; inWindow: boolean; startedAt: number; raceStarts: number;
  }>();
  // Диагностика места среди одинаковых цен.
  private lastDeepScanAt = 0;
  private deepScanDisabled = false;
  private diagLogState = { signature: "", at: 0, fileAt: 0 };
  // item_id -> когда бот последний раз менял цену (для диагностики).
  private readonly lastPriceChangeAt = new Map<string, number>();
  // "token|currency" -> эталонная цена, вычисленная из floating-объявлений стакана.
  private readonly stakanReference = new Map<string, { value: number; at: number }>();
  // Последняя строка "scout check" по разведчику — чтобы не спамить лог.
  private readonly scanLogState = new Map<string, { signature: string; at: number }>();
  // Сколько отказов по лимиту подряд получило объявление.
  private readonly limitStrikes = new Map<string, number>();
  private readonly positionLogAt = new Map<string, number>();
  // Объявления, данные которых сейчас обновляются в фоне.
  private readonly detailsRefreshing = new Set<string>();
  // Когда последний раз "грели" соединение с api.bybit.com.
  private lastWarmAt = 0;
  // Проверки стакана, которые сейчас идут в фоне (ключ — ведомый).
  private readonly lookupsInFlight = new Set<string>();
  // chatId -> item_id объявлений, за которыми кто-то следует (разведчики).
  private readonly leadersByChat = new Map<number, Set<string>>();
  // "chatId:adId ведомого" -> последний результат проверки видимости разведчика.
  private readonly followLookups = new Map<string, {
    at: number; found: boolean; hitPrice: string | null; bestOther: number | null;
  }>();

  constructor(private readonly notify: Notify, private readonly observe?: (event: WorkingAdEvent) => void) {}

  private emit(event: WorkingAdEvent): void {
    try { this.observe?.(event); } catch { /* Monitoring must not interrupt trading. */ }
  }

  async resumeAll(): Promise<void> {
    const chatIds = await listWorkingAdsEnabledChatIds();
    for (const chatId of chatIds) await this.schedule(chatId);
    console.log(`Resumed working-ad updater for ${chatIds.length} chat(s)`);
  }

  stopAll(): void {
    for (const handle of this.handles.values()) {
      if (handle.timer) clearTimeout(handle.timer);
    }
    this.handles.clear();
    this.observations.clear();
    this.accounts.clear();
    this.detailsCache.clear();
    this.paymentLists.clear();
  }

  async list(chatId: number): Promise<WorkingAdRow[]> {
    return listWorkingAds(chatId);
  }

  async add(chatId: number, rawItemId: string): Promise<WorkingAdRow> {
    const itemId = rawItemId.trim();
    if (!/^\d{6,30}$/.test(itemId)) {
      throw new Error("ID объявления должен состоять из цифр.");
    }
    const existing = await listWorkingAds(chatId);
    if (
      existing.length >= MAX_WORKING_ADS &&
      !existing.some((ad) => ad.item_id === itemId)
    ) {
      throw new Error(`Можно добавить не больше ${MAX_WORKING_ADS} объявлений.`);
    }
    await this.assertNotManagedByBot(chatId, itemId);

    const settings = await ensureSettings(chatId);
    const details = await withBybitConnection(
      settings.connection_mode,
      () => getOwnAdDetails(itemId),
      chatId,
    );
    const normalized = normalizeWorkingAdDetails(details, itemId);
    if (!normalized.online) {
      throw new Error(
        "Объявление найдено, но оно не активно. Сначала включи его в Bybit.",
      );
    }
    return saveWorkingAd({
      chatId,
      itemId,
      tokenId: normalized.tokenId,
      currencyId: normalized.currencyId,
      side: normalized.side,
      priceType: normalized.priceType,
      lastPrice: normalized.price,
    });
  }

  async remove(chatId: number, id: number): Promise<void> {
    this.observations.delete(`${chatId}:${id}`);
    this.detailsCache.delete(`${chatId}:${id}`);
    await deleteWorkingAd(chatId, id);
  }

  async toggleAd(chatId: number, id: number): Promise<WorkingAdRow | null> {
    const ads = await listWorkingAds(chatId);
    const ad = ads.find((entry) => entry.id === id);
    if (!ad) return null;
    return this.setAdEnabled(chatId, id, !ad.enabled);
  }

  async setAdEnabled(chatId: number, id: number, enabled: boolean): Promise<WorkingAdRow | null> {
    this.observations.delete(`${chatId}:${id}`);
    this.detailsCache.delete(`${chatId}:${id}`);
    return setWorkingAdEnabled(chatId, id, enabled);
  }

  /**
   * "Ведомое объявление": вместо расчёта цены от рынка это объявление
   * просто копирует последнюю известную цену другого объявления (лидера)
   * из того же чата. followItemId = null — снять ведение, вернуть к
   * обычному расчёту от рынка.
   */
  async setFollow(
    chatId: number,
    id: number,
    followItemId: string | null,
  ): Promise<WorkingAdRow | null> {
    const ads = await listWorkingAds(chatId);
    const ad = ads.find((entry) => entry.id === id);
    if (!ad) throw new Error("Объявление не найдено в списке.");
    if (followItemId) {
      if (followItemId === ad.item_id) {
        throw new Error("Объявление не может вести само себя.");
      }
      const leader = ads.find((entry) => entry.item_id === followItemId);
      if (!leader) {
        throw new Error(
          "Объявление-лидер с таким ID не найдено среди уже добавленных рабочих объявлений этого чата. " +
            "Сначала добавьте его в список кнопкой «➕ Добавить ID».",
        );
      }
      if (leader.follow_item_id) {
        throw new Error("Нельзя вести объявление, которое само является ведомым (цепочки не поддерживаются).");
      }
    }
    this.detailsCache.delete(`${chatId}:${id}`);
    return setWorkingAdFollow(chatId, id, followItemId);
  }

  async setEnabled(chatId: number, enabled: boolean): Promise<void> {
    if (enabled) {
      const ads = await listEnabledWorkingAds(chatId);
      if (ads.length === 0) {
        throw new Error("Сначала добавь и включи хотя бы одно рабочее объявление.");
      }
      const busy = ads.filter((entry) => {
        const owner = this.itemOwner.get(String(entry.item_id));
        return owner !== undefined && owner !== chatId && this.handles.has(owner);
      });
      if (busy.length > 0) {
        throw new Error(`Эти объявления уже ведёт автокурс в другом чате Telegram: ` +
          `${busy.map((entry) => `…${String(entry.item_id).slice(-4)}`).join(", ")}. Сначала выключи автокурс там.`);
      }
    }
    await updateSettings(chatId, { workingAdsEnabled: enabled });
    // При включении/выключении начинаем цикл разведчика заново: при
    // включении он сразу возьмёт текущий топ-1 и пойдёт искать потолок.
    this.resetScouts(chatId);
    if (enabled) await this.schedule(chatId);
    else this.unschedule(chatId);
  }

  /**
   * Один запрос к стакану (первые FOLLOW_PAGES × 10 объявлений) даёт сразу:
   * топ-1 (первое чужое объявление), место разведчика и лучшую чужую цену.
   * Результат сохраняется и для разведчика, и для всех его ведомых.
   */
  private async scanStakanForScout(args: {
    chatId: number;
    handle: ManagerHandle;
    settings: Settings;
    tokenId: string;
    currencyId: string;
    side: "0" | "1";
    scoutItemId: string;
    ads: WorkingAdRow[];
    ownUserId: string | undefined;
    extraItemIds?: string[];
    // Диагностика: читать не 50, а DIAG_DEEP_SIZE объявлений (тем же запросом).
    deep?: boolean;
    // Окно смены курса, пара ждёт: хватит топ-1, читаем меньше объявлений.
    small?: boolean;
    // Срочно, без очереди чтений (подтверждение подозрительного снимка).
    urgent?: boolean;
  }): Promise<{
    top1: string | null; found: boolean; hitPrice: string | null; bestOther: number | null; startedAt: number;
    hits: Map<string, number | null>;
    ranks: Map<string, number | null>;
    source?: string;
    rivalFeed?: () => void;
  }> {
    const { chatId, handle, settings, scoutItemId, ads, ownUserId } = args;
    let startedAt = Date.now();
    const readStakan = (size: number) => withBybitConnection(settings.connection_mode, () =>
      this.read("market", () => {
        startedAt = Date.now();
        return listOnline({
          tokenId: args.tokenId,
          currencyId: args.currencyId,
          side: args.side,
          size,
          page: 1,
          verificationFilter: settings.bourse_verification_filter,
          canTrade: false, // иначе Bybit прячет свои объявления
          // Без этого Bybit показывает только верифицированных
          // мейкеров, и объявлений обычного аккаунта там нет вовсе.
          vaMaker: false,
          bulkMaker: settings.bourse_bulk_maker,
          tradeWith: settings.bourse_trade_with,
          sortType: settings.bourse_sort_type,
        });
      }, () => this.handles.get(chatId) === handle, Boolean(args.urgent)), chatId);
    let result: Awaited<ReturnType<typeof readStakan>>;
    let deep = Boolean(args.deep) && !this.deepScanDisabled;
    if (deep) {
      try {
        result = await readStakan(DIAG_DEEP_SIZE);
      } catch (error) {
        if (error instanceof ObservationExpired || this.isRateLimitError(error)) throw error;
        // Bybit не отдаёт столько объявлений за раз — диагностику выключаем.
        this.deepScanDisabled = true;
        deep = false;
        console.warn(`[diag] стакан на ${DIAG_DEEP_SIZE} объявлений не читается (${(error as Error).message}) — диагностика места выключена`);
        result = await readStakan(args.small ? SMALL_STAKAN_SIZE : FOLLOW_PAGES * SITE_PAGE_SIZE);
      }
    } else {
      result = await readStakan(args.small ? SMALL_STAKAN_SIZE : FOLLOW_PAGES * SITE_PAGE_SIZE);
    }
    const allItems = result.items ?? [];
    if (deep) this.logTieDiagnostics(scoutItemId, args.extraItemIds ?? [],
      allItems as unknown as Array<Record<string, unknown>>, startedAt);
    const items = allItems.slice(0, FOLLOW_PAGES * SITE_PAGE_SIZE);
    // Слежение за конкурентами (RIVAL_NICKS в .env): только разбор уже
    // полученного стакана, без лишних запросов.
    // Слежение за конкурентами — после того как пара проверит снимок (см.
    // вызов onScan): устаревшие снимки в слежение не попадают.
    const rivalFeed = RIVAL_NICKS.length > 0
      ? () => {
        try {
          this.trackRivals(allItems as unknown as Array<Record<string, unknown>>, startedAt,
            [scoutItemId, ...(args.extraItemIds ?? [])], ads, ownUserId, args.side);
        } catch (error) {
          console.warn(`[rival] ошибка слежения: ${(error as Error).message}`);
        }
      }
      : undefined;
    const total = typeof result.count === "number" ? result.count : null;
    const ownItemIds = new Set(ads.map((entry) => String(entry.item_id)));
    let top1: string | null = null;
    let bestOther: number | null = null;
    for (const item of items) {
      const itemId = String(item.id ?? item.itemId ?? "");
      const mine = ownItemIds.has(itemId) ||
        (ownUserId !== undefined && String(item.userId ?? "") === String(ownUserId));
      const value = Number(item.price);
      if (mine || !Number.isFinite(value) || value <= 0) continue;
      if (top1 === null) top1 = String(item.price);
      if (bestOther === null || (args.side === "1" ? value < bestOther : value > bestOther)) bestOther = value;
    }
    // Эталон из чужих floating-объявлений: цена = эталон × процент / 100.
    {
      const refs: number[] = [];
      for (const item of items) {
        const premium = Number(item.premium);
        const price = Number(item.price);
        if (String(item.priceType ?? "") === "1" && premium > 0 && price > 0) refs.push(price * 100 / premium);
      }
      if (refs.length > 0) {
        refs.sort((x, y) => x - y);
        this.stakanReference.set(`${args.tokenId}|${args.currencyId}`, {
          value: refs[Math.floor(refs.length / 2)]!, at: startedAt,
        });
      }
    }
    const index = items.findIndex((item) => String(item.id ?? item.itemId) === String(scoutItemId));
    const hitItem = index >= 0 ? items[index] : undefined;
    const hit = hitItem?.price
      ? {
          price: String(hitItem.price),
          page: Math.floor(index / SITE_PAGE_SIZE) + 1,
          pos: (index % SITE_PAGE_SIZE) + 1,
        }
      : null;
    const found = hit !== null;
    const hitPrice = hit?.price ?? null;

    this.scoutVisibility.set(`${chatId}:${scoutItemId}`, {
      at: startedAt, found, price: hitPrice,
      bestOther: bestOther === null ? null : bestOther.toFixed(2),
    });
    for (const follower of ads) {
      if (follower.follow_item_id !== scoutItemId) continue;
      this.followLookups.set(`${chatId}:${follower.id}`, { at: startedAt, found, hitPrice, bestOther });
    }

    // Лог — только когда что-то поменялось (или раз в 10 с), иначе при чтении
    // раз в ~0,55 с консоль утонет в одинаковых строках.
    // Без total (число объявлений меняется почти при каждом чтении) и не чаще
    // раза в 30 с, если ничего не поменялось: консоль Windows медленная.
    const signature = `${found}|${hit?.page}|${hit?.pos}|${hitPrice}|${top1}|${bestOther}`;
    const lastLog = this.scanLogState.get(`${chatId}:${scoutItemId}`);
    if (!lastLog || lastLog.signature !== signature || startedAt - lastLog.at > 30_000) {
      this.scanLogState.set(`${chatId}:${scoutItemId}`, { signature, at: startedAt });
      deferredLog(
        `[working-ads] scout check item=${scoutItemId} visible=${found ? "yes" : "no"}` +
          (hit ? ` page=${hit.page} pos=${hit.pos} price=${hit.price}` : items.length < FOLLOW_PAGES * SITE_PAGE_SIZE
            ? ` (нет в первых ${items.length} — в окне смены курса бот читает сокращённый стакан)`
            : ` (нет на страницах 1-${FOLLOW_PAGES})`) +
          ` top1=${top1 ?? "-"} best=${bestOther === null ? "-" : bestOther.toFixed(2)} total=${total ?? "-"}`,
      );
    }
    // Цена и место (1..50) своих объявлений в стакане.
    const hits = new Map<string, number | null>();
    const ranks = new Map<string, number | null>();
    hits.set(scoutItemId, hitPrice === null ? null : Number(hitPrice));
    ranks.set(scoutItemId, index >= 0 ? index + 1 : null);
    for (const extraId of args.extraItemIds ?? []) {
      const extraIndex = items.findIndex((item) => String(item.id ?? item.itemId) === String(extraId));
      const extra = extraIndex >= 0 ? items[extraIndex] : undefined;
      hits.set(extraId, extra?.price ? Number(extra.price) : null);
      ranks.set(extraId, extraIndex >= 0 ? extraIndex + 1 : null);
    }
    const source = (result as { stakanSource?: unknown }).stakanSource;
    return {
      top1, found, hitPrice, bestOther, startedAt, hits, ranks,
      // Если слой listOnline не сохранил метку — берём IP последнего чтения.
      source: typeof source === "string" ? source : (lastServedStakanSource() ?? undefined),
      rivalFeed,
    };
  }

  /**
   * Пара стоит на потолке, но floating-объявление "уплыло": Bybit пересчитал
   * его цену по новому эталону (эталон × процент ≠ потолок). Возвращаем его
   * на потолок — процент пересчитается от свежего эталона из стакана.
   */
  private checkFloatingDrift(chatId: number, race: PairRace, ads: WorkingAdRow[],
    tokenId: string, currencyId: string, hits?: Map<string, number | null>): void {
    const ceiling = race.settledPrice;
    if (ceiling === null) return;
    const now = Date.now();
    if (now - race.lastActivity < FLOAT_DRIFT_QUIET_MS) return;
    const reference = this.stakanReference.get(`${tokenId}|${currencyId}`);
    if (!reference || now - reference.at > STAKAN_REFERENCE_MAX_AGE_MS) return;
    for (const row of ads) {
      if (row.price_type !== "1") continue;
      if (row.item_id !== race.a && row.item_id !== race.b) continue;
      if (this.writers.has(row.item_id)) continue;
      const cached = this.detailsCache.get(`${chatId}:${row.id}`);
      const premium = Number((cached?.raw as { premium?: unknown } | undefined)?.premium);
      if (!(premium > 0)) continue;
      // Эталон из стакана — оценка (медиана по чужим floating), он "дрожит" на
      // сотые доли процента. Поэтому: если наше floating видно в стакане —
      // верим его реальной цене; если не видно — считаем, что уплыло, только
      // когда оценка отличается от потолка явно (≥ 1,5 копейки), а не на
      // округлении (лог 01.10 08:29: 83.2376 × 106.26% = 88.449 ≈ 88.44, ложные
      // "уплыл" каждые 15 с).
      const exact = reference.value * premium / 100;
      const predicted = Math.round(exact * 100) / 100;
      const seen = hits?.get(row.item_id);
      if (seen !== undefined && seen !== null) {
        if (Math.abs(seen - ceiling) < 0.0099) continue;
      } else if (Math.abs(exact - ceiling) < 0.015) {
        continue;
      }
      if (now - (this.driftFixAt.get(row.item_id) ?? 0) < FLOAT_DRIFT_COOLDOWN_MS) continue;
      this.driftFixAt.set(row.item_id, now);
      deferredLog(`[pair] …${row.item_id.slice(-4)} (floating) уплыл: эталон ${reference.value.toFixed(4)} × ` +
        `${premium}% = ${predicted.toFixed(2)}${seen != null ? ` (в стакане ${seen.toFixed(2)})` : ""}, ` +
        `а потолок ${ceiling.toFixed(2)} — возвращаю на потолок`);
      race.forgetApplied(row.item_id);
      this.kickPairMember(chatId, race, row.item_id);
    }
  }

  /** Диагностика: читаем своё объявление и пишем, что в нём изменилось. */
  private itemProbeTick(chatId: number, ads: WorkingAdRow[], connectionMode: Settings["connection_mode"]): void {
    if (ITEM_PROBE_MS <= 0 || this.itemProbeBusy) return;
    const now = Date.now();
    if (now - this.itemProbeAt < ITEM_PROBE_MS) return;
    if (now - this.lastWriteSentAt < ITEM_PROBE_QUIET_MS) return;
    const pairIds = ads.filter((entry) => this.raceFor(chatId, entry.item_id) !== undefined)
      .map((entry) => String(entry.item_id));
    const ids = pairIds.length > 0 ? pairIds : ads.map((entry) => String(entry.item_id));
    if (ids.length === 0) return;
    const itemId = ids[this.itemProbeTurn % ids.length]!;
    this.itemProbeTurn += 1;
    this.itemProbeAt = now;
    this.itemProbeBusy = true;
    const startedAt = Date.now();
    // Тем же подключением, что и остальной бот (официальный API по ключу).
    void withBybitConnection(connectionMode,
      () => getOwnAdDetails(itemId), chatId)
      .then(async (raw) => {
        const at = Date.now();
        const flat = flattenForDiff(raw);
        const prev = this.itemProbeLast.get(itemId);
        this.itemProbeLast.set(itemId, flat);
        const short = `…${itemId.slice(-4)}`;
        if (!prev) {
          console.log(`[item-probe] ${short}: первое чтение (${at - startedAt} мс), полей ${flat.size} — ` +
            `весь ответ в data/item-probe.jsonl`);
        } else {
          const changes: string[] = [];
          for (const [key, value] of flat) {
            const old = prev.get(key);
            if (old !== value) changes.push(`${key}: ${old ?? "—"} → ${value}`);
          }
          for (const key of prev.keys()) if (!flat.has(key)) changes.push(`${key}: ${prev.get(key)} → —`);
          if (changes.length > 0) {
            console.log(`[item-probe] ${short} ${new Date(startedAt).toISOString().slice(11, 23)} ` +
              `(ответ ${at - startedAt} мс) изменилось: ${changes.slice(0, 12).join("; ")}` +
              (changes.length > 12 ? `; и ещё ${changes.length - 12}` : ""));
          }
        }
        await mkdir(resolve(process.cwd(), "data"), { recursive: true });
        await appendFile(ITEM_PROBE_FILE, JSON.stringify({
          at: new Date(startedAt).toISOString(), ms: at - startedAt, itemId, raw,
        }) + "\n", "utf8");
      })
      .catch((error: unknown) => {
        // Не чаще раза в 30 с, чтобы не засыпать лог одинаковыми строками.
        if (Date.now() - this.itemProbeErrorAt > 30_000) {
          this.itemProbeErrorAt = Date.now();
          console.warn(`[item-probe] ошибка чтения: ${(error as Error).message}`);
        }
      })
      .finally(() => { this.itemProbeBusy = false; });
  }

  /**
   * Окно смены курса. За минуту до окна — обновить данные объявлений (чтобы в
   * окне ничего не читать), в окне — держать свежими проверки перед отправкой,
   * в начале и в конце окна — строка в лог.
   */
  private rateWindowTick(chatId: number, ads: WorkingAdRow[], connectionMode: Settings["connection_mode"]): void {
    const window = rateWindow();
    if (!window) return;
    const now = Date.now();
    const hour = new Date(now).toISOString().slice(0, 13);
    const state = this.windowState.get(chatId) ??
      { preparedHour: "", inWindow: false, startedAt: 0, raceStarts: 0 };
    this.windowState.set(chatId, state);
    const pad = (value: number) => String(value).padStart(2, "0");
    const label = `:${pad(window.from)}–:${pad(window.to)}`;

    if (beforeRateWindow(now) && state.preparedHour !== hour) {
      state.preparedHour = hour;
      // Данные объявлений считаем устаревшими — они обновятся в фоне сейчас,
      // до окна (в паре чтение объявления цену не задерживает).
      for (const ad of ads) {
        const cached = this.detailsCache.get(`${chatId}:${ad.id}`);
        if (cached) cached.expiresAt = 0;
      }
      console.log(`[window] через минуту окно смены курса ${label} — обновляю данные объявлений`);
    }

    const inside = inRateWindow(now);
    if (inside && !state.inWindow) {
      state.inWindow = true;
      state.startedAt = now;
      state.raceStarts = 0;
      const races = [...this.races.entries()].filter(([key]) => key.startsWith(`${chatId}:`));
      console.log(`[window] окно смены курса ${label} началось: стакан пока пара ждёт — ${SMALL_STAKAN_SIZE} объявлений, ` +
        `фоновые чтения объявлений выключены, пар: ${races.length}`);
    } else if (!inside && state.inWindow) {
      state.inWindow = false;
      console.log(`[window] окно ${label} закончилось: стартов гонки за окно ${state.raceStarts}`);
    }
    if (!inside) return;
    this.itemProbeTick(chatId, ads, connectionMode);

    // Считаем старты гонки (для итога окна).
    for (const [key, race] of this.races) {
      if (!key.startsWith(`${chatId}:`)) continue;
      const flag = `${key}:race`;
      if (race.state === "race" && !this.windowRaceSeen.has(flag)) {
        this.windowRaceSeen.add(flag);
        state.raceStarts += 1;
      } else if (race.state !== "race") {
        this.windowRaceSeen.delete(flag);
      }
    }
    // Проверки перед отправкой держим свежими.
    for (const ad of ads) {
      const key = `${chatId}:${ad.id}`;
      const cached = this.assertCache.get(key);
      const observation = this.observations.get(key);
      if (!observation || (cached && now - cached.at < WINDOW_ASSERT_REFRESH_MS)) continue;
      void this.assertCanUpdate(key, observation).catch(() => {});
    }
  }

  /**
   * Слежение за конкурентами по нику в стакане. Пишет в лог:
   *  - когда объявление конкурента меняет цену / место или пропадает из
   *    видимых N объявлений;
   *  - после смены топ-1 — итог: когда на новую цену встал конкурент и когда
   *    наш держатель (разница в мс и места).
   */
  private trackRivals(
    items: Array<Record<string, unknown>>, at: number, ourIds: string[],
    ads: WorkingAdRow[], ownUserId: string | undefined, side: "0" | "1",
  ): void {
    const ownIds = new Set(ads.map((entry) => String(entry.item_id)));
    const idOf = (item: Record<string, unknown>) => String(item.id ?? item.itemId ?? "");
    const time = (ms: number) => new Date(ms).toISOString().slice(11, 23);
    const better = (x: number, y: number) => (side === "1" ? x < y - 0.005 : x > y + 0.005);
    // Топ-1 среди чужих.
    let top: number | null = null;
    for (const item of items) {
      const mine = ownIds.has(idOf(item)) || (ownUserId !== undefined && String(item.userId ?? "") === String(ownUserId));
      const price = Number(item.price);
      if (mine || !(price > 0)) continue;
      top = price;
      break;
    }
    if (top === null) return;

    // Смена топ-1 — начинаем новое событие (прошлое подводим итогом).
    if (this.rivalTop === null || Math.abs(top - this.rivalTop) >= 0.005) {
      if (this.rivalTop !== null) {
        if (this.rivalEvent && !this.rivalEvent.logged) this.logRivalSummary();
        this.rivalEvent = {
          fromTop: this.rivalTop, top, at, logged: false, rivals: new Map(), ours: null,
        };
        this.rivalAdsAtEvent = new Map([...this.rivalAds].map(([id, ad]) => [id, ad.price]));
      }
      this.rivalTop = top;
    }

    const lower = RIVAL_NICKS.map((nick) => nick.toLowerCase());
    const adLabel = (nick: string, id: string) => `${nick} #…${id.slice(-4)}`;
    const describe = (price: number, rank: number) =>
      `${price.toFixed(2)}, место ${rank}${Math.abs(price - top!) < 0.005 ? " (на топ-1)" : better(price, top!) ? " (выше топ-1?)" : ""}`;
    for (let i = 0; i < RIVAL_NICKS.length; i++) {
      const nick = RIVAL_NICKS[i]!;
      // Все объявления конкурента в прочитанном стакане.
      const seen = new Map<string, { price: number; rank: number }>();
      for (let index = 0; index < items.length; index++) {
        const name = String(items[index]!.nickName ?? "").toLowerCase();
        if (name !== lower[i]) continue;
        seen.set(idOf(items[index]!), { price: Number(items[index]!.price), rank: index + 1 });
      }
      for (const [id, ad] of seen) {
        const prev = this.rivalAds.get(id);
        if (!prev || prev.price === null) {
          const why = !prev ? (this.rivalStarted.has(nick) ? "появилось" : "видно")
            : "снова видно";
          deferredLog(`[rival] ${adLabel(nick, id)}: ${why} — ${describe(ad.price, ad.rank)} — ${time(at)}`);
        } else if (Math.abs(prev.price - ad.price) >= 0.005) {
          deferredLog(`[rival] ${adLabel(nick, id)}: ${prev.price.toFixed(2)} → ${describe(ad.price, ad.rank)} ` +
            `(прошлая смена цены ${Math.round((at - prev.changedAt) / 100) / 10} с назад) — ${time(at)}`);
        }
        const changedAt = !prev || prev.price === null || Math.abs(prev.price - ad.price) >= 0.005 ? at : prev.changedAt;
        this.rivalAds.set(id, { nick, price: ad.price, rank: ad.rank, changedAt });
      }
      // Объявления, которые были видны, а теперь нет. Если стакан прочитан
      // короче (окно смены курса) и объявление было ниже — это не "пропало".
      for (const [id, prev] of this.rivalAds) {
        if (prev.nick !== nick || seen.has(id) || prev.price === null) continue;
        if (prev.rank !== null && prev.rank > items.length) continue;
        deferredLog(`[rival] ${adLabel(nick, id)}: пропало из первых ${items.length} (было ${prev.price.toFixed(2)}, место ${prev.rank}) — ${time(at)}`);
        this.rivalAds.set(id, { ...prev, price: null, rank: null, changedAt: at });
      }
      if (!this.rivalStarted.has(nick)) {
        this.rivalStarted.add(nick);
        deferredLog(`[rival] ${nick}: видно объявлений ${seen.size} в первых ${items.length}`);
      }
      // Лучшее объявление на новом топ-1 — для итога смены.
      const event = this.rivalEvent;
      if (event && !event.rivals.has(nick)) {
        for (const [id, ad] of seen) {
          if (Math.abs(ad.price - event.top) >= 0.005) continue;
          const prev = this.rivalAdsAtEvent.get(id);
          event.rivals.set(nick, {
            at, rank: ad.rank, beforeSmena: at <= event.at,
            note: prev === undefined || prev === null ? `#…${id.slice(-4)} до смены не было видно` : `#…${id.slice(-4)} было на ${prev.toFixed(2)}`,
          });
          break;
        }
      }
    }

    // Наш держатель / второе объявление на новом топ-1.
    const event = this.rivalEvent;
    if (event && !event.ours) {
      for (let index = 0; index < items.length; index++) {
        const id = idOf(items[index]!);
        if (!ourIds.includes(id)) continue;
        if (Math.abs(Number(items[index]!.price) - event.top) < 0.005) {
          event.ours = { at, rank: index + 1, itemId: id };
          break;
        }
      }
    }
    if (event && !event.logged && at - event.at >= RIVAL_SUMMARY_AFTER_MS) this.logRivalSummary();
  }

  private logRivalSummary(): void {
    const event = this.rivalEvent;
    if (!event || event.logged) return;
    event.logged = true;
    const time = (ms: number) => new Date(ms).toISOString().slice(11, 23);
    const short = (id: string) => (id.length > 6 ? `…${id.slice(-4)}` : id);
    const parts: string[] = [];
    for (const nick of RIVAL_NICKS) {
      const rival = event.rivals.get(nick);
      parts.push(rival
        ? `${nick} — в ${time(rival.at)} (+${rival.at - event.at} мс от смены), место ${rival.rank}` +
          (rival.beforeSmena ? ", был на этой цене уже в первом снимке с новым топ-1" : "") + ` (${rival.note})`
        : `${nick} — не видно на ${event.top.toFixed(2)} за ${RIVAL_SUMMARY_AFTER_MS / 1000} с`);
    }
    const ours = event.ours;
    parts.push(ours
      ? `мы (${short(ours.itemId)}) — в ${time(ours.at)} (+${ours.at - event.at} мс), место ${ours.rank}`
      : `мы — не видно на ${event.top.toFixed(2)} в первых объявлениях за ${RIVAL_SUMMARY_AFTER_MS / 1000} с`);
    const first = [...event.rivals.values()][0];
    const delta = ours && first ? ours.at - first.at : null;
    const diff = delta === null ? ""
      : delta > 0 ? ` → он раньше нас на ${delta} мс`
      : delta < 0 ? ` → мы раньше него на ${-delta} мс`
      : " → одновременно (в одном снимке стакана)";
    deferredLog(`[rival] итог смены ${event.fromTop?.toFixed(2) ?? "?"}→${event.top.toFixed(2)} ` +
      `(смена замечена в ${time(event.at)}): ${parts.join("; ")}${diff}`);
  }

  /** Раз в POSITION_LOG_EVERY_MS: цена и место моих объявлений (из уже прочитанного стакана). */
  private logPositions(
    chatId: number,
    scout: WorkingAdRow,
    race: PairRace | undefined,
    scan: { top1: string | null; hits: Map<string, number | null>; ranks: Map<string, number | null> },
    ads: WorkingAdRow[],
  ): void {
    if (POSITION_LOG_EVERY_MS <= 0 || inRateWindow()) return;
    const key = `${chatId}:${scout.item_id}`;
    const now = Date.now();
    if (now - (this.positionLogAt.get(key) ?? 0) < POSITION_LOG_EVERY_MS) return;
    this.positionLogAt.set(key, now);
    const ids = [scout.item_id, ...(race ? [race.b] : [])];
    const parts = ids.map((id) => {
      const row = ads.find((entry) => entry.item_id === id);
      const kind = row?.price_type === "1" ? "floating" : "fixed";
      const price = scan.hits.get(id);
      const rank = scan.ranks.get(id);
      return `…${id.slice(-4)} (${kind}) ` + (price != null && rank != null
        ? `${price.toFixed(2)} — место ${rank}`
        : `не видно в первых ${FOLLOW_PAGES * SITE_PAGE_SIZE}`);
    });
    deferredLog(`[pos] мои объявления: ${parts.join("; ")}; топ-1 чужих ${scan.top1 ?? "-"}`);
  }

  /** Сразу запустить изменение цены второго объявления пары, если оно ему нужно. */
  private kickPairMember(chatId: number, race: PairRace, itemId: string): void {
    if (this.writers.has(itemId) || (this.retryAfter.get(itemId) ?? 0) > Date.now()) return;
    if (race.target(itemId) === null) return;
    for (const [key, observation] of this.observations) {
      if (observation.chatId !== chatId || observation.ad.item_id !== itemId) continue;
      if (this.handles.get(chatId) !== observation.handle) return;
      void this.startWriter(key, observation, false);
      return;
    }
  }

  /** Пора ли сделать диагностическое "глубокое" чтение стакана (только вне гонки). */
  private wantDeepScan(race: PairRace | undefined): boolean {
    if (DIAG_DEEP_EVERY_MS <= 0 || this.deepScanDisabled) return false;
    if (race?.state === "race") return false;
    const now = Date.now();
    if (now - this.lastDeepScanAt < DIAG_DEEP_EVERY_MS) return false;
    this.lastDeepScanAt = now;
    return true;
  }

  /**
   * Диагностика: где стоят наши объявления в стакане (глубже 5-й страницы) и
   * какими по счёту среди объявлений с той же ценой. Пишет строку [diag] в
   * консоль (при изменении или раз в 30 с) и снимок группы в data/ties.csv.
   */
  private logTieDiagnostics(
    scoutItemId: string,
    extraItemIds: string[],
    items: Array<Record<string, unknown>>,
    at: number,
  ): void {
    const idOf = (item: Record<string, unknown>) => String(item.id ?? item.itemId ?? "");
    const short = (id: string) => (id.length > 6 ? `…${id.slice(-4)}` : id);
    const ours = [scoutItemId, ...extraItemIds];
    const parts: string[] = [];
    const signatureParts: string[] = [];
    let groupForFile: { price: number; from: number; to: number } | null = null;
    for (const id of ours) {
      const index = items.findIndex((item) => idOf(item) === id);
      if (index < 0) {
        parts.push(`${short(id)} — нет в первых ${items.length}`);
        signatureParts.push(`${id}:-`);
        continue;
      }
      const price = Number(items[index]!.price);
      let from = index;
      let to = index;
      while (from > 0 && Math.abs(Number(items[from - 1]!.price) - price) < 0.005) from--;
      while (to < items.length - 1 && Math.abs(Number(items[to + 1]!.price) - price) < 0.005) to++;
      const changedAt = this.lastPriceChangeAt.get(id);
      parts.push(
        `${short(id)} ${price.toFixed(2)} — ${index + 1}-е место (стр. ${Math.floor(index / SITE_PAGE_SIZE) + 1}), ` +
          `среди ${price.toFixed(2)}: ${index - from + 1}-е из ${to - from + 1} (места ${from + 1}–${to + 1}` +
          `${to === items.length - 1 ? `, дальше ${items.length} не видно` : ""})` +
          (changedAt ? `, цена менялась ${Math.round((at - changedAt) / 1000)} с назад` : ""),
      );
      signatureParts.push(`${id}:${index}:${from}:${to}`);
      if (id === scoutItemId || groupForFile === null) groupForFile = { price, from, to };
    }
    const signature = signatureParts.join("|");
    const state = this.diagLogState;
    const changed = signature !== state.signature;
    if (changed || at - state.at > 30_000) {
      console.log(`[diag] топ-1 ${items[0] ? Number(items[0].price).toFixed(2) : "-"}; ${parts.join("; ")}`);
      state.at = at;
    }
    state.signature = signature;
    if (!groupForFile || (!changed && at - state.fileAt < DIAG_TIES_FILE_MS)) return;
    state.fileAt = at;
    const stamp = new Date(at).toISOString();
    const clean = (value: unknown) => {
      if (value === undefined || value === null) return "";
      const text = typeof value === "object" ? JSON.stringify(value) : String(value);
      return text.replace(/[;\r\n]/g, " ");
    };
    const rows: string[] = [];
    for (let i = groupForFile.from; i <= groupForFile.to; i++) {
      const item = items[i]!;
      const id = idOf(item);
      rows.push([
        stamp, groupForFile.price.toFixed(2), String(i + 1), String(i - groupForFile.from + 1),
        ours.includes(id) ? "МОЁ" : "", id,
        ...DIAG_FIELDS.map((field) => clean(item[field])),
      ].join(";"));
    }
    const header = existsSync(DIAG_TIES_FILE) ? "" :
      ["time_utc", "price", "place", "place_in_group", "mine", "item_id", ...DIAG_FIELDS].join(";") + "\n";
    void appendFile(DIAG_TIES_FILE, header + rows.join("\n") + "\n", "utf8")
      .catch((error: unknown) => console.warn(`[diag] ties.csv: ${(error as Error).message}`));
  }

  /** Проверка стакана со стороны ведомого (когда разведчик сам стакан не читает). */
  private async lookupScout(
    chatId: number,
    handle: ManagerHandle,
    settings: Settings,
    ad: WorkingAdRow,
    ads: WorkingAdRow[],
    ownUserId: string | undefined,
  ): Promise<{ found: boolean; hitPrice: string | null; bestOther: number | null }> {
    const scan = await this.scanStakanForScout({
      chatId, handle, settings,
      tokenId: ad.token_id, currencyId: ad.currency_id, side: ad.side,
      scoutItemId: ad.follow_item_id!, ads, ownUserId,
    });
    return { found: scan.found, hitPrice: scan.hitPrice, bestOther: scan.bestOther };
  }

  /**
   * Держим соединение с api.bybit.com открытым: раз в WARM_INTERVAL_MS лёгкий
   * публичный запрос времени сервера (не входит в лимиты P2P). Без этого при
   * редких запросах соединение закрывается, и первое изменение цены в момент
   * смены курса тратит время на новое защищённое соединение.
   */
  private keepApiConnectionWarm(mode: string): void {
    if (mode !== "api") return;
    const now = Date.now();
    if (now - this.lastWarmAt < WARM_INTERVAL_MS) return;
    this.lastWarmAt = now;
    // Греем соединения со всеми адресами, через которые идут изменения цены.
    for (const host of new Set([config.bybit.apiBaseUrl.replace(/\/+$/, ""), ...apiUpdateHosts()])) {
      void fetch(`${host}/v5/market/time`, { signal: AbortSignal.timeout(5_000) })
        .then((response) => response.arrayBuffer())
        .catch(() => {});
    }
  }

  /** Пара-чехарда, в которой участвует объявление (как разведчик или как ведомый). */
  private raceFor(chatId: number, itemId: string): PairRace | undefined {
    const direct = this.races.get(`${chatId}:${itemId}`);
    if (direct) return direct;
    for (const [key, race] of this.races) {
      if (key.startsWith(`${chatId}:`) && race.b === itemId) return race;
    }
    return undefined;
  }

  private resetScouts(chatId: number): void {
    const prefix = `${chatId}:`;
    for (const map of [this.scoutModes, this.scoutVisibility, this.followLookups, this.races] as Map<string, unknown>[]) {
      for (const key of [...map.keys()]) if (key.startsWith(prefix)) map.delete(key);
    }
  }

  async setIntervalSeconds(chatId: number, seconds: number): Promise<void> {
    if (!Number.isFinite(seconds) || seconds < 0.01 || seconds > 86_400) {
      throw new Error("Интервал мониторинга должен быть от 0,01 до 86400 секунд.");
    }
    const intervalMs = Math.round(seconds * 1000);
    const settings = await updateSettings(chatId, {
      workingAdsIntervalMs: intervalMs,
    });
    if (settings.working_ads_enabled) {
      this.unschedule(chatId);
      await this.schedule(chatId);
    }
  }

  async setUpdateIntervalSeconds(chatId: number, seconds: number): Promise<void> {
    if (!Number.isFinite(seconds) || seconds < 0.01 || seconds > 86_400) {
      throw new Error("Минимальный интервал редактирования должен быть от 0,01 до 86400 секунд.");
    }
    await updateSettings(chatId, {
      workingAdsUpdateIntervalMs: Math.round(seconds * 1000),
    });
    // Recalculate waiting times from persisted attempts using the new interval.
    const ads = await listWorkingAds(chatId);
    for (const ad of ads) this.retryAfter.delete(ad.item_id);
  }

  async setFollowIntervalSeconds(chatId: number, seconds: number): Promise<void> {
    if (!Number.isFinite(seconds) || seconds < 0.01 || seconds > 86_400) {
      throw new Error("Интервал ведомого должен быть от 0,01 до 86400 секунд.");
    }
    await updateSettings(chatId, {
      workingAdsFollowIntervalMs: Math.round(seconds * 1000),
    });
    // Следующая проверка ведомого сразу пойдёт с новым интервалом.
    for (const key of this.followLookups.keys()) {
      if (key.startsWith(`${chatId}:`)) this.followLookups.delete(key);
    }
  }

  async syncNow(chatId: number): Promise<WorkingAdSyncResult[]> {
    const settings = await ensureSettings(chatId);
    if (!settings.working_ads_enabled) {
      throw new Error("Автокурс рабочих объявлений выключен.");
    }
    if (Date.now() < this.pausedUntil) {
      throw new Error("Пауза после ошибки Bybit. Автоматическая проверка возобновится позже.");
    }
    return this.processChat(chatId, false, true);
  }

  private async schedule(chatId: number): Promise<void> {
    if (this.handles.has(chatId)) return;
    const settings = await ensureSettings(chatId);
    if (this.handles.has(chatId) || !settings.working_ads_enabled) return;
    const intervalMs = Math.max(
      10,
      Number(settings.working_ads_interval_ms || config.cycle.intervalMs),
    );
    const handle: ManagerHandle = { chatId, timer: null, busy: false, intervalMs };
    this.handles.set(chatId, handle);
    const poll = async () => {
      if (this.handles.get(chatId) !== handle) return;
      const startedAt = Date.now();
      try { await this.processChat(chatId, true); }
      catch (error) { console.warn(`[working-ads] polling: ${(error as Error).message}`); }
      finally {
        if (this.handles.get(chatId) === handle) {
          // Schedule from request start, without waiting for an extra interval tick after a slow reply.
          handle.timer = setTimeout(() => void poll(), Math.max(0, startedAt + intervalMs - Date.now()));
        }
      }
    };
    setImmediate(() => void poll());
  }

  private unschedule(chatId: number): void {
    const handle = this.handles.get(chatId);
    if (!handle) return;
    if (handle.timer) clearTimeout(handle.timer);
    this.handles.delete(chatId);
    for (const [id, owner] of [...this.itemOwner]) if (owner === chatId) this.itemOwner.delete(id);
    this.lastChatError.delete(chatId);
    this.accounts.delete(chatId);
    this.paymentLists.delete(chatId);
    for (const [key, observation] of this.observations) {
      if (observation.chatId === chatId) {
        this.observations.delete(key);
        this.detailsCache.delete(key);
      }
    }
  }

  private async processChat(
    chatId: number,
    notifyChanges: boolean,
    throwOuterError = false,
  ): Promise<WorkingAdSyncResult[]> {
    const handle = this.handles.get(chatId);
    if (!handle || Date.now() < this.pausedUntil) return [];
    if (handle.busy) {
      if (throwOuterError) throw new Error("Проверка уже выполняется.");
      return [];
    }
    handle.busy = true;

    try {
      const settings = await ensureSettings(chatId);
      if (!settings.working_ads_enabled) {
        this.unschedule(chatId);
        return [];
      }
      const allAds = await listEnabledWorkingAds(chatId);
      // Объявление уже ведёт другой чат Telegram — этот чат его не трогает.
      const ads = allAds.filter((entry) => {
        const id = String(entry.item_id);
        const owner = this.itemOwner.get(id);
        if (owner === undefined || owner === chatId || !this.handles.has(owner)) {
          this.itemOwner.set(id, chatId);
          return true;
        }
        const warnKey = `${chatId}:${id}`;
        if (Date.now() - (this.ownerWarnedAt.get(warnKey) ?? 0) > 60_000) {
          this.ownerWarnedAt.set(warnKey, Date.now());
          console.warn(`[working-ads] chat=${chatId}: объявление …${id.slice(-4)} уже ведёт чат ${owner} — ` +
            `здесь пропускаю (два автокурса на одно объявление дерутся за цену)`);
        }
        return false;
      });
      if (ads.length === 0) return [];
      const accountItemIds = ads.map((entry) => String(entry.item_id));
      this.chatItemIds.set(chatId, accountItemIds);
      this.leadersByChat.set(chatId, new Set(
        ads.map((entry) => entry.follow_item_id).filter((id): id is string => Boolean(id)),
      ));
      // Пары для чехарды: разведчик + его ведомый (оба включены).
      {
        const floating = new Set(ads.filter((entry) => entry.price_type === "1").map((entry) => entry.item_id));
        const alive = new Set<string>();
        for (const follower of ads) {
          if (!follower.follow_item_id) continue;
          const scout = ads.find((entry) => entry.item_id === follower.follow_item_id);
          if (!scout) continue;
          const raceKey = `${chatId}:${scout.item_id}`;
          alive.add(raceKey);
          const options = {
            side: scout.side,
            step: Number(settings.price_step) > 0 ? Number(settings.price_step) : 0.01,
            min: Number(settings.price_min),
            max: Number(settings.price_max),
            floating,
            log: (message: string) => deferredLog(message),
            onStaleSource: (source: string, reason: string) => reportStaleStakan(source, reason),
            updatesLeft: () => accountUpdatesLeft(this.chatItemIds.get(chatId) ?? accountItemIds),
          };
          const existing = this.races.get(raceKey);
          if (existing && existing.b === follower.item_id) existing.configure(options);
          else this.races.set(raceKey, new PairRace(scout.item_id, follower.item_id, options));
        }
        for (const raceKey of [...this.races.keys()]) {
          if (raceKey.startsWith(`${chatId}:`) && !alive.has(raceKey)) this.races.delete(raceKey);
        }
      }
      const activeIds = new Set(ads.map((ad) => `${chatId}:${ad.id}`));
      for (const [key, value] of this.observations) {
        if (value.chatId === chatId && !activeIds.has(key)) this.observations.delete(key);
      }
      const sourceKey = await this.connectionKey(chatId, settings);
      const session =
        settings.connection_mode === "session"
          ? await authService.getCurrent()
          : null;
      let account = this.accounts.get(chatId);
      if (!account || account.sourceKey !== sourceKey) {
        const workConfig = await withBybitConnection(
          settings.connection_mode,
          () => this.read("account", () => getWorkConfig(), () => this.handles.get(chatId) === handle),
          chatId,
        );
        account = {
          sourceKey,
          userId: workConfig.userId || session?.bybitUid || config.bybit.userId || undefined,
        };
        this.accounts.set(chatId, account);
      }
      this.keepApiConnectionWarm(settings.connection_mode);
      this.rateWindowTick(chatId, ads, settings.connection_mode);
      const markets = new Map<string, { price: string | null; observedAt: number; startedAt: number }>();
      const results: Promise<WorkingAdSyncResult>[] = [];
      // Ведомых обрабатываем первыми: при смене курса ведомый сразу берёт тот
      // же топ-1, что и разведчик, не дожидаясь очередного чтения стакана.
      const ordered = [...ads].sort((a, b) => Number(Boolean(b.follow_item_id)) - Number(Boolean(a.follow_item_id)));
      for (const ad of ordered) {
        if (this.handles.get(chatId) !== handle) break;
        const key = `${chatId}:${ad.id}`;
        const marketKey = JSON.stringify([ad.token_id, ad.currency_id, ad.side, ad.price_type]);
        try {
          // Ведомому топ-1 не нужен (он копирует разведчика), а разведчик на
          // подъёме рынок не смотрит — не тратим на них общий лимит чтения,
          // чтобы проверки видимости и смена курса шли быстрее.
          const pairRace = this.races.get(`${chatId}:${ad.item_id}`);
          const skipMarket = Boolean(ad.follow_item_id) || (
            // Пока проба пары применяется, читать стакан бесполезно — прочитаем
            // сразу после ответа Bybit.
            (pairRace?.shouldHoldScan(Date.now()) ?? false) &&
            this.observations.get(key) !== undefined) || (!pairRace &&
            this.scoutModes.get(`${chatId}:${ad.item_id}`)?.mode === "climbing" &&
            this.observations.get(key) !== undefined);
          const isLeader = !ad.follow_item_id && (this.leadersByChat.get(chatId)?.has(ad.item_id) ?? false);
          const scoutMarketKey = `scout:${ad.item_id}`;
          if (!skipMarket && isLeader) {
            // Разведчик: один запрос даёт и топ-1 (смена курса), и его место в
            // стакане — видимость обновляется при каждом чтении, без отдельной
            // проверки.
            // Пара отбросила снимок как подозрительный (топ-1 откатился) —
            // сразу, без очереди, читаем ещё раз (очередь выберет другой IP),
            // чтобы подтверждение пришло через ~50–80 мс, а не на следующем круге.
            for (let attempt = 0; attempt < 1 + REVERT_CONFIRMATIONS; attempt++) {
            const urgent = attempt > 0;
            const scan = await this.scanStakanForScout({
              chatId, handle, settings,
              tokenId: ad.token_id, currencyId: ad.currency_id, side: ad.side,
              scoutItemId: ad.item_id, ads, ownUserId: account!.userId,
              extraItemIds: pairRace ? [pairRace.b] : [],
              deep: !urgent && this.wantDeepScan(pairRace),
              small: Boolean(pairRace) && pairRace!.state !== "race" && inRateWindow(),
              urgent,
            });
            if (urgent) deferredLog(`[pair] срочное чтение стакана для подтверждения (${scan.source ?? "IP"}): топ-1 ${scan.top1 ?? "-"}`);
            markets.set(scoutMarketKey, { price: scan.top1, observedAt: Date.now(), startedAt: scan.startedAt });
            if (!pairRace && scan.rivalFeed) setTimeout(scan.rivalFeed, RIVAL_FEED_DELAY_MS);
            if (pairRace) {
              pairRace.onScan({
                at: scan.startedAt,
                top1: scan.top1 === null ? null : Number(scan.top1),
                best: scan.bestOther,
                hits: scan.hits,
                ranks: scan.ranks,
                source: scan.source,
              });
              // Слежение за конкурентами — после отправки цены (время снимка
              // сохранено в самом снимке, так что задержка разбора ничего не искажает).
              if (pairRace.scanAccepted && scan.rivalFeed) setTimeout(scan.rivalFeed, RIVAL_FEED_DELAY_MS);
              // Ведомое объявление обработано в этом круге ДО чтения стакана.
              // Если по новому стакану ему нужно менять цену (например, оно
              // держатель после смены ролей) — отправляем сразу, а не на
              // следующем круге (+0,2 с).
              this.kickPairMember(chatId, pairRace, pairRace.b);
              this.checkFloatingDrift(chatId, pairRace, ads, ad.token_id, ad.currency_id, scan.hits);
            }
            if (!urgent && (!pairRace || (pairRace.scanAccepted && pairRace.state !== "race"))) {
              this.logPositions(chatId, ad, pairRace, scan, ads);
            }
            if (!pairRace || !pairRace.checkingSnapshot || pairRace.scanAccepted) break;
            }
          } else if (!skipMarket && !markets.has(marketKey)) {
            let marketStartedAt = Date.now();
            const topPrice = await withBybitConnection(settings.connection_mode, () =>
              this.read("market", () => {
                marketStartedAt = Date.now();
                return getTopPrice({
                  tokenId: ad.token_id,
                  currencyId: ad.currency_id,
                  side: ad.side,
                  userId: account!.userId,
                  ...(ad.price_type === "1" ? {
                    verificationFilter: settings.bourse_verification_filter,
                    vaMaker: false,
                    bulkMaker: settings.bourse_bulk_maker,
                    tradeWith: settings.bourse_trade_with,
                    endpoint: "v5" as const,
                  } : {}),
                });
              }, () => this.handles.get(chatId) === handle), chatId);
            markets.set(marketKey, { price: topPrice, observedAt: Date.now(), startedAt: marketStartedAt });
          }
          const skippedAt = Date.now();
          const market = skipMarket
            ? {
                price: this.observations.get(key)?.topPrice ?? ad.last_price ?? "0",
                observedAt: skippedAt, startedAt: skippedAt,
              }
            : markets.get(isLeader ? scoutMarketKey : marketKey)!;
          const topPrice: string = market.price ?? "0";
          if (!skipMarket && !positiveNumberOrNull(topPrice)) {
            throw new Error("стакан пуст или не вернул цену");
          }
          if (this.handles.get(chatId) !== handle) break;
          const previous = this.observations.get(key);
          this.emit({ kind: "market", chatId, itemId: ad.item_id, top: topPrice,
            price: ad.last_price, target: ad.last_target_price });
          // Для ведомого объявления: проверяем, виден ли лидер прямо
          // сейчас на 1-й странице стакана (по его item_id) — отдельный
          // лёгкий запрос, не общий с обычным market-опросом других
          // объявлений (у лидера может быть другая сторона/тип цены).
          // Ведомый смотрит, виден ли разведчик на страницах 1-5 стакана
          // (те же фильтры, что у кнопки "Стакан", но свои объявления не
          // исключаются). Виден — копируем его цену. Пропал со страниц 1-5 —
          // ведомый стоит, разведчик ждёт следующей смены курса.
          let followLeaderPrice: string | null = null;
          if (ad.follow_item_id && !this.raceFor(chatId, ad.item_id)) {
            const lookupKey = `${chatId}:${ad.id}`;
            const cachedLookup = this.followLookups.get(lookupKey);
            const leaderState = this.scoutModes.get(`${chatId}:${ad.follow_item_id}`);
            // Разведчик только что взял топ-1 (или держит топ-1): ведомый ставит
            // ту же цену сразу, не дожидаясь проверки стакана.
            const launching = Boolean(leaderState?.launchPrice) && leaderState?.mode !== "climbing";
            const awaitingConfirm = leaderState?.mode === "climbing" && cachedLookup !== undefined && (
              cachedLookup.at < leaderState.lastStepAt + SCOUT_CONFIRM_MS ||
              (cachedLookup.found && cachedLookup.hitPrice !== null && leaderState.currentPrice !== null &&
                Math.abs(Number(cachedLookup.hitPrice) - Number(leaderState.currentPrice)) > 0.005) ||
              (!cachedLookup.found && cachedLookup.at < leaderState.lastStepAt + SCOUT_CEILING_CONFIRM_MS));
            const lookupTtl = awaitingConfirm
              ? SCOUT_RECHECK_MS
              : leaderState?.mode === "idle"
              ? Math.max(SCOUT_IDLE_LOOKUP_MS, Number(settings.working_ads_follow_interval_ms ?? 1000))
              : Math.max(10, Number(settings.working_ads_follow_interval_ms ?? 1000));
            // Раньше, чем через SCOUT_CONFIRM_MS после шага, проверять бесполезно.
            const tooEarly = leaderState?.mode === "climbing" &&
              Date.now() < leaderState.lastStepAt + SCOUT_CONFIRM_MS;
            const cacheFresh = cachedLookup !== undefined &&
              (tooEarly || Date.now() - cachedLookup.at < lookupTtl);

            let found = cachedLookup?.found ?? false;
            let hitPrice = cachedLookup?.hitPrice ?? null;
            let bestOtherValue = cachedLookup?.bestOther ?? null;
            if (!cacheFresh) {
              const lookup = () => this.lookupScout(chatId, handle, settings, ad, ads, account?.userId);
              if (launching) {
                // Не задерживаем цену ведомого — проверяем стакан в фоне, чтобы
                // разведчик узнал, если его стало видно.
                if (!this.lookupsInFlight.has(lookupKey)) {
                  this.lookupsInFlight.add(lookupKey);
                  void lookup().catch(() => {}).finally(() => this.lookupsInFlight.delete(lookupKey));
                }
              } else {
                const fresh = await lookup();
                found = fresh.found;
                hitPrice = fresh.hitPrice;
                bestOtherValue = fresh.bestOther;
              }
            }

            if (launching) {
              followLeaderPrice = leaderState!.launchPrice;
            } else {
              // Ведомый копирует цену разведчика, если она допустимая: разведчик
              // виден, или его цена не лучше лучшей видимой цены конкурентов (то
              // есть его просто не видно среди равных). Если цена разведчика
              // выше потолка — ведомый стоит на последней допустимой цене.
              const scoutNow = leaderState?.currentPrice ?? null;
              if (found && hitPrice) {
                followLeaderPrice = hitPrice;
              } else if (scoutNow !== null && bestOtherValue !== null && (ad.side === "1"
                ? Number(scoutNow) >= bestOtherValue - 0.005
                : Number(scoutNow) <= bestOtherValue + 0.005)) {
                followLeaderPrice = scoutNow;
              } else {
                followLeaderPrice = null;
              }
            }
          }
          const observedTop = ad.follow_item_id ? (followLeaderPrice ?? topPrice) : topPrice;
          this.observations.set(key, {
            chatId, ad, settings, topPrice: observedTop, sourceKey, handle, observedAt: market.observedAt,
            marketStartedAt: market.startedAt,
            priceObservedAt: previous?.topPrice === observedTop && previous.sourceKey === sourceKey
              ? previous.priceObservedAt : market.observedAt,
            followLeaderPrice,
          });
          // One writer per Bybit item; market observations continue during verification.
          const existing = this.writers.get(ad.item_id);
          if (existing) {
            results.push(existing);
          } else if ((this.retryAfter.get(ad.item_id) ?? 0) <= Date.now()) {
            const job = this.startWriter(key, this.observations.get(key)!, notifyChanges);
            results.push(job);
          } else {
            results.push(Promise.resolve({
              ad, changed: false, previousPrice: ad.last_price, targetPrice: null,
              error: ad.last_error,
              notifyError: false,
              deferredUntil: this.retryAfter.get(ad.item_id),
            }));
          }
        } catch (error) {
          this.observations.delete(key);
          const result = await this.recordError(chatId, ad, error);
          results.push(Promise.resolve(result));
          if (notifyChanges) this.notifyDetached(chatId, [result]);
        }
      }
      this.lastChatError.delete(chatId);
      // Release the polling lock before manual callers wait for update results.
      return throwOuterError ? Promise.all(results) : [];
    } catch (error) {
      if (error instanceof ObservationExpired) return [];
      console.warn(`[working-ads] chat=${chatId} error: ${(error as Error).message}`);
      this.pauseAfterError(error);
      if (throwOuterError) throw error;
      const message = (error as Error).message;
      if (notifyChanges && this.lastChatError.get(chatId) !== message) {
        this.lastChatError.set(chatId, message);
        void this.notify(
          chatId,
          `⚠️ Автокурс рабочих объявлений: ${escapeHtml(message)}`,
        ).catch((e: unknown) => console.warn(`[working-ads] notification: ${(e as Error).message}`));
      }
      return [];
    } finally {
      handle.busy = false;
    }
  }

  private notifyDetached(chatId: number, results: WorkingAdSyncResult[]): void {
    void this.notifyResults(chatId, results).catch((e: unknown) => {
      console.warn(`[working-ads] notification: ${(e as Error).message}`);
    });
  }

  private startWriter(key: string, initial: Observation, notifyChanges: boolean): Promise<WorkingAdSyncResult> {
    const { chatId, ad, handle } = initial;
    const existing = this.writers.get(ad.item_id);
    if (existing) return existing;
    const job = this.syncOne(key).catch((e: unknown) => this.recordError(chatId, ad, e));
    this.writers.set(ad.item_id, job);
    void job.then(result => {
      if (this.writers.get(ad.item_id) !== job) return;
      this.writers.delete(ad.item_id);
      if (this.handles.get(chatId) !== handle) return;
      if (notifyChanges) this.notifyDetached(chatId, [result]);
      if (ad.price_type !== "0" || result.error || (this.retryAfter.get(ad.item_id) ?? 0) > Date.now()) return;
      try {
        const latest = this.latest(key, initial);
        if (latest.observedAt <= initial.observedAt) return;
        const target = computeTargetPrice({
          topPrice: latest.topPrice, side: latest.ad.side, step: Number(latest.settings.price_step),
          min: Number(latest.settings.price_min), max: Number(latest.settings.price_max),
          mode: latest.settings.price_mode, fixedPrice: latest.settings.price_fixed,
        });
        // Use the newest already-received observation without waiting for another market poll.
        if (target.ok && target.price !== result.targetPrice) this.startWriter(key, latest, notifyChanges);
      } catch (e) {
        if (!(e instanceof ObservationExpired)) throw e;
      }
    }).catch((e: unknown) => {
      if (this.writers.get(ad.item_id) === job) this.writers.delete(ad.item_id);
      console.warn(`[working-ads] updater: ${(e as Error).message}`);
    });
    return job;
  }

  private resolvePaymentIds(raw: PersonalItem, initial: Observation): Promise<string[]> {
    return resolveUpdatePaymentIds(raw, () => {
      const cached = this.paymentLists.get(initial.chatId);
      if (cached?.sourceKey === initial.sourceKey && cached.expiresAt > Date.now()) return cached.promise;
      const entry = {
        sourceKey: initial.sourceKey, expiresAt: Date.now() + PAYMENTS_CACHE_MS,
        promise: this.read("payments", () => listPostAdPayments(),
          () => this.handles.get(initial.chatId) === initial.handle),
      };
      entry.promise = entry.promise.catch((error: unknown) => {
        entry.expiresAt = Date.now() + 5_000;
        if (this.handles.get(initial.chatId) === initial.handle && !(error instanceof ObservationExpired)) {
          this.pauseAfterError(error);
        }
        throw error;
      });
      this.paymentLists.set(initial.chatId, entry);
      return entry.promise;
    });
  }

  private computeFollowTarget(
    observation: Observation,
    settings: Settings,
  ): { ok: true; price: string; numericPrice: number; topNumeric: number } {
    if (observation.followLeaderPrice === null) {
      // Лидер сейчас не виден на 1-й странице стакана (вылетел — ошибка,
      // квота, снят и т.п.). Ничего не пересчитываем и не трогаем —
      // держим последнюю цену как есть, это и есть "остановиться на
      // последнем курсе".
      throw new ObservationExpired();
    }
    const numericLeaderPrice = Number(observation.followLeaderPrice);
    const min = Number(settings.price_min);
    const max = Number(settings.price_max);
    const clamped = Math.min(max, Math.max(min, numericLeaderPrice));
    return {
      ok: true,
      price: clamped.toFixed(2),
      numericPrice: clamped,
      topNumeric: numericLeaderPrice,
    };
  }

  /**
   * Разведчик ищет потолок: при смене курса один раз берёт топ-1, дальше
   * сам поднимает цену на шаг, каждый раз дожидаясь свежей проверки, что он
   * всё ещё виден в стакане. Пропал со стакана — стоп до следующей смены курса.
   */
  private computeScoutTarget(
    scoutKey: string,
    observation: Observation,
    currentPrice: string,
    side: "0" | "1",
  ): { ok: true; price: string; numericPrice: number; topNumeric: number } {
    const settings = observation.settings;
    let state = this.scoutModes.get(scoutKey);
    if (!state) {
      state = this.ensureScoutState(scoutKey);
    }
    const step = Number(settings.price_step) > 0 ? Number(settings.price_step) : 0.01;
    const min = Number(settings.price_min);
    const max = Number(settings.price_max);
    const top = Number(observation.topPrice);
    const result = (value: number) => {
      const clamped = Math.min(max, Math.max(min, value));
      return { ok: true as const, price: clamped.toFixed(2), numericPrice: clamped, topNumeric: top };
    };

    if (state.mode === "idle") {
      // baseTop === null — автокурс только что включили (или бот запустился):
      // сразу берём текущий топ-1, не дожидаясь смены курса.
      if (state.tracking && Math.abs(Number(currentPrice) - top) < 0.005) {
        // Держим топ-1 и уже стоим на нём.
        state.baseTop = observation.topPrice;
        const vis = this.scoutVisibility.get(scoutKey);
        const visibleNow = vis !== undefined && vis.found &&
          vis.at >= state.lastStepAt + SCOUT_CONFIRM_MS && vis.price !== null &&
          Math.abs(Number(vis.price) - Number(currentPrice)) < 0.005;
        if (!visibleNow) throw new ObservationExpired();
        // Разведчика стало видно на страницах 1-5 — можно искать потолок.
        state.pendingTop = observation.topPrice;
        const start = result(top);
        state.launchPrice = start.price;
        return start;
      }
      if (state.baseTop !== null && state.baseTop === observation.topPrice) {
        throw new ObservationExpired();
      }
      // Курс сменился (или первый запуск) — один раз берём топ-1 Bybit.
      state.pendingTop = observation.topPrice;
      const launch = result(top);
      state.launchPrice = launch.price;
      return launch;
    }

    // climbing: рынок больше не смотрим, двигаемся от своей цены.
    const visibility = this.scoutVisibility.get(scoutKey);
    if (!visibility || visibility.at < state.lastStepAt + SCOUT_CONFIRM_MS) {
      // Ждём проверку стакана, сделанную уже после последнего шага.
      throw new ObservationExpired();
    }
    const current = Number(currentPrice);
    const up = (value: number) => (side === "1" ? value - step : value + step);
    if (visibility.found) {
      // Виден — но верим только если стакан уже показывает нашу текущую
      // цену (иначе это ещё старый снимок стакана).
      if (visibility.price === null || Math.abs(Number(visibility.price) - current) > 0.005) {
        throw new ObservationExpired();
      }
      state.visibleOnce = true;
      state.pendingNote = null;
      return result(up(current));
    }
    if (visibility.at < state.lastStepAt + SCOUT_CEILING_CONFIRM_MS) {
      // Не видно — но выводы делаем только по проверке, начатой достаточно
      // поздно после шага, чтобы стакан точно успел обновиться.
      throw new ObservationExpired();
    }
    const best = visibility.bestOther === null ? null : Number(visibility.bestOther);
    const itemId = scoutKey.split(":")[1];
    const startTracking = (reason: string) => {
      // Без видимости потолок не найти: держим топ-1 и следим за курсом.
      state.mode = "idle";
      state.tracking = true;
      state.baseTop = null; // на следующем тике сверим с актуальным топ-1
      console.log(`[working-ads] scout hold item=${itemId} price=${currentPrice} (${reason} — держу топ-1 и слежу за курсом)`);
      throw new ObservationExpired();
    };
    if (!state.visibleOnce) startTracking(`не виден на страницах 1-${FOLLOW_PAGES}`);
    const beyond = best === null || (side === "1" ? current < best - 0.005 : current > best + 0.005);
    if (!beyond) {
      // Не потолок: наша цена не лучше лучшей видимой.
      if (Math.abs(current - best!) < 0.005) {
        // Стоим на лучшей видимой цене, но нас не показывают — держим топ-1.
        startTracking(`на лучшей видимой ${best!.toFixed(2)}, но не показан`);
      }
      // Нас перебили — встаём на лучшую видимую цену (топ).
      state.pendingNote = `перебили — встал на лучшую видимую ${best!.toFixed(2)}`;
      return result(best!);
    }
    // Наша цена лучше всех видимых, а нас не показывают — это потолок.
    state.mode = "idle";
    state.tracking = false;
    state.launchPrice = null;
    // Сравниваем с курсом, с которого начинали: если за время подъёма
    // курс уже сменился, на следующем тике сразу возьмём новый топ-1.
    state.baseTop = state.startTop ?? observation.topPrice;
    console.log(`[working-ads] scout stop item=${scoutKey.split(":")[1]} price=${currentPrice} ` +
      `(лучше лучшей видимой ${best === null ? "-" : best.toFixed(2)} и не показан — потолок найден, ждём смены курса)`);
    throw new ObservationExpired();
  }

  private ensureScoutState(scoutKey: string) {
    let state = this.scoutModes.get(scoutKey);
    if (!state) {
      state = {
        mode: "idle", baseTop: null, lastStepAt: 0, startTop: null,
        pendingTop: null, pendingNote: null, currentPrice: null, launchPrice: null,
        tracking: false, visibleOnce: false,
      };
      this.scoutModes.set(scoutKey, state);
    }
    return state;
  }

  private async syncOne(key: string): Promise<WorkingAdSyncResult> {
    const initial = this.latest(key);
    const preparationStartedAt = Date.now();
    const { chatId, ad, settings } = initial;
    // Разбивка подготовки изменения (prepare_ms) — куда ушло время.
    const prep = { detailsMs: 0, detailsFrom: "cache", paymentsMs: 0, limitWaitMs: 0 };
    return withBybitConnection(
      settings.connection_mode,
      async () => {
        const readDetails = () => this.read("details", () => getOwnAdDetails(ad.item_id),
          () => this.handles.get(chatId) === initial.handle);
        const cached = this.detailsCache.get(key);
        let fromCache = cached?.sourceKey === initial.sourceKey && cached.expiresAt > Date.now();
        const pairMember = this.raceFor(chatId, ad.item_id) !== undefined;
        if (!fromCache && pairMember && cached?.sourceKey === initial.sourceKey) {
          // В паре не ждём чтения объявления перед изменением цены: берём
          // сохранённые данные сразу, а обновляем их в фоне. Иначе в момент
          // смены курса первое изменение ждёт ещё ~0,1 с на это чтение.
          fromCache = true;
          // Во время гонки не обновляем данные в фоне: этот запрос может встать
          // в очередь Bybit рядом с изменением цены и задержать его.
          // В окне смены курса тоже не обновляем: данные обновлены заранее (за
          // минуту до окна), а лишние запросы по ключу рядом с изменением цены
          // могут дать отказ 10006.
          if (!this.detailsRefreshing.has(key) && this.raceFor(chatId, ad.item_id)?.state !== "race" &&
              !inRateWindow()) {
            this.detailsRefreshing.add(key);
            void readDetails()
              .then((fresh) => {
                this.detailsCache.set(key, {
                  raw: fresh, sourceKey: initial.sourceKey, expiresAt: Date.now() + detailsTtl(fresh),
                });
              })
              .catch(() => {})
              .finally(() => this.detailsRefreshing.delete(key));
          }
        }
        const detailsStartedAt = Date.now();
        let raw = fromCache ? cached!.raw : await readDetails();
        if (!fromCache) {
          prep.detailsMs += Date.now() - detailsStartedAt;
          prep.detailsFrom = cached ? "read(устарели)" : "read(нет в памяти)";
        }
        let details = normalizeWorkingAdDetails(raw, ad.item_id);
        if (!details.online) {
          throw new Error("объявление не активно (Bybit status не ONLINE)");
        }
        if (details.tokenId !== ad.token_id || details.currencyId !== ad.currency_id ||
            details.side !== ad.side || details.priceType !== ad.price_type) {
          await updateWorkingAdState(chatId, ad.id, {
            tokenId: details.tokenId, currencyId: details.currencyId,
            side: details.side, priceType: details.priceType,
          });
          throw new ObservationExpired();
        }
        // Прочитанные данные сохраняем сразу. Раньше они сохранялись только
        // после расчёта цены, а у пары, которой менять нечего, расчёт
        // прерывается раньше — и бот читал объявление снова и снова (раз в
        // секунду), а в момент смены курса нужное чтение ждало в очереди.
        if (!fromCache) {
          this.detailsCache.set(key, {
            raw, sourceKey: initial.sourceKey, expiresAt: Date.now() + detailsTtl(raw),
          });
        }
        // Показываем в списке фактическую цену с Bybit, даже если дальше
        // объявление стоит (разведчик остановлен) и цикл прервётся раньше.
        if (details.price && details.price !== ad.last_price) {
          await updateWorkingAdState(chatId, ad.id, {
            lastPrice: details.price,
            checkedAt: new Date(),
          });
        }
        const scoutKey = `${chatId}:${ad.item_id}`;
        const race = this.raceFor(chatId, ad.item_id);
        if (race) {
          const hadTarget = race.target(ad.item_id) !== null;
          race.onCurrentPrice(ad.item_id, Number(details.price), Date.now());
          if (hadTarget && race.target(ad.item_id) === null) this.kickPairMember(chatId, race, race.other(ad.item_id));
        }
        const isScout = !race && !ad.follow_item_id && (this.leadersByChat.get(chatId)?.has(ad.item_id) ?? false);
        if (isScout) this.ensureScoutState(scoutKey).currentPrice = details.price;
        const calculate = () => {
          const observation = this.latest(key, initial);
          const step = Number(observation.settings.price_step);
          const raceTarget = race ? race.target(ad.item_id) : null;
          if (race && raceTarget === null) throw new ObservationExpired();
          const target = raceTarget !== null
            ? { ok: true as const, price: raceTarget, numericPrice: Number(raceTarget), topNumeric: Number(raceTarget) }
            : ad.follow_item_id
            ? this.computeFollowTarget(observation, observation.settings)
            : isScout
            ? this.computeScoutTarget(scoutKey, observation, details.price, details.side)
            : computeTargetPrice({
                topPrice: observation.topPrice,
                side: details.side,
                step,
                min: Number(observation.settings.price_min),
                max: Number(observation.settings.price_max),
                mode: observation.settings.price_mode,
                fixedPrice: observation.settings.price_fixed,
              });
          if (!target.ok) throw new Error(target.reason);
          // Точность floating обеспечивают свежие данные (обновляются в фоне раз
          // в 5 с): при точном эталоне обычное округление процента всегда даёт
          // нужную копейку (ошибка не больше ±0,0042 ₽).
          // Процент floating считаем от свежего эталона из стакана, если он есть;
          // иначе — по сохранённым цене и проценту объявления.
          const reference = details.priceType === "1"
            ? this.stakanReference.get(`${details.tokenId}|${details.currencyId}`)
            : undefined;
          const freshReference = reference && Date.now() - reference.at <= STAKAN_REFERENCE_MAX_AGE_MS
            ? reference.value : null;
          const floating = details.priceType !== "1" ? null
            : freshReference !== null
            ? floatingPlanFromReference(freshReference, details.premium, target.price)
            : computeStableFloatingPlan({
                currentPrice: details.price, currentPremium: details.premium,
                targetPrice: target.price,
              });
          return {
            price: target.price,
            premium: floating?.premium ?? "",
            changed: floating?.changed ?? (Number(details.price).toFixed(2) !== target.price),
            // Цена, которую покажет Bybit для floating (если процент посчитан от
            // эталона из стакана).
            predicted: floating?.predictedPrice,
          };
        };
        let plan = calculate();
        // Перед изменением бот перечитывает объявление, если данные взяты из
        // кэша. В паре этого не делаем: данные обновляются после каждого
        // изменения, а лишний запрос в момент смены курса — это отказы Bybit.
        if (plan.changed && fromCache && !race) {
          const rereadStartedAt = Date.now();
          raw = await readDetails();
          prep.detailsMs += Date.now() - rereadStartedAt;
          prep.detailsFrom = "reread";
          details = normalizeWorkingAdDetails(raw, ad.item_id);
          if (!details.online || details.priceType !== ad.price_type || details.side !== ad.side ||
              details.tokenId !== ad.token_id || details.currencyId !== ad.currency_id) {
            this.detailsCache.delete(key);
            throw new ObservationExpired();
          }
          fromCache = false;
          plan = calculate();
        }
        if (!fromCache) this.detailsCache.set(key, {
          raw, sourceKey: initial.sourceKey, expiresAt: Date.now() + detailsTtl(raw),
        });
        const previousPrice = details.price;
        let appliedPrice = details.price;

        if (plan.changed) {
          const paymentsStartedAt = Date.now();
          const paymentIds = await this.resolvePaymentIds(raw, initial);
          prep.paymentsMs = Date.now() - paymentsStartedAt;
          const paymentPassword =
            settings.payment_password ||
            config.bybit.paymentPassword ||
            undefined;
          plan = calculate();
          let sentAt = 0;
          let sentObservation = initial;
          // Для пары "увидел" = момент, когда пара решила поставить эту цену
          // (у ведомого своего чтения стакана нет, его старая метка бессмысленна).
          const seenAt = () => race?.targetSince(ad.item_id) ?? sentObservation.priceObservedAt;
          let waitedForLimit = false;
          const beforeSend = async () => {
            for (;;) {
              // Второе объявление пары, которое ждало слот лимита: перед отправкой
              // дожидаемся свежего чтения стакана — за время ожидания курс мог
              // смениться, и тогда слот нужнее держателю (цель пересчитается).
              // Свежий снимок уже есть (принят меньше PROBE_FRESH_ENOUGH_MS назад) —
              // не ждём следующего: цель и так пересчитается ниже по нему.
              if (race && !race.isHolder(ad.item_id) && (race.checkingSnapshot ||
                  (waitedForLimit && Date.now() - race.lastAcceptedScanAt > PROBE_FRESH_ENOUGH_MS))) {
                waitedForLimit = false;
                for (let i = 0; PROBE_FRESH_SCAN_WAIT_MS > 0 && i < 3; i++) {
                  await race.waitNextScan(PROBE_FRESH_SCAN_WAIT_MS);
                  if (!race.checkingSnapshot) break;
                }
              }
              // FIRST_UPDATE_DELAY_MS: первое изменение после смены курса — не
              // раньше чем через столько мс (Bybit в первые доли секунды почти
              // всегда отвечает 10006). Цель пересчитается после ожидания.
              if (race && FIRST_UPDATE_DELAY_MS > 0) {
                const wait = race.firstSendWait(Date.now(), FIRST_UPDATE_DELAY_MS);
                if (wait > 0) await sleep(wait);
              }
              await this.assertCanUpdate(key, initial);
              const latestPlan = calculate();
              if (latestPlan.price !== plan.price || latestPlan.premium !== plan.premium) {
                throw new ObservationExpired();
              }
              try {
                reserveWorkingAdUpdate(details.itemId, Date.now(),
                  this.latest(key, initial).settings.working_ads_update_interval_ms,
                  this.chatItemIds.get(chatId),
                  // Возврат вниз под потолок не блокируем внутренним лимитом:
                  // иначе объявление минутами стоит выше потолка и не видно.
                  Boolean(race && race.isRetreat(ad.item_id, Number(latestPlan.predicted ?? latestPlan.price))));
                sentAt = Date.now();
                race?.markSent();
                this.lastWriteSentAt = sentAt;
                sentObservation = this.latest(key, initial);
                return;
              } catch (error) {
                if (!(error instanceof WorkingAdUpdateDeferred) || error.retryAt - Date.now() > 1_000) throw error;
                const waitStartedAt = Date.now();
                await sleep(Math.max(1, error.retryAt - Date.now()));
                prep.limitWaitMs += Date.now() - waitStartedAt;
                waitedForLimit = true;
              }
            }
          };
          if (plan.changed && details.priceType === "1") {
            const after = await this.updateFloatingUntilApplied({
              details,
              paymentIds,
              targetPrice: plan.predicted ?? plan.price,
              nextPremium: plan.premium,
              paymentPassword,
              beforeSend,
              readDetails,
              verifyDelayMs: isScout || race ? SCOUT_VERIFY_DELAY_MS : UPDATE_VERIFY_DELAY_MS,
              // Быстрый режим (без повторного чтения объявления). Если процент
              // посчитан от эталона из стакана, реальная цена известна заранее —
              // перечитывать не нужно. Иначе прыгающему floating в паре нужна его
              // реальная цена — тогда перечитываем.
              fastRaw: race
                ? (race.isProber(ad.item_id) && plan.predicted === undefined ? undefined : raw)
                : (ad.follow_item_id ? raw : undefined),
            });
            appliedPrice = String(after.price ?? plan.price);
            {
              const respondedAt = Date.now();
              console.log(`[working-ads] floating item=${details.itemId} price=${appliedPrice} premium=${plan.premium} ` +
                `seen=${new Date(seenAt()).toISOString()} sent=${new Date(sentAt).toISOString()} ` +
                `prepare_ms=${sentAt - preparationStartedAt} seen_to_send_ms=${sentAt - seenAt()} ` +
                `total_ms=${respondedAt - sentAt} host=${lastUpdateHost()} result=api_ok ` +
                `prep[details=${prep.detailsFrom} ${prep.detailsMs}мс, payments=${prep.paymentsMs}мс, limit_wait=${prep.limitWaitMs}мс]`);
            }
            this.detailsCache.set(key, {
              raw: after, sourceKey: initial.sourceKey, expiresAt: Date.now() + detailsTtl(after),
            });
          } else if (plan.changed) {
            await updateAd({
              itemId: details.itemId,
              priceType: details.priceType,
              premium: plan.premium,
              price: plan.price,
              minAmount: details.minAmount,
              maxAmount: details.maxAmount,
              remark: details.remark,
              tradingPreferenceSet: details.tradingPreferenceSet,
              paymentIds,
              quantity: details.quantity,
              paymentPeriod: details.paymentPeriod,
              paymentPassword,
              beforeSend,
            });
            const respondedAt = Date.now();
            this.emit({ kind: "update", chatId, sample: { at: respondedAt, itemId: details.itemId,
              price: plan.price, marketMs: sentObservation.observedAt - sentObservation.marketStartedAt,
              prepareMs: sentAt - preparationStartedAt, seenToSendMs: sentAt - seenAt(),
              apiMs: respondedAt - sentAt } });
            console.log(`[working-ads] fixed item=${details.itemId} price=${plan.price} ` +
              `seen=${new Date(seenAt()).toISOString()} sent=${new Date(sentAt).toISOString()} ` +
              `market_ms=${sentObservation.observedAt - sentObservation.marketStartedAt} ` +
              `prepare_ms=${sentAt - preparationStartedAt} seen_to_send_ms=${sentAt - seenAt()} ` +
              `api_ms=${respondedAt - sentAt} host=${lastUpdateHost()} result=api_ok ` +
              `prep[details=${prep.detailsFrom} ${prep.detailsMs}мс, payments=${prep.paymentsMs}мс, limit_wait=${prep.limitWaitMs}мс]`);
            appliedPrice = plan.price;
            this.detailsCache.set(key, {
              raw: { ...raw, price: plan.price }, sourceKey: initial.sourceKey,
              expiresAt: Date.now() + DETAILS_CACHE_MS,
            });
          }
        } else if (!fromCache) {
          // Resolve legacy payment types before a price change, without delaying the market scanner.
          void this.resolvePaymentIds(raw, initial).catch(() => {});
        }

        if (isScout && !plan.changed) {
          // Разведчик уже стоит на нужном топ-1 — изменение не требуется, но
          // подъём всё равно начинаем (иначе он бы так и ждал).
          const state = this.scoutModes.get(scoutKey);
          if (state && state.mode === "idle" && state.launchPrice !== null &&
              Math.abs(Number(state.launchPrice) - Number(details.price)) < 0.005) {
            state.startTop = state.pendingTop;
            state.tracking = false;
            state.visibleOnce = false;
            state.mode = "climbing";
            state.lastStepAt = Date.now();
            state.currentPrice = details.price;
            console.log(`[working-ads] scout start item=${ad.item_id} price=${details.price} (уже стоит на топ-1 — начинаю подъём)`);
          }
        }
        if (plan.changed) this.lastPriceChangeAt.set(ad.item_id, Date.now());
        if (race && plan.changed) {
          race.onApplied(ad.item_id, Number(appliedPrice), Date.now());
          // Ответ Bybit мог открыть прыжок второму объявлению — запускаем его
          // сразу, не дожидаясь следующего круга (он ждёт очередь стакана ~0,7 с).
          this.kickPairMember(chatId, race, race.other(ad.item_id));
        }
        if (isScout && plan.changed) {
          const state = this.scoutModes.get(scoutKey);
          if (state) {
            if (state.mode === "idle" && state.tracking) {
              // Режим "держу топ-1": просто встали на новый топ-1 и остаёмся в
              // этом режиме — без круга с проверкой видимости, чтобы на серии
              // смен курса реагировать сразу. Если разведчик окажется виден,
              // подъём начнётся сам (см. computeScoutTarget).
              state.baseTop = state.pendingTop;
              state.lastStepAt = Date.now();
              state.currentPrice = appliedPrice;
              console.log(`[working-ads] scout hold item=${ad.item_id} price=${appliedPrice} (курс сменился — встал на новый топ-1)`);
            } else {
              if (state.mode === "idle") {
                state.startTop = state.pendingTop;
                state.tracking = false;
                state.visibleOnce = false;
                console.log(`[working-ads] scout start item=${ad.item_id} price=${appliedPrice} (курс сменился — взял топ-1)`);
              } else {
                state.launchPrice = null;
                console.log(`[working-ads] scout step item=${ad.item_id} price=${appliedPrice}` +
                  (state.pendingNote ? ` (${state.pendingNote})` : ""));
              }
              state.mode = "climbing";
              state.lastStepAt = Date.now();
              state.currentPrice = appliedPrice;
            }
          }
        }

        this.limitStrikes.delete(ad.item_id); // проверка прошла — счётчик отказов сбрасываем
        const persist = plan.changed || !fromCache || ad.last_error || ad.last_target_price !== plan.price;
        const updated = persist ?
          (await updateWorkingAdState(chatId, ad.id, {
            tokenId: details.tokenId,
            currencyId: details.currencyId,
            side: details.side,
            priceType: details.priceType,
            lastPrice: plan.changed ? appliedPrice : details.price,
            lastTargetPrice: plan.price,
            lastError: null,
            checkedAt: new Date(),
            ...(plan.changed ? { priceUpdatedAt: new Date() } : {}),
          })) ?? ad : ad;
        return {
          ad: updated,
          changed: plan.changed,
          previousPrice,
          targetPrice: plan.changed ? appliedPrice : details.price,
          error: null,
        };
      },
      chatId,
    );
  }

  private async updateFloatingUntilApplied(args: {
    details: NormalizedAdDetails;
    paymentIds: string[];
    targetPrice: string;
    nextPremium: string;
    paymentPassword?: string;
    beforeSend: () => Promise<void>;
    readDetails: () => Promise<PersonalItem>;
    verifyDelayMs?: number;
    // Быстрый режим: после ответа Bybit "OK" не ждём и не перечитываем
    // объявление, а сразу считаем цену применённой (на основе этих данных).
    // Если Bybit на деле не применил — это всплывёт при следующем чтении.
    fastRaw?: PersonalItem;
  }): Promise<PersonalItem> {
    const candidates: Array<{
      price: string;
      tradingPreferenceSet: TradingPreferenceSet;
    }> = [
      {
        price: args.targetPrice,
        tradingPreferenceSet: args.details.tradingPreferenceSet,
      },
      {
        price: "",
        tradingPreferenceSet: args.details.tradingPreferenceSet,
      },
      {
        price: args.targetPrice,
        tradingPreferenceSet: {},
      },
    ];

    let lastAfter: PersonalItem | null = null;
    let lastError: unknown = null;
    for (let index = 0; index < candidates.length; index++) {
      const candidate = candidates[index]!;
      try {
        await updateAd({
          itemId: args.details.itemId,
          priceType: "1",
          premium: args.nextPremium,
          price: candidate.price,
          minAmount: args.details.minAmount,
          maxAmount: args.details.maxAmount,
          remark: args.details.remark,
          tradingPreferenceSet: candidate.tradingPreferenceSet,
          paymentIds: args.paymentIds,
          quantity: args.details.quantity,
          paymentPeriod: args.details.paymentPeriod,
          paymentPassword: args.paymentPassword,
          beforeSend: args.beforeSend,
        });
      } catch (error) {
        if (error instanceof ObservationExpired || error instanceof WorkingAdUpdateDeferred) throw error;
        lastError = error;
        const message = (error as Error).message;
        console.warn(`[working-ads] floating update failed #${index + 1}: ${message}`);
        if (
          error instanceof BybitApiError &&
          (error.code === 10001 || error.code === 912300014)
        ) {
          continue;
        }
        throw error;
      }

      if (args.fastRaw) {
        return { ...args.fastRaw, price: args.targetPrice, premium: args.nextPremium };
      }
      await sleep(args.verifyDelayMs ?? UPDATE_VERIFY_DELAY_MS);
      lastAfter = await args.readDetails();
      const actualPremium = positiveNumberOrNull(lastAfter.premium);
      const actualPrice = positiveNumberOrNull(lastAfter.price);
      if (
        (actualPremium !== null &&
          Math.abs(actualPremium - Number(args.nextPremium)) < 0.01) ||
        (actualPrice !== null &&
          Math.abs(actualPrice - Number(args.targetPrice)) < 0.01)
      ) {
        return lastAfter;
      }
    }

    if (lastError) {
      throw new Error(
        `Bybit не применил premium. Последняя ошибка: ${(lastError as Error).message}`,
      );
    }
    throw new Error(
      `Bybit ответил OK, но premium не изменился. Сейчас price=${lastAfter?.price ?? "?"}, premium=${lastAfter?.premium ?? "?"}`,
    );
  }

  private async connectionKey(chatId: number, settings: Settings): Promise<string> {
    if (settings.connection_mode === "api") {
      const account = await getActiveApiAccount(chatId);
      return `api:${account?.id ?? "env"}:${account?.keyHint ?? ""}`;
    }
    const session = await authService.getCurrent();
    return `session:${session?.bybitUid ?? ""}`;
  }

  private latest(key: string, initial?: Observation): Observation {
    const observation = this.observations.get(key);
    if (!observation || this.handles.get(observation.chatId) !== observation.handle ||
        (initial && (initial.handle !== observation.handle || initial.sourceKey !== observation.sourceKey)) ||
        Date.now() < this.pausedUntil ||
        Date.now() - observation.observedAt > Math.max(2_000, Math.min(10_000, observation.handle.intervalMs * 2))) {
      throw new ObservationExpired();
    }
    return observation;
  }

  private async assertCanUpdate(key: string, initial: Observation): Promise<void> {
    // Проверки в базе (настройки, объявление, API-аккаунт) держим в памяти
    // ASSERT_CACHE_MS: при смене курса это экономит ~15 мс перед отправкой.
    const cached = this.assertCache.get(key);
    const observation0 = this.latest(key, initial);
    if (cached && Date.now() - cached.at < ASSERT_CACHE_MS &&
        cached.settingsJson === JSON.stringify(observation0.settings) && cached.sourceKey === initial.sourceKey) {
      return;
    }
    const settings = await ensureSettings(initial.chatId);
    const ad = await getWorkingAd(initial.chatId, initial.ad.id);
    const sourceKey = await this.connectionKey(initial.chatId, settings);
    const observation = this.latest(key, initial);
    if (!settings.working_ads_enabled || !ad?.enabled || sourceKey !== initial.sourceKey ||
        JSON.stringify(settings) !== JSON.stringify(observation.settings)) {
      this.assertCache.delete(key);
      throw new ObservationExpired();
    }
    this.assertCache.set(key, { at: Date.now(), settingsJson: JSON.stringify(settings), sourceKey });
  }

  private async read<T>(kind: string, request: () => Promise<T>, active: () => boolean, urgent = false): Promise<T> {
    for (;;) {
      if (!active() || Date.now() < this.pausedUntil) throw new ObservationExpired();
      // Срочное чтение (подтвердить подозрительный снимок) — без очереди.
      if (urgent) break;
      const delay = (this.nextReadAt.get(kind) ?? 0) - Date.now();
      if (delay <= 0) break;
      await sleep(Math.min(delay, READ_SPACING_MS));
    }
    // No catch-up bursts when a timer fires late; shared by all working-ad chats.
    this.nextReadAt.set(kind, Date.now() + (
      kind === "market" ? marketReadSpacingMs()
        : kind === "details" ? DETAILS_READ_SPACING_MS
        : READ_SPACING_MS));
    try {
      return await request();
    } catch (error) {
      const value = error as { code?: number; status?: number; message?: string };
      if (value.code === 10006 || value.status === 10006 || value.status === 429 ||
          /too many|rate.?limit/i.test(value.message ?? "")) {
        console.warn(`[rate-limit] отказ Bybit на чтении "${kind === "market" ? "стакан" : kind}"`);
      }
      throw error;
    }
  }

  private isRateLimitError(error: unknown): boolean {
    const value = error as { code?: number; status?: number; message?: string };
    return value.code === 10006 || value.status === 10006 || value.status === 429 ||
      /too many|rate.?limit/i.test(value.message ?? "");
  }

  /** Временный сбой Bybit: таймаут сервера, сеть, лимит. Данные при этом не устарели. */
  private isTransientError(error: unknown): boolean {
    const value = error as { code?: number; status?: number; message?: string; name?: string };
    const message = value.message ?? "";
    return value.code === 10000 || value.status === 10000 || value.code === 10006 || value.status === 10006 ||
      value.status === 429 || value.name === "TimeoutError" || value.name === "AbortError" ||
      /server timeout|timed? ?out|fetch failed|ECONNRESET|ETIMEDOUT|too many|rate.?limit/i.test(message);
  }

  private pauseAfterError(error: unknown): void {
    const value = error as { code?: number; status?: number; message?: string; endpoint?: string };
    const message = value.message ?? "";
    const forbidden = value.status === 403 || /HTTP 403|access too frequent/i.test(message);
    const limited = value.code === 10006 || value.status === 10006 ||
      value.status === 429 || /HTTP 429|too many|rate.?limit/i.test(message);
    let delay: number;
    if (forbidden) delay = 600_000;
    // Лимит публичного стакана (по IP) — ждём, пока он сбросится (5 с).
    else if (limited && value.endpoint === "stakan") delay = STAKAN_LIMIT_PAUSE_MS;
    // Лимит API аккаунта (чтение/изменение объявления) стакан не затрагивает —
    // весь бот не останавливаем.
    else if (limited) delay = 0;
    // Таймаут/сбой сервера Bybit — не останавливаем бота, объявление просто
    // повторит попытку.
    else if (this.isTransientError(error)) delay = 0;
    else delay = 2_000;
    if (delay > 0) this.pausedUntil = Math.max(this.pausedUntil, Date.now() + delay);
  }

  private async recordError(chatId: number, ad: WorkingAdRow, error: unknown): Promise<WorkingAdSyncResult> {
    if (error instanceof ObservationExpired) {
      return { ad, changed: false, previousPrice: ad.last_price, targetPrice: null, error: null };
    }
    if (error instanceof WorkingAdUpdateDeferred) {
      this.retryAfter.set(ad.item_id, error.retryAt);
      if (error.reason) {
        console.warn(`[limit] item=…${ad.item_id.slice(-4)}: ${error.reason} — изменение цены отложено на ` +
          `${Math.max(0, Math.round((error.retryAt - Date.now()) / 100) / 10)} с`);
      }
      return {
        ad, changed: false, previousPrice: ad.last_price, targetPrice: null,
        error: null, deferredUntil: error.retryAt,
      };
    }
    this.pauseAfterError(error);
    console.warn(`[working-ads] error item=${ad.item_id}: ${(error as Error).message}`);
    if (this.isRateLimitError(error)) {
      // Отказ по лимиту: данные не сбрасываем, повторяем с растущей паузой.
      const strikes = (this.limitStrikes.get(ad.item_id) ?? 0) + 1;
      this.limitStrikes.set(ad.item_id, strikes);
      const wait = Math.min(LIMIT_RETRY_MAX_MS, LIMIT_RETRY_BASE_MS * 2 ** (strikes - 1));
      this.retryAfter.set(ad.item_id, Date.now() + wait);
      console.warn(`[working-ads] item=${ad.item_id}: отказ по лимиту ${strikes}-й подряд, следующая попытка через ${wait} мс`);
      // Держатель пары получил отказ — на курс сразу ставим второе объявление.
      const race = this.raceFor(chatId, ad.item_id);
      if (race?.onRejected(ad.item_id, Date.now())) {
        this.kickPairMember(chatId, race, race.other(ad.item_id));
      }
    } else if (this.isTransientError(error)) {
      // Таймаут сервера Bybit: данные не устарели — быстро повторяем.
      this.retryAfter.set(ad.item_id, Date.now() + TRANSIENT_RETRY_MS);
    } else {
      this.retryAfter.set(ad.item_id, Date.now() + 5_000);
      this.detailsCache.delete(`${chatId}:${ad.id}`);
      this.paymentLists.delete(chatId);
    }
    const message = (error as Error).message;
    this.emit({ kind: "error", chatId, itemId: ad.item_id, message });
    const updated = (await updateWorkingAdState(chatId, ad.id, {
      lastError: message, checkedAt: new Date(),
    })) ?? ad;
    return {
      ad: updated, changed: false, previousPrice: ad.last_price,
      targetPrice: null, error: message, notifyError: ad.last_error !== message,
    };
  }

  private async notifyResults(
    chatId: number,
    results: WorkingAdSyncResult[],
  ): Promise<void> {
    const errors = results.filter(
      (result) => result.error && result.notifyError !== false,
    );
    if (errors.length === 0) return;

    const lines = ["💼 <b>Рабочие объявления</b>"];
    for (const result of errors) {
      lines.push(
        `⚠️ <code>${result.ad.item_id}</code>: ${escapeHtml(result.error ?? "")}`,
      );
    }
    await this.notify(chatId, lines.join("\n"));
  }

  private async assertNotManagedByBot(
    chatId: number,
    itemId: string,
  ): Promise<void> {
    const cycle = await getActiveCycleByChat(chatId);
    if (
      cycle &&
      [cycle.current_item_id, cycle.secondary_item_id].some(
        (id) => id && String(id) === itemId,
      )
    ) {
      throw new Error(
        "Это объявление уже управляется автоциклом. Добавь отдельное рабочее объявление.",
      );
    }
    const manualAds = await listActiveManualAds(chatId);
    if (manualAds.some((manualAd) => manualAd.item_id === itemId)) {
      throw new Error(
        "Это объявление создано ручным режимом бота и уже управляется им.",
      );
    }
  }
}

export function normalizeWorkingAdDetails(
  details: PersonalItem,
  fallbackItemId: string,
): NormalizedAdDetails {
  const itemId = String(details.id ?? details.itemId ?? fallbackItemId);
  const tokenId = requiredString(details.tokenId, "tokenId");
  const currencyId = requiredString(details.currencyId, "currencyId");
  const sideRaw = String(details.side ?? "");
  if (sideRaw !== "0" && sideRaw !== "1") {
    throw new Error(`неизвестная сторона объявления: ${sideRaw || "—"}`);
  }
  const priceTypeRaw = String(details.priceType ?? "0");
  if (priceTypeRaw !== "0" && priceTypeRaw !== "1") {
    throw new Error(`неизвестный тип цены: ${priceTypeRaw}`);
  }
  const price = requiredPositiveString(details.price, "price");
  const quantity = requiredPositiveString(
    details.lastQuantity ?? details.quantity,
    "quantity",
  );
  const minAmount = requiredPositiveString(details.minAmount, "minAmount");
  const maxAmount = requiredPositiveString(details.maxAmount, "maxAmount");
  const paymentPeriod = requiredPositiveString(
    details.paymentPeriod,
    "paymentPeriod",
  );
  const paymentIds = extractPaymentIds(details);
  if (paymentIds.length === 0) {
    throw new Error("Bybit не вернул реквизиты объявления");
  }
  const status = details.status;
  const online =
    status !== undefined && status !== null
      ? String(status) === "10"
      : details.showStatus === "ONLINE" || details.isOnline !== false;

  return {
    itemId,
    tokenId,
    currencyId,
    side: sideRaw,
    priceType: priceTypeRaw,
    price,
    premium: String(details.premium ?? ""),
    quantity,
    minAmount,
    maxAmount,
    remark: String(details.remark ?? ""),
    paymentPeriod,
    paymentIds,
    tradingPreferenceSet: normalizeTradingPreferences(
      details.tradingPreferenceSet,
    ),
    online,
  };
}

function extractPaymentIds(details: PersonalItem): string[] {
  const termIds = (details.paymentTerms ?? [])
    .map((term) => String(term.id ?? term.paymentId ?? ""))
    .filter((id) => id && id !== "-1");
  if (termIds.length > 0) return [...new Set(termIds)];

  const values = details.paymentIds ?? details.payments ?? [];
  const ids = values
    .map((value) => {
      if (typeof value === "string" || typeof value === "number") {
        return String(value);
      }
      return String(
        value.id ?? value.paymentId ?? value.paymentType ?? "",
      );
    })
    .filter(Boolean);
  return [...new Set(ids)];
}

async function resolveUpdatePaymentIds(
  details: PersonalItem,
  getAvailable: typeof listPostAdPayments = listPostAdPayments,
): Promise<string[]> {
  const termIds = (details.paymentTerms ?? [])
    .map((term) => String(term.id ?? term.paymentId ?? ""))
    .filter((id) => id && id !== "-1");
  if (termIds.length > 0) return [...new Set(termIds)];

  const directIds = (details.paymentIds ?? [])
    .map(String)
    .filter((id) => id && id !== "-1");
  if (directIds.length > 0) return [...new Set(directIds)];

  const typeIds = (details.payments ?? [])
    .map((value) => {
      if (typeof value === "string" || typeof value === "number") {
        return String(value);
      }
      return String(value.paymentType ?? "");
    })
    .filter(Boolean);
  if (typeIds.length === 0) {
    throw new Error("Bybit не вернул реквизиты объявления");
  }

  const available = await getAvailable();
  const typeSet = new Set(typeIds);
  const mapped = available
    .filter((payment) => typeSet.has(String(payment.paymentType ?? "")))
    .map((payment) => String(payment.id))
    .filter((id) => id && id !== "-1");
  if (mapped.length === 0) {
    throw new Error(
      `Не удалось сопоставить реквизиты объявления с аккаунтом. Типы: [${typeIds.join(", ")}].`,
    );
  }
  return [...new Set(mapped)];
}

function normalizeTradingPreferences(
  value: Record<string, unknown> | undefined,
): TradingPreferenceSet {
  const source = value ?? {};
  const keys = [
    "isKyc",
    "hasCompleteRateDay30",
    "completeRateDay30",
    "hasOrderFinishNumberDay30",
    "orderFinishNumberDay30",
    "isMobile",
    "isEmail",
    "hasUnPostAd",
    "hasRegisterTime",
    "registerTimeThreshold",
    "hasNationalLimit",
    "nationalLimit",
    "hasSingleUserOrderLimit",
    "singleUserOrderLimit",
  ] as const;
  const result: Record<string, string> = {};
  for (const key of keys) {
    if (source[key] !== undefined && source[key] !== null) {
      result[key] = String(source[key]);
    }
  }
  return result as TradingPreferenceSet;
}

function requiredString(value: unknown, field: string): string {
  const text = String(value ?? "").trim();
  if (!text) throw new Error(`Bybit не вернул ${field}`);
  return text;
}

function requiredPositiveString(value: unknown, field: string): string {
  const text = requiredString(value, field);
  const number = Number(text);
  if (!Number.isFinite(number) || number <= 0) {
    throw new Error(`некорректный ${field}: ${text}`);
  }
  return text;
}

function positiveNumber(value: unknown, field: string): number {
  const number = positiveNumberOrNull(value);
  if (number === null) {
    throw new Error(`Некорректная ${field}: ${String(value ?? "—")}`);
  }
  return number;
}

function positiveNumberOrNull(value: unknown): number | null {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : null;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}
