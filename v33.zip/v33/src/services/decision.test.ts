import { describe, it } from "node:test";
import { strict as assert } from "node:assert";
import {
  decideAfterRankCheck,
  nextCycleStatus,
  shouldCancelBeforeRecreate,
} from "./decision.js";

describe("decideAfterRankCheck (топ-10 по умолчанию)", () => {
  it("rank=1 → stop_recreate", () => {
    const action = decideAfterRankCheck({ rank: 1, page: 1 });
    assert.equal(action.kind, "stop_recreate");
  });

  it("rank=10 → stop_recreate", () => {
    const action = decideAfterRankCheck({ rank: 10, page: 1 });
    assert.equal(action.kind, "stop_recreate");
  });

  it("rank=11 → keep_running (вне топ-10)", () => {
    const action = decideAfterRankCheck({ rank: 11, page: 2 });
    assert.equal(action.kind, "keep_running");
    assert.equal(action.reason, "below_top");
  });

  it("rank=null → keep_running (вне стакана)", () => {
    const action = decideAfterRankCheck({ rank: null, page: null });
    assert.equal(action.kind, "keep_running");
    assert.equal(action.reason, "not_in_top");
  });
});

describe("decideAfterRankCheck с кастомным topN", () => {
  it("rank=20, topN=30 → stop_recreate", () => {
    const action = decideAfterRankCheck({ rank: 20, page: 2 }, 30);
    assert.equal(action.kind, "stop_recreate");
    assert.equal(action.reason, "in_top");
  });

  it("rank=30, topN=30 → stop_recreate (граница включена)", () => {
    const action = decideAfterRankCheck({ rank: 30, page: 3 }, 30);
    assert.equal(action.kind, "stop_recreate");
  });

  it("rank=31, topN=30 → keep_running", () => {
    const action = decideAfterRankCheck({ rank: 31, page: 4 }, 30);
    assert.equal(action.kind, "keep_running");
  });

  it("rank=50, topN=100 → stop_recreate", () => {
    const action = decideAfterRankCheck({ rank: 50, page: 5 }, 100);
    assert.equal(action.kind, "stop_recreate");
  });

  it("rank=null, topN=50 → keep_running", () => {
    const action = decideAfterRankCheck({ rank: null, page: null }, 50);
    assert.equal(action.kind, "keep_running");
    assert.equal(action.reason, "not_in_top");
  });
});

describe("nextCycleStatus", () => {
  it("в топе → stopped", () => {
    assert.equal(
      nextCycleStatus({ kind: "stop_recreate", reason: "in_top" }),
      "stopped",
    );
  });
  it("не в топе → running", () => {
    assert.equal(
      nextCycleStatus({ kind: "keep_running", reason: "not_in_top" }),
      "running",
    );
    assert.equal(
      nextCycleStatus({ kind: "keep_running", reason: "below_top" }),
      "running",
    );
  });
});

describe("shouldCancelBeforeRecreate", () => {
  it("в топе с активным объявлением — НЕ отменять (главный invariant)", () => {
    const action = decideAfterRankCheck({ rank: 3, page: 1 });
    assert.equal(shouldCancelBeforeRecreate(action, true), false);
  });

  it("в топе без объявления — НЕ отменять", () => {
    const action = decideAfterRankCheck({ rank: 3, page: 1 });
    assert.equal(shouldCancelBeforeRecreate(action, false), false);
  });

  it("не нашли + есть текущее → отменить перед созданием нового", () => {
    const action = decideAfterRankCheck({ rank: null, page: null });
    assert.equal(shouldCancelBeforeRecreate(action, true), true);
  });

  it("не нашли + нет текущего — нечего отменять", () => {
    const action = decideAfterRankCheck({ rank: null, page: null });
    assert.equal(shouldCancelBeforeRecreate(action, false), false);
  });
});

describe("Сценарий: объявление в топ-N → stopped, объява живёт", () => {
  it("topN=10, rank=1 → stopped, cancel НЕ выполняется", () => {
    const action = decideAfterRankCheck({ rank: 1, page: 1 }, 10);
    assert.equal(nextCycleStatus(action), "stopped");
    assert.equal(shouldCancelBeforeRecreate(action, true), false);
  });

  it("topN=30, rank=25 → stopped, cancel=false", () => {
    const action = decideAfterRankCheck({ rank: 25, page: 3 }, 30);
    assert.equal(nextCycleStatus(action), "stopped");
    assert.equal(shouldCancelBeforeRecreate(action, true), false);
  });

  it("topN=10, rank=11 → running и cancel (выпали из топ-10)", () => {
    const action = decideAfterRankCheck({ rank: 11, page: 2 }, 10);
    assert.equal(nextCycleStatus(action), "running");
    assert.equal(shouldCancelBeforeRecreate(action, true), true);
  });

  it("вне стакана (rank=null) → running и cancel", () => {
    const action = decideAfterRankCheck({ rank: null, page: null }, 10);
    assert.equal(nextCycleStatus(action), "running");
    assert.equal(shouldCancelBeforeRecreate(action, true), true);
  });
});
