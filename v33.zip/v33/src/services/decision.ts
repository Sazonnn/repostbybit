/**
 * Чистая логика принятия решений в цикле — что делать после поиска себя в стакане.
 * Ничего не сайд-эффектит, удобно покрыть юнит-тестами.
 */

export interface RankInfo {
  rank: number | null;
  page: number | null;
}

export type CycleNextAction =
  | { kind: "stop_recreate"; reason: "in_top" }
  | { kind: "keep_running"; reason: "not_in_top" | "below_top" };

/**
 * Главное правило цикла: rank ≤ topN → останавливаем пересоздание,
 * объявление остаётся жить. Иначе keep_running.
 * topN по умолчанию = 10 (классический "топ-10").
 */
export function decideAfterRankCheck(
  found: RankInfo,
  topN: number = 10,
): CycleNextAction {
  if (found.rank != null && found.rank <= topN) {
    return { kind: "stop_recreate", reason: "in_top" };
  }
  if (found.rank != null) {
    return { kind: "keep_running", reason: "below_top" };
  }
  return { kind: "keep_running", reason: "not_in_top" };
}

/**
 * Какое следующее cycle.status выставить.
 *  - stop_recreate → "stopped" (бот выходит из цикла, объявление НЕ удаляется)
 *  - всё остальное → "running"
 */
export function nextCycleStatus(action: CycleNextAction): "stopped" | "running" {
  return action.kind === "stop_recreate" ? "stopped" : "running";
}

/**
 * Должен ли мы в этом тике отменять текущее объявление перед созданием нового.
 * Cancel ТОЛЬКО когда мы в running-режиме И уже есть объявление.
 * Если мы в top → не пересоздаём → cancel не нужен.
 */
export function shouldCancelBeforeRecreate(
  action: CycleNextAction,
  hasCurrentItem: boolean,
): boolean {
  if (!hasCurrentItem) return false;
  return action.kind === "keep_running";
}
