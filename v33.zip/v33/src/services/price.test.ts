import { describe, it } from "node:test";
import { strict as assert } from "node:assert";
import {
  computeFloatingPremium,
  computeTargetPrice,
  estimateFloatingPrice,
} from "./price.js";

describe("computeTargetPrice / auto", () => {
  it("SELL вычитает step из топа", () => {
    const r = computeTargetPrice({
      topPrice: "75.50",
      side: "1",
      step: 0.01,
      min: 0,
      max: 100,
    });
    assert.equal(r.ok, true);
    if (r.ok) assert.equal(r.price, "75.49");
  });

  it("BUY прибавляет step к топу", () => {
    const r = computeTargetPrice({
      topPrice: "75.50",
      side: "0",
      step: 0.01,
      min: 0,
      max: 100,
    });
    assert.equal(r.ok, true);
    if (r.ok) assert.equal(r.price, "75.51");
  });

  it("step=0 даёт цену равную топу", () => {
    const r = computeTargetPrice({
      topPrice: "75.50",
      side: "1",
      step: 0,
      min: 0,
      max: 100,
    });
    assert.equal(r.ok, true);
    if (r.ok) assert.equal(r.price, "75.50");
  });

  it("выход за safety нижний → ok=false", () => {
    const r = computeTargetPrice({
      topPrice: "60.00",
      side: "1",
      step: 0.01,
      min: 65,
      max: 90,
    });
    assert.equal(r.ok, false);
  });

  it("выход за safety верхний → ok=false", () => {
    const r = computeTargetPrice({
      topPrice: "100.00",
      side: "0",
      step: 0.01,
      min: 65,
      max: 90,
    });
    assert.equal(r.ok, false);
  });

  it("кривой topPrice → ok=false", () => {
    const r = computeTargetPrice({
      topPrice: "abc",
      side: "1",
      step: 0.01,
      min: 0,
      max: 100,
    });
    assert.equal(r.ok, false);
  });
});

describe("computeTargetPrice / fixed", () => {
  it("берёт fixedPrice игнорируя топ", () => {
    const r = computeTargetPrice({
      topPrice: "999",
      side: "1",
      step: 999,
      min: 0,
      max: 100,
      mode: "fixed",
      fixedPrice: 75.5,
    });
    assert.equal(r.ok, true);
    if (r.ok) assert.equal(r.price, "75.50");
  });

  it("fixed без значения → ok=false", () => {
    const r = computeTargetPrice({
      topPrice: "75",
      side: "1",
      step: 0.01,
      min: 0,
      max: 100,
      mode: "fixed",
      fixedPrice: null,
    });
    assert.equal(r.ok, false);
  });

  it("fixed выходит за safety bounds → ok=false", () => {
    const r = computeTargetPrice({
      topPrice: "75",
      side: "1",
      step: 0.01,
      min: 65,
      max: 90,
      mode: "fixed",
      fixedPrice: 100,
    });
    assert.equal(r.ok, false);
  });
});

describe("floating premium", () => {
  it("auto premium подгоняет target к reference price", () => {
    const r = computeFloatingPremium({
      referencePrice: "73.02",
      targetPrice: "73.01",
    });
    assert.equal(r.ok, true);
    if (r.ok) {
      assert.equal(r.premium, "99.99");
      assert.equal(r.estimatedPrice, "73.01");
    }
  });

  it("manual premium 100.01% даёт цену чуть выше reference", () => {
    const r = estimateFloatingPrice("73.02", "100.01");
    assert.equal(r.ok, true);
    if (r.ok) {
      assert.equal(r.premium, "100.01");
      assert.equal(r.estimatedPrice, "73.03");
    }
  });
});
