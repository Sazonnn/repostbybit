export interface OfficialAdStateInput {
  status?: number | string;
  hiddenReason?: string;
}

export interface HiddenAdState {
  hidden: boolean;
  reason: string | null;
}

export function classifyOfficialAdState(
  input: OfficialAdStateInput,
): HiddenAdState {
  const hiddenReason = String(input.hiddenReason ?? "").trim();
  if (hiddenReason) return { hidden: true, reason: hiddenReason };

  const status = Number(input.status);
  if (status === 20) return { hidden: true, reason: "status=20" };

  return { hidden: false, reason: null };
}
