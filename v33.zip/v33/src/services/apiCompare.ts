/**
 * Проверка: можно ли читать стакан через официальный подписанный API вместо
 * публичного стакана сайта. Раз в COMPARE_MS запрашивает стакан через API и
 * сравнивает топ-1 с тем, что сейчас видит разведчик. При смене курса пишет,
 * какой источник увидел новый курс раньше. На работу автокурса не влияет:
 * запросы идут в лимит аккаунта, а не в лимит IP публичного стакана, а ошибки
 * этой проверки только пишутся в консоль.
 */

export interface CompareContext {
  side: "0" | "1";
  fetchOfficial: () => Promise<{ count?: number; items?: Array<Record<string, unknown>> }>;
  // Топ-1, который сейчас использует разведчик (публичный стакан), и когда он
  // впервые был увиден. null — сравнивать сейчас не с чем (разведчик на подъёме
  // и стакан не читает).
  publicTop: () => { price: string; seenAt: number } | null;
  isOwn: (item: Record<string, unknown>) => boolean;
}

const COMPARE_MS = 500;
const SUMMARY_MS = 60_000;
const MISMATCH_LOG_MS = 30_000;

function hms(at: number): string {
  const d = new Date(at);
  return `${d.toLocaleTimeString("ru-RU")}.${String(d.getMilliseconds()).padStart(3, "0")}`;
}

export class ApiSourceCompare {
  private running = false;
  private lastRunAt = 0;
  private lastSummaryAt = Date.now();
  private stats = { total: 0, match: 0, apiMsSum: 0, errors: 0 };
  private lastOfficialTop: string | null = null;
  private lastPublicTop: string | null = null;
  private lastMismatchLogAt = 0;
  private lastError = "";
  private readonly firstSeen = new Map<string, { api?: number; site?: number }>();

  maybeRun(ctx: CompareContext): void {
    this.trackPublic(ctx);
    const now = Date.now();
    if (this.running || now - this.lastRunAt < COMPARE_MS) return;
    this.running = true;
    this.lastRunAt = now;
    void this.run(ctx).finally(() => {
      this.running = false;
    });
  }

  private trackPublic(ctx: CompareContext): void {
    const pub = ctx.publicTop();
    if (!pub) return;
    const price = Number(pub.price).toFixed(2);
    if (price !== this.lastPublicTop) {
      this.lastPublicTop = price;
      this.mark(price, "site", pub.seenAt);
    }
  }

  /** Запоминает, когда источник впервые показал этот курс; когда оба — пишет разницу. */
  private mark(price: string, source: "api" | "site", at: number): void {
    const entry = this.firstSeen.get(price) ?? {};
    if (entry[source] === undefined) entry[source] = at;
    this.firstSeen.set(price, entry);
    if (entry.api !== undefined && entry.site !== undefined) {
      const diff = entry.site - entry.api;
      console.log(
        `[api-compare] курс ${price}: API — ${hms(entry.api)}, сайт — ${hms(entry.site)} → ` +
          (diff >= 0 ? `API раньше на ${(diff / 1000).toFixed(2)} с` : `сайт раньше на ${(-diff / 1000).toFixed(2)} с`),
      );
      this.firstSeen.delete(price);
    }
    while (this.firstSeen.size > 30) {
      const oldest = this.firstSeen.keys().next().value;
      if (oldest === undefined) break;
      this.firstSeen.delete(oldest);
    }
  }

  private async run(ctx: CompareContext): Promise<void> {
    const startedAt = Date.now();
    try {
      const result = await ctx.fetchOfficial();
      const answeredAt = Date.now();
      const items = (result.items ?? []).filter((item) => !ctx.isOwn(item));
      const prices = items.map((item) => Number(item.price)).filter((v) => Number.isFinite(v) && v > 0);
      if (prices.length === 0) return;
      const top1 = prices[0]!.toFixed(2);
      const best = (ctx.side === "1" ? Math.min(...prices) : Math.max(...prices)).toFixed(2);
      this.stats.total += 1;
      this.stats.apiMsSum += answeredAt - startedAt;
      this.lastError = "";

      const pub = ctx.publicTop();
      const siteTop = pub ? Number(pub.price).toFixed(2) : null;
      if (siteTop !== null && siteTop === top1) this.stats.match += 1;
      if (top1 !== this.lastOfficialTop) {
        this.lastOfficialTop = top1;
        this.mark(top1, "api", answeredAt);
      }
      if (siteTop !== null && siteTop !== top1 && answeredAt - this.lastMismatchLogAt > MISMATCH_LOG_MS) {
        this.lastMismatchLogAt = answeredAt;
        console.log(
          `[api-compare] расхождение: сайт топ-1 ${siteTop}, API топ-1 ${top1}, API лучшая ${best}; ` +
            `первые цены API: ${prices.slice(0, 5).map((v) => v.toFixed(2)).join(", ")}`,
        );
      }
    } catch (error) {
      this.stats.errors += 1;
      const message = (error as Error).message;
      if (message !== this.lastError) {
        this.lastError = message;
        console.warn(`[api-compare] ошибка запроса API: ${message}`);
      }
    } finally {
      const now = Date.now();
      if (now - this.lastSummaryAt >= SUMMARY_MS) {
        const { total, match, apiMsSum, errors } = this.stats;
        console.log(
          `[api-compare] за минуту: сравнений ${total}, топ-1 совпал ${match}/${total}` +
            (total > 0 ? ` (${Math.round(match / total * 100)}%)` : "") +
            `, ответ API в среднем ${total > 0 ? Math.round(apiMsSum / total) : "-"} мс, ошибок ${errors}`,
        );
        this.stats = { total: 0, match: 0, apiMsSum: 0, errors: 0 };
        this.lastSummaryAt = now;
      }
    }
  }
}
