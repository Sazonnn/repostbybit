/**
 * Инварианты цикла: жёсткие правила которые НИКОГДА не должны нарушаться.
 * Если этот файл падает — не выкатывать.
 */
import { describe, it } from "node:test";
import { strict as assert } from "node:assert";
import {
  decideAfterRankCheck,
  nextCycleStatus,
  shouldCancelBeforeRecreate,
} from "./decision.js";

describe("ИНВАРИАНТ #1: если объявление в топ-10 (default) — НЕ удаляем", () => {
  for (let rank = 1; rank <= 10; rank++) {
    it(`rank=${rank} → cancel=false, status=stopped`, () => {
      const action = decideAfterRankCheck({ rank, page: 1 });
      assert.equal(
        shouldCancelBeforeRecreate(action, true),
        false,
        `НИКОГДА не отменяем объявление в топ-10 (rank=${rank})`,
      );
      assert.equal(
        nextCycleStatus(action),
        "stopped",
        `Должны останавливаться когда в топ-10 (rank=${rank})`,
      );
    });
  }
});

describe("ИНВАРИАНТ #1b: вне топ-10 (default) — running и cancel", () => {
  for (let page = 2; page <= 3; page++) {
    for (let posOnPage = 1; posOnPage <= 10; posOnPage++) {
      const rank = (page - 1) * 10 + posOnPage;
      it(`rank=${rank} page=${page} → cancel=true, status=running`, () => {
        const action = decideAfterRankCheck({ rank, page });
        assert.equal(shouldCancelBeforeRecreate(action, true), true);
        assert.equal(nextCycleStatus(action), "running");
      });
    }
  }
});

describe("ИНВАРИАНТ #1c: для кастомного topN — то же правило, граница ≤ topN", () => {
  for (const topN of [20, 30, 50, 70, 100]) {
    it(`topN=${topN}, rank=${topN} → stopped, cancel=false`, () => {
      const action = decideAfterRankCheck({ rank: topN, page: Math.ceil(topN / 10) }, topN);
      assert.equal(nextCycleStatus(action), "stopped");
      assert.equal(shouldCancelBeforeRecreate(action, true), false);
    });
    it(`topN=${topN}, rank=${topN + 1} → running, cancel=true`, () => {
      const action = decideAfterRankCheck({ rank: topN + 1, page: Math.ceil((topN + 1) / 10) }, topN);
      assert.equal(nextCycleStatus(action), "running");
      assert.equal(shouldCancelBeforeRecreate(action, true), true);
    });
  }
});

describe("ИНВАРИАНТ #2: rank=null (не нашли) → нужно пересоздавать", () => {
  it("rank=null + есть current_item_id → cancel + running", () => {
    const action = decideAfterRankCheck({ rank: null, page: null });
    assert.equal(shouldCancelBeforeRecreate(action, true), true);
    assert.equal(nextCycleStatus(action), "running");
  });

  it("rank=null + нет current_item_id → нет cancel, running (создаём первое)", () => {
    const action = decideAfterRankCheck({ rank: null, page: null });
    assert.equal(shouldCancelBeforeRecreate(action, false), false);
    assert.equal(nextCycleStatus(action), "running");
  });
});

describe("ИНВАРИАНТ #3: nextCycleStatus детерминирован", () => {
  it("stop_recreate ВСЕГДА → stopped", () => {
    const action = decideAfterRankCheck({ rank: 1, page: 1 });
    for (let i = 0; i < 100; i++) {
      assert.equal(nextCycleStatus(action), "stopped");
    }
  });

  it("keep_running ВСЕГДА → running", () => {
    const action = decideAfterRankCheck({ rank: null, page: null });
    for (let i = 0; i < 100; i++) {
      assert.equal(nextCycleStatus(action), "running");
    }
  });
});

describe("ИНВАРИАНТ #4: в топе — никогда не cancel", () => {
  for (let rank = 1; rank <= 10; rank++) {
    it(`rank=${rank} → cancel=false независимо от hasCurrentItem`, () => {
      const action = decideAfterRankCheck({ rank, page: 1 });
      assert.equal(shouldCancelBeforeRecreate(action, true), false);
      assert.equal(shouldCancelBeforeRecreate(action, false), false);
    });
  }
});

describe("Граничные кейсы", () => {
  it("rank=undefined обрабатывается как rank=null (страховка)", () => {
    // @ts-expect-error — намеренно передаём странные значения
    const action = decideAfterRankCheck({ rank: undefined, page: undefined });
    assert.equal(action.kind, "keep_running");
  });

  it("rank=0 (странно но возможно) — оплачиваем как 'нашли'", () => {
    // rank=0 не должен встречаться, но если приедет — действуем как "нашли"
    // (rank ≤ topN → stop_recreate)
    const action = decideAfterRankCheck({ rank: 0, page: 1 });
    assert.equal(action.kind, "stop_recreate");
  });

  it("rank очень большой (rank=999) → keep_running (вне топ-10)", () => {
    const action = decideAfterRankCheck({ rank: 999, page: 100 });
    assert.equal(action.kind, "keep_running");
    assert.equal(shouldCancelBeforeRecreate(action, true), true);
  });
});
