/**
 * Цена в P2P задаётся в "копейках" целевой валюты (RUB и т.п.).
 * Bybit принимает строки. Считаем через числа, обрезая до 2 знаков
 * (этого хватает для всех актуальных пар; если нужно больше — допилить).
 */
const PRECISION = 2;
const PREMIUM_PRECISION = 2;

export function formatPrice(value: number): string {
  return value.toFixed(PRECISION);
}

export function formatPremium(value: number): string {
  return value.toFixed(PREMIUM_PRECISION);
}

export interface ComputeTargetPriceInput {
  topPrice: string;
  side: "0" | "1";
  step: number;
  min: number;
  max: number;
  /** "auto" — top ± step (по умолчанию). "fixed" — игнорим топ, берём fixedPrice. */
  mode?: "auto" | "fixed";
  fixedPrice?: string | number | null;
}

export interface ComputeTargetPriceResult {
  ok: true;
  price: string;
  numericPrice: number;
  topNumeric: number;
}

export interface ComputeTargetPriceError {
  ok: false;
  reason: string;
  topNumeric: number;
}

export interface ComputeFloatingPremiumInput {
  targetPrice: string | number;
  referencePrice: string | number;
  min?: number;
  max?: number;
}

export interface ComputeFloatingPremiumResult {
  ok: true;
  premium: string;
  numericPremium: number;
  estimatedPrice: string;
  numericEstimatedPrice: number;
  numericReferencePrice: number;
}

export interface ComputeFloatingPremiumError {
  ok: false;
  reason: string;
}

/**
 * Считает целевую цену "на step лучше топа стакана".
 *  - SELL (side=1): мы продаём → хотим встать ниже топа = top - step
 *  - BUY  (side=0): мы покупаем → хотим встать выше топа = top + step
 */
export function computeTargetPrice(
  input: ComputeTargetPriceInput,
): ComputeTargetPriceResult | ComputeTargetPriceError {
  const top = Number(input.topPrice);
  if (!Number.isFinite(top) || top <= 0) {
    return { ok: false, reason: `Bad top price: ${input.topPrice}`, topNumeric: top };
  }

  let target: number;
  if (input.mode === "fixed") {
    const fixed = Number(input.fixedPrice);
    if (!Number.isFinite(fixed) || fixed <= 0) {
      return { ok: false, reason: `Bad fixed price: ${input.fixedPrice}`, topNumeric: top };
    }
    target = fixed;
  } else {
    target = input.side === "1" ? top - input.step : top + input.step;
  }

  if (target < input.min || target > input.max) {
    return {
      ok: false,
      reason: `target ${target} out of bounds [${input.min}, ${input.max}]`,
      topNumeric: top,
    };
  }
  if (target <= 0) {
    return { ok: false, reason: `target ${target} <= 0`, topNumeric: top };
  }
  return {
    ok: true,
    price: formatPrice(target),
    numericPrice: target,
    topNumeric: top,
  };
}

/**
 * Для плавающего объявления Bybit принимает premium как процент от своей
 * reference/last price: 100.00 = ровно рынок, 99.99 = чуть ниже рынка.
 */
export function computeFloatingPremium(
  input: ComputeFloatingPremiumInput,
): ComputeFloatingPremiumResult | ComputeFloatingPremiumError {
  const target = Number(input.targetPrice);
  const reference = Number(input.referencePrice);
  if (!Number.isFinite(target) || target <= 0) {
    return { ok: false, reason: `Bad target price: ${input.targetPrice}` };
  }
  if (!Number.isFinite(reference) || reference <= 0) {
    return { ok: false, reason: `Bad reference price: ${input.referencePrice}` };
  }
  const numericPremium = Number(formatPremium((target / reference) * 100));
  if (
    (input.min !== undefined && numericPremium < input.min) ||
    (input.max !== undefined && numericPremium > input.max)
  ) {
    return {
      ok: false,
      reason: `premium ${numericPremium} out of bounds [${input.min ?? "-∞"}, ${input.max ?? "+∞"}]`,
    };
  }
  const estimated = reference * (numericPremium / 100);
  return {
    ok: true,
    premium: formatPremium(numericPremium),
    numericPremium,
    estimatedPrice: formatPrice(estimated),
    numericEstimatedPrice: Number(formatPrice(estimated)),
    numericReferencePrice: reference,
  };
}

export function estimateFloatingPrice(
  referencePrice: string | number,
  premium: string | number,
): ComputeFloatingPremiumResult | ComputeFloatingPremiumError {
  const reference = Number(referencePrice);
  const numericPremium = Number(premium);
  if (!Number.isFinite(reference) || reference <= 0) {
    return { ok: false, reason: `Bad reference price: ${referencePrice}` };
  }
  if (!Number.isFinite(numericPremium) || numericPremium <= 0) {
    return { ok: false, reason: `Bad premium: ${premium}` };
  }
  const estimated = reference * (numericPremium / 100);
  return {
    ok: true,
    premium: formatPremium(numericPremium),
    numericPremium,
    estimatedPrice: formatPrice(estimated),
    numericEstimatedPrice: Number(formatPrice(estimated)),
    numericReferencePrice: reference,
  };
}
