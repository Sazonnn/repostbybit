import { config } from "../config.js";
import {
  cancelAd,
  createAd,
  findMyRankInStack,
  getLastPrice,
  getTopPrice,
  getWorkConfig,
  withBybitConnection,
} from "../bybit/index.js";
import {
  createManualAdRecord,
  listActiveManualAds,
  updateManualAdStatus,
  type ManualAdRow,
} from "../db/repositories/manualAds.js";
import { getActiveCycleByChat } from "../db/repositories/cycles.js";
import { ensureSettings } from "../db/repositories/userSettings.js";
import { ensureSideSettings } from "../db/repositories/sideSettings.js";
import { authService } from "../auth/authService.js";
import {
  computeFloatingPremium,
  computeTargetPrice,
  estimateFloatingPrice,
} from "./price.js";

class ManualAdConfigError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ManualAdConfigError";
  }
}

export interface ReplaceManualAdResult {
  itemId: string;
  priceType: "0" | "1";
  price: string;
  premium: string | null;
  topPrice: string | null;
  rank: number | null;
  page: number | null;
  cancelled: number;
  cancelWarnings: string[];
}

export async function replaceManualAd(
  chatId: number,
): Promise<ReplaceManualAdResult> {
  const settings = await ensureSettings(chatId);
  if (settings.ad_mode !== "manual") {
    throw new ManualAdConfigError(
      "Ручной режим выключен. Включи /settings → Ручной режим.",
    );
  }
  const activeCycle = await getActiveCycleByChat(chatId);
  if (activeCycle) {
    throw new ManualAdConfigError(
      "Сначала останови активный цикл /stop, потом создавай ручное объявление.",
    );
  }

  const { cancelled, warnings } = await cancelActiveManualAds(chatId);

  const wc = await withBybitConnection(
    settings.connection_mode,
    () => getWorkConfig(),
    chatId,
  );
  if (wc.workStatus === "REST") {
    throw new ManualAdConfigError(
      "Аккаунт в REST mode. Включи Online в Bybit и повтори создание.",
    );
  }

  const side = await ensureSideSettings(chatId, settings.side);
  if (side.payment_ids.length === 0) {
    throw new ManualAdConfigError(
      `Для ${settings.side === "1" ? "SELL" : "BUY"} не выбраны Payments. /settings → Payments.`,
    );
  }

  const session = await authService.getCurrent();
  const ownUserId =
    settings.connection_mode === "api"
      ? wc.userId || undefined
      : session?.bybitUid ?? config.bybit.userId ?? undefined;
  const topPrice = await withBybitConnection(
    settings.connection_mode,
    () =>
      getTopPrice({
        tokenId: settings.token_id,
        currencyId: settings.currency_id,
        side: settings.side,
        userId: ownUserId,
      }),
    chatId,
  );
  if (!topPrice) throw new ManualAdConfigError("Стакан пуст или не вернул цену");

  const target = computeTargetPrice({
    topPrice,
    side: settings.side,
    step: Number(settings.price_step),
    min: Number(settings.price_min),
    max: Number(settings.price_max),
    mode: settings.price_mode,
    fixedPrice: settings.price_fixed,
  });
  if (!target.ok) throw new ManualAdConfigError(target.reason);

  const plan =
    settings.primary_price_type === "floating"
      ? await withBybitConnection(
          settings.connection_mode,
          () =>
            resolveFloatingPlan({
              tokenId: settings.token_id,
              currencyId: settings.currency_id,
              targetPrice: target.price,
              premiumMode: settings.dual_ads_premium_mode,
              premiumManual: settings.dual_ads_premium_manual,
            }),
          chatId,
        )
      : {
          priceType: "0" as const,
          price: target.price,
          premium: null as string | null,
          useFlexible: false,
        };

  const quantity = effectiveQuantity(
    {
      quantity: side.quantity,
      quantityAuto: side.quantity_auto,
      minAmount: side.min_amount,
      maxAmount: side.max_amount,
    },
    plan.price,
  );

  const paymentPassword =
    settings.payment_password || config.bybit.paymentPassword || undefined;
  const created = await withBybitConnection(
    settings.connection_mode,
    () =>
      createAd({
        tokenId: settings.token_id,
        currencyId: settings.currency_id,
        side: settings.side,
        priceType: plan.priceType,
        price: plan.price,
        premium: plan.premium ?? undefined,
        quantity,
        minAmount: side.min_amount,
        maxAmount: side.max_amount,
        paymentPeriod: side.payment_period,
        paymentIds: side.payment_ids,
        remark: side.remark,
        useFlexible: plan.useFlexible,
        paymentPassword,
      }),
    chatId,
  );
  const itemId = String(created.itemId ?? created.id ?? "");
  if (!itemId) throw new ManualAdConfigError("createAd вернул пустой itemId");

  await createManualAdRecord({
    chatId,
    itemId,
    tokenId: settings.token_id,
    currencyId: settings.currency_id,
    side: settings.side,
    priceType: plan.priceType,
    price: plan.price,
    premium: plan.premium,
  });

  let rank: number | null = null;
  let page: number | null = null;
  try {
    const pageSize = config.p2p.pageSize;
    const maxPages = Math.max(1, Math.ceil(settings.bourse_top_n / pageSize));
    const found = await withBybitConnection(
      settings.connection_mode,
      () =>
        findMyRankInStack({
          itemId,
          tokenId: settings.token_id,
          currencyId: settings.currency_id,
          side: settings.side,
          pageSize,
          maxPages,
          verificationFilter: settings.bourse_verification_filter,
        }),
      chatId,
    );
    rank = found.rank;
    page = found.page;
  } catch (err) {
    warnings.push(`позицию не проверил: ${(err as Error).message}`);
  }

  return {
    itemId,
    priceType: plan.priceType,
    price: plan.price,
    premium: plan.premium,
    topPrice,
    rank,
    page,
    cancelled,
    cancelWarnings: warnings,
  };
}

export async function cancelActiveManualAds(chatId: number): Promise<{
  cancelled: number;
  warnings: string[];
}> {
  const settings = await ensureSettings(chatId);
  const active = await listActiveManualAds(chatId);
  let cancelled = 0;
  const warnings: string[] = [];
  for (const ad of active) {
    try {
      await withBybitConnection(
        settings.connection_mode,
        () => cancelAd(ad.item_id),
        chatId,
      );
      await updateManualAdStatus(ad.id, "cancelled");
      cancelled++;
    } catch (err) {
      await updateManualAdStatus(ad.id, "error");
      warnings.push(`${ad.item_id}: ${(err as Error).message}`);
    }
  }
  return { cancelled, warnings };
}

export async function listManualAds(chatId: number): Promise<ManualAdRow[]> {
  return listActiveManualAds(chatId);
}

function effectiveQuantity(
  input: {
    quantity: string;
    quantityAuto: boolean;
    minAmount: string;
    maxAmount: string;
  },
  price: string,
): string {
  const priceN = Number(price);
  const minF = Number(input.minAmount);
  const maxF = Number(input.maxAmount);
  let qty = input.quantity;
  if (input.quantityAuto) {
    if (priceN <= 0) throw new ManualAdConfigError(`Bad price: ${price}`);
    qty = String(Math.ceil(maxF / priceN));
  }
  const qtyN = Number(qty);
  if (!Number.isFinite(qtyN) || qtyN <= 0) {
    throw new ManualAdConfigError(`Bad quantity: ${qty}`);
  }
  const totalFiat = priceN * qtyN;
  if (minF > totalFiat) {
    throw new ManualAdConfigError(
      `min (${minF}) > price × qty (${totalFiat.toFixed(2)}). Уменьши min или увеличь qty.`,
    );
  }
  if (maxF > totalFiat) {
    throw new ManualAdConfigError(
      `max (${maxF}) > price × qty (${totalFiat.toFixed(2)}). Уменьши max до ≤ ${Math.floor(totalFiat)} или увеличь qty.`,
    );
  }
  return qty;
}

async function resolveFloatingPlan(input: {
  tokenId: string;
  currencyId: string;
  targetPrice: string;
  premiumMode: "auto" | "manual";
  premiumManual: string;
}): Promise<{
  priceType: "1";
  price: string;
  premium: string;
  useFlexible: true;
}> {
  const ref = await getLastPrice(input.tokenId, input.currencyId);
  const referencePrice = ref.price ?? ref.lastPrice ?? null;
  if (!referencePrice) {
    throw new ManualAdConfigError("floating: Bybit не вернул reference price");
  }
  const floating =
    input.premiumMode === "manual"
      ? estimateFloatingPrice(referencePrice, input.premiumManual)
      : computeFloatingPremium({
          targetPrice: input.targetPrice,
          referencePrice,
        });
  if (!floating.ok) {
    throw new ManualAdConfigError(`floating: ${floating.reason}`);
  }
  return {
    priceType: "1",
    price: floating.estimatedPrice,
    premium: floating.premium,
    useFlexible: true,
  };
}
