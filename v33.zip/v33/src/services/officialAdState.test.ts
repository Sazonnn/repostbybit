import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { classifyOfficialAdState } from "./officialAdState.js";

describe("official API ad state", () => {
  it("online status=10 не считается скрытым", () => {
    assert.deepEqual(classifyOfficialAdState({ status: 10 }), {
      hidden: false,
      reason: null,
    });
  });

  it("offline status=20 останавливает пересоздание", () => {
    assert.deepEqual(classifyOfficialAdState({ status: 20 }), {
      hidden: true,
      reason: "status=20",
    });
  });

  it("hiddenReason имеет приоритет над статусом", () => {
    assert.deepEqual(
      classifyOfficialAdState({ status: 10, hiddenReason: "REST" }),
      { hidden: true, reason: "REST" },
    );
  });
});
