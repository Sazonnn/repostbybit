import { authService, describeSession } from "../auth/authService.js";
import { runLoginFlow } from "../auth/loginFlow.js";
import { hasUsersUsingSessionConnection } from "../db/repositories/userSettings.js";

export type SessionWatcherNotify = (text: string) => Promise<void>;

const CHECK_INTERVAL_MS = 30 * 60_000; // раз в полчаса
const REFRESH_THRESHOLD_MS = 12 * 3600_000; // если до exp < 12 часов — пора рефрешить
const SILENT_FAIL_INTERACTIVE_THRESHOLD_MS = 6 * 3600_000; // <6ч до exp — алерт юзеру
const MIN_GAP_MS = 6 * 3600_000; // не чаще раза в 6 часов

export class SessionWatcher {
  private timer: NodeJS.Timeout | null = null;
  private lastRefreshAt = 0;

  constructor(private readonly notifyOwner: SessionWatcherNotify) {}

  start(): void {
    if (this.timer) return;
    setImmediate(() => void this.tick());
    this.timer = setInterval(() => void this.tick(), CHECK_INTERVAL_MS);
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  private async tick(): Promise<void> {
    try {
      if (!(await hasUsersUsingSessionConnection())) return;
      const s = await authService.getCurrent();
      if (!s) return; // ещё не логинились
      if (!s.expiresAt) return;
      const msLeft = s.expiresAt.getTime() - Date.now();
      if (msLeft > REFRESH_THRESHOLD_MS) return;
      if (msLeft <= 0) {
        await this.notifyOwner(
          `🔐 secure-token УЖЕ истёк. Запусти /auth_refresh.`,
        );
        return;
      }

      const sinceLastRefresh = Date.now() - this.lastRefreshAt;
      if (this.lastRefreshAt > 0 && sinceLastRefresh < MIN_GAP_MS) {
        // Только что рефрешили — не лезем снова в Bybit, ждём.
        return;
      }

      console.log(
        `[sessionWatcher] до exp ${Math.round(msLeft / 3_600_000)}ч — пробую silent refresh`,
      );
      try {
        const fresh = await runLoginFlow({ silent: true });
        this.lastRefreshAt = Date.now();
        await this.notifyOwner(
          `🔁 Сессия продлена авто. ${describeSession(fresh)}.`,
        );
      } catch (err) {
        const msg = (err as Error).message;
        console.warn(`[sessionWatcher] silent refresh упал: ${msg}`);
        if (msLeft < SILENT_FAIL_INTERACTIVE_THRESHOLD_MS) {
          await this.notifyOwner(
            `🔐 Авто-продление сессии не удалось (${msg}). До истечения <${Math.round(msLeft / 3_600_000)}ч — запусти /auth_refresh.`,
          );
        }
      }
    } catch (err) {
      console.error("sessionWatcher tick error:", err);
    }
  }
}
