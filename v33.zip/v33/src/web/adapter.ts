import { createHash } from "node:crypto";
import { config } from "../config.js";
import { db } from "../db/pool.js";
import { ensureSettings, updateSettings } from "../db/repositories/userSettings.js";
import { getActiveApiAccount } from "../db/repositories/apiAccounts.js";
import { getActiveCycleByChat } from "../db/repositories/cycles.js";
import type { WorkingAdsManager } from "../services/workingAdsManager.js";
import { PanelError, type PanelAdapter } from "./server.js";
import type { PanelTelemetry } from "./telemetry.js";

function number(value: unknown, name: string, min: number, max: number): number {
  if ((typeof value !== "number" && typeof value !== "string") || String(value).trim() === "") throw new PanelError(400, `Неверное значение: ${name}.`);
  const result = Number(String(value).replace(",", "."));
  if (!Number.isFinite(result) || result < min || result > max) throw new PanelError(400, `${name}: от ${min} до ${max}.`);
  return result;
}
export function validatePriceSettings(input: Record<string, unknown>) {
  if (input.mode !== "auto" && input.mode !== "fixed") throw new PanelError(400, "Неизвестный режим цены.");
  const min = number(input.min, "Нижняя граница", 0, 1e9);
  const max = number(input.max, "Верхняя граница", 0.01, 1e9);
  const fixed = input.fixed === null || input.fixed === "" ? null : String(number(input.fixed, "Фиксированная цена", 0.01, 1e9));
  if (min > max || (input.mode === "fixed" && (fixed === null || Number(fixed) < min || Number(fixed) > max))) throw new PanelError(400, "Цена и границы не согласованы.");
  return { priceMode: input.mode as "auto" | "fixed", priceStep: String(number(input.step, "Шаг", -1e6, 1e6)), priceMin: String(min),
    priceMax: String(max), priceFixed: fixed,
    monitor: number(input.monitor, "Мониторинг, секунды", 0.01, 86_400),
    edit: number(input.edit, "Редактирование, секунды", 0.01, 86_400) };
}

export function createPanelAdapter(chatId: number, manager: WorkingAdsManager, telemetry: PanelTelemetry): PanelAdapter {
  const startedAt = Date.now();
  const settingsView = (s: Awaited<ReturnType<typeof ensureSettings>>) => ({
    enabled: s.working_ads_enabled, monitor: s.working_ads_interval_ms / 1_000,
    edit: s.working_ads_update_interval_ms / 1_000, mode: s.price_mode, step: s.price_step,
    min: s.price_min, max: s.price_max, fixed: s.price_fixed,
  });
  const read = async () => {
    const settings = await ensureSettings(chatId);
    const ads = await manager.list(chatId);
    const account = await getActiveApiAccount(chatId);
    const revision = createHash("sha256").update(JSON.stringify({ settings: settingsView(settings),
      source: [settings.connection_mode, account?.id, account?.keyHint], ads: ads.map(a => [a.id, a.enabled, a.item_id]) })).digest("hex");
    return { settings, ads, account, revision };
  };
  return {
    async snapshot() {
      const { settings, ads, account, revision } = await read();
      const cycle = await getActiveCycleByChat(chatId);
      return {
        version: "web-1", demo: false, now: Date.now(), startedAt, chatId, revision,
        account: { name: account?.name ?? (settings.connection_mode === "api" ? "API из .env" : "Сессия Bybit"), mode: settings.connection_mode,
          configured: settings.connection_mode === "api" ? Boolean(account || (config.bybit.apiKey && config.bybit.apiSecret)) : true },
        settings: settingsView(settings),
        cycle: cycle ? { status: cycle.status, itemId: cycle.current_item_id, price: cycle.current_price } : null,
        ads: ads.map(a => {
          const attempts = db.prepare("SELECT COUNT(*) AS n FROM working_ad_update_attempts WHERE item_id = ? AND sent_at_ms > ?").get(a.item_id, Date.now() - 300_000);
          return { id: a.id, itemId: a.item_id, pair: `${a.token_id}/${a.currency_id}`, side: a.side === "0" ? "BUY" : "SELL",
            type: a.price_type === "0" ? "fixed" : "floating", enabled: a.enabled, price: a.last_price,
            target: a.last_target_price, error: a.last_error, checkedAt: a.last_checked_at, updatedAt: a.last_updated_at,
            attempts: Number(attempts?.n ?? 0) };
        }),
        telemetry: telemetry.snapshot(),
      };
    },
    async command(input) {
      const { settings, ads, revision } = await read();
      if (input.revision !== revision) throw new PanelError(409, "Настройки изменились в другом окне или Telegram. Обнови данные и повтори.");
      const known = ["enable", "ad-enable", "ad-remove", "ad-add", "sync", "settings"];
      if (typeof input.action !== "string" || !known.includes(input.action)) throw new PanelError(400, "Неизвестная команда.");
      try {
        if (input.action === "enable") {
          if (typeof input.enabled !== "boolean") throw new PanelError(400, "Неверный статус.");
          await manager.setEnabled(chatId, input.enabled);
        } else if (input.action === "ad-enable" || input.action === "ad-remove") {
          if (!Number.isSafeInteger(input.id) || !ads.some(ad => ad.id === input.id)) throw new PanelError(404, "Объявление не найдено.");
          if (input.action === "ad-remove") await manager.remove(chatId, Number(input.id));
          else {
            if (typeof input.enabled !== "boolean") throw new PanelError(400, "Неверный статус.");
            await manager.setAdEnabled(chatId, Number(input.id), input.enabled);
          }
        } else if (input.action === "ad-add") {
          if (typeof input.itemId !== "string" || !/^\d{6,30}$/.test(input.itemId)) throw new PanelError(400, "Неверный ID объявления.");
          await manager.add(chatId, input.itemId);
        } else if (input.action === "sync") {
          const results = await manager.syncNow(chatId);
          const error = results.find(r => r.error)?.error;
          if (error) throw new PanelError(400, error);
        } else {
          const parsed = validatePriceSettings(input);
          const { monitor, edit, ...patch } = parsed;
          // Working ads read these settings; an active legacy cycle also uses them.
          if (await getActiveCycleByChat(chatId)) throw new PanelError(409, "Сначала останови автоцикл в Telegram: он использует те же настройки курса.");
          await updateSettings(chatId, patch);
          if (Math.round(edit * 1000) !== settings.working_ads_update_interval_ms) await manager.setUpdateIntervalSeconds(chatId, edit);
          if (Math.round(monitor * 1000) !== settings.working_ads_interval_ms) await manager.setIntervalSeconds(chatId, monitor);
        }
        const labels: Record<string, string> = { enable: input.enabled ? "Автокурс включён" : "Автокурс на паузе",
          "ad-enable": input.enabled ? "Объявление включено в автокурс" : "Объявление на паузе",
          "ad-remove": "Объявление убрано из автокурса", "ad-add": "Рабочее объявление добавлено",
          sync: "Проверка завершена", settings: "Настройки курса сохранены" };
        telemetry.add("info", labels[input.action]!);
        return { ok: true, message: labels[input.action] };
      } catch (error) {
        if (error instanceof PanelError) throw error;
        const message = (error as Error).message;
        telemetry.add("error", message);
        throw new PanelError(400, message.slice(0, 500));
      }
    },
  };
}
