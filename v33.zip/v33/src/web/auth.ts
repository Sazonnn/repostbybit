import { randomBytes, scrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { readFileSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const derive = promisify(scrypt);
export const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "../..");
export const panelConfigPath = resolve(projectRoot, "data", "web-panel.json");
export interface PanelConfig { version: 1; chatId: number; port: number; origin: string; passwordHash: string }

export async function hashPassword(password: string): Promise<string> {
  if (password.length < 14 || password.length > 256) throw new Error("Пароль: от 14 до 256 символов.");
  const salt = randomBytes(16).toString("hex");
  const key = await derive(password, salt, 64) as Buffer;
  return `scrypt:${salt}:${key.toString("hex")}`;
}

export async function checkPassword(password: unknown, hash: string): Promise<boolean> {
  if (typeof password !== "string" || password.length > 256) return false;
  if (!/^scrypt:[a-f0-9]{32}:[a-f0-9]{128}$/.test(hash)) return false;
  const [, salt, expected] = hash.split(":");
  const actual = await derive(password, salt!, 64) as Buffer;
  return timingSafeEqual(actual, Buffer.from(expected!, "hex"));
}

export function validateConfig(value: unknown): PanelConfig {
  const c = value as PanelConfig;
  if (!c || c.version !== 1 || !Number.isSafeInteger(c.chatId) || c.chatId <= 0 ||
      !Number.isInteger(c.port) || c.port < 1024 || c.port > 65535 ||
      !/^scrypt:[a-f0-9]{32}:[a-f0-9]{128}$/.test(c.passwordHash)) throw new Error("Неверный data/web-panel.json. Выполни npm run panel:setup.");
  const url = new URL(c.origin);
  if (url.origin !== c.origin || url.username || url.password ||
      (url.protocol !== "https:" && !(url.protocol === "http:" && url.hostname === "127.0.0.1" && url.port === String(c.port)))) {
    throw new Error("Адрес панели должен быть HTTPS или http://127.0.0.1:порт.");
  }
  return c;
}

export function readPanelConfig(): PanelConfig | null {
  try { return validateConfig(JSON.parse(readFileSync(panelConfigPath, "utf8"))); }
  catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") return null; throw error; }
}
