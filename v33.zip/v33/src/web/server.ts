import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { checkPassword, projectRoot, validateConfig, type PanelConfig } from "./auth.js";

export class PanelError extends Error { constructor(public status: number, message: string) { super(message); } }
export interface PanelAdapter { snapshot(): Promise<unknown>; command(input: Record<string, unknown>): Promise<unknown> }
const assets: Record<string, [string, string]> = {
  "/": ["index.html", "text/html; charset=utf-8"], "/app.js": ["app.js", "text/javascript; charset=utf-8"],
  "/style.css": ["style.css", "text/css; charset=utf-8"], "/icons.js": ["icons.js", "text/javascript; charset=utf-8"],
  "/manifest.webmanifest": ["manifest.webmanifest", "application/manifest+json"], "/sw.js": ["sw.js", "text/javascript; charset=utf-8"],
  "/icon-192.png": ["icon-192.png", "image/png"], "/icon-512.png": ["icon-512.png", "image/png"],
  "/apple-touch-icon.png": ["apple-touch-icon.png", "image/png"],
};
const token = () => randomBytes(32).toString("base64url");
const digest = (value: string) => createHash("sha256").update(value).digest("hex");
const equal = (a: string, b: string) => {
  const left = Buffer.from(a), right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
};
async function body(req: IncomingMessage): Promise<Record<string, unknown>> {
  if (!(req.headers["content-type"] ?? "").startsWith("application/json")) throw new PanelError(415, "Ожидается JSON.");
  if (Number(req.headers["content-length"]) > 16_384) {
    req.resume(); throw new PanelError(413, "Слишком большой запрос.");
  }
  const chunks: Buffer[] = []; let size = 0;
  // Keep the socket alive long enough to return a useful 413 for chunked bodies.
  for await (const chunk of req.iterator({ destroyOnReturn: false })) {
    size += chunk.length;
    if (size > 16_384) { req.resume(); throw new PanelError(413, "Слишком большой запрос."); }
    chunks.push(Buffer.from(chunk));
  }
  let value: unknown;
  try { value = JSON.parse(Buffer.concat(chunks).toString("utf8")); } catch { throw new PanelError(400, "Неверный JSON."); }
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new PanelError(400, "Неверный запрос.");
  return value as Record<string, unknown>;
}
function json(res: ServerResponse, status: number, value: unknown) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" }); res.end(JSON.stringify(value));
}

export async function startPanel(raw: PanelConfig, adapter: PanelAdapter) {
  const config = validateConfig(raw);
  const secure = config.origin.startsWith("https:");
  const cookieName = secure ? "__Host-repost_session" : "repost_session";
  const sessions = new Map<string, { csrf: string; expires: number; usedAt: number }>();
  const operations = new Map<string, { hash: string; promise: Promise<unknown>; expires: number }>();
  let loginAttempts: number[] = [];
  let commandAttempts: number[] = [];
  let loginBusy = false;
  let commandBusy = false;
  const files = new Map<string, Buffer>();
  for (const [path, [filename]] of Object.entries(assets)) files.set(path, await readFile(resolve(projectRoot, "web", filename)));
  const cookie = (value: string, seconds: number) => `${cookieName}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${seconds}${secure ? "; Secure" : ""}`;
  const server = createServer((req, res) => {
    void (async () => {
      res.setHeader("Cache-Control", "no-store");
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader("X-Frame-Options", "DENY");
      res.setHeader("Referrer-Policy", "no-referrer");
      res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
      res.setHeader("Content-Security-Policy", "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; font-src 'self'; connect-src 'self'; manifest-src 'self'; worker-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
      if (secure) res.setHeader("Strict-Transport-Security", "max-age=31536000");
      if (req.headers.host !== new URL(config.origin).host) throw new PanelError(403, "Недопустимый адрес панели.");
      if (secure && req.headers["x-forwarded-proto"] !== "https") throw new PanelError(403, "Требуется HTTPS.");
      if (req.headers.origin && req.headers.origin !== config.origin) throw new PanelError(403, "Недопустимый источник запроса.");
      const url = new URL(req.url ?? "/", config.origin);
      const path = url.pathname;
      if (req.method === "GET" && Object.hasOwn(assets, path)) {
        res.setHeader("Content-Type", assets[path]![1]);
        res.end(files.get(path)); return;
      }
      if (req.method === "POST" && req.headers.origin !== config.origin) throw new PanelError(403, "Отсутствует источник запроса.");
      if (req.method === "POST" && path === "/api/login") {
        loginAttempts = loginAttempts.filter(at => Date.now() - at < 900_000);
        if (loginBusy || loginAttempts.length >= 8) throw new PanelError(429, "Слишком много попыток входа. Подожди 15 минут.");
        loginAttempts.push(Date.now()); loginBusy = true;
        try {
          const input = await body(req);
          if (!await checkPassword(input.password, config.passwordHash)) throw new PanelError(401, "Неверный пароль.");
          const value = token(); const csrf = token();
          for (const [key, s] of sessions) if (s.expires < Date.now() || Date.now() - s.usedAt > 1_800_000) sessions.delete(key);
          if (sessions.size >= 8) sessions.delete(sessions.keys().next().value!);
          sessions.set(digest(value), { csrf, expires: Date.now() + 43_200_000, usedAt: Date.now() });
          res.setHeader("Set-Cookie", cookie(value, 43_200));
          json(res, 200, { csrf }); return;
        } finally { loginBusy = false; }
      }
      const rawCookie = (req.headers.cookie ?? "").split(";").map(v => v.trim()).find(v => v.startsWith(cookieName + "="))?.slice(cookieName.length + 1) ?? "";
      const sessionKey = digest(rawCookie);
      const session = sessions.get(sessionKey);
      if (!session || session.expires < Date.now() || Date.now() - session.usedAt > 1_800_000) {
        sessions.delete(sessionKey); throw new PanelError(401, "Войди в панель.");
      }
      session.usedAt = Date.now();
      if (req.method === "GET" && path === "/api/session") { json(res, 200, { csrf: session.csrf }); return; }
      if (req.method === "GET" && path === "/api/state") { json(res, 200, await adapter.snapshot()); return; }
      if (req.method !== "POST") throw new PanelError(404, "Не найдено.");
      if (!equal(String(req.headers["x-csrf-token"] ?? ""), session.csrf)) throw new PanelError(403, "Сессия изменилась. Обнови страницу.");
      if (path === "/api/logout") {
        sessions.delete(sessionKey); res.setHeader("Set-Cookie", cookie("", 0)); json(res, 200, { ok: true }); return;
      }
      if (path !== "/api/command") throw new PanelError(404, "Не найдено.");
      const id = String(req.headers["idempotency-key"] ?? "");
      if (!/^[a-zA-Z0-9-]{16,80}$/.test(id)) throw new PanelError(400, "Нужен идентификатор команды.");
      const input = await body(req);
      const hash = digest(JSON.stringify(input));
      const key = `${sessionKey}:${id}`;
      for (const [k, op] of operations) if (op.expires < Date.now()) operations.delete(k);
      let op = operations.get(key);
      if (op && op.hash !== hash) throw new PanelError(409, "Идентификатор уже использован.");
      if (!op) {
        if (commandBusy) throw new PanelError(409, "Предыдущая команда ещё выполняется.");
        commandAttempts = commandAttempts.filter(at => Date.now() - at < 60_000);
        if (commandAttempts.length >= 20) throw new PanelError(429, "Слишком много команд. Подожди минуту.");
        commandAttempts.push(Date.now()); commandBusy = true;
        const promise = Promise.resolve().then(() => adapter.command(input)).finally(() => { commandBusy = false; });
        op = { hash, promise, expires: Date.now() + 900_000 }; operations.set(key, op);
      }
      json(res, 200, await op.promise);
    })().catch((error: unknown) => {
      if (res.headersSent) { res.end(); return; }
      const known = error instanceof PanelError;
      if (known && error.status === 413) res.setHeader("Connection", "close");
      json(res, known ? error.status : 500, { error: known ? error.message : "Не удалось выполнить запрос. Проверь журнал бота." });
    });
  });
  server.requestTimeout = 20_000;
  server.headersTimeout = 10_000;
  server.keepAliveTimeout = 5_000;
  server.maxHeadersCount = 40;
  await new Promise<void>((resolve, reject) => { server.once("error", reject); server.listen(config.port, "127.0.0.1", resolve); });
  return { server, close: () => new Promise<void>((resolve, reject) => { server.close(error => error ? reject(error) : resolve()); server.closeIdleConnections(); }) };
}
