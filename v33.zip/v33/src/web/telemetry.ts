export interface PriceSample { at: number; itemId: string; top: number; target: number | null; price: number | null }
export interface UpdateSample { at: number; itemId: string; price: string; marketMs: number; prepareMs: number; seenToSendMs: number; apiMs: number }
export interface PanelEvent { at: number; kind: "info" | "error"; message: string; itemId?: string }
export type WorkingAdEvent =
  | { kind: "market"; chatId: number; itemId: string; top: string; price: string | null; target: string | null }
  | { kind: "update"; chatId: number; sample: UpdateSample }
  | { kind: "error"; chatId: number; itemId: string; message: string };

export class PanelTelemetry {
  private series: PriceSample[] = [];
  private updates: UpdateSample[] = [];
  private events: PanelEvent[] = [];
  constructor(private readonly chatId: number) {}
  observe(event: WorkingAdEvent): void {
    if (event.chatId !== this.chatId) return;
    if (event.kind === "market") {
      let last: PriceSample | undefined;
      for (let i = this.series.length - 1; i >= 0; i--) {
        if (this.series[i]!.itemId === event.itemId) { last = this.series[i]; break; }
      }
      if (last && Date.now() - last.at < 1_000) return;
      this.series.push({ at: Date.now(), itemId: event.itemId, top: Number(event.top),
        price: event.price === null ? null : Number(event.price), target: event.target === null ? null : Number(event.target) });
      this.series = this.series.filter(p => Date.now() - p.at < 900_000).slice(-3_000);
    } else if (event.kind === "update") {
      this.updates.push(event.sample);
      this.updates = this.updates.slice(-100);
      this.add("info", `Цена ${event.sample.price}; ответ API за ${event.sample.apiMs} мс`, event.sample.itemId);
    } else this.add("error", event.message, event.itemId);
  }
  add(kind: PanelEvent["kind"], message: string, itemId?: string): void {
    this.events.push({ at: Date.now(), kind, message: message.slice(0, 500), itemId });
    this.events = this.events.slice(-200);
  }
  snapshot() { return { series: [...this.series], updates: [...this.updates], events: [...this.events] }; }
}
