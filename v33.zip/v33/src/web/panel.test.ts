import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { createServer } from "node:net";
import { request } from "node:http";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { hashPassword, checkPassword, validateConfig } from "./auth.js";
import { startPanel, PanelError, type PanelAdapter } from "./server.js";
import { PanelTelemetry } from "./telemetry.js";
import type { WorkingAdsManager } from "../services/workingAdsManager.js";

const root = mkdtempSync(join(tmpdir(), "repost-panel-test-"));
process.env.TELEGRAM_BOT_TOKEN = "test-token";
process.env.SQLITE_PATH = join(root, "test.db");
process.env.BYBIT_API_KEY = "test-api-key";
process.env.BYBIT_API_SECRET = "test-api-secret";
const password = "test-private-password-123";
async function rawFetch(url: string, options: RequestInit = {}): Promise<Response> {
  return new Promise((resolve, reject) => {
    const req = request(url, {method:options.method, headers:Object.fromEntries(new Headers(options.headers).entries())}, res => {
      const chunks: Buffer[] = [];
      res.on("data",chunk=>chunks.push(Buffer.from(chunk)));
      res.on("end",()=>{
        const headers = new Headers();
        for(let i=0;i<res.rawHeaders.length;i+=2)headers.append(res.rawHeaders[i]!,res.rawHeaders[i+1]!);
        resolve(new Response(Buffer.concat(chunks),{status:res.statusCode,headers}));
      });
    });
    req.on("error",reject);req.end(options.body);
  });
}
let passwordHash = "";
before(async () => { passwordHash = await hashPassword(password); });
after(async () => {
  const { pool } = await import("../db/pool.js"); await pool.end();
  rmSync(root, { recursive: true, force: true });
});
async function freePort(): Promise<number> {
  const s = createServer();
  await new Promise<void>(resolve => s.listen(0, "127.0.0.1", resolve));
  const port = (s.address() as { port: number }).port;
  await new Promise<void>(resolve => s.close(() => resolve())); return port;
}
describe("panel security", () => {
  it("hashes passwords and validates secure deployment configuration", async () => {
    assert.ok(!passwordHash.includes(password));
    assert.equal(await checkPassword(password, passwordHash), true);
    assert.equal(await checkPassword("wrong", passwordHash), false);
    assert.equal(await checkPassword({}, passwordHash), false);
    const c = { version: 1, chatId: 123, port: 8787, origin: "http://127.0.0.1:8787", passwordHash };
    assert.equal(validateConfig(c).chatId, 123);
    for (const patch of [{origin:"http://my-server.example"},{origin:"https://x.example/path"},{chatId:0},{port:80},{passwordHash:"plain"}]) {
      assert.throws(() => validateConfig({...c,...patch}));
    }
    assert.equal(validateConfig({...c,origin:"https://panel.example"}).origin, "https://panel.example");
  });

  it("requires login, exact origin, CSRF and scoped static paths; invalidates logout", async (t) => {
    const port = await freePort(), origin = `http://127.0.0.1:${port}`;
    const calls: unknown[] = [];
    const panel = await startPanel({version:1,chatId:123,port,origin,passwordHash}, {
      async snapshot() { return {safe:true}; }, async command(input) { calls.push(input); return {ok:true}; },
    });
    t.after(() => panel.close());
    const post = (path: string, value: unknown, headers = {}) => fetch(origin+path,{method:"POST",headers:{Origin:origin,"Content-Type":"application/json",...headers},body:JSON.stringify(value)});
    assert.equal((await fetch(origin+"/api/state")).status,401);
    assert.equal((await post("/api/login",{password:"wrong"})).status,401);
    assert.equal((await post("/api/login",{password},{Origin:"https://evil.example"})).status,403);
    const login = await post("/api/login",{password});
    assert.equal(login.status,200);
    const cookie = login.headers.get("set-cookie")!;
    assert.match(cookie,/HttpOnly/);assert.match(cookie,/SameSite=Strict/);
    const {csrf} = await login.json() as {csrf:string};
    const auth = {Cookie:cookie.split(";")[0]!,"X-CSRF-Token":csrf,"Idempotency-Key":"test-request-0000001"};
    const state = await fetch(origin+"/api/state",{headers:auth});assert.deepEqual(await state.json(),{safe:true});
    assert.equal(state.headers.get("cache-control"),"no-store");assert.match(state.headers.get("content-security-policy")!,/frame-ancestors 'none'/);
    for(const path of ["/.env","/data/web-panel.json","/src/config.ts","/../.env"])assert.equal((await fetch(origin+path,{headers:auth})).status,404);
    assert.equal((await rawFetch(origin+"/",{headers:{Host:"evil.example"}})).status,403);
    assert.equal((await post("/api/command",{action:"enable"},{...auth,"X-CSRF-Token":"wrong"})).status,403);
    assert.equal(calls.length,0);
    assert.equal((await post("/api/command",{action:"enable"},auth)).status,200);
    assert.equal(calls.length,1);
    assert.equal((await post("/api/logout",{},auth)).status,200);
    assert.equal((await fetch(origin+"/api/state",{headers:auth})).status,401);
  });

  it("deduplicates concurrent commands and does not retry them after uncertain responses", async (t) => {
    const port=await freePort(),origin=`http://127.0.0.1:${port}`;let calls=0,release!:()=>void;
    const gate=new Promise<void>(resolve=>{release=resolve;});
    const panel=await startPanel({version:1,chatId:123,port,origin,passwordHash},{async snapshot(){return {};},async command(){calls++;await gate;return {ok:true};}});
    t.after(()=>panel.close());
    const login=await fetch(origin+"/api/login",{method:"POST",headers:{Origin:origin,"Content-Type":"application/json"},body:JSON.stringify({password})});
    const {csrf}=await login.json() as {csrf:string};
    const headers={Origin:origin,"Content-Type":"application/json",Cookie:login.headers.get("set-cookie")!.split(";")[0]!,"X-CSRF-Token":csrf,"Idempotency-Key":"test-request-0000002"};
    const send=(id=headers["Idempotency-Key"],value={action:"sync"})=>fetch(origin+"/api/command",{method:"POST",headers:{...headers,"Idempotency-Key":id},body:JSON.stringify(value)});
    const a=send();await new Promise(resolve=>setTimeout(resolve,20));
    const b=send();await new Promise(resolve=>setTimeout(resolve,20));
    assert.equal((await send("test-request-0000003")).status,409);
    assert.equal((await send(undefined,{action:"enable"})).status,409);
    assert.equal(calls,1);release();assert.equal((await a).status,200);assert.equal((await b).status,200);
    assert.equal((await send()).status,200);assert.equal(calls,1);
  });

  it("limits password attempts and requires HTTPS from the reverse proxy", async (t) => {
    const port=await freePort(),origin="https://panel.example";
    const panel=await startPanel({version:1,chatId:123,port,origin,passwordHash},{async snapshot(){return {};},async command(){return {};}});
    t.after(()=>panel.close());const base=`http://127.0.0.1:${port}`;
    assert.equal((await rawFetch(base,{headers:{Host:"panel.example"}})).status,403);
    const headers={Host:"panel.example",Origin:origin,"X-Forwarded-Proto":"https","Content-Type":"application/json"};
    const login=await rawFetch(base+"/api/login",{method:"POST",headers,body:JSON.stringify({password})});
    assert.match(login.headers.get("set-cookie")!,/__Host-repost_session/);assert.match(login.headers.get("set-cookie")!,/Secure/);
    for(let i=0;i<7;i++)assert.equal((await rawFetch(base+"/api/login",{method:"POST",headers,body:'{"password":"wrong"}'})).status,401);
    assert.equal((await rawFetch(base+"/api/login",{method:"POST",headers,body:JSON.stringify({password})})).status,429);
  });

  it("rejects oversized and invalid bodies, and hides unexpected server errors", async (t) => {
    const port=await freePort(),origin=`http://127.0.0.1:${port}`;
    let commands=0;
    const panel=await startPanel({version:1,chatId:123,port,origin,passwordHash},{
      async snapshot(){throw new Error("private-implementation-secret");},
      async command(){commands++;return {};},
    });
    t.after(()=>panel.close());
    const login=await fetch(origin+"/api/login",{method:"POST",headers:{Origin:origin,"Content-Type":"application/json"},body:JSON.stringify({password})});
    const {csrf}=await login.json() as {csrf:string};
    const headers={Origin:origin,"Content-Type":"application/json",Cookie:login.headers.get("set-cookie")!.split(";")[0]!,"X-CSRF-Token":csrf,"Idempotency-Key":"test-body-00000001"};
    const send=(body:string,extra={})=>rawFetch(origin+"/api/command",{method:"POST",headers:{...headers,...extra},body});
    const large=JSON.stringify({value:"x".repeat(20000)});
    assert.equal((await send(large,{"Content-Length":String(Buffer.byteLength(large))})).status,413);
    assert.equal((await send(large,{"Transfer-Encoding":"chunked"})).status,413);
    assert.equal((await send("{" )).status,400);
    assert.equal((await send("[]")).status,400);
    assert.equal((await send("{}",{"Content-Type":"text/plain"})).status,415);
    assert.equal(commands,0);
    const failed=await fetch(origin+"/api/state",{headers});
    assert.equal(failed.status,500);assert.doesNotMatch(await failed.text(),/private-implementation-secret/);
    const manifest=await fetch(origin+"/manifest.webmanifest");
    const pwa=await manifest.json() as {display:string;icons:{sizes:string}[]};
    assert.equal(pwa.display,"standalone");assert.deepEqual(pwa.icons.map(i=>i.sizes),["192x192","512x512"]);
  });
});

describe("panel adapter and telemetry", () => {
  let adapter: PanelAdapter;
  const calls: unknown[] = [];
  before(async () => {
    const {runMigrations}=await import("../db/migrate.js");await runMigrations();
    const {ensureSettings,updateSettings}=await import("../db/repositories/userSettings.js");await ensureSettings(123);
    await updateSettings(123,{paymentPassword:"never-return-this-password",connectionMode:"api"});
    const {createPanelAdapter}=await import("./adapter.js");
    adapter=createPanelAdapter(123,{
      list:async()=>[{id:7,item_id:"123456789",enabled:true,token_id:"USDT",currency_id:"RUB",side:"0",price_type:"0",last_price:"90",last_target_price:"90",last_error:null}],
      setEnabled:async(...args:unknown[])=>{calls.push(args);},
      setAdEnabled:async(...args:unknown[])=>{calls.push(args);},remove:async(...args:unknown[])=>{calls.push(args);},
      setIntervalSeconds:async()=>{},setUpdateIntervalSeconds:async()=>{},syncNow:async()=>[],
    } as unknown as WorkingAdsManager,new PanelTelemetry(123));
  });
  it("returns only public settings and does not expose secrets", async () => {
    const result=JSON.stringify(await adapter.snapshot());
    assert.doesNotMatch(result,/never-return|test-api|password|encrypted/);
    assert.match(result,/123456789/);
  });
  it("rejects stale settings, foreign IDs, non-boolean flags and arbitrary commands", async () => {
    const {revision}=await adapter.snapshot() as {revision:string};
    for(const input of [{action:"enable",revision:"old",enabled:true},{action:"ad-enable",revision,id:999,enabled:true},{action:"enable",revision,enabled:"true"},{action:"withdraw",revision}]) {
      await assert.rejects(adapter.command(input),PanelError);
    }
    assert.equal(calls.length,0);
    await adapter.command({action:"enable",revision,enabled:false});
    assert.deepEqual(calls,[[123,false]]);
  });
  it("validates intervals, decimals, fixed price and price boundaries", async () => {
    const {validatePriceSettings}=await import("./adapter.js");
    const good={mode:"auto",step:"0",min:"0",max:"120",fixed:null,monitor:"0,1",edit:"0.01"};
    assert.equal(validatePriceSettings(good).monitor,0.1);
    for(const patch of [{monitor:0},{edit:.009},{edit:Infinity},{min:121},{mode:"fixed"},{step:"NaN"},{monitor:""},{fixed:0}])assert.throws(()=>validatePriceSettings({...good,...patch}),PanelError);
  });
  it("keeps bounded telemetry per owner without reading the exchange", () => {
    const telemetry=new PanelTelemetry(123);
    telemetry.observe({kind:"market",chatId:456,itemId:"other",top:"999",price:null,target:null});
    for(let i=0;i<500;i++)telemetry.observe({kind:"market",chatId:123,itemId:"one",top:"90",price:"90",target:"90"});
    assert.equal(telemetry.snapshot().series.length,1);
    for(let i=0;i<300;i++)telemetry.add("info","test");
    assert.equal(telemetry.snapshot().events.length,200);
    assert.doesNotMatch(JSON.stringify(telemetry.snapshot()),/other/);
  });
});
