import { mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { DatabaseSync, type SQLInputValue } from "node:sqlite";
import { config } from "../config.js";

const here = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(here, "..", "..");
const DEFAULT_DB_PATH = resolve(ROOT, "data", "bybit_bot.db");

function resolveDbPath(): string {
  const p = config.database.path;
  return p && p.length > 0 ? p : DEFAULT_DB_PATH;
}

const dbPath = resolveDbPath();
mkdirSync(dirname(dbPath), { recursive: true });

export const db = new DatabaseSync(dbPath);
db.exec("PRAGMA journal_mode = WAL;");
db.exec("PRAGMA foreign_keys = ON;");

/** Совместимость со старыми вызовами pool.end() — закрывает SQLite-файл. */
export const pool = {
  end: async (): Promise<void> => {
    db.close();
  },
};

export interface QueryResult<T> {
  rows: T[];
}

/**
 * Тонкая прослойка эмулирующая pg-style API:
 *  - $1, $2 → ? позиционно
 *  - .query(sql, params) → {rows: [...]}
 *  - bool ↔ INTEGER 0/1 (на insert), TEXT[] ↔ JSON-string
 *
 * Это позволило перейти с pg на sqlite не переписывая каждый repository.
 */
export async function query<T = Record<string, unknown>>(
  text: string,
  params?: unknown[],
): Promise<QueryResult<T>> {
  const sql = text.replace(/\$(\d+)/g, "?");
  const args = (params ?? []).map(adaptInputParam) as SQLInputValue[];

  const trimmed = sql.trim().toUpperCase();
  const stmt = db.prepare(sql);

  if (trimmed.startsWith("SELECT") || /\bRETURNING\b/i.test(sql)) {
    const rows = stmt.all(...args) as T[];
    return { rows: rows.map(adaptOutputRow) as T[] };
  }

  stmt.run(...args);
  return { rows: [] };
}

/** SQLite не любит boolean — конвертим в 0/1. Массивы → JSON-string. */
function adaptInputParam(v: unknown): unknown {
  if (typeof v === "boolean") return v ? 1 : 0;
  if (Array.isArray(v)) return JSON.stringify(v);
  if (v instanceof Date) return v.toISOString();
  return v;
}

/** При чтении — пытаемся восстановить arrays и booleans по содержимому. */
function adaptOutputRow<T>(row: T): T {
  if (!row || typeof row !== "object") return row;
  const out: Record<string, unknown> = { ...(row as Record<string, unknown>) };
  for (const [k, v] of Object.entries(out)) {
    if (typeof v === "string") {
      // массив (payment_ids и т.п.) — JSON-encoded
      if (
        (k.endsWith("_ids") || k === "payment_ids") &&
        v.startsWith("[") &&
        v.endsWith("]")
      ) {
        try {
          out[k] = JSON.parse(v);
          continue;
        } catch {}
      }
      // ISO дата
      if (
        (k.endsWith("_at") || k === "expires_at") &&
        /^\d{4}-\d{2}-\d{2}T/.test(v)
      ) {
        out[k] = new Date(v);
      }
    }
    // INTEGER 0/1 для boolean-полей
    if (
      typeof v === "number" &&
      (k === "is_active" ||
        k === "quantity_auto" ||
        k === "subsidy_ad" ||
        k === "ok" ||
        k === "bourse_can_trade" ||
        k === "bourse_bulk_maker" ||
        k === "bourse_trade_with" ||
        k === "enabled" ||
        k === "working_ads_enabled" ||
        k === "dual_ads_enabled" ||
        k === "dual_ads_use_primary_params")
    ) {
      out[k] = Boolean(v);
    }
  }
  return out as T;
}
