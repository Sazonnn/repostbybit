ALTER TABLE user_settings ADD COLUMN dual_ads_enabled INTEGER NOT NULL DEFAULT 0;
ALTER TABLE user_settings ADD COLUMN dual_ads_premium_mode TEXT NOT NULL DEFAULT 'auto';
ALTER TABLE user_settings ADD COLUMN dual_ads_premium_manual TEXT NOT NULL DEFAULT '100.00';
ALTER TABLE user_settings ADD COLUMN dual_ads_use_primary_params INTEGER NOT NULL DEFAULT 1;

CREATE TABLE IF NOT EXISTS dual_side_settings (
  chat_id        INTEGER NOT NULL,
  side           TEXT    NOT NULL CHECK (side IN ('0','1')),
  quantity       TEXT    NOT NULL DEFAULT '10',
  quantity_auto  INTEGER NOT NULL DEFAULT 0,
  min_amount     TEXT    NOT NULL DEFAULT '500',
  max_amount     TEXT    NOT NULL DEFAULT '1000',
  payment_period TEXT    NOT NULL DEFAULT '30',
  payment_ids    TEXT    NOT NULL DEFAULT '[]',
  remark         TEXT    NOT NULL DEFAULT '',
  created_at     TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  updated_at     TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  PRIMARY KEY (chat_id, side)
);

ALTER TABLE ad_cycles ADD COLUMN secondary_item_id TEXT;
ALTER TABLE ad_cycles ADD COLUMN secondary_price TEXT;
ALTER TABLE ad_cycles ADD COLUMN secondary_premium TEXT;
ALTER TABLE ad_cycles ADD COLUMN secondary_last_rank INTEGER;
ALTER TABLE ad_cycles ADD COLUMN secondary_last_page INTEGER;
