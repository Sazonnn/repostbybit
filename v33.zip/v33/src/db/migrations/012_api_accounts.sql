CREATE TABLE IF NOT EXISTS bybit_api_accounts (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id              INTEGER NOT NULL,
  name                 TEXT    NOT NULL,
  api_key_encrypted    TEXT    NOT NULL,
  api_secret_encrypted TEXT    NOT NULL,
  key_hint             TEXT    NOT NULL,
  is_active            INTEGER NOT NULL DEFAULT 1,
  created_at           TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  updated_at           TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  UNIQUE(chat_id, name)
);

CREATE INDEX IF NOT EXISTS bybit_api_accounts_active_idx
  ON bybit_api_accounts(chat_id, is_active, updated_at DESC);
