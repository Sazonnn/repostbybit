ALTER TABLE user_settings ADD COLUMN bourse_can_trade INTEGER NOT NULL DEFAULT 1;
ALTER TABLE user_settings ADD COLUMN bourse_bulk_maker INTEGER NOT NULL DEFAULT 1;
ALTER TABLE user_settings ADD COLUMN bourse_trade_with INTEGER NOT NULL DEFAULT 1;
