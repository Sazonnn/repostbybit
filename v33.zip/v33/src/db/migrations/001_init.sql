-- SQLite-схема. Все таблицы в одном файле, чтобы миграция была идемпотентной
-- и не зависела от порядка применения старых pg-миграций.

CREATE TABLE IF NOT EXISTS bybit_sessions (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  bybit_uid    INTEGER,
  cookie       TEXT    NOT NULL,
  risk_token   TEXT    NOT NULL,
  guid         TEXT    NOT NULL,
  user_agent   TEXT    NOT NULL,
  expires_at   TEXT,
  is_active    INTEGER NOT NULL DEFAULT 1,
  created_at   TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  refreshed_at TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);
CREATE INDEX IF NOT EXISTS bybit_sessions_active_idx
  ON bybit_sessions(is_active, refreshed_at DESC);

CREATE TABLE IF NOT EXISTS user_settings (
  chat_id      INTEGER PRIMARY KEY,
  token_id     TEXT    NOT NULL DEFAULT 'USDT',
  currency_id  TEXT    NOT NULL DEFAULT 'RUB',
  side         TEXT    NOT NULL DEFAULT '1' CHECK (side IN ('0','1')),
  price_mode   TEXT    NOT NULL DEFAULT 'auto' CHECK (price_mode IN ('auto','fixed')),
  price_step   TEXT    NOT NULL DEFAULT '0.01',
  price_fixed  TEXT,
  price_min    TEXT    NOT NULL DEFAULT '0',
  price_max    TEXT    NOT NULL DEFAULT '999999',
  page_size    INTEGER NOT NULL DEFAULT 10,
  created_at   TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  updated_at   TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

CREATE TABLE IF NOT EXISTS side_settings (
  chat_id        INTEGER NOT NULL,
  side           TEXT    NOT NULL CHECK (side IN ('0','1')),
  quantity       TEXT    NOT NULL DEFAULT '10',
  quantity_auto  INTEGER NOT NULL DEFAULT 0,
  min_amount     TEXT    NOT NULL DEFAULT '500',
  max_amount     TEXT    NOT NULL DEFAULT '1000',
  payment_period TEXT    NOT NULL DEFAULT '30',
  payment_ids    TEXT    NOT NULL DEFAULT '[]',
  remark         TEXT    NOT NULL DEFAULT '',
  created_at     TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  updated_at     TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  PRIMARY KEY (chat_id, side)
);

CREATE TABLE IF NOT EXISTS ad_cycles (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id         INTEGER NOT NULL,
  user_id         INTEGER NOT NULL,
  status          TEXT    NOT NULL CHECK (status IN ('running','monitoring','stopped','failed','first_page')),
  token_id        TEXT    NOT NULL,
  currency_id     TEXT    NOT NULL,
  side            TEXT    NOT NULL,
  quantity        TEXT    NOT NULL,
  quantity_auto   INTEGER NOT NULL DEFAULT 0,
  min_amount      TEXT    NOT NULL,
  max_amount      TEXT    NOT NULL,
  payment_period  TEXT    NOT NULL,
  payment_ids     TEXT    NOT NULL DEFAULT '[]',
  remark          TEXT    NOT NULL DEFAULT '',
  current_item_id TEXT,
  current_price   TEXT,
  last_rank       INTEGER,
  last_page       INTEGER,
  attempts        INTEGER NOT NULL DEFAULT 0,
  last_error      TEXT,
  work_status     TEXT,
  show_status     TEXT,
  hidden_reason   TEXT,
  started_at      TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  updated_at      TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  stopped_at      TEXT
);
CREATE INDEX IF NOT EXISTS ad_cycles_chat_id_status_idx ON ad_cycles(chat_id, status);

CREATE TABLE IF NOT EXISTS cycle_attempts (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  cycle_id      INTEGER NOT NULL REFERENCES ad_cycles(id) ON DELETE CASCADE,
  item_id       TEXT,
  price         TEXT    NOT NULL,
  top_price     TEXT,
  rank          INTEGER,
  page          INTEGER,
  ok            INTEGER NOT NULL,
  error         TEXT,
  show_status   TEXT,
  hidden_reason TEXT,
  created_at    TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);
CREATE INDEX IF NOT EXISTS cycle_attempts_cycle_id_idx ON cycle_attempts(cycle_id, created_at DESC);
