-- В этой версии остаются только одиночный автоцикл и ручное создание.
-- Старые настройки dual переводим в single, а оставшийся второй item
-- снимается кодом остановки при первом управлении циклом.
UPDATE user_settings
SET ad_mode = 'single',
    dual_ads_enabled = 0,
    updated_at = CURRENT_TIMESTAMP
WHERE ad_mode = 'dual' OR dual_ads_enabled = 1;
