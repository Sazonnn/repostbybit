ALTER TABLE user_settings
  ADD COLUMN working_ads_update_interval_ms INTEGER NOT NULL DEFAULT 250
  CHECK (working_ads_update_interval_ms BETWEEN 250 AND 86400000);
