ALTER TABLE user_settings ADD COLUMN primary_price_type TEXT NOT NULL DEFAULT 'fixed';

ALTER TABLE ad_cycles ADD COLUMN current_price_type TEXT NOT NULL DEFAULT '0';
ALTER TABLE ad_cycles ADD COLUMN current_premium TEXT;
