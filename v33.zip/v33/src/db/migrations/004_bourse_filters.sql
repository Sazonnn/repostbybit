ALTER TABLE user_settings ADD COLUMN bourse_verification_filter INTEGER NOT NULL DEFAULT 0;
ALTER TABLE user_settings ADD COLUMN bourse_sort_type TEXT NOT NULL DEFAULT 'OVERALL_RANKING';
