ALTER TABLE bybit_sessions ADD COLUMN nickname TEXT;
