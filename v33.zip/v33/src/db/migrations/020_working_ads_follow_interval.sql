-- Отдельный интервал проверки для "ведомых" объявлений: как часто ведомый
-- смотрит, где в стакане разведчик и какая у него цена.
ALTER TABLE user_settings
  ADD COLUMN working_ads_follow_interval_ms INTEGER NOT NULL DEFAULT 1000;
