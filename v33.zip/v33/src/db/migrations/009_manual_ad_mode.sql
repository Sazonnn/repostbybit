ALTER TABLE user_settings ADD COLUMN ad_mode TEXT NOT NULL DEFAULT 'single';
UPDATE user_settings SET ad_mode = 'dual' WHERE dual_ads_enabled = 1;

CREATE TABLE IF NOT EXISTS manual_ads (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id     INTEGER NOT NULL,
  item_id     TEXT    NOT NULL,
  token_id    TEXT    NOT NULL,
  currency_id TEXT    NOT NULL,
  side        TEXT    NOT NULL,
  price_type  TEXT    NOT NULL DEFAULT '0',
  price       TEXT    NOT NULL,
  premium     TEXT,
  status      TEXT    NOT NULL DEFAULT 'active',
  created_at  TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  updated_at  TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);
CREATE INDEX IF NOT EXISTS manual_ads_chat_status_idx
  ON manual_ads(chat_id, status, created_at DESC);
