ALTER TABLE user_settings ADD COLUMN payment_password TEXT;
