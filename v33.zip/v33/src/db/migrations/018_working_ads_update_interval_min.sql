ALTER TABLE user_settings
  ADD COLUMN working_ads_update_interval_ms_new INTEGER NOT NULL DEFAULT 250
  CHECK (working_ads_update_interval_ms_new BETWEEN 10 AND 86400000);

UPDATE user_settings
  SET working_ads_update_interval_ms_new = working_ads_update_interval_ms;

ALTER TABLE user_settings DROP COLUMN working_ads_update_interval_ms;
ALTER TABLE user_settings
  RENAME COLUMN working_ads_update_interval_ms_new TO working_ads_update_interval_ms;
