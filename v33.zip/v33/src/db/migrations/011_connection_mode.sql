ALTER TABLE user_settings ADD COLUMN connection_mode TEXT NOT NULL DEFAULT 'session';
