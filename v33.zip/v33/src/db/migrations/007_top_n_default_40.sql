UPDATE user_settings
SET bourse_top_n = 40
WHERE bourse_top_n = 10;
