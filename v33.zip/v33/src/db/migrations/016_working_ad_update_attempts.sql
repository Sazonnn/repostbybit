CREATE TABLE working_ad_update_attempts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id TEXT NOT NULL,
  sent_at_ms INTEGER NOT NULL
);

CREATE INDEX working_ad_update_attempts_item_time
  ON working_ad_update_attempts (item_id, sent_at_ms);
