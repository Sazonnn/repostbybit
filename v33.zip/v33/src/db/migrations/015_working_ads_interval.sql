ALTER TABLE user_settings
  ADD COLUMN working_ads_interval_ms INTEGER NOT NULL DEFAULT 30000;
