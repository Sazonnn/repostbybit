ALTER TABLE user_settings
  ADD COLUMN working_ads_enabled INTEGER NOT NULL DEFAULT 0;

CREATE TABLE working_ads (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id           INTEGER NOT NULL,
  item_id           TEXT    NOT NULL,
  enabled           INTEGER NOT NULL DEFAULT 1,
  token_id          TEXT    NOT NULL,
  currency_id       TEXT    NOT NULL,
  side              TEXT    NOT NULL CHECK (side IN ('0','1')),
  price_type        TEXT    NOT NULL CHECK (price_type IN ('0','1')),
  last_price        TEXT,
  last_target_price TEXT,
  last_error        TEXT,
  last_checked_at   TEXT,
  last_updated_at   TEXT,
  created_at        TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  updated_at        TEXT    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  UNIQUE(chat_id, item_id)
);

CREATE INDEX working_ads_chat_enabled_idx
  ON working_ads(chat_id, enabled, id);
