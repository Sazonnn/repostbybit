import { query } from "../pool.js";
import { config } from "../../config.js";

export interface SideSettingsRow {
  chat_id: string;
  side: "0" | "1";
  quantity: string;
  quantity_auto: boolean;
  min_amount: string;
  max_amount: string;
  payment_period: string;
  payment_ids: string[];
  remark: string;
  created_at: Date;
  updated_at: Date;
}

export async function ensureSideSettings(
  chatId: number,
  side: "0" | "1",
): Promise<SideSettingsRow> {
  const existing = await getSideSettings(chatId, side);
  if (existing) return existing;
  const { rows } = await query<SideSettingsRow>(
    `INSERT INTO side_settings
       (chat_id, side, quantity, min_amount, max_amount, payment_period, payment_ids, remark)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
     ON CONFLICT (chat_id, side) DO UPDATE SET updated_at = CURRENT_TIMESTAMP
     RETURNING *`,
    [
      chatId,
      side,
      config.p2p.quantity,
      config.p2p.minAmount,
      config.p2p.maxAmount,
      config.p2p.paymentPeriod,
      config.p2p.paymentIds,
      config.p2p.remark,
    ],
  );
  return rows[0]!;
}

export async function getSideSettings(
  chatId: number,
  side: "0" | "1",
): Promise<SideSettingsRow | null> {
  const { rows } = await query<SideSettingsRow>(
    `SELECT * FROM side_settings WHERE chat_id = $1 AND side = $2`,
    [chatId, side],
  );
  return rows[0] ?? null;
}

export async function updateSideSettings(
  chatId: number,
  side: "0" | "1",
  patch: Partial<{
    quantity: string;
    quantityAuto: boolean;
    minAmount: string;
    maxAmount: string;
    paymentPeriod: string;
    paymentIds: string[];
    remark: string;
  }>,
): Promise<SideSettingsRow> {
  await ensureSideSettings(chatId, side);
  const map: Record<string, string> = {
    quantity: "quantity",
    quantityAuto: "quantity_auto",
    minAmount: "min_amount",
    maxAmount: "max_amount",
    paymentPeriod: "payment_period",
    paymentIds: "payment_ids",
    remark: "remark",
  };
  const sets: string[] = ["updated_at = CURRENT_TIMESTAMP"];
  const values: unknown[] = [];
  let i = 1;
  for (const [k, v] of Object.entries(patch)) {
    const col = map[k];
    if (!col) continue;
    sets.push(`${col} = $${i++}`);
    values.push(v);
  }
  if (values.length === 0) {
    return (await getSideSettings(chatId, side))!;
  }
  values.push(chatId, side);
  const { rows } = await query<SideSettingsRow>(
    `UPDATE side_settings SET ${sets.join(", ")}
     WHERE chat_id = $${i} AND side = $${i + 1}
     RETURNING *`,
    values,
  );
  return rows[0]!;
}
