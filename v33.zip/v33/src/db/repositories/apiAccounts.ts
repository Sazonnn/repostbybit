import {
  decryptCredential,
  encryptCredential,
} from "../../security/credentialCrypto.js";
import { db, query } from "../pool.js";

export interface ApiAccountRow {
  id: number;
  chat_id: string;
  name: string;
  api_key_encrypted: string;
  api_secret_encrypted: string;
  key_hint: string;
  is_active: boolean;
  created_at: Date;
  updated_at: Date;
}

export interface ApiAccountSummary {
  id: number;
  name: string;
  keyHint: string;
  isActive: boolean;
}

export interface ActiveApiCredentials extends ApiAccountSummary {
  apiKey: string;
  apiSecret: string;
}

function keyHint(apiKey: string): string {
  if (apiKey.length <= 8) return `${apiKey.slice(0, 2)}…${apiKey.slice(-2)}`;
  return `${apiKey.slice(0, 4)}…${apiKey.slice(-4)}`;
}

function summary(row: ApiAccountRow): ApiAccountSummary {
  return {
    id: row.id,
    name: row.name,
    keyHint: row.key_hint,
    isActive: row.is_active,
  };
}

export async function listApiAccounts(
  chatId: number,
): Promise<ApiAccountSummary[]> {
  const { rows } = await query<ApiAccountRow>(
    `SELECT * FROM bybit_api_accounts
     WHERE chat_id = $1
     ORDER BY is_active DESC, updated_at DESC, id DESC`,
    [chatId],
  );
  return rows.map(summary);
}

export async function getActiveApiAccount(
  chatId: number,
): Promise<ApiAccountSummary | null> {
  const { rows } = await query<ApiAccountRow>(
    `SELECT * FROM bybit_api_accounts
     WHERE chat_id = $1 AND is_active = 1
     ORDER BY updated_at DESC, id DESC
     LIMIT 1`,
    [chatId],
  );
  return rows[0] ? summary(rows[0]) : null;
}

// Расшифрованные ключи активного аккаунта держим в памяти 60 с, чтобы не
// ходить в базу и не расшифровывать их при каждом запросе к Bybit.
const CREDENTIALS_CACHE_MS = 60_000;
const credentialsCache = new Map<number, { value: ActiveApiCredentials; expiresAt: number }>();

function clearCredentialsCache(chatId?: number): void {
  if (chatId === undefined) credentialsCache.clear();
  else credentialsCache.delete(chatId);
}

export async function getActiveApiCredentials(
  chatId: number,
): Promise<ActiveApiCredentials | null> {
  const cached = credentialsCache.get(chatId);
  if (cached && cached.expiresAt > Date.now()) return cached.value;
  const value = await loadActiveApiCredentials(chatId);
  if (value) credentialsCache.set(chatId, { value, expiresAt: Date.now() + CREDENTIALS_CACHE_MS });
  else credentialsCache.delete(chatId);
  return value;
}

async function loadActiveApiCredentials(
  chatId: number,
): Promise<ActiveApiCredentials | null> {
  const { rows } = await query<ApiAccountRow>(
    `SELECT * FROM bybit_api_accounts
     WHERE chat_id = $1 AND is_active = 1
     ORDER BY updated_at DESC, id DESC
     LIMIT 1`,
    [chatId],
  );
  const row = rows[0];
  if (!row) return null;
  return {
    ...summary(row),
    apiKey: decryptCredential(row.api_key_encrypted),
    apiSecret: decryptCredential(row.api_secret_encrypted),
  };
}

export async function saveApiAccount(input: {
  chatId: number;
  name: string;
  apiKey: string;
  apiSecret: string;
}): Promise<ApiAccountSummary> {
  clearCredentialsCache();
  const encryptedKey = encryptCredential(input.apiKey);
  const encryptedSecret = encryptCredential(input.apiSecret);
  const hint = keyHint(input.apiKey);

  db.exec("BEGIN IMMEDIATE");
  try {
    db.prepare(
      `UPDATE bybit_api_accounts
       SET is_active = 0, updated_at = CURRENT_TIMESTAMP
       WHERE chat_id = ?`,
    ).run(input.chatId);
    db.prepare(
      `INSERT INTO bybit_api_accounts
         (chat_id, name, api_key_encrypted, api_secret_encrypted, key_hint, is_active)
       VALUES (?, ?, ?, ?, ?, 1)
       ON CONFLICT(chat_id, name) DO UPDATE SET
         api_key_encrypted = excluded.api_key_encrypted,
         api_secret_encrypted = excluded.api_secret_encrypted,
         key_hint = excluded.key_hint,
         is_active = 1,
         updated_at = CURRENT_TIMESTAMP`,
    ).run(
      input.chatId,
      input.name,
      encryptedKey,
      encryptedSecret,
      hint,
    );
    db.exec("COMMIT");
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
  const active = await getActiveApiAccount(input.chatId);
  if (!active) throw new Error("API-аккаунт сохранился, но не найден в базе");
  return active;
}

export async function activateApiAccount(
  chatId: number,
  accountId: number,
): Promise<ApiAccountSummary> {
  clearCredentialsCache();
  db.exec("BEGIN IMMEDIATE");
  try {
    const exists = db
      .prepare(
        `SELECT id FROM bybit_api_accounts WHERE id = ? AND chat_id = ?`,
      )
      .get(accountId, chatId);
    if (!exists) throw new Error("API-аккаунт не найден");
    db.prepare(
      `UPDATE bybit_api_accounts
       SET is_active = 0, updated_at = CURRENT_TIMESTAMP
       WHERE chat_id = ?`,
    ).run(chatId);
    db.prepare(
      `UPDATE bybit_api_accounts
       SET is_active = 1, updated_at = CURRENT_TIMESTAMP
       WHERE id = ? AND chat_id = ?`,
    ).run(accountId, chatId);
    db.exec("COMMIT");
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
  const active = await getActiveApiAccount(chatId);
  if (!active) throw new Error("Не удалось активировать API-аккаунт");
  return active;
}

export async function deleteApiAccount(
  chatId: number,
  accountId: number,
): Promise<void> {
  clearCredentialsCache();
  const row = db
    .prepare(
      `SELECT is_active FROM bybit_api_accounts WHERE id = ? AND chat_id = ?`,
    )
    .get(accountId, chatId) as { is_active?: number } | undefined;
  if (!row) return;

  db.exec("BEGIN IMMEDIATE");
  try {
    db.prepare(
      `DELETE FROM bybit_api_accounts WHERE id = ? AND chat_id = ?`,
    ).run(accountId, chatId);
    if (row.is_active) {
      const replacement = db
        .prepare(
          `SELECT id FROM bybit_api_accounts
           WHERE chat_id = ?
           ORDER BY updated_at DESC, id DESC
           LIMIT 1`,
        )
        .get(chatId) as { id?: number } | undefined;
      if (replacement?.id) {
        db.prepare(
          `UPDATE bybit_api_accounts
           SET is_active = 1, updated_at = CURRENT_TIMESTAMP
           WHERE id = ?`,
        ).run(replacement.id);
      }
    }
    db.exec("COMMIT");
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}
