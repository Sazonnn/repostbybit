import { query } from "../pool.js";

export interface WorkingAdRow {
  id: number;
  chat_id: string;
  item_id: string;
  enabled: boolean;
  token_id: string;
  currency_id: string;
  side: "0" | "1";
  price_type: "0" | "1";
  last_price: string | null;
  last_target_price: string | null;
  last_error: string | null;
  last_checked_at: Date | null;
  last_updated_at: Date | null;
  created_at: Date;
  updated_at: Date;
  // "Ведомое объявление": item_id другого рабочего объявления (лидера),
  // чью последнюю известную цену просто копируем вместо расчёта от рынка.
  // NULL — обычное объявление, считает цену от стакана как раньше.
  follow_item_id: string | null;
}

export async function listWorkingAds(chatId: number): Promise<WorkingAdRow[]> {
  const { rows } = await query<WorkingAdRow>(
    `SELECT * FROM working_ads
     WHERE chat_id = $1
     ORDER BY enabled DESC, id ASC`,
    [chatId],
  );
  return rows;
}

export async function listEnabledWorkingAds(
  chatId: number,
): Promise<WorkingAdRow[]> {
  const { rows } = await query<WorkingAdRow>(
    `SELECT * FROM working_ads
     WHERE chat_id = $1 AND enabled = 1
     ORDER BY id ASC`,
    [chatId],
  );
  return rows;
}

export async function getWorkingAd(
  chatId: number,
  id: number,
): Promise<WorkingAdRow | null> {
  const { rows } = await query<WorkingAdRow>(
    `SELECT * FROM working_ads WHERE chat_id = $1 AND id = $2`,
    [chatId, id],
  );
  return rows[0] ?? null;
}

export async function saveWorkingAd(input: {
  chatId: number;
  itemId: string;
  tokenId: string;
  currencyId: string;
  side: "0" | "1";
  priceType: "0" | "1";
  lastPrice: string | null;
}): Promise<WorkingAdRow> {
  const { rows } = await query<WorkingAdRow>(
    `INSERT INTO working_ads
       (chat_id, item_id, enabled, token_id, currency_id, side, price_type,
        last_price)
     VALUES ($1,$2,1,$3,$4,$5,$6,$7)
     ON CONFLICT(chat_id, item_id) DO UPDATE SET
       enabled = 1,
       token_id = excluded.token_id,
       currency_id = excluded.currency_id,
       side = excluded.side,
       price_type = excluded.price_type,
       last_price = excluded.last_price,
       last_error = NULL,
       updated_at = CURRENT_TIMESTAMP
     RETURNING *`,
    [
      input.chatId,
      input.itemId,
      input.tokenId,
      input.currencyId,
      input.side,
      input.priceType,
      input.lastPrice,
    ],
  );
  return rows[0]!;
}

export async function setWorkingAdEnabled(
  chatId: number,
  id: number,
  enabled: boolean,
): Promise<WorkingAdRow | null> {
  const { rows } = await query<WorkingAdRow>(
    `UPDATE working_ads
     SET enabled = $1, last_error = NULL, updated_at = CURRENT_TIMESTAMP
     WHERE chat_id = $2 AND id = $3
     RETURNING *`,
    [enabled, chatId, id],
  );
  return rows[0] ?? null;
}

export async function deleteWorkingAd(
  chatId: number,
  id: number,
): Promise<void> {
  await query(
    `DELETE FROM working_ads WHERE chat_id = $1 AND id = $2`,
    [chatId, id],
  );
}

export async function setWorkingAdFollow(
  chatId: number,
  id: number,
  followItemId: string | null,
): Promise<WorkingAdRow | null> {
  const { rows } = await query<WorkingAdRow>(
    `UPDATE working_ads
     SET follow_item_id = $1, last_error = NULL, updated_at = CURRENT_TIMESTAMP
     WHERE chat_id = $2 AND id = $3
     RETURNING *`,
    [followItemId, chatId, id],
  );
  return rows[0] ?? null;
}

export async function updateWorkingAdState(
  chatId: number,
  id: number,
  patch: Partial<{
    tokenId: string;
    currencyId: string;
    side: "0" | "1";
    priceType: "0" | "1";
    lastPrice: string | null;
    lastTargetPrice: string | null;
    lastError: string | null;
    checkedAt: Date;
    priceUpdatedAt: Date;
  }>,
): Promise<WorkingAdRow | null> {
  const map: Record<string, string> = {
    tokenId: "token_id",
    currencyId: "currency_id",
    side: "side",
    priceType: "price_type",
    lastPrice: "last_price",
    lastTargetPrice: "last_target_price",
    lastError: "last_error",
    checkedAt: "last_checked_at",
    priceUpdatedAt: "last_updated_at",
  };
  const sets = ["updated_at = CURRENT_TIMESTAMP"];
  const values: unknown[] = [];
  let index = 1;
  for (const [key, value] of Object.entries(patch)) {
    const column = map[key];
    if (!column) continue;
    sets.push(`${column} = $${index++}`);
    values.push(value);
  }
  if (values.length === 0) return getWorkingAd(chatId, id);
  values.push(chatId, id);
  const { rows } = await query<WorkingAdRow>(
    `UPDATE working_ads
     SET ${sets.join(", ")}
     WHERE chat_id = $${index++} AND id = $${index}
     RETURNING *`,
    values,
  );
  return rows[0] ?? null;
}
