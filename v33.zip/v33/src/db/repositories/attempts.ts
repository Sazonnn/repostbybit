import { query } from "../pool.js";

export interface CycleAttemptInput {
  cycleId: number;
  itemId?: string | null;
  price: string;
  topPrice?: string | null;
  rank?: number | null;
  page?: number | null;
  ok: boolean;
  error?: string | null;
  showStatus?: string | null;
  hiddenReason?: string | null;
}

export async function recordAttempt(input: CycleAttemptInput): Promise<void> {
  await query(
    `INSERT INTO cycle_attempts
       (cycle_id, item_id, price, top_price, rank, page, ok, error, show_status, hidden_reason)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
    [
      input.cycleId,
      input.itemId ?? null,
      input.price,
      input.topPrice ?? null,
      input.rank ?? null,
      input.page ?? null,
      input.ok,
      input.error ?? null,
      input.showStatus ?? null,
      input.hiddenReason ?? null,
    ],
  );
}
