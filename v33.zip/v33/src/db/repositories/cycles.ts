import { query } from "../pool.js";

export type CycleStatus =
  | "running"
  | "monitoring"
  | "stopped"
  | "failed"
  | "first_page";

export interface AdCycleRow {
  id: number;
  chat_id: string;
  user_id: string;
  status: CycleStatus;
  token_id: string;
  currency_id: string;
  side: string;
  quantity: string;
  quantity_auto: boolean;
  min_amount: string;
  max_amount: string;
  payment_period: string;
  payment_ids: string[];
  remark: string;
  current_item_id: string | null;
  current_price: string | null;
  current_price_type: "0" | "1";
  current_premium: string | null;
  secondary_item_id: string | null;
  secondary_price: string | null;
  secondary_premium: string | null;
  secondary_last_rank: number | null;
  secondary_last_page: number | null;
  last_rank: number | null;
  last_page: number | null;
  attempts: number;
  last_error: string | null;
  work_status: string | null;
  show_status: string | null;
  hidden_reason: string | null;
  started_at: Date;
  updated_at: Date;
  stopped_at: Date | null;
}

export interface CreateCycleInput {
  chatId: number;
  userId: number;
  tokenId: string;
  currencyId: string;
  side: string;
  quantity: string;
  quantityAuto: boolean;
  minAmount: string;
  maxAmount: string;
  paymentPeriod: string;
  paymentIds: string[];
  remark: string;
}

export async function createCycle(input: CreateCycleInput): Promise<AdCycleRow> {
  const { rows } = await query<AdCycleRow>(
    `INSERT INTO ad_cycles
       (chat_id, user_id, status, token_id, currency_id, side, quantity, quantity_auto,
        min_amount, max_amount, payment_period, payment_ids, remark)
     VALUES ($1, $2, 'running', $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
     RETURNING *`,
    [
      input.chatId,
      input.userId,
      input.tokenId,
      input.currencyId,
      input.side,
      input.quantity,
      input.quantityAuto,
      input.minAmount,
      input.maxAmount,
      input.paymentPeriod,
      input.paymentIds,
      input.remark,
    ],
  );
  return rows[0]!;
}

export async function getActiveCycleByChat(
  chatId: number,
): Promise<AdCycleRow | null> {
  const { rows } = await query<AdCycleRow>(
    `SELECT * FROM ad_cycles
     WHERE chat_id = $1 AND status IN ('running', 'monitoring', 'first_page')
     ORDER BY id DESC LIMIT 1`,
    [chatId],
  );
  return rows[0] ?? null;
}

export async function getCycleById(id: number): Promise<AdCycleRow | null> {
  const { rows } = await query<AdCycleRow>(
    `SELECT * FROM ad_cycles WHERE id = $1`,
    [id],
  );
  return rows[0] ?? null;
}

export async function listActiveCycles(): Promise<AdCycleRow[]> {
  const { rows } = await query<AdCycleRow>(
    `SELECT * FROM ad_cycles
     WHERE status IN ('running', 'monitoring', 'first_page')
     ORDER BY id ASC`,
  );
  return rows;
}

export async function updateCycleState(
  id: number,
  patch: Partial<{
    status: CycleStatus;
    currentItemId: string | null;
    currentPrice: string | null;
    currentPriceType: "0" | "1";
    currentPremium: string | null;
    secondaryItemId: string | null;
    secondaryPrice: string | null;
    secondaryPremium: string | null;
    secondaryLastRank: number | null;
    secondaryLastPage: number | null;
    lastRank: number | null;
    lastPage: number | null;
    attempts: number;
    lastError: string | null;
    stoppedAt: Date | null;
    workStatus: string | null;
    showStatus: string | null;
    hiddenReason: string | null;
  }>,
): Promise<void> {
  const sets: string[] = ["updated_at = CURRENT_TIMESTAMP"];
  const values: unknown[] = [];
  let i = 1;

  const map: Record<string, string> = {
    status: "status",
    currentItemId: "current_item_id",
    currentPrice: "current_price",
    currentPriceType: "current_price_type",
    currentPremium: "current_premium",
    secondaryItemId: "secondary_item_id",
    secondaryPrice: "secondary_price",
    secondaryPremium: "secondary_premium",
    secondaryLastRank: "secondary_last_rank",
    secondaryLastPage: "secondary_last_page",
    lastRank: "last_rank",
    lastPage: "last_page",
    attempts: "attempts",
    lastError: "last_error",
    stoppedAt: "stopped_at",
    workStatus: "work_status",
    showStatus: "show_status",
    hiddenReason: "hidden_reason",
  };

  for (const [key, value] of Object.entries(patch)) {
    const col = map[key];
    if (!col) continue;
    sets.push(`${col} = $${i++}`);
    values.push(value);
  }

  values.push(id);
  await query(
    `UPDATE ad_cycles SET ${sets.join(", ")} WHERE id = $${i}`,
    values,
  );
}

export async function incrementAttempts(id: number): Promise<void> {
  await query(
    `UPDATE ad_cycles SET attempts = attempts + 1, updated_at = CURRENT_TIMESTAMP WHERE id = $1`,
    [id],
  );
}
