import { query } from "../pool.js";

export interface ManualAdRow {
  id: number;
  chat_id: string;
  item_id: string;
  token_id: string;
  currency_id: string;
  side: "0" | "1";
  price_type: "0" | "1";
  price: string;
  premium: string | null;
  status: "active" | "cancelled" | "error";
  created_at: Date;
  updated_at: Date;
}

export async function createManualAdRecord(input: {
  chatId: number;
  itemId: string;
  tokenId: string;
  currencyId: string;
  side: "0" | "1";
  priceType?: "0" | "1";
  price: string;
  premium?: string | null;
}): Promise<ManualAdRow> {
  const { rows } = await query<ManualAdRow>(
    `INSERT INTO manual_ads
       (chat_id, item_id, token_id, currency_id, side, price_type, price, premium, status)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'active')
     RETURNING *`,
    [
      input.chatId,
      input.itemId,
      input.tokenId,
      input.currencyId,
      input.side,
      input.priceType ?? "0",
      input.price,
      input.premium ?? null,
    ],
  );
  return rows[0]!;
}

export async function listActiveManualAds(chatId: number): Promise<ManualAdRow[]> {
  const { rows } = await query<ManualAdRow>(
    `SELECT * FROM manual_ads
     WHERE chat_id = $1 AND status = 'active'
     ORDER BY created_at DESC`,
    [chatId],
  );
  return rows;
}

export async function updateManualAdStatus(
  id: number,
  status: ManualAdRow["status"],
): Promise<void> {
  await query(
    `UPDATE manual_ads
     SET status = $1, updated_at = CURRENT_TIMESTAMP
     WHERE id = $2`,
    [status, id],
  );
}
