import { query } from "../pool.js";

export interface SessionRow {
  id: number;
  bybit_uid: string | null;
  cookie: string;
  risk_token: string;
  guid: string;
  user_agent: string;
  nickname: string | null;
  expires_at: Date | null;
  is_active: boolean;
  created_at: Date;
  refreshed_at: Date;
}

export async function setSessionNickname(
  sessionId: number,
  nickname: string,
): Promise<void> {
  await query(
    `UPDATE bybit_sessions SET nickname = $1 WHERE id = $2`,
    [nickname, sessionId],
  );
}

export interface SaveSessionInput {
  bybitUid?: string | null;
  cookie: string;
  riskToken: string;
  guid: string;
  userAgent: string;
  expiresAt?: Date | null;
}

export async function getActiveSession(): Promise<SessionRow | null> {
  const { rows } = await query<SessionRow>(
    `SELECT * FROM bybit_sessions
     WHERE is_active = 1
     ORDER BY refreshed_at DESC LIMIT 1`,
  );
  return rows[0] ?? null;
}

export async function saveSession(input: SaveSessionInput): Promise<SessionRow> {
  await query(`UPDATE bybit_sessions SET is_active = 0 WHERE is_active = 1`);
  const { rows } = await query<SessionRow>(
    `INSERT INTO bybit_sessions
       (bybit_uid, cookie, risk_token, guid, user_agent, expires_at, is_active)
     VALUES ($1, $2, $3, $4, $5, $6, 1)
     RETURNING *`,
    [
      input.bybitUid ?? null,
      input.cookie,
      input.riskToken,
      input.guid,
      input.userAgent,
      input.expiresAt ?? null,
    ],
  );
  return rows[0]!;
}

export async function markStale(sessionId: number): Promise<void> {
  await query(
    `UPDATE bybit_sessions SET is_active = 0 WHERE id = $1`,
    [sessionId],
  );
}
