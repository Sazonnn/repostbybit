import { db } from "../pool.js";

// NO_API_LIMITS=1 в .env — выключить ВСЕ внутренние ограничения на частоту изменений
// цены: зазор между изменениями, лимит за 5 с и за 1 с по аккаунту, разнос 50 мс,
// минимальный интервал по объявлению и лимит на объявление за 5 мин. Бот отправляет
// изменение сразу, Bybit может отвечать 10006 — бот повторяет без паузы.
// Внимание: по документации Bybit одно объявление можно менять не больше 10 раз
// за 5 минут — при превышении Bybit может отказывать этому объявлению дольше.
export const NO_API_LIMITS = process.env.NO_API_LIMITS === "1";

const WINDOW_MS = 300_000;
// Внутренний (не Bybit) предохранитель: сколько изменений цены одного
// объявления за 5 мин. Раньше было 10 — на смене курса пара делает 12+
// прыжков, и объявление застревало выше потолка на 4,5 мин (лог 27.09 20:26).
// Можно поменять в .env: AD_UPDATE_LIMIT_5MIN=40 (от 10 до 200).
const MAX_ATTEMPTS = (() => {
  const value = Number(process.env.AD_UPDATE_LIMIT_5MIN);
  return Number.isFinite(value) && value >= 10 && value <= 200 ? Math.round(value) : 40;
})();
const ITEM_LIMIT_5MIN = NO_API_LIMITS ? 1_000_000 : MAX_ATTEMPTS;
// Между любыми двумя изменениями цены (по всем объявлениям) — не меньше этого.
// В момент смены курса оба объявления пары меняют цену почти одновременно;
// небольшой разнос, чтобы они не уходили к Bybit в одну и ту же миллисекунду.
const WRITE_SPACING_MS = NO_API_LIMITS ? 0 : 50;
// Минимально допустимая настройка "Мин. интервал редактирования".
const MIN_USER_INTERVAL_MS = 10;
const WRITE_WINDOW_MS = 1_000;
// WRITES_PER_SECOND в .env (1..100): сколько изменений цены можно отправить за 1 с.
// По умолчанию 4 (без NO_API_LIMITS) или без ограничения (с NO_API_LIMITS=1). По
// документации Bybit запись — 5 запросов в секунду на UID: лишние получают 10006, а
// сам отказ, скорее всего, тоже занимает окно. Лишнее изменение лучше отложить на
// десятки мс, чем отправить на отказ: WRITES_PER_SECOND=4 при NO_API_LIMITS=1.
const MAX_WRITES_PER_WINDOW = (() => {
  const raw = process.env.WRITES_PER_SECOND;
  const value = Number(raw);
  if (raw !== undefined && raw.trim() !== "" && Number.isFinite(value) && value >= 1 && value <= 100) {
    return Math.round(value);
  }
  return NO_API_LIMITS ? 1_000_000 : 4;
})();
const DEFAULT_UPDATE_INTERVAL_MS = 250;
const MAX_UPDATE_INTERVAL_MS = 86_400_000;

// Лимит Bybit на изменение цены (/v5/p2p/item/update) — на аккаунт, общий для
// всех его объявлений. По логам: 4 изменения за 5 с проходят, 5-е получает
// 10006 (и после него пауза 1–8 с). Держимся в этих рамках сами.
export const ACCOUNT_UPDATE_WINDOW_MS = 5_000;
// Можно поднять в .env: ACCOUNT_UPDATE_LIMIT=100 (от 4 до 100) — тогда бот не
// будет ждать освобождения слота, а просто отправит (Bybit может ответить 10006).
export const ACCOUNT_UPDATE_LIMIT = NO_API_LIMITS ? 1_000_000 : (() => {
  const raw = process.env.ACCOUNT_UPDATE_LIMIT;
  const value = Number(raw);
  return raw !== undefined && raw.trim() !== "" && Number.isFinite(value) && value >= 4 && value <= 100
    ? Math.round(value) : 4;
})();
// И второе правило Bybit: не больше одного изменения цены в секунду на
// аккаунт. Лог: два изменения с разницей 907 мс (разные объявления) — второе
// получило 10006, хотя за 5 с их было всего 2. Позже отказ пришёл и при
// паузе 1,05 с (Bybit, похоже, считает по времени обработки) — держим 1,5 с.
// Можно поменять в .env: API_UPDATE_GAP_MS=1250 (от 0 до 5000 мс; 0 — без зазора).
// 0 — зазор выключен совсем (изменения могут уходить друг за другом сразу;
// остаётся только разнос 50 мс и лимит изменений за 5 с ниже).
export const ACCOUNT_UPDATE_MIN_GAP_MS = NO_API_LIMITS ? 0 : (() => {
  const raw = process.env.API_UPDATE_GAP_MS;
  const value = Number(raw);
  return raw !== undefined && raw.trim() !== "" && Number.isFinite(value) && value >= 0 && value <= 5_000
    ? Math.round(value) : 1_500;
})();

// Когда Bybit ответил на изменение цены (по объявлению). Лог 27.09: бот
// отправлял 4-е изменение ровно через 5,001 с после 1-го по своему времени
// отправки — и дважды получил 10006 ("3 за 5 с"). У 1-го изменения ответ шёл
// 1172 мс: Bybit засчитывает изменение позже, чем мы его отправили. Поэтому
// окно 5 с считаем от момента ответа Bybit (пока ответа нет — от "сейчас").
const answeredAt = new Map<string, number[]>();
const ANSWER_KEEP_MS = 60_000;
const IN_FLIGHT_MAX_MS = 3_000;
// Небольшой запас сверх 5 с на расхождение часов/обработку у Bybit.
const ACCOUNT_WINDOW_MARGIN_MS = 150;

/** Bybit ответил (успехом или ошибкой) на изменение цены этого объявления. */
export function noteAccountUpdateAnswered(itemId: string, at = Date.now()): void {
  if (!itemId) return;
  const list = (answeredAt.get(itemId) ?? []).filter((t) => at - t < ANSWER_KEEP_MS);
  list.push(at);
  answeredAt.set(itemId, list);
}

/** Момент, когда Bybit засчитал изменение (не раньше ответа; без ответа — сейчас). */
function effectiveTime(itemId: string, sentAt: number, now: number): number {
  const answer = (answeredAt.get(itemId) ?? []).find((t) => t >= sentAt);
  if (answer !== undefined) return answer;
  return Math.min(now, sentAt + IN_FLIGHT_MAX_MS);
}

/** Сколько изменений цены (включая неудачные попытки) Bybit засчитал по этим объявлениям за последние 5 с. */
export function recentAccountUpdates(
  itemIds: readonly string[],
  now = Date.now(),
): { count: number; oldest: number | null } {
  if (itemIds.length === 0) return { count: 0, oldest: null };
  const placeholders = itemIds.map(() => "?").join(",");
  const window = ACCOUNT_UPDATE_WINDOW_MS + ACCOUNT_WINDOW_MARGIN_MS;
  const rows = db.prepare(`
    SELECT item_id, sent_at_ms FROM working_ad_update_attempts
    WHERE sent_at_ms > ? AND item_id IN (${placeholders})
  `).all(now - window - IN_FLIGHT_MAX_MS, ...itemIds) as { item_id: string; sent_at_ms: number }[];
  let count = 0;
  let oldest: number | null = null;
  for (const row of rows) {
    const at = effectiveTime(String(row.item_id), Number(row.sent_at_ms), now);
    if (at <= now - window) continue;
    count += 1;
    if (oldest === null || at < oldest) oldest = at;
  }
  return { count, oldest };
}

/** Сколько изменений цены ещё можно сделать прямо сейчас, не получив 10006. */
export function accountUpdatesLeft(itemIds: readonly string[], now = Date.now()): number {
  return Math.max(0, ACCOUNT_UPDATE_LIMIT - recentAccountUpdates(itemIds, now).count);
}

export class WorkingAdUpdateDeferred extends Error {
  // Причина — только для "долгих" внутренних лимитов (пишется в лог).
  constructor(public readonly retryAt: number, public readonly reason?: string) {
    super("Лимит редактирований: мониторинг продолжается, обновление отложено.");
    this.name = "WorkingAdUpdateDeferred";
  }
}

// Count attempts before sending, including uncertain responses, across restarts.
export function reserveWorkingAdUpdate(
  itemId: string,
  now = Date.now(),
  minIntervalMs = DEFAULT_UPDATE_INTERVAL_MS,
  // Все объявления этого аккаунта Bybit — для лимита 4 изменения за 5 с.
  accountItemIds?: readonly string[],
  // Срочное изменение (вернуть объявление под потолок): внутренний лимит на
  // объявление не применяется — лимиты Bybit на аккаунт соблюдаются как обычно.
  urgent = false,
): void {
  const perItemMax = urgent ? 1_000_000 : ITEM_LIMIT_5MIN;
  if (!Number.isSafeInteger(minIntervalMs) || minIntervalMs < MIN_USER_INTERVAL_MS || minIntervalMs > MAX_UPDATE_INTERVAL_MS) {
    throw new Error("Минимальный интервал редактирования должен быть от 0,01 до 86400 секунд.");
  }
  if (accountItemIds && accountItemIds.length > 0) {
    const ids = accountItemIds.includes(itemId) ? accountItemIds : [...accountItemIds, itemId];
    const recent = recentAccountUpdates(ids, now);
    if (recent.count >= ACCOUNT_UPDATE_LIMIT && recent.oldest !== null) {
      // Лучше подождать освобождения слота, чем получить 10006 и паузу до 8 с.
      throw new WorkingAdUpdateDeferred(recent.oldest + ACCOUNT_UPDATE_WINDOW_MS + ACCOUNT_WINDOW_MARGIN_MS + 1);
    }
    const placeholders = ids.map(() => "?").join(",");
    const last = db.prepare(`
      SELECT MAX(sent_at_ms) AS latest FROM working_ad_update_attempts
      WHERE item_id IN (${placeholders})
    `).get(...ids) as { latest: number | null };
    if (last.latest !== null && now - Number(last.latest) < ACCOUNT_UPDATE_MIN_GAP_MS) {
      // Меньше секунды после прошлого изменения по аккаунту — ждём (бот
      // подождёт сам и отправит ровно через ACCOUNT_UPDATE_MIN_GAP_MS).
      throw new WorkingAdUpdateDeferred(Number(last.latest) + ACCOUNT_UPDATE_MIN_GAP_MS);
    }
  }
  // Retain history long enough for a user interval longer than the API window.
  db.prepare("DELETE FROM working_ad_update_attempts WHERE sent_at_ms <= ?")
    .run(now - MAX_UPDATE_INTERVAL_MS);
  const inserted = db.prepare(`
    INSERT INTO working_ad_update_attempts (item_id, sent_at_ms)
    SELECT ?, ?
    WHERE (SELECT COUNT(*) FROM working_ad_update_attempts
           WHERE item_id = ? AND sent_at_ms > ?) < ?
      AND NOT EXISTS (SELECT 1 FROM working_ad_update_attempts
                      WHERE item_id = ? AND sent_at_ms > ?)
      AND NOT EXISTS (SELECT 1 FROM working_ad_update_attempts WHERE sent_at_ms > ?)
      AND (SELECT COUNT(*) FROM working_ad_update_attempts WHERE sent_at_ms > ?) < ?
    RETURNING id
  `).get(itemId, now, itemId, now - WINDOW_MS, perItemMax,
    itemId, now - (NO_API_LIMITS ? 0 : minIntervalMs), now - WRITE_SPACING_MS,
    now - WRITE_WINDOW_MS, MAX_WRITES_PER_WINDOW);
  if (inserted) return;

  const item = db.prepare(`
    SELECT COUNT(CASE WHEN sent_at_ms > ? THEN 1 END) AS count,
           MIN(CASE WHEN sent_at_ms > ? THEN sent_at_ms END) AS oldest,
           MAX(sent_at_ms) AS latest
    FROM working_ad_update_attempts WHERE item_id = ?
  `).get(now - WINDOW_MS, now - WINDOW_MS, itemId)!;
  // Allow short gaps without exceeding the previous aggregate budget of four writes per second.
  const recent = db.prepare(`
    SELECT COUNT(*) AS count, MIN(sent_at_ms) AS oldest, MAX(sent_at_ms) AS latest
    FROM working_ad_update_attempts WHERE sent_at_ms > ?
  `).get(now - WRITE_WINDOW_MS)!;
  const perItemLimited = Number(item.count) >= perItemMax;
  throw new WorkingAdUpdateDeferred(Math.max(
    now + 1,
    recent.latest === null ? 0 : Number(recent.latest) + WRITE_SPACING_MS,
    Number(recent.count) >= MAX_WRITES_PER_WINDOW ? Number(recent.oldest) + WRITE_WINDOW_MS : 0,
    item.latest === null || NO_API_LIMITS ? 0 : Number(item.latest) + minIntervalMs,
    Number(item.count) >= perItemMax ? Number(item.oldest) + WINDOW_MS : 0,
  ), perItemLimited ? `внутренний лимит ${MAX_ATTEMPTS} изменений на объявление за ${WINDOW_MS / 60_000} мин` : undefined);
}
