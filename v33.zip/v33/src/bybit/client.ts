import * as tlsClient from "node-tls-client";
import { authService } from "../auth/authService.js";
import { currentConnectionMode } from "./connectionContext.js";
import { officialApiCall } from "./officialClient.js";

const { ClientIdentifier, Session, initTLS, destroyTLS } = tlsClient;

const BASE_URL = "https://www.bybit.com";

export interface BybitResponse<T> {
  ret_code: number;
  ret_msg: string;
  result: T;
  ext_info?: unknown;
  ext_code?: string;
  time_now?: string;
}

export class BybitApiError extends Error {
  constructor(
    public readonly code: number,
    message: string,
    public readonly raw: unknown,
  ) {
    super(`Bybit API ${code}: ${message}`);
    this.name = "BybitApiError";
  }
}

export class BybitAuthError extends Error {
  constructor(
    public readonly status: number,
    public readonly source: "session" | "api" = "session",
  ) {
    super(describeAuthError(status, source));
    this.name = "BybitAuthError";
  }
}

function describeAuthError(
  status: number,
  source: "session" | "api",
): string {
  if (source !== "api") return `Bybit auth required (HTTP ${status})`;
  if (status === 10003) {
    return "Bybit API 10003: неверный API Key или выбран не тот домен/mainnet.";
  }
  if (status === 10004) {
    return "Bybit API 10004: неверная подпись. Проверь API Secret и тип ключа HMAC.";
  }
  if (status === 10005) {
    return "Bybit API 10005: недостаточно прав. Включи P2P «Ордера» и «Объявления», режим Read-Write и проверь доступ P2P Open API.";
  }
  if (status === 10007) {
    return "Bybit API 10007: пользователь не прошёл авторизацию.";
  }
  if (status === 10010) {
    return "Bybit API 10010: IP сервера не совпадает с IP, привязанным к ключу.";
  }
  return `Bybit API authentication failed (${status})`;
}

const STATIC_HEADERS: Record<string, string> = {
  accept: "application/json",
  "accept-language": "en",
  origin: BASE_URL,
  referer: `${BASE_URL}/en/p2p/advertiser/create`,
  lang: "en",
  platform: "PC",
  "sec-ch-ua":
    '"Google Chrome";v="131", "Not.A/Brand";v="8", "Chromium";v="131"',
  "sec-ch-ua-mobile": "?0",
  "sec-fetch-dest": "empty",
  "sec-fetch-mode": "cors",
  "sec-fetch-site": "same-origin",
};

/** sec-ch-ua-platform должен совпадать с UA, иначе Akamai задетектит mismatch. */
function platformHeader(ua: string): string {
  if (/Windows/i.test(ua)) return '"Windows"';
  if (/Macintosh|Mac OS/i.test(ua)) return '"macOS"';
  if (/Linux/i.test(ua)) return '"Linux"';
  if (/Android/i.test(ua)) return '"Android"';
  if (/CrOS/i.test(ua)) return '"Chrome OS"';
  return '"Unknown"';
}

/*
 * node-tls-client притворяется реальным Chrome 131:
 *   - JA3 fingerprint совпадает с настоящим Chrome
 *   - HTTP/2 SETTINGS frame идентичен
 *   - Pseudo-header order :method/:authority/:scheme/:path
 *   - ALPS / GREASE / certificate compression
 *
 * Для Akamai/Cloudflare/PerimeterX это критично — Node.js HTTP стек
 * палится на любом из этих параметров.
 */
let tlsSession: InstanceType<typeof Session> | null = null;
let tlsInitPromise: Promise<void> | null = null;

async function ensureTlsInit(): Promise<void> {
  if (!tlsInitPromise) {
    tlsInitPromise = initTLS().catch((err) => {
      // Если упало (например, ECONNRESET при скачивании DLL с GitHub) —
      // сбрасываем cache, чтобы следующий вызов попробовал заново.
      tlsInitPromise = null;
      throw err;
    });
  }
  return tlsInitPromise;
}

async function getSession(): Promise<InstanceType<typeof Session>> {
  await ensureTlsInit();
  if (!tlsSession) {
    tlsSession = new Session({
      clientIdentifier: ClientIdentifier.chrome_131,
      timeout: 15_000,
    });
  }
  return tlsSession;
}

export async function closeHttpSession(): Promise<void> {
  if (tlsSession) {
    await tlsSession.close().catch(() => {});
    tlsSession = null;
  }
  if (tlsInitPromise) {
    await destroyTLS().catch(() => {});
    tlsInitPromise = null;
  }
}

async function buildHeaders(method: "GET" | "POST"): Promise<Record<string, string>> {
  const session = await authService.require();
  const headers: Record<string, string> = {
    ...STATIC_HEADERS,
    "sec-ch-ua-platform": platformHeader(session.userAgent),
    "user-agent": session.userAgent,
    cookie: session.cookie,
    risktoken: session.riskToken,
    guid: session.guid,
  };
  if (method === "POST") {
    headers["content-type"] = "application/json;charset=UTF-8";
  }
  return headers;
}

async function rawCall<T>(
  method: "GET" | "POST",
  path: string,
  body?: unknown,
): Promise<T> {
  const headers = await buildHeaders(method);
  const url = path.startsWith("http") ? path : BASE_URL + path;
  const tls = await getSession();

  const response =
    method === "POST"
      ? await tls.post(url, { headers, body: body !== undefined ? JSON.stringify(body) : "" })
      : await tls.get(url, { headers });

  if (response.status === 401 || response.status === 403) {
    await authService.markStale();
    throw new BybitAuthError(response.status);
  }
  if (response.status >= 400) {
    throw new Error(
      `HTTP ${response.status}: ${response.body.slice(0, 300)}`,
    );
  }
  let data: BybitResponse<T>;
  try {
    data = JSON.parse(response.body) as BybitResponse<T>;
  } catch {
    throw new Error(`Bybit returned non-JSON: ${response.body.slice(0, 200)}`);
  }
  if (data.ret_code !== 0) {
    if (looksLikeAuthError(data.ret_code, data.ret_msg)) {
      await authService.markStale();
      throw new BybitAuthError(data.ret_code);
    }
    throw new BybitApiError(data.ret_code, data.ret_msg ?? "unknown", data);
  }
  return data.result;
}

function looksLikeAuthError(code: number, msg?: string): boolean {
  if (
    code === 10005 ||
    code === 10006 ||
    code === 10007 ||
    code === 401 ||
    code === 403
  ) {
    return true;
  }
  if (msg && /auth|not.*log|session.*expir/i.test(msg)) return true;
  return false;
}

export function bybitPost<T>(path: string, body: unknown): Promise<T> {
  if (currentConnectionMode() === "api") {
    return officialApiCall<T>(path, body);
  }
  return rawCall<T>("POST", path, body);
}

export function bybitGet<T>(path: string): Promise<T> {
  if (currentConnectionMode() === "api") {
    return officialApiCall<T>(path);
  }
  return rawCall<T>("GET", path);
}
