import { bybitPost } from "./client.js";
import type {
  AvailableBalanceResult,
  FeeRateResult,
  LastPriceResult,
  RiskRequest,
} from "./types.js";

export async function getLastPrice(tokenId: string, currencyId: string) {
  return bybitPost<LastPriceResult>("/x-api/fiat/otc/item/last_price", {
    tokenId,
    currencyId,
  });
}

export async function getFeeRate(tokenId: string, currencyId: string) {
  return bybitPost<FeeRateResult>("/x-api/fiat/otc/item/fee-rate", {
    tokenId,
    currencyId,
    bulk: false,
  });
}

export async function getAvailableBalance(tokenId: string, currencyId: string) {
  return bybitPost<AvailableBalanceResult>(
    "/x-api/fiat/otc/user/availableBalance",
    { tokenId, currencyId },
  );
}

export async function checkRisk(
  scene = "P2PADAccessSellTab",
): Promise<unknown> {
  const body: RiskRequest = { scene };
  return bybitPost<unknown>("/x-api/fiat/otc/user/risk", body);
}
