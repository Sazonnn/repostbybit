import { bybitPost } from "./client.js";
import { verifyPaymentPassword } from "./risk.js";
import type {
  CreateAdRequest,
  CreateAdResult,
  Side,
  TradingPreferenceSet,
} from "./types.js";

export class SecurityChallengeRequiredError extends Error {
  constructor(
    public readonly riskToken: string,
    public readonly riskTokenType: string,
    public readonly raw: unknown,
  ) {
    super(`Bybit требует 2FA challenge для создания объявления (${riskTokenType})`);
    this.name = "SecurityChallengeRequiredError";
  }
}

const DEFAULT_PREFERENCES: TradingPreferenceSet = {
  isKyc: "1",
  hasCompleteRateDay30: "0",
  completeRateDay30: "",
  hasOrderFinishNumberDay30: "0",
  orderFinishNumberDay30: "",
  isMobile: "0",
  isEmail: "0",
  hasUnPostAd: "0",
  hasRegisterTime: "0",
  registerTimeThreshold: "",
  hasNationalLimit: "0",
  nationalLimit: "",
  hasSingleUserOrderLimit: "0",
  singleUserOrderLimit: "",
};

export interface CreateAdInput {
  tokenId: string;
  currencyId: string;
  side: Side;
  price: string;
  quantity: string;
  minAmount: string;
  maxAmount: string;
  paymentPeriod: string;
  paymentIds: string[];
  remark?: string;
  priceType?: "0" | "1";
  premium?: string;
  preferences?: Partial<TradingPreferenceSet>;
  privateAd?: 0 | 1;
  useFiatAccount?: boolean;
  useFlexible?: boolean;
  itemType?: "ORIGIN" | "BULK";
  /** Если требуется второй фактор — передать токен от 2FA challenge. */
  securityRiskToken?: string;
  /**
   * Платёжный пароль Bybit. Если задан, при получении challenge функция
   * автоматически пройдёт verify и повторит create.
   */
  paymentPassword?: string;
}

type CreateAdRawResult = CreateAdResult & {
  needSecurityRisk?: boolean;
  securityRiskToken?: string;
  riskTokenType?: string;
};

async function postCreate(body: CreateAdRequest): Promise<CreateAdRawResult> {
  return bybitPost<CreateAdRawResult>("/x-api/fiat/otc/item/create", body);
}

export async function createAd(input: CreateAdInput): Promise<CreateAdResult> {
  const body: CreateAdRequest = {
    tokenId: input.tokenId,
    currencyId: input.currencyId,
    side: input.side,
    priceType: input.priceType ?? "0",
    price: input.price,
    premium: input.premium ?? "",
    quantity: input.quantity,
    minAmount: input.minAmount,
    maxAmount: input.maxAmount,
    paymentPeriod: input.paymentPeriod,
    remark: input.remark ?? "",
    paymentIds: input.paymentIds,
    tradingPreferenceSet: { ...DEFAULT_PREFERENCES, ...input.preferences },
    itemType: input.itemType ?? "ORIGIN",
    subsidyAd: false,
    privateAd: input.privateAd ?? 0,
    useFiatAccount: input.useFiatAccount ?? true,
    useFlexible: input.useFlexible ?? false,
    securityRiskToken: input.securityRiskToken ?? "",
  };

  const first = await postCreate(body);
  if (!first.needSecurityRisk) return first;

  const challengeToken = first.securityRiskToken ?? "";
  if (!challengeToken) {
    throw new SecurityChallengeRequiredError(
      "",
      first.riskTokenType ?? "challenge",
      first,
    );
  }
  if (!input.paymentPassword) {
    throw new SecurityChallengeRequiredError(
      challengeToken,
      first.riskTokenType ?? "challenge",
      first,
    );
  }

  await verifyPaymentPassword({
    riskToken: challengeToken,
    password: input.paymentPassword,
  });

  const second = await postCreate({ ...body, securityRiskToken: challengeToken });
  if (second.needSecurityRisk) {
    throw new SecurityChallengeRequiredError(
      second.securityRiskToken ?? challengeToken,
      second.riskTokenType ?? "challenge",
      second,
    );
  }
  return second;
}
