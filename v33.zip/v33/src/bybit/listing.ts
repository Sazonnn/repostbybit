import { bybitPost } from "./client.js";
import type { Side } from "./types.js";

export interface OnlineItem {
  id?: string;
  itemId?: string;
  accountId?: string | number;
  userId?: string | number;
  nickName?: string;
  price?: string;
  lastPrice?: string;
  lastQuantity?: string;
  quantity?: string;
  executedQuantity?: string;
  frozenQuantity?: string;
  minAmount?: string;
  maxAmount?: string;
  paymentPeriod?: number;
  payments?: string[];
  /**
   * Ценовой ранг Bybit. Он не совпадает с позицией в OVERALL_RANKING,
   * поэтому для общей выдачи нельзя использовать его как фактическое место.
   */
  orderBookLevel?: number;
  finishNum?: number;
  orderNum?: number;
  recentExecuteRate?: number;
  recentOrderNum?: number;
  status?: number;
  isOnline?: boolean;
  authStatus?: number;
  authTag?: string[];
  [key: string]: unknown;
}

export interface OnlineListResult {
  count?: number;
  items?: OnlineItem[];
  [key: string]: unknown;
}

export interface OnlineListInput {
  tokenId: string;
  currencyId: string;
  side: Side;
  page?: number;
  size?: number;
  /** свой userId — Bybit обычно исключает его из выдачи */
  userId?: string;
  amount?: string;
  payment?: string[];
  sortType?: "OVERALL_RANKING" | "PRICE" | "TRADE_COUNT";
  itemRegion?: number;
  countryCode?: string;
  /**
   * canTrade=true (default, Bybit-default) — eligible-фильтр.
   * Для поиска самого себя в стакане надо ставить false.
   */
  canTrade?: boolean;
  /**
   * Битовая маска фильтра «Проверенные мерчанты / Без проверки / etc.».
   * 0 = no filter, 1 = только Verified Merchants (то что Bybit включает по умолчанию покупателям).
   */
  verificationFilter?: number;
  /** Только мерчанты блочной торговли. */
  bulkMaker?: boolean;
  /** Только мерчанты с которыми были сделки за последние 6 месяцев. */
  tradeWith?: boolean;
  /** UI-фильтр «Show only Verified Advertisers». */
  vaMaker?: boolean;
  /** Новый V5-маршрут используется точечно автокурсом рабочих объявлений. */
  endpoint?: "legacy" | "v5";
}

export async function listOnline(
  input: OnlineListInput,
): Promise<OnlineListResult> {
  const body = {
    userId: input.userId ? Number(input.userId) : undefined,
    tokenId: input.tokenId,
    currencyId: input.currencyId,
    payment: input.payment ?? [],
    side: input.side,
    size: String(input.size ?? 10),
    page: String(input.page ?? 1),
    amount: input.amount ?? "",
    vaMaker: input.vaMaker ?? true,
    bulkMaker: input.bulkMaker ?? false,
    canTrade: input.canTrade ?? true,
    verificationFilter: input.verificationFilter ?? 0,
    sortType: input.sortType ?? "OVERALL_RANKING",
    paymentPeriod: [],
    itemRegion: input.itemRegion ?? 1,
    countryCode: input.countryCode ?? "",
    tradeWith: input.tradeWith ?? false,
  };
  const path =
    input.endpoint === "v5"
      ? "/v5/p2p/item/online"
      : "/x-api/fiat/otc/item/online";
  return bybitPost<OnlineListResult>(path, body);
}

/**
 * Возвращает цену лучшего объявления в стакане (исключая своё, по идее).
 *
 * Для SELL (side="1") — лучшая = самая низкая (продаём дороже -> хочется быть ниже остальных).
 * Для BUY  (side="0") — лучшая = самая высокая.
 *
 * Bybit при sortType=OVERALL_RANKING уже возвращает первым самый "лучший" для покупателя
 * объявление, поэтому достаточно взять `items[0].price`.
 */
export async function getTopPrice(input: {
  tokenId: string;
  currencyId: string;
  side: Side;
  userId?: string;
  /** Фильтры должны совпадать с тем видом стакана, под который ставится объявление. */
  verificationFilter?: number;
  vaMaker?: boolean;
  bulkMaker?: boolean;
  tradeWith?: boolean;
  endpoint?: "legacy" | "v5";
}): Promise<string | null> {
  const result = await listOnline({
    tokenId: input.tokenId,
    currencyId: input.currencyId,
    side: input.side,
    userId: input.userId,
    page: 1,
    size: 1,
    verificationFilter: input.verificationFilter,
    vaMaker: input.vaMaker,
    bulkMaker: input.bulkMaker,
    tradeWith: input.tradeWith,
    endpoint: input.endpoint,
  });
  const top = result.items?.[0];
  return top?.price ?? null;
}

export interface MyRankInStack {
  /** Глобальная позиция (1..count). null если объявления нет в первых maxPages страницах. */
  rank: number | null;
  /** Номер страницы стакана (1..). null если глубже maxPages. */
  page: number | null;
  /** Item из стакана если найден. */
  item: OnlineItem | null;
  /** Сколько всего в стакане. */
  total: number | null;
  /** Ник найденного объявления (если найдено). */
  nickName: string | null;
  /** Сколько страниц реально просмотрели. */
  scannedPages: number;
  /** Сколько объявлений реально посмотрели. */
  scannedItems: number;
}

/**
 * Ищет своё объявление в стакане листая первые maxPages страниц по 10.
 * Возвращает реальную позицию (учитывает Bybit-ranking, не гипотезу).
 *
 * Эмпирически (2026-05-11) для не-Verified акка работает только
 * `canTrade=false, verificationFilter=0` — иначе Bybit либо исключает свои
 * объявления как «не можешь взять» (canTrade=true), либо отдаёт пустой
 * стакан (vf=1 на парах без Verified Merchants).
 *
 * Матчим по `it.id` — в /item/online поле `itemId` приходит undefined,
 * Bybit отдаёт snowflake ID именно в `id`. Поэтому даже если на акке
 * несколько объявлений (одно ручное + одно от бота), мы попадём именно
 * на запомненный `current_item_id`, без путаницы по `userId`/`accountId`
 * (которые одинаковые у всех объяв одного акка).
 */
export async function findMyRankInStack(args: {
  itemId: string;
  tokenId: string;
  currencyId: string;
  side: Side;
  pageSize?: number;
  maxPages?: number;
  /** Фильтр который видит покупатель (1 = Verified Merchants only). По умолчанию 1. */
  verificationFilter?: number;
}): Promise<MyRankInStack> {
  const pageSize = args.pageSize ?? 10;
  const maxPages = args.maxPages ?? 10;
  const verificationFilter = args.verificationFilter ?? 1;
  let total: number | null = null;
  let scannedPages = 0;
  let scannedItems = 0;

  for (let page = 1; page <= maxPages; page++) {
    const r = await listOnline({
      tokenId: args.tokenId,
      currencyId: args.currencyId,
      side: args.side,
      page,
      size: pageSize,
      canTrade: false, // не исключаем свои
      verificationFilter,
      // Без этого тихо уходит в default (true) — из-за чего функция видит
      // совсем другую, гораздо более широкую выборку (~1500 вместо
      // реальных ~10-20), не совпадающую с тем, что видно на самом сайте.
      // Подтверждено вживую: пользователь на 8-м месте 1-й страницы,
      // а без этой правки found=no при total=1490.
      vaMaker: false,
    });
    scannedPages = page;
    if (typeof r.count === "number") total = r.count;
    const items = r.items ?? [];
    scannedItems += items.length;
    const mine = items.find(
      (it) => String(it.id ?? it.itemId) === String(args.itemId),
    );
    if (mine) {
      const rank = (page - 1) * pageSize + items.indexOf(mine) + 1;
      return {
        rank,
        page,
        item: mine,
        total,
        nickName: (mine.nickName as string | undefined) ?? null,
        scannedPages,
        scannedItems,
      };
    }
  }
  return {
    rank: null,
    page: null,
    item: null,
    total,
    nickName: null,
    scannedPages,
    scannedItems,
  };
}
