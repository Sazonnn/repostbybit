import { createHash } from "node:crypto";
import { bybitPost } from "./client.js";

export interface RiskComponent {
  component_id: string;
  component_extension?: string;
  disposal?: string;
  disposal_extension?: string;
}

export interface RiskComponentsResult {
  risk_token?: string;
  component_type?: number;
  component_list?: RiskComponent[];
  logc_ext?: { required?: string[]; option?: string[] };
  [key: string]: unknown;
}

export async function getRiskComponents(
  riskToken: string,
): Promise<RiskComponentsResult> {
  return bybitPost<RiskComponentsResult>(
    "/x-api/user/public/risk/components",
    { risk_token: riskToken },
  );
}

/** Bybit принимает sha256 от платёжного пароля. */
export function hashPaymentPassword(password: string): string {
  return createHash("sha256").update(password, "utf8").digest("hex");
}

export async function verifyPaymentPassword(args: {
  riskToken: string;
  password: string;
}): Promise<unknown> {
  return bybitPost<unknown>("/x-api/user/public/risk/verify", {
    risk_token: args.riskToken,
    component_list: {
      payment_password_verify: hashPaymentPassword(args.password),
    },
  });
}
