import { bybitPost } from "./client.js";

export interface MerchantPersonalInfo {
  nickName?: string;
  realName?: string;
  userId?: string;
  accountId?: string;
  kycLevel?: number;
  totalFinishCount?: number;
  recentRate?: number;
  isOnline?: boolean;
  [k: string]: unknown;
}

/** Личная инфо мерчанта: ник, KYC, статистика, и т.п. */
export async function getMyMerchantInfo(): Promise<MerchantPersonalInfo> {
  return bybitPost<MerchantPersonalInfo>(
    "/x-api/fiat/otc/user/personal/info",
    undefined,
  );
}
