import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  currentConnectionChatId,
  currentConnectionCredentials,
  currentConnectionMode,
  withBybitConnection,
  withOfficialApiCredentials,
} from "./connectionContext.js";

process.env.SQLITE_PATH ||= `/tmp/bybit-official-client-test-${process.pid}.db`;

describe("official API transport", () => {
  it("объясняет ошибку прав 10005", async () => {
    process.env.TELEGRAM_BOT_TOKEN ||= "test-token";
    const { BybitAuthError } = await import("./client.js");
    const error = new BybitAuthError(10005, "api");
    assert.match(error.message, /Ордера/);
    assert.match(error.message, /Объявления/);
    assert.match(error.message, /Read-Write/);
  });

  it("подписывает POST payload по схеме Bybit V5", async () => {
    process.env.TELEGRAM_BOT_TOKEN ||= "test-token";
    const { signOfficialRequest } = await import("./officialClient.js");
    const signature = signOfficialRequest({
      timestamp: "1658384314791",
      apiKey: "apiKey",
      recvWindow: "5000",
      payload: '{"foo":"bar"}',
      apiSecret: "secret",
    });
    assert.equal(
      signature,
      "8221041b317f0308fbefcfdcd08526111ec176733354d2ec0affdb6e2771e0ed",
    );
  });

  it("изолирует API и session режимы между async-вызовами", async () => {
    assert.equal(currentConnectionMode(), "session");
    await withBybitConnection("api", async () => {
      await Promise.resolve();
      assert.equal(currentConnectionMode(), "api");
      assert.equal(currentConnectionChatId(), 12345);
    }, 12345);
    assert.equal(currentConnectionMode(), "session");
    assert.equal(currentConnectionChatId(), null);
  });

  it("может проверить новые credentials до сохранения в БД", async () => {
    await withOfficialApiCredentials(
      { apiKey: "temporary-key", apiSecret: "temporary-secret" },
      async () => {
        assert.deepEqual(currentConnectionCredentials(), {
          apiKey: "temporary-key",
          apiSecret: "temporary-secret",
        });
        assert.equal(currentConnectionMode(), "api");
        assert.equal(currentConnectionChatId(), 99);
      },
      99,
    );
    assert.equal(currentConnectionCredentials(), null);
  });

  it("берёт API-стакан из публичного OVERALL_RANKING и не путает его с ценовым рангом", async () => {
    process.env.TELEGRAM_BOT_TOKEN ||= "test-token";
    const originalFetch = globalThis.fetch;
    let requestBody: Record<string, unknown> | null = null;
    globalThis.fetch = async (_input, init) => {
      requestBody = JSON.parse(String(init?.body)) as Record<string, unknown>;
      return new Response(
        JSON.stringify({
          ret_code: 0,
          ret_msg: "SUCCESS",
          result: {
            count: 300,
            items: [
              {
                id: "my-ad",
                userId: "42",
                nickName: "merchant",
                price: "76.29",
                orderBookLevel: 187,
              },
            ],
          },
        }),
        {
          status: 200,
          headers: { "content-type": "application/json" },
        },
      );
    };

    try {
      const { findMyRankInStack } = await import("./listing.js");
      const found = await withBybitConnection("api", () =>
        findMyRankInStack({
          itemId: "my-ad",
          tokenId: "USDT",
          currencyId: "RUB",
          side: "0",
          pageSize: 10,
          maxPages: 1,
        }),
      );
      assert.equal(
        (requestBody as unknown as Record<string, unknown>).sortType,
        "OVERALL_RANKING",
      );
      assert.equal(found.rank, 1);
      assert.equal(found.item?.orderBookLevel, 187);
    } finally {
      globalThis.fetch = originalFetch;
    }
  });

  for (const scenario of [
    { name: "берёт первую чужую цену из короткой страницы без изменения сортировки", first: ["42", "99", "100"], expected: "76.01", sizes: ["10"] },
    { name: "расширяет страницу до 50 только когда короткая содержит свои объявления", first: ["42", "42"], expected: "77.00", sizes: ["10", "50"] },
    { name: "не повторяет запрос при пустом рынке", first: [], expected: null, sizes: ["10"] },
  ]) {
    it(scenario.name, async (t) => {
      process.env.TELEGRAM_BOT_TOKEN ||= "test-token";
      const requests: Array<Record<string, unknown>> = [];
      t.mock.method(globalThis, "fetch", async (input: unknown, init?: RequestInit) => {
        assert.match(String(input), /\/x-api\/fiat\/otc\/item\/online$/);
        requests.push(JSON.parse(String(init?.body)));
        const items = requests.length === 1
          ? scenario.first.map((userId, index) => ({ userId, price: (76 + index / 100).toFixed(2) }))
          : [{ userId: "99", price: "77.00" }];
        return Response.json({ ret_code: 0, result: { items } });
      });
      const { getTopPrice } = await import("./listing.js");
      const price = await withBybitConnection("api", () => getTopPrice({
        tokenId: "USDT", currencyId: "RUB", side: "0", userId: "42",
        vaMaker: false, bulkMaker: true, tradeWith: true, verificationFilter: 1,
      }));
      assert.equal(price, scenario.expected);
      assert.deepEqual(requests.map(body => body.size), scenario.sizes);
      for (const body of requests) {
        assert.equal(body.sortType, "OVERALL_RANKING");
        assert.equal(body.userId, 42);
        assert.equal(body.vaMaker, false);
        assert.equal(body.bulkMaker, true);
        assert.equal(body.tradeWith, true);
        assert.equal(body.verificationFilter, 1);
      }
    });
  }

  it("обновляет объявление через официальный /v5/p2p/item/update", async () => {
    process.env.TELEGRAM_BOT_TOKEN ||= "test-token";
    const originalFetch = globalThis.fetch;
    let requestUrl = "";
    let requestBody: Record<string, unknown> | null = null;
    const order: string[] = [];
    globalThis.fetch = async (input, init) => {
      order.push("send");
      requestUrl = String(input);
      requestBody = JSON.parse(String(init?.body)) as Record<string, unknown>;
      return new Response(
        JSON.stringify({
          retCode: 0,
          retMsg: "OK",
          result: { needSecurityRisk: false },
        }),
        {
          status: 200,
          headers: { "content-type": "application/json" },
        },
      );
    };

    try {
      const { updateAd } = await import("./manage.js");
      await withOfficialApiCredentials(
        { apiKey: "temporary-key", apiSecret: "temporary-secret" },
        () =>
          updateAd({
            itemId: "1898988222063644672",
            priceType: "0",
            premium: "",
            price: "75.50",
            minAmount: "500",
            maxAmount: "1000",
            remark: "keep me",
            tradingPreferenceSet: { isKyc: "1" },
            paymentIds: ["123"],
            quantity: "100",
            paymentPeriod: "30",
            beforeSend: async () => { order.push("guard"); },
          }),
      );
      assert.match(requestUrl, /\/v5\/p2p\/item\/update$/);
      const body = requestBody as unknown as Record<string, unknown>;
      assert.equal(body.id, "1898988222063644672");
      assert.equal(body.price, "75.50");
      assert.equal(body.actionType, "MODIFY");
      assert.deepEqual(body.paymentIds, ["123"]);
      assert.deepEqual(body.tradingPreferenceSet, { isKyc: "1" });
      assert.equal("securityRiskToken" in body, false);
      assert.equal("beforeSend" in body, false);
      assert.deepEqual(order, ["guard", "send"]);
    } finally {
      globalThis.fetch = originalFetch;
    }
  });

  it("отмена в последней проверке предотвращает отправку обновления", async (t) => {
    process.env.TELEGRAM_BOT_TOKEN ||= "test-token";
    const fetch = t.mock.method(globalThis, "fetch", async () => { throw new Error("must not send"); });
    const { updateAd } = await import("./manage.js");
    await assert.rejects(withOfficialApiCredentials(
      { apiKey: "temporary-key", apiSecret: "temporary-secret" },
      () => updateAd({
        itemId: "1898988222063644672", priceType: "0", premium: "", price: "75.50", minAmount: "500", maxAmount: "1000",
        remark: "", tradingPreferenceSet: {}, paymentIds: ["123"], quantity: "100", paymentPeriod: "30",
        beforeSend: async () => { throw new Error("observation expired"); },
      }),
    ), /observation expired/);
    assert.equal(fetch.mock.callCount(), 0);
  });
});
