export type Side = "0" | "1";

export interface OrderBookLevelRequest {
  tokenId: string;
  currencyId: string;
  side: 0 | 1;
  price: string;
}

/**
 * Ответ API /x-api/fiat/p2p/item/price/orderBook-level.
 *
 * Поля частично выведены по логике интерфейса Bybit; точная схема может
 * отличаться. На реальном вызове логируем `raw` чтобы дозаполнить типы.
 */
export interface OrderBookLevelResult {
  /** Позиция в стакане при заданной цене (1-based). Точное имя поля у Bybit. */
  orderBookLevel?: number;
  /** Запасные имена — на случай, если ответ когда-то изменится. */
  level?: number;
  rank?: number;
  total?: number;
  [key: string]: unknown;
}

export interface LastPriceRequest {
  tokenId: string;
  currencyId: string;
}

export interface LastPriceResult {
  price?: string;
  lastPrice?: string;
  [key: string]: unknown;
}

export interface FeeRateRequest {
  tokenId: string;
  currencyId: string;
  bulk: boolean;
}

export interface FeeRateResult {
  feeRate?: string;
  [key: string]: unknown;
}

export interface AvailableBalanceRequest {
  tokenId: string;
  currencyId: string;
}

export interface AvailableBalanceResult {
  balance?: string;
  [key: string]: unknown;
}

export interface RiskRequest {
  scene: string;
}

export interface TradingPreferenceSet {
  isKyc?: "0" | "1";
  hasCompleteRateDay30?: "0" | "1";
  completeRateDay30?: string;
  hasOrderFinishNumberDay30?: "0" | "1";
  orderFinishNumberDay30?: string;
  isMobile?: "0" | "1";
  isEmail?: "0" | "1";
  hasUnPostAd?: "0" | "1";
  hasRegisterTime?: "0" | "1";
  registerTimeThreshold?: string;
  hasNationalLimit?: "0" | "1";
  nationalLimit?: string;
  hasSingleUserOrderLimit?: "0" | "1";
  singleUserOrderLimit?: string;
}

export interface CreateAdRequest {
  tokenId: string;
  currencyId: string;
  side: Side;
  /** "0" — фиксированная, "1" — плавающая (по премиуму к рынку). */
  priceType: "0" | "1";
  price: string;
  premium: string;
  quantity: string;
  minAmount: string;
  maxAmount: string;
  paymentPeriod: string;
  remark: string;
  paymentIds: string[];
  tradingPreferenceSet: TradingPreferenceSet;
  itemType: "ORIGIN" | "BULK";
  subsidyAd: boolean;
  privateAd: 0 | 1;
  useFiatAccount: boolean;
  useFlexible: boolean;
  securityRiskToken: string;
}

export interface CreateAdResult {
  itemId?: string;
  id?: string;
  [key: string]: unknown;
}

export interface UpdateAdRequest {
  id: string;
  itemId: string;
  priceType: "0" | "1";
  premium: string;
  price: string;
  minAmount: string;
  maxAmount: string;
  remark: string;
  tradingPreferenceSet: TradingPreferenceSet;
  paymentIds: string[];
  actionType: "MODIFY" | "ACTIVE";
  quantity: string;
  paymentPeriod: string;
  securityRiskToken: string;
}

export interface UpdateAdResult {
  needSecurityRisk?: boolean;
  securityRiskToken?: string;
  riskTokenType?: string;
  [key: string]: unknown;
}
