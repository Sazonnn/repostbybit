import { bybitPost } from "./client.js";
import type {
  OrderBookLevelRequest,
  OrderBookLevelResult,
  Side,
} from "./types.js";

/**
 * Узнать позицию (level) указанной цены в P2P-стакане Bybit.
 *
 * Используется ровно тот же запрос, что отправляет фронт страницы
 * "advertiser/create": POST /x-api/fiat/p2p/item/price/orderBook-level
 */
export async function getOrderBookLevel(args: {
  tokenId: string;
  currencyId: string;
  side: Side;
  price: string | number;
}): Promise<OrderBookLevelResult> {
  const body: OrderBookLevelRequest = {
    tokenId: args.tokenId,
    currencyId: args.currencyId,
    side: Number(args.side) as 0 | 1,
    price: String(args.price),
  };
  return bybitPost<OrderBookLevelResult>(
    "/x-api/fiat/p2p/item/price/orderBook-level",
    body,
  );
}

export interface RankInfo {
  rank: number | null;
  page: number | null;
  isFirstPage: boolean;
  raw: OrderBookLevelResult;
}

/** Достаёт ранг из ответа и считает номер страницы. */
export function rankFromOrderBook(
  result: OrderBookLevelResult,
  pageSize: number,
): RankInfo {
  const rank = (result.orderBookLevel ?? result.level ?? result.rank ?? null) as
    | number
    | null;
  const page =
    rank !== null && rank > 0 ? Math.ceil(rank / pageSize) : null;
  return {
    rank,
    page,
    isFirstPage: page === 1,
    raw: result,
  };
}
