import { bybitGet, bybitPost } from "./client.js";
import { SecurityChallengeRequiredError } from "./createAd.js";
import { verifyPaymentPassword } from "./risk.js";
import type {
  TradingPreferenceSet,
  UpdateAdRequest,
  UpdateAdResult,
} from "./types.js";

export interface PersonalItem {
  id?: string;
  itemId?: string;
  price?: string;
  status?: number | string;
  tokenId?: string;
  currencyId?: string;
  side?: string | number;
  priceType?: string | number;
  premium?: string;
  quantity?: string;
  lastQuantity?: string;
  minAmount?: string;
  maxAmount?: string;
  remark?: string;
  paymentPeriod?: string | number;
  paymentIds?: Array<string | number>;
  paymentTerms?: Array<{
    id?: string | number;
    paymentId?: string | number;
    paymentType?: string | number;
    [key: string]: unknown;
  }>;
  payments?: Array<
    | string
    | number
    | {
        id?: string | number;
        paymentId?: string | number;
        paymentType?: string | number;
        [key: string]: unknown;
      }
  >;
  tradingPreferenceSet?: Record<string, unknown>;
  /** "ONLINE" | "HIDDEN" | … */
  showStatus?: string;
  /** "REST" | "PAUSED" | "" — почему объявление скрыто */
  hiddenReason?: string;
  isOnline?: boolean;
  [key: string]: unknown;
}

export interface WorkConfig {
  userId: string;
  /** "REST" — мерчант на паузе, "WORKING" / иначе — активен. */
  workStatus: string;
  timeZone?: string;
  offlineSchedule?: string;
  offlineCron?: unknown[];
  [key: string]: unknown;
}

export async function getWorkConfig(): Promise<WorkConfig> {
  return bybitGet<WorkConfig>("/x-api/fiat/otc/maker/work-config/get");
}

export interface PersonalListResult {
  count?: number;
  items?: PersonalItem[];
  [key: string]: unknown;
}

/**
 * Список своих объявлений.
 *  status="2" — активные (на странице "Мои объявления" UI шлёт именно это).
 */
export async function listPersonal(input: {
  status?: string;
  page?: number;
  size?: number;
}): Promise<PersonalListResult> {
  return bybitPost<PersonalListResult>("/x-api/fiat/otc/item/personal/list", {
    page: String(input.page ?? 1),
    size: String(input.size ?? 10),
    status: input.status ?? "2",
  });
}

/** Найти своё объявление по itemId среди активных (status=10 в response). */
export async function findOwnAd(itemId: string): Promise<PersonalItem | null> {
  const r = await listPersonal({ status: "1", page: 1, size: 30 });
  return (
    (r.items ?? []).find(
      (it) => String(it.id ?? it.itemId) === String(itemId),
    ) ?? null
  );
}

/** Детали конкретного своего объявления. В API-режиме использует официальный Get My Ad Details. */
export async function getOwnAdDetails(itemId: string): Promise<PersonalItem> {
  return bybitPost<PersonalItem>("/x-api/fiat/otc/item/info", { itemId });
}

export async function cancelAd(itemId: string): Promise<unknown> {
  return bybitPost<unknown>("/x-api/fiat/otc/item/cancel", { itemId });
}

export interface UpdateAdInput {
  itemId: string;
  priceType: "0" | "1";
  premium: string;
  price: string;
  minAmount: string;
  maxAmount: string;
  remark: string;
  tradingPreferenceSet: TradingPreferenceSet;
  paymentIds: string[];
  quantity: string;
  paymentPeriod: string;
  paymentPassword?: string;
  securityRiskToken?: string;
  beforeSend?: () => Promise<void>;
}

async function postUpdate(body: UpdateAdRequest): Promise<UpdateAdResult> {
  return bybitPost<UpdateAdResult>("/x-api/fiat/otc/item/update", body);
}

export async function updateAd(input: UpdateAdInput): Promise<UpdateAdResult> {
  const body: UpdateAdRequest = {
    id: input.itemId,
    itemId: input.itemId,
    priceType: input.priceType,
    premium: input.premium,
    price: input.price,
    minAmount: input.minAmount,
    maxAmount: input.maxAmount,
    remark: input.remark,
    tradingPreferenceSet: input.tradingPreferenceSet,
    paymentIds: input.paymentIds,
    actionType: "MODIFY",
    quantity: input.quantity,
    paymentPeriod: input.paymentPeriod,
    securityRiskToken: input.securityRiskToken ?? "",
  };

  await input.beforeSend?.();
  const first = await postUpdate(body);
  if (!first.needSecurityRisk) return first;

  const challengeToken = first.securityRiskToken ?? "";
  if (!challengeToken || !input.paymentPassword) {
    throw new SecurityChallengeRequiredError(
      challengeToken,
      first.riskTokenType ?? "challenge",
      first,
    );
  }
  await verifyPaymentPassword({
    riskToken: challengeToken,
    password: input.paymentPassword,
  });
  await input.beforeSend?.();
  const second = await postUpdate({
    ...body,
    securityRiskToken: challengeToken,
  });
  if (second.needSecurityRisk) {
    throw new SecurityChallengeRequiredError(
      second.securityRiskToken ?? challengeToken,
      second.riskTokenType ?? "challenge",
      second,
    );
  }
  return second;
}
