import { bybitPost } from "./client.js";

/**
 * Платёжный метод юзера на Bybit (банк-карта, СБП, …).
 * Поля те, что встречаются в реальных curl-ах + /post-ad/payment-list.
 */
export interface PaymentMethod {
  id: string;
  paymentType?: number;
  bankName?: string;
  branchName?: string;
  accountNo?: string;
  realName?: string;
  payMessage?: string;
  visible?: number;
  online?: string | number;
  realNameVerified?: boolean;
  paymentConfigVo?: { paymentName?: string; online?: number; [k: string]: unknown };
  [k: string]: unknown;
}

/** Список платёжных методов юзера (карты, СБП, и т.п.). Balance (id=-1) отфильтрован. */
export async function listPostAdPayments(): Promise<PaymentMethod[]> {
  const result = await bybitPost<unknown>(
    "/x-api/fiat/otc/user/payment/list",
    undefined,
  );
  let list: PaymentMethod[] = [];
  if (Array.isArray(result)) list = result as PaymentMethod[];
  else if (result && typeof result === "object") {
    const obj = result as Record<string, unknown>;
    if (Array.isArray(obj.list)) list = obj.list as PaymentMethod[];
    else if (Array.isArray(obj.items)) list = obj.items as PaymentMethod[];
  }
  return list.filter((p) => String(p.id) !== "-1");
}

/**
 * Можно ли реально использовать в post-ad.
 * Эмпирически: единственное что точно блокирует — это `realNameVerified: false`.
 * Все остальные флаги (online, paymentConfigVo.online, visible) встречаются =0
 * даже у методов которые Bybit принимает в объявление — не используем их.
 */
export function isPaymentUsable(p: PaymentMethod): boolean {
  return p.realNameVerified !== false;
}

/** Человекочитаемая подпись для UI кнопок. */
export function paymentLabel(p: PaymentMethod): string {
  const name =
    (p.bankName && p.bankName.trim()) ||
    p.paymentConfigVo?.paymentName ||
    "Pay";
  const numeric =
    (p.accountNo && p.accountNo.trim()) ||
    (p.payMessage && p.payMessage.match(/\d{4,}/)?.[0]) ||
    p.debitCardNumber ||
    p.mobile ||
    "";
  const tail = numeric ? numeric.toString().slice(-4) : "";
  return tail ? `${name} ····${tail}` : String(name);
}
