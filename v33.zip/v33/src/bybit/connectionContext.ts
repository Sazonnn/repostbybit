import { AsyncLocalStorage } from "node:async_hooks";

export type ConnectionMode = "session" | "api";

interface ConnectionContext {
  mode: ConnectionMode;
  chatId?: number;
  credentials?: {
    apiKey: string;
    apiSecret: string;
  };
}

const storage = new AsyncLocalStorage<ConnectionContext>();

export function currentConnectionMode(): ConnectionMode {
  return storage.getStore()?.mode ?? "session";
}

export function currentConnectionChatId(): number | null {
  return storage.getStore()?.chatId ?? null;
}

export function currentConnectionCredentials(): {
  apiKey: string;
  apiSecret: string;
} | null {
  return storage.getStore()?.credentials ?? null;
}

export function withBybitConnection<T>(
  mode: ConnectionMode,
  fn: () => Promise<T>,
  chatId?: number,
): Promise<T> {
  return storage.run({ mode, chatId }, fn);
}

export function withOfficialApiCredentials<T>(
  credentials: { apiKey: string; apiSecret: string },
  fn: () => Promise<T>,
  chatId?: number,
): Promise<T> {
  return storage.run({ mode: "api", chatId, credentials }, fn);
}
