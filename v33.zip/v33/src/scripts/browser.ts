/**
 * Просто открывает chromium с залогиненной сессией. Окно не закрывается
 * автоматически — закроешь руками когда нагляделся.
 */
import { mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "patchright";
import { config } from "../config.js";

const here = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(here, "..", "..");
const USER_DATA_DIR =
  config.playwright.userDataDir || resolve(ROOT, "data", "chromium-profile");

const TARGET = process.argv[2] ?? "https://www.bybit.com/en/p2p/merchant-admin/ads";

async function main() {
  mkdirSync(USER_DATA_DIR, { recursive: true });
  const ctx = await chromium.launchPersistentContext(USER_DATA_DIR, {
    channel: config.playwright.channel,
    headless: false,
    viewport: null,
  });
  const page = ctx.pages()[0] ?? (await ctx.newPage());
  await page.goto(TARGET, { waitUntil: "domcontentloaded" }).catch(() => {});
  console.log(
    `Окно открыто на ${TARGET}\nЗакрой его руками когда насмотришься, скрипт сам выйдет.`,
  );
  page.on("close", async () => {
    await ctx.close().catch(() => {});
    process.exit(0);
  });
  ctx.on("close", () => process.exit(0));
}

main().catch((err) => {
  console.error("FAIL:", err);
  process.exit(1);
});
