/** Проверка TLS-fingerprint через peet.ws — тыкаем https://tls.peet.ws/api/clean и смотрим JA3 */
import {
  ClientIdentifier,
  Session,
  initTLS,
  destroyTLS,
} from "node-tls-client";

async function main() {
  await initTLS();
  const s = new Session({
    clientIdentifier: ClientIdentifier.chrome_131,
    timeout: 15_000,
  });
  const t0 = Date.now();
  const r = await s.get("https://tls.peet.ws/api/clean");
  console.log(`status=${r.status} dur=${Date.now() - t0}ms`);
  console.log(r.body.slice(0, 1500));
  await s.close();
  await destroyTLS();
}
main().catch((e) => {
  console.error("FAIL:", e);
  process.exit(1);
});
