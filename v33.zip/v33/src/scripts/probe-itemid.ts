/**
 * Создаёт сразу ДВА объявления на одной стороне, проверяет что:
 *   - Bybit вернул разные itemId
 *   - оба находятся в стакане по СВОЕМУ itemId, не путаются между собой
 *   - и в /personal/list они тоже различимы
 *
 * Доказывает что в кейсе "2 объявы на одном акке в топ-10" фильтрация
 * по current_item_id (как сейчас в боте) работает корректно.
 *
 * Запуск: npm run probe-itemid
 */
import { config } from "../config.js";
import { runMigrations } from "../db/migrate.js";
import { pool, query } from "../db/pool.js";
import {
  BybitApiError,
  cancelAd,
  closeHttpSession,
  createAd,
  getTopPrice,
  listOnline,
  listPersonal,
} from "../bybit/index.js";
import { computeTargetPrice } from "../services/price.js";
import { authService, describeSession } from "../auth/authService.js";
import { getSideSettings } from "../db/repositories/sideSettings.js";
import { getSettings } from "../db/repositories/userSettings.js";

function dump(label: string, obj: unknown): void {
  console.log(`\n--- ${label} ---`);
  console.log(JSON.stringify(obj, null, 2));
}

async function main() {
  await runMigrations();

  const session = await authService.getCurrent();
  if (!session) {
    console.error("Нет сессии. Сначала: npm run login");
    process.exit(1);
  }
  console.log(`Сессия #${session.id}, ${describeSession(session)}`);

  const chatIdEnv = process.env.PROBE_CHAT_ID;
  if (!chatIdEnv) {
    const { rows } = await query<{ chat_id: string }>(
      `SELECT chat_id FROM user_settings ORDER BY updated_at DESC LIMIT 1`,
    );
    if (!rows[0]) throw new Error("Нет user_settings в БД");
    process.env.PROBE_CHAT_ID = String(rows[0].chat_id);
    console.log(`Использую chat_id=${rows[0].chat_id} (последний в user_settings)`);
  }
  const chatId = Number(process.env.PROBE_CHAT_ID);
  const sideEnv = (process.env.PROBE_SIDE ?? "1") as "0" | "1";

  const us = await getSettings(chatId);
  if (!us) throw new Error(`Нет user_settings для chat_id=${chatId}`);
  const ss = await getSideSettings(chatId, sideEnv);
  if (!ss) throw new Error(`Нет side_settings для chat_id=${chatId} side=${sideEnv}`);

  const tokenId = us.token_id;
  const currencyId = us.currency_id;
  const side = sideEnv;

  console.log(
    `Настройки: pair=${tokenId}/${currencyId} side=${side} qty=${ss.quantity} min=${ss.min_amount} max=${ss.max_amount} payments=${ss.payment_ids.join(",")} pass=${us.payment_password ? "есть" : "нет"}`,
  );
  if (ss.payment_ids.length === 0) {
    throw new Error(
      `У side=${side} пустой список paymentIds — создание объявления провалится. Используй PROBE_SIDE=другая сторона`,
    );
  }

  // Подберём qty чтобы price*qty был в пределах [min, max] с запасом.
  let probeQty = ss.quantity;
  const probeMin = Number(ss.min_amount);
  const probeMax = Number(ss.max_amount);

  const top = await getTopPrice({
    tokenId,
    currencyId,
    side,
    userId: session.bybitUid ?? undefined,
  });
  if (!top) throw new Error("Стакан пуст");
  console.log(`Топ ${tokenId}/${currencyId} side=${side}: ${top}`);

  const target = computeTargetPrice({
    topPrice: top,
    side,
    step: Number(us.price_step),
    min: Number(us.price_min),
    max: Number(us.price_max),
  });
  if (!target.ok) throw new Error(target.reason);

  // Делаем 2 цены, разнесённые на ≥1.5% — иначе Bybit блочит вторую объяву
  // с кодом 90043 ("разница меньше 1% от существующей").
  // SELL: вторая ХУЖЕ (выше), BUY: вторая хуже (ниже).
  const priceA = target.price;
  const aN = Number(priceA);
  const deltaPct = 0.05; // 5%, чтобы точно пройти любую проверку Bybit
  const priceB =
    side === "1"
      ? (aN * (1 + deltaPct)).toFixed(2)
      : (aN * (1 - deltaPct)).toFixed(2);

  function adjustQty(price: string): string {
    const priceN = Number(price);
    const qtyN = Number(probeQty);
    if (priceN * qtyN < probeMin) return String(Math.ceil(probeMin / priceN) + 1);
    if (priceN * qtyN > probeMax) return String(Math.floor(probeMax / priceN));
    return probeQty;
  }
  const qtyA = adjustQty(priceA);
  const qtyB = adjustQty(priceB);

  console.log(
    `\nСоздаю ОБЪЯВУ #A: qty=${qtyA}, price=${priceA} и ОБЪЯВУ #B: qty=${qtyB}, price=${priceB}`,
  );

  const baseInput = {
    tokenId,
    currencyId,
    side,
    minAmount: ss.min_amount,
    maxAmount: ss.max_amount,
    paymentPeriod: ss.payment_period,
    paymentIds: ss.payment_ids,
    remark: ss.remark,
    paymentPassword: us.payment_password ?? undefined,
  };

  const createdA = await createAd({ ...baseInput, price: priceA, quantity: qtyA });
  const itemIdA = String(createdA.itemId ?? createdA.id ?? "");
  console.log(`A) createAd → itemId=${itemIdA}`);
  if (!itemIdA) throw new Error("A: empty itemId");

  // Маленькая пауза чтобы Bybit не считал это одним запросом и rate-limit не сработал.
  await new Promise((r) => setTimeout(r, 1500));

  let itemIdB = "";
  try {
    const createdB = await createAd({ ...baseInput, price: priceB, quantity: qtyB });
    itemIdB = String(createdB.itemId ?? createdB.id ?? "");
    console.log(`B) createAd → itemId=${itemIdB}`);
  } catch (err) {
    console.error("B) createAd упал:", String(err));
  }

  console.log(`\n>>> Уникальные ID? itemIdA=${itemIdA}, itemIdB=${itemIdB}, equal=${itemIdA === itemIdB}`);

  console.log("Жду 15с чтобы Bybit прокинул объявления в стакан…");
  await new Promise((r) => setTimeout(r, 15000));

  // Для совместимости со старым кодом ниже — главный id (объявы A).
  const itemId = itemIdA;

  // 2) /personal/list — должны найтись ОБА с разными id.
  try {
    const personal = await listPersonal({ status: "2", page: 1, size: 30 });
    const mineA = (personal.items ?? []).find(
      (it) => String(it.id ?? it.itemId) === itemIdA,
    );
    const mineB = (personal.items ?? []).find(
      (it) => String(it.id ?? it.itemId) === itemIdB,
    );
    console.log(
      `2) listPersonal:\n   A: ${mineA ? `id=${mineA.id} price=${mineA.price} status=${mineA.status} showStatus=${mineA.showStatus}` : "(не нашли)"}\n   B: ${mineB ? `id=${mineB.id} price=${mineB.price} status=${mineB.status} showStatus=${mineB.showStatus}` : "(не нашли)"}`,
    );
  } catch (err) {
    console.error("listPersonal упал:", String(err));
  }

  // 3) /item/online — листаем 10 страниц, ищем КАЖДЫЙ itemId. Подтверждаем что
  //    они НЕ путаются: даже на смежных позициях у них разные id и цены.
  console.log("\n3) Сканирую стакан 10 страниц с canTrade=false vf=0…");
  let foundA: {
    rank: number | null;
    page: number;
    price: string | null;
    id: string | null;
  } | null = null;
  let foundB: {
    rank: number | null;
    page: number;
    price: string | null;
    id: string | null;
  } | null = null;
  let total: number | null = null;
  for (let page = 1; page <= 10; page++) {
    const r = await listOnline({
      tokenId,
      currencyId,
      side,
      page,
      size: 10,
      canTrade: false,
      verificationFilter: 0,
    });
    if (typeof r.count === "number") total = r.count;
    const items = r.items ?? [];
    for (const it of items) {
      const id = String(it.id ?? it.itemId ?? "");
      if (!foundA && id === itemIdA) {
        foundA = {
          rank: it.orderBookLevel ?? null,
          page,
          price: it.price ?? null,
          id,
        };
      }
      if (!foundB && id === itemIdB) {
        foundB = {
          rank: it.orderBookLevel ?? null,
          page,
          price: it.price ?? null,
          id,
        };
      }
    }
    if (foundA && foundB) break;
    if (items.length < 10) break;
  }
  console.log(`   total=${total}`);
  console.log(
    `   A: ${foundA ? `rank=${foundA.rank} page=${foundA.page} price=${foundA.price} id=${foundA.id}` : "не найден"}`,
  );
  console.log(
    `   B: ${foundB ? `rank=${foundB.rank} page=${foundB.page} price=${foundB.price} id=${foundB.id}` : "не найден"}`,
  );
  if (foundA && foundB) {
    console.log(
      `\n>>> ВЫВОД: оба объявления различимы в стакане по своему id, путаницы нет.`,
    );
    console.log(
      `   A на цене ${foundA.price} (rank ${foundA.rank}), B на цене ${foundB.price} (rank ${foundB.rank}).`,
    );
  }

  console.log("\nОтменяю оба объявления…");
  for (const [label, id] of [["A", itemIdA], ["B", itemIdB]] as const) {
    if (!id) continue;
    try {
      await cancelAd(id);
      console.log(`✅ ${label} (${id}) отменено`);
    } catch (err) {
      console.error(`❌ ${label} cancel упал — сними вручную:`, String(err));
    }
  }

  await closeHttpSession();
  await pool.end();
}

main().catch(async (err) => {
  if (err instanceof BybitApiError) {
    console.error(`\nFATAL Bybit ${err.code}: ${err.message}`);
    console.error(JSON.stringify(err.raw, null, 2));
  } else {
    console.error("\nFATAL:", err);
  }
  await closeHttpSession().catch(() => {});
  await pool.end().catch(() => {});
  process.exit(1);
});
