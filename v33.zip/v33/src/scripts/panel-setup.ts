import "dotenv/config";
import { createInterface } from "node:readline/promises";
import { stdin, stdout } from "node:process";
import { mkdir, writeFile, rename, readFile } from "node:fs/promises";
import { dirname } from "node:path";
import { randomBytes } from "node:crypto";
import { hashPassword, panelConfigPath, validateConfig } from "../web/auth.js";

const rl = createInterface({ input: stdin, output: stdout });
try {
  console.log("RepostG: настройка личной веб-панели. Торговые настройки и .env не меняются.");
  let old: Record<string, unknown> = {};
  try { old = JSON.parse(await readFile(panelConfigPath, "utf8")); } catch (e) { if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e; }
  if (old.version && (await rl.question("Пароль панели будет заменён. Продолжить? Введи YES: ")).trim() !== "YES") process.exit(0);
  const defaultId = String(old.chatId ?? process.env.ALLOWED_TG_USER_IDS?.split(",")[0]?.trim() ?? "");
  const chatId = Number((await rl.question(`Твой Telegram ID [${defaultId}]: `)).trim() || defaultId);
  const port = Number((await rl.question(`Локальный порт [${old.port ?? 8787}]: `)).trim() || old.port || 8787);
  const defaultOrigin = String(old.origin ?? `http://127.0.0.1:${port}`);
  const origin = (await rl.question(`Адрес панели (HTTPS-домен или локальный адрес) [${defaultOrigin}]: `)).trim() || defaultOrigin;
  const password = randomBytes(24).toString("base64url");
  const config = validateConfig({ version: 1, chatId, port, origin, passwordHash: await hashPassword(password) });
  await mkdir(dirname(panelConfigPath), { recursive: true });
  await writeFile(panelConfigPath + ".tmp", JSON.stringify(config, null, 2), { mode: 0o600 });
  await rename(panelConfigPath + ".tmp", panelConfigPath);
  console.log(`\nАдрес: ${origin}\nПароль (сохрани в менеджере паролей): ${password}\n\nЗапусти npm start. Пароль не передавай в переписке. Повторная настройка меняет пароль; затем нужен перезапуск.`);
} finally { rl.close(); }
