import { runMigrations } from "../db/migrate.js";
import { db } from "../db/pool.js";

runMigrations()
  .then(() => {
    console.log("Migrations done");
    db.close();
  })
  .catch((err) => {
    console.error("Migration failed:", err);
    process.exit(1);
  });
