/**
 * Smoke-тест: использует уже сохранённую через `npm run login` сессию.
 * Никаких chromium-окон тут не открывается — всё через axios.
 */
import { config } from "../config.js";
import { runMigrations } from "../db/migrate.js";
import { pool } from "../db/pool.js";
import {
  BybitApiError,
  cancelAd,
  closeHttpSession,
  createAd,
  findOwnAd,
  getOrderBookLevel,
  getTopPrice,
  getWorkConfig,
  listPersonal,
  rankFromOrderBook,
} from "../bybit/index.js";
import { computeTargetPrice } from "../services/price.js";
import { authService, describeSession } from "../auth/authService.js";

function log(stage: string, ...rest: unknown[]) {
  console.log(`\n=== ${stage} ===`);
  for (const r of rest) {
    if (typeof r === "string") console.log(r);
    else console.log(JSON.stringify(r, null, 2).slice(0, 1500));
  }
}

async function main() {
  await runMigrations();

  const session = await authService.getCurrent();
  if (!session) {
    console.error("Нет сессии в БД. Запусти сначала: npx tsx src/scripts/login.ts");
    process.exit(1);
  }
  console.log(`Сессия #${session.id}, ${describeSession(session)}`);

  const { tokenId, currencyId, side } = config.p2p;

  const wc = await getWorkConfig();
  log("workConfig", wc);

  const personal = await listPersonal({ status: "1", page: 1, size: 5 });
  log("1) listPersonal OK", { count: personal.count });

  const top = await getTopPrice({
    tokenId,
    currencyId,
    side,
    userId: session.bybitUid ?? undefined,
  });
  log("2) getTopPrice", { topPrice: top });
  if (!top) throw new Error("Стакан пуст");

  const target = computeTargetPrice({
    topPrice: top,
    side,
    step: config.p2p.priceStep,
    min: config.p2p.priceMin,
    max: config.p2p.priceMax,
  });
  log("3) computeTargetPrice", target);
  if (!target.ok) throw new Error(target.reason);

  let itemId: string | null = null;
  try {
    const created = await createAd({
      tokenId,
      currencyId,
      side,
      price: target.price,
      quantity: config.p2p.quantity,
      minAmount: config.p2p.minAmount,
      maxAmount: config.p2p.maxAmount,
      paymentPeriod: config.p2p.paymentPeriod,
      paymentIds: config.p2p.paymentIds,
      remark: config.p2p.remark,
      paymentPassword: config.bybit.paymentPassword || undefined,
    });
    itemId = (created.itemId ?? created.id ?? null) as string | null;
    log("4) createAd OK", { itemId, raw: created });
  } catch (err) {
    log("4) createAd FAILED", String(err));
    throw err;
  }

  if (itemId) {
    const ad = await findOwnAd(itemId);
    log("4b) findOwnAd", {
      showStatus: ad?.showStatus,
      hiddenReason: ad?.hiddenReason,
      isOnline: ad?.isOnline,
      status: ad?.status,
    });
  }

  try {
    const ob = await getOrderBookLevel({
      tokenId,
      currencyId,
      side,
      price: target.price,
    });
    const info = rankFromOrderBook(ob, config.p2p.pageSize);
    log("5) getOrderBookLevel", info);
  } catch (err) {
    log("5) getOrderBookLevel FAILED (но идём дальше отменять)", String(err));
  }

  if (itemId) {
    try {
      const cancelled = await cancelAd(itemId);
      log("6) cancelAd OK", cancelled);
    } catch (err) {
      log("6) cancelAd FAILED — ВРУЧНУЮ СНЯТЬ В UI!", { itemId, err: String(err) });
      throw err;
    }
  }

  log("DONE", "smoke-цикл прошёл целиком");
  await closeHttpSession();
  await pool.end();
}

main().catch(async (err) => {
  if (err instanceof BybitApiError) {
    console.error(`\nFATAL Bybit ${err.code}: ${err.message}`);
    console.error(JSON.stringify(err.raw, null, 2));
  } else {
    console.error("\nFATAL:", err);
  }
  await closeHttpSession().catch(() => {});
  await pool.end().catch(() => {});
  process.exit(1);
});
