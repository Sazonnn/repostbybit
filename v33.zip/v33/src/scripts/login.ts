/**
 * Открывает chromium через patchright, ждёт пока залогинишься в окне,
 * захватывает cookies + risktoken, сохраняет в Postgres.
 *
 * После этого можно `npm run smoke` или запускать бота — они уже
 * будут ходить axios-ом с этой сессией.
 */
import { runMigrations } from "../db/migrate.js";
import { runLoginFlow } from "../auth/loginFlow.js";
import { describeSession } from "../auth/authService.js";
import { pool } from "../db/pool.js";

async function main() {
  await runMigrations();
  console.log("Открываю chromium. Залогинься в окне на bybit.com.");
  const session = await runLoginFlow();
  console.log(`✅ Сессия #${session.id} сохранена. ${describeSession(session)}.`);
  console.log(`bybitUid=${session.bybitUid ?? "?"}, ua=${session.userAgent}`);
  await pool.end();
}

main().catch((err) => {
  console.error("FAIL:", err);
  process.exit(1);
});
