import "dotenv/config";
import { checkOfficialApi, hasOfficialApiCredentials } from "../bybit/index.js";
import { config } from "../config.js";

async function main(): Promise<void> {
  if (!hasOfficialApiCredentials()) {
    throw new Error(
      "Заполни BYBIT_API_KEY и BYBIT_API_SECRET в .env перед проверкой.",
    );
  }
  const result = await checkOfficialApi({
    tokenId: config.p2p.tokenId,
    currencyId: config.p2p.currencyId,
    side: config.p2p.side,
  });
  console.log("Bybit P2P Open API: OK");
  console.log(`uid: ${String(result.account.userId ?? "?")}`);
  console.log(`nickname: ${String(result.account.nickName ?? "?")}`);
  console.log(`online ads fetched: ${result.onlineAds}`);
  console.log(`own ads fetched: ${result.ownAds}`);
  console.log(`payments fetched: ${result.payments}`);
  console.log("No ad was created or cancelled.");
}

main().catch((err) => {
  console.error(`API check failed: ${(err as Error).message}`);
  process.exit(1);
});
