/**
 * Read-only health check текущей сессии.
 * Делает 2 запроса: getTopPrice (публичный) + listPersonal (требует auth).
 * Если auth-запрос упал на 401/403/code != 0 — куки протухли, нужен /auth_refresh.
 */
import { runMigrations } from "../db/migrate.js";
import { pool } from "../db/pool.js";
import {
  closeHttpSession,
  getTopPrice,
  getWorkConfig,
  listPersonal,
} from "../bybit/index.js";
import { authService, describeSession } from "../auth/authService.js";

async function main() {
  await runMigrations();
  const s = await authService.getCurrent();
  if (!s) {
    console.error("Нет сессии. Запусти: npm run login");
    process.exit(1);
  }
  console.log(`Сессия #${s.id}, ${describeSession(s)}`);

  const t0 = Date.now();
  try {
    const top = await getTopPrice({ tokenId: "USDT", currencyId: "RUB", side: "1" });
    console.log(`✅ public getTopPrice = ${top} (${Date.now() - t0}ms)`);
  } catch (err) {
    console.log(`❌ public getTopPrice FAILED: ${(err as Error).message}`);
  }

  const t1 = Date.now();
  try {
    const wc = await getWorkConfig();
    console.log(`✅ auth getWorkConfig: workStatus=${wc.workStatus} (${Date.now() - t1}ms)`);
  } catch (err) {
    console.log(`❌ auth getWorkConfig FAILED: ${(err as Error).message}`);
  }

  const t2 = Date.now();
  try {
    const r = await listPersonal({ status: "1", page: 1, size: 5 });
    console.log(`✅ auth listPersonal: count=${r.count} (${Date.now() - t2}ms)`);
  } catch (err) {
    console.log(`❌ auth listPersonal FAILED: ${(err as Error).message}`);
  }

  await closeHttpSession();
  await pool.end();
}

main().catch(async (err) => {
  console.error("FATAL:", err);
  await closeHttpSession().catch(() => {});
  await pool.end().catch(() => {});
  process.exit(1);
});
