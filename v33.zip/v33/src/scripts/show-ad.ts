/**
 * 1. Создаёт объявление через node-tls-client (сохранённая сессия).
 * 2. Открывает chromium через patchright на странице "Мои объявления".
 * 3. Ждёт Enter в терминале → отменяет объявление, закрывает окно.
 */
import { mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "patchright";
import { config } from "../config.js";
import {
  cancelAd,
  closeHttpSession,
  createAd,
  getTopPrice,
} from "../bybit/index.js";
import { computeTargetPrice } from "../services/price.js";
import { authService, describeSession } from "../auth/authService.js";
import { runMigrations } from "../db/migrate.js";
import { pool } from "../db/pool.js";

const here = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(here, "..", "..");
const USER_DATA_DIR =
  config.playwright.userDataDir || resolve(ROOT, "data", "chromium-profile");

const MY_ADS_URL = "https://www.bybit.com/en/p2p/myads";

const HOLD_SEC = Number(process.env.SHOW_AD_HOLD_SEC ?? "180");

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  await runMigrations();

  const session = await authService.getCurrent();
  if (!session) {
    console.error("Нет сессии. Сначала: npm run login");
    process.exit(1);
  }
  console.log(`Сессия #${session.id}, ${describeSession(session)}`);

  const { tokenId, currencyId, side } = config.p2p;

  const top = await getTopPrice({
    tokenId,
    currencyId,
    side,
    userId: session.bybitUid ?? undefined,
  });
  if (!top) throw new Error("Стакан пуст");
  console.log(`Топ стакана ${tokenId}/${currencyId}: ${top}`);

  const target = computeTargetPrice({
    topPrice: top,
    side,
    step: config.p2p.priceStep,
    min: config.p2p.priceMin,
    max: config.p2p.priceMax,
  });
  if (!target.ok) throw new Error(target.reason);
  console.log(`Создаю объявление по цене ${target.price}…`);

  const created = await createAd({
    tokenId,
    currencyId,
    side,
    price: target.price,
    quantity: config.p2p.quantity,
    minAmount: config.p2p.minAmount,
    maxAmount: config.p2p.maxAmount,
    paymentPeriod: config.p2p.paymentPeriod,
    paymentIds: config.p2p.paymentIds,
    remark: config.p2p.remark,
    paymentPassword: config.bybit.paymentPassword || undefined,
  });
  const itemId = String(created.itemId ?? created.id ?? "");
  if (!itemId || itemId === "0") {
    throw new Error("createAd вернул пустой itemId");
  }
  console.log(`✅ Создано: itemId=${itemId}, price=${target.price}`);

  console.log("Открываю окно chromium на 'My Ads'…");
  mkdirSync(USER_DATA_DIR, { recursive: true });
  const ctx = await chromium.launchPersistentContext(USER_DATA_DIR, {
    channel: config.playwright.channel,
    headless: false,
    viewport: null,
  });
  const page = ctx.pages()[0] ?? (await ctx.newPage());
  await page.goto(MY_ADS_URL, { waitUntil: "domcontentloaded" }).catch(() => {});

  console.log(
    `\nОбъявление создано (itemId=${itemId}, цена ${target.price}). Окно chromium открыто на 'My Ads'.`,
  );
  console.log(`Жду ${HOLD_SEC} сек, потом сам отменю.`);
  for (let s = HOLD_SEC; s > 0; s -= 30) {
    console.log(`  осталось ${s}s…`);
    await sleep(Math.min(30, s) * 1000);
  }

  console.log(`Отменяю ${itemId}…`);
  try {
    await cancelAd(itemId);
    console.log("✅ Отменено");
  } catch (err) {
    console.error("❌ cancel упал — отмени вручную в UI:", String(err));
  }

  await ctx.close().catch(() => {});
  await closeHttpSession();
  await pool.end();
}

main().catch(async (err) => {
  console.error("FATAL:", err);
  await closeHttpSession().catch(() => {});
  await pool.end().catch(() => {});
  process.exit(1);
});
