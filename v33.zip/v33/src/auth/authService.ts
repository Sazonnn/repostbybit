import { EventEmitter } from "node:events";
import {
  SaveSessionInput,
  SessionRow,
  getActiveSession,
  markStale,
  saveSession,
  setSessionNickname,
} from "../db/repositories/sessions.js";
import { extractSecureToken } from "./jwt.js";

export interface ActiveSession {
  id: number;
  cookie: string;
  riskToken: string;
  guid: string;
  userAgent: string;
  bybitUid: string | null;
  nickname: string | null;
  expiresAt: Date | null;
}

const CACHE_TTL_MS = 60_000;

class AuthService extends EventEmitter {
  private cache: { session: ActiveSession | null; at: number } | null = null;
  private refreshInProgress: Promise<ActiveSession> | null = null;

  async getCurrent(): Promise<ActiveSession | null> {
    const now = Date.now();
    if (this.cache && now - this.cache.at < CACHE_TTL_MS) {
      return this.cache.session;
    }
    const row = await getActiveSession();
    const session = row ? this.toSession(row) : null;
    this.cache = { session, at: now };
    return session;
  }

  async require(): Promise<ActiveSession> {
    const s = await this.getCurrent();
    if (!s) throw new Error("Нет активной Bybit-сессии. Запусти /auth refresh.");
    return s;
  }

  invalidateCache(): void {
    this.cache = null;
  }

  async save(input: SaveSessionInput): Promise<ActiveSession> {
    const row = await saveSession(input);
    const session = this.toSession(row);
    this.cache = { session, at: Date.now() };
    this.emit("refreshed", session);
    return session;
  }

  async markStale(): Promise<void> {
    const s = await this.getCurrent();
    if (!s) return;
    await markStale(s.id);
    this.cache = { session: null, at: Date.now() };
    this.emit("stale", s);
  }

  /**
   * Запускает refresh ровно один раз при параллельных вызовах.
   * Тело должно вернуть свежую сессию (через .save()).
   */
  refreshOnce(impl: () => Promise<ActiveSession>): Promise<ActiveSession> {
    if (this.refreshInProgress) return this.refreshInProgress;
    this.refreshInProgress = impl().finally(() => {
      this.refreshInProgress = null;
    });
    return this.refreshInProgress;
  }

  async setNickname(sessionId: number, nickname: string): Promise<void> {
    await setSessionNickname(sessionId, nickname);
    if (this.cache?.session && this.cache.session.id === sessionId) {
      this.cache.session.nickname = nickname;
    }
  }

  private toSession(row: SessionRow): ActiveSession {
    return {
      id: row.id,
      cookie: row.cookie,
      riskToken: row.risk_token,
      guid: row.guid,
      userAgent: row.user_agent,
      bybitUid: row.bybit_uid,
      nickname: row.nickname,
      expiresAt: row.expires_at,
    };
  }
}

export const authService = new AuthService();

/** Утилита: оценка сколько живёт secure-token JWT. */
export function describeSession(s: ActiveSession): string {
  const payload = extractSecureToken(s.cookie);
  if (!payload?.exp) return "exp неизвестен";
  const ms = payload.exp * 1000 - Date.now();
  if (ms < 0) return "❌ просрочен";
  const h = Math.floor(ms / 3_600_000);
  const m = Math.floor((ms % 3_600_000) / 60_000);
  return `живёт ещё ${h}ч ${m}м`;
}
