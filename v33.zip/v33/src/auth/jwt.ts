interface SecureTokenPayload {
  user_id?: number;
  exp?: number; // unix seconds
  [k: string]: unknown;
}

function base64urlToBuffer(s: string): Buffer {
  const pad = s.length % 4 === 0 ? "" : "=".repeat(4 - (s.length % 4));
  return Buffer.from(s.replace(/-/g, "+").replace(/_/g, "/") + pad, "base64");
}

export function decodeSecureToken(jwt: string): SecureTokenPayload | null {
  const parts = jwt.split(".");
  if (parts.length !== 3) return null;
  try {
    return JSON.parse(base64urlToBuffer(parts[1]!).toString("utf8")) as SecureTokenPayload;
  } catch {
    return null;
  }
}

/** Достаёт secure-token из cookie-строки и декодит. */
export function extractSecureToken(cookieHeader: string): SecureTokenPayload | null {
  const m = cookieHeader.match(/(?:^|;\s*)secure-token=([^;]+)/);
  if (!m || !m[1]) return null;
  return decodeSecureToken(m[1]);
}
