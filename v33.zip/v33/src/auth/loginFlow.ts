import { mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { chromium, BrowserContext, Page } from "patchright";
import { config } from "../config.js";
import { authService, ActiveSession } from "./authService.js";
import { extractSecureToken } from "./jwt.js";

const here = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(here, "..", "..");
const DEFAULT_USER_DATA_DIR = resolve(ROOT, "data", "chromium-profile");

const HOME_URL = "https://www.bybit.com/en/p2p";
/**
 * Страница которая 100% делает sensitive XHR на /x-api/fiat/otc/* — фронт
 * на ней сразу шлёт user/risk, item/last_price, item/fee-rate, work-config/get
 * и т.д. Все эти запросы JS-интерсептор обогащает risktoken'ом.
 */
const RISKTOKEN_PAGE = "https://www.bybit.com/en/p2p/advertiser/create";
const LOGIN_TIMEOUT_MS = 5 * 60 * 1000;

export interface LoginFlowOptions {
  /** Сколько ждать логина после открытия окна. */
  timeoutMs?: number;
  /** Открыть окно даже если cookies уже валидны (для ручного refresh). */
  forceOpen?: boolean;
  /** Колбэк когда окно открыто — для уведомления юзера в TG. */
  onWindowOpen?: () => void | Promise<void>;
  /**
   * Тихий режим: если cookies в profile живые и Bybit пустит без интерактива,
   * окно мелькнёт на 3-5 сек и сразу закроется. Если требуется интерактив —
   * RuntimeError, юзер должен запустить /auth_refresh руками.
   */
  silent?: boolean;
}

interface CapturedSession {
  cookieHeader: string;
  riskToken: string;
  guid: string;
  userAgent: string;
  bybitUid: string | null;
  expiresAt: Date | null;
}

/**
 * Запускает chromium через patchright, ждёт пока юзер залогинится в окне.
 * Захватывает cookies + risktoken, сохраняет в БД через AuthService, закрывает.
 */
export async function runLoginFlow(opts: LoginFlowOptions = {}): Promise<ActiveSession> {
  return authService.refreshOnce(async () => {
    const userDataDir = config.playwright.userDataDir || DEFAULT_USER_DATA_DIR;
    mkdirSync(userDataDir, { recursive: true });

    const context = await chromium.launchPersistentContext(userDataDir, {
      channel: config.playwright.channel,
      headless: false,
      viewport: null,
    });

    let page: Page | undefined;
    try {
      page = context.pages()[0] ?? (await context.newPage());
      const captured = await captureSession(page, context, opts);
      const session = await authService.save({
        bybitUid: captured.bybitUid,
        cookie: captured.cookieHeader,
        riskToken: captured.riskToken,
        guid: captured.guid,
        userAgent: captured.userAgent,
        expiresAt: captured.expiresAt,
      });
      // После сохранения сессии — подтянем ник профиля, чтобы он был доступен везде.
      try {
        const { getMyMerchantInfo } = await import("../bybit/profile.js");
        const info = await getMyMerchantInfo();
        if (info.nickName) {
          await authService.setNickname(session.id, info.nickName);
          session.nickname = info.nickName;
        }
      } catch (err) {
        console.warn("Не удалось подтянуть ник:", err);
      }
      return session;
    } finally {
      await context.close().catch(() => {});
    }
  });
}

async function captureSession(
  page: Page,
  context: BrowserContext,
  opts: LoginFlowOptions,
): Promise<CapturedSession> {
  let capturedRisktoken: string | null = null;
  let capturedUA: string | null = null;

  page.on("request", (req) => {
    const headers = req.headers();
    const rt = headers["risktoken"] ?? headers["riskToken"];
    if (rt) capturedRisktoken = rt;
    const ua = headers["user-agent"];
    if (ua) capturedUA = ua;
  });

  await page.goto(HOME_URL, { waitUntil: "domcontentloaded", timeout: 60_000 });
  if (opts.onWindowOpen) await opts.onWindowOpen();

  const timeoutMs =
    opts.timeoutMs ?? (opts.silent ? 30_000 : LOGIN_TIMEOUT_MS);
  const deadline = Date.now() + timeoutMs;
  console.log(
    `[loginFlow${opts.silent ? " silent" : ""}] жду логина и risktoken до ${new Date(deadline).toLocaleTimeString()}…`,
  );

  let pushedAt = 0;
  let triggeredFetch = false;
  while (Date.now() < deadline) {
    if (capturedRisktoken && (await isLoggedIn(context))) break;

    // Как только видим логин — насильно ведём на /p2p/advertiser/create.
    if (!pushedAt && (await isLoggedIn(context))) {
      pushedAt = Date.now();
      console.log(
        "[loginFlow] логин ОК, гоню на /p2p/advertiser/create чтобы поймать risktoken",
      );
      page
        .goto(RISKTOKEN_PAGE, { waitUntil: "domcontentloaded", timeout: 30_000 })
        .catch(() => {});
    }

    // Если через 6 сек после goto risktoken ещё не пойман — тригерим явный fetch
    // на sensitive endpoint, JS-интерсептор Bybit обогатит запрос risktoken'ом.
    if (
      pushedAt > 0 &&
      !triggeredFetch &&
      !capturedRisktoken &&
      Date.now() - pushedAt > 6_000
    ) {
      triggeredFetch = true;
      console.log("[loginFlow] триггерю явный fetch на /user/risk");
      await page
        .evaluate(() =>
          fetch("/x-api/fiat/otc/user/risk", {
            method: "POST",
            headers: { "content-type": "application/json;charset=UTF-8" },
            body: JSON.stringify({ scene: "P2PADAccessSellTab" }),
            credentials: "include",
          }).catch(() => null),
        )
        .catch(() => {});
    }

    await sleep(2000);
  }

  if (!capturedRisktoken) {
    throw new Error(
      opts.silent
        ? "Silent refresh не удался — risktoken не перехвачен за 30с. Нужен ручной /auth_refresh."
        : "Не удалось перехватить risktoken за 5 минут.",
    );
  }
  if (!(await isLoggedIn(context))) {
    throw new Error(
      opts.silent
        ? "Silent refresh не удался — Bybit не пустил по сохранённому профилю. Нужен ручной /auth_refresh."
        : "Не дождался логина (нет secure-token cookie).",
    );
  }

  const cookies = await context.cookies("https://www.bybit.com");
  const cookieHeader = cookies.map((c) => `${c.name}=${c.value}`).join("; ");
  const guid =
    cookies.find((c) => c.name === "_by_l_g_d")?.value ??
    cookies.find((c) => c.name === "deviceId")?.value ??
    "";
  const userAgent =
    capturedUA ?? (await page.evaluate(() => navigator.userAgent));

  const tokenPayload = extractSecureToken(cookieHeader);
  const bybitUid = tokenPayload?.user_id ? String(tokenPayload.user_id) : null;
  const expiresAt = tokenPayload?.exp ? new Date(tokenPayload.exp * 1000) : null;

  return {
    cookieHeader,
    riskToken: capturedRisktoken,
    guid,
    userAgent,
    bybitUid,
    expiresAt,
  };
}

async function isLoggedIn(context: BrowserContext): Promise<boolean> {
  const cookies = await context.cookies("https://www.bybit.com");
  const secure = cookies.find((c) => c.name === "secure-token");
  if (!secure?.value) return false;
  const payload = extractSecureToken(`secure-token=${secure.value}`);
  if (!payload?.exp) return false;
  return payload.exp * 1000 > Date.now();
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}
