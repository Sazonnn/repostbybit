import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, it } from "node:test";
import {
  credentialsKeyLocation,
  decryptCredential,
  encryptCredential,
} from "./credentialCrypto.js";

describe("API credential encryption", () => {
  it("шифрует и расшифровывает secret, не сохраняя его открытым", () => {
    const dir = mkdtempSync(join(tmpdir(), "bybit-credentials-"));
    process.env.API_CREDENTIALS_KEY_PATH = join(dir, "master.key");
    try {
      const secret = "super-secret-api-value";
      const encrypted = encryptCredential(secret);
      assert.notEqual(encrypted, secret);
      assert.equal(encrypted.includes(secret), false);
      assert.equal(decryptCredential(encrypted), secret);
      assert.equal(credentialsKeyLocation(), join(dir, "master.key"));
    } finally {
      delete process.env.API_CREDENTIALS_KEY_PATH;
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("отвергает повреждённый ciphertext", () => {
    const dir = mkdtempSync(join(tmpdir(), "bybit-credentials-"));
    process.env.API_CREDENTIALS_KEY_PATH = join(dir, "master.key");
    try {
      const encrypted = encryptCredential("secret");
      assert.throws(() => decryptCredential(`${encrypted}broken`));
    } finally {
      delete process.env.API_CREDENTIALS_KEY_PATH;
      rmSync(dir, { recursive: true, force: true });
    }
  });
});
