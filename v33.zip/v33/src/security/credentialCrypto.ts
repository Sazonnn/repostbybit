import {
  createCipheriv,
  createDecipheriv,
  randomBytes,
} from "node:crypto";
import {
  chmodSync,
  existsSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
} from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(here, "..", "..");
const DEFAULT_KEY_PATH = resolve(ROOT, "data", "api-master.key");
const KEY_BYTES = 32;
const IV_BYTES = 12;

function keyPath(): string {
  return process.env.API_CREDENTIALS_KEY_PATH
    ? resolve(process.env.API_CREDENTIALS_KEY_PATH)
    : DEFAULT_KEY_PATH;
}

// Мастер-ключ читаем с диска один раз и держим в памяти: раньше файл читался
// дважды при КАЖДОМ запросе к API (расшифровка ключа и секрета).
let cachedKey: { path: string; key: Buffer } | null = null;

function loadOrCreateKey(): Buffer {
  const path = keyPath();
  if (cachedKey && cachedKey.path === path) return cachedKey.key;
  const key = loadOrCreateKeyFromDisk(path);
  cachedKey = { path, key };
  return key;
}

function loadOrCreateKeyFromDisk(path: string): Buffer {
  if (!existsSync(path)) {
    mkdirSync(dirname(path), { recursive: true });
    const key = randomBytes(KEY_BYTES);
    writeFileSync(path, key.toString("base64"), {
      encoding: "utf8",
      mode: 0o600,
      flag: "wx",
    });
    try {
      chmodSync(path, 0o600);
    } catch {
      // Windows не поддерживает POSIX permissions так же строго.
    }
    return key;
  }
  const key = Buffer.from(readFileSync(path, "utf8").trim(), "base64");
  if (key.length !== KEY_BYTES) {
    throw new Error(
      `Неверный мастер-ключ API credentials: ${path}. Ожидалось ${KEY_BYTES} байт.`,
    );
  }
  return key;
}

export function encryptCredential(value: string): string {
  const key = loadOrCreateKey();
  const iv = randomBytes(IV_BYTES);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const ciphertext = Buffer.concat([
    cipher.update(value, "utf8"),
    cipher.final(),
  ]);
  const tag = cipher.getAuthTag();
  return [
    "v1",
    iv.toString("base64"),
    tag.toString("base64"),
    ciphertext.toString("base64"),
  ].join(".");
}

export function decryptCredential(payload: string): string {
  const [version, ivText, tagText, ciphertextText] = payload.split(".");
  if (
    version !== "v1" ||
    !ivText ||
    !tagText ||
    ciphertextText === undefined
  ) {
    throw new Error("Неверный формат зашифрованных API credentials");
  }
  const decipher = createDecipheriv(
    "aes-256-gcm",
    loadOrCreateKey(),
    Buffer.from(ivText, "base64"),
  );
  decipher.setAuthTag(Buffer.from(tagText, "base64"));
  return Buffer.concat([
    decipher.update(Buffer.from(ciphertextText, "base64")),
    decipher.final(),
  ]).toString("utf8");
}

export function credentialsKeyLocation(): string {
  return keyPath();
}
